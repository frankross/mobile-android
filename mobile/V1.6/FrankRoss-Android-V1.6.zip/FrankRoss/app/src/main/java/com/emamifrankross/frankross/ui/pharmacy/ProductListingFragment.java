/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.pharmacy;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.aloglia.AlgoliaManager;
import com.emamifrankross.frankross.core.aloglia.datamodel.AlgoliaProductsFilterInfo;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FacebookManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.HomeRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.ProductSortAdapter;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.SortType;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.products.AddToCartDialogFragment;
import com.emamifrankross.frankross.ui.products.ProductDetailActivity;
import com.emamifrankross.frankross.ui.products.filter.ProductFilterFragment;
import com.emamifrankross.frankross.ui.products.sort.ProductSortFragment;
import com.emamifrankross.frankross.ui.search.SearchActivity;
import com.emamifrankross.frankross.ui.viewmodels.ProductDataModel;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Utils;
import com.facebook.FacebookSdk;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by gauthami on 13/7/15.
 */

/**
 * This class represents the UI for Products listing screen
 */
public class ProductListingFragment extends ApiRequestBaseFragment implements IToolbar,
        BaseRecyclerAdapter.RecyclerItemClickListener, View.OnClickListener, BaseRecyclerAdapter.OnPageEndListener {

    private static final String TAG = ProductListingFragment.class.getSimpleName();
    private static final String EXTRA_CATEGORY_NAME = "category_name";
    protected static final String EXTRA_CATEGORY_ID = "category_id";
    protected static final int ALGOLIA_PRODUCTS_COUNT = 10;
    private static final int PRODUCTS_COUNT_PAGINATION = 10;

    protected RobotoTextView mSearchTerm;
    protected RobotoTextView mSearchCountText;
    protected LinearLayout mSearchCountLinLyt;
    protected LinearLayout mSearchProductsLinLyt;
    protected ListingFlow mListingFlow = ListingFlow.CATEGORY_LISTING;
    protected SortType mCurrentSortType = SortType.NONE;
    protected AlgoliaProductsFilterInfo mAppliedFilterInfo;
    private LinearLayout mSortProducts;
    private LinearLayout mFilterProducts;
    private RobotoTextView mSortBy;
    private RobotoTextView mFilterBy;
    private RobotoTextView mEmptyView;
    private RobotoTextView mSortTitle;
    private RobotoTextView mFilterTitle;

    private List<BaseRecyclerAdapter.IViewType> mProductListingScreenData = new ArrayList<>();
    private List<BaseRecyclerAdapter.IViewType> mAlgoliaProductSortInfoList = new ArrayList<>();
    private HomeRecyclerAdapter mProductListingAdapter;
    private AlgoliaProductsFilterInfo mAlgoliaProductFilterInfo;

    protected int mProductsCount = 0;
    protected int mCurrentPageNumber = 0;

    private long mVariantId = 0;
    protected long mCategoryId = -1;

    private String mSortByTxt = "";
    private String mFilterByTxt = "";
    private String mCategoryName = "";
    private String mProductName = "";

    private boolean mIsAllProductsFetched = false;
    private boolean mIsSingleProduct = false;

    public static ProductListingFragment create(long categoryId, String categoryName) {
        ProductListingFragment fragment = new ProductListingFragment();
        Bundle bundle = new Bundle();
        bundle.putLong(EXTRA_CATEGORY_ID, categoryId);
        bundle.putString(EXTRA_CATEGORY_NAME, categoryName);
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle bundle = getArguments();
        if (bundle != null && bundle.getLong(EXTRA_CATEGORY_ID) != -1) {
            mCategoryId = bundle.getLong(EXTRA_CATEGORY_ID);
            mCategoryName = bundle.getString(EXTRA_CATEGORY_NAME);
        }

        mProductListingAdapter = new HomeRecyclerAdapter(mProductListingScreenData);
        mFragmentInteractionListener.showBlockingProgressBar();
        getAlogliaProduct();
        getSortInfo();
    }

    protected void logVisitEvent() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PRODUCT_LISTING_VISIT_EVENT);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        FacebookSdk.sdkInitialize(getActivity().getApplicationContext());
        return inflater.inflate(R.layout.fragment_product_listing, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the views
     *
     * @param view the root view
     */
    private void initViews(View view) {
        mSortProducts = (LinearLayout) view.findViewById(R.id.product_sort_linLayout);
        mFilterProducts = (LinearLayout) view.findViewById(R.id.product_filter_linLayout);
        mSortBy = (RobotoTextView) view.findViewById(R.id.sort_by_txt_tv);
        mFilterBy = (RobotoTextView) view.findViewById(R.id.filter_by_txt_tv);
        mEmptyView = (RobotoTextView) view.findViewById(R.id.product_listing_empty_view_tv);
        mSearchTerm = (RobotoTextView) view.findViewById(R.id.search_result_search_term_tv);
        mSearchCountLinLyt = (LinearLayout) view.findViewById(R.id.product_listing_search_count_header_linLyt);
        mSearchCountText = (RobotoTextView) view.findViewById(R.id.product_listing_search_count_header_tv);
        mSortTitle = (RobotoTextView) view.findViewById(R.id.sort_title_tv);
        mFilterTitle = (RobotoTextView) view.findViewById(R.id.filter_title_tv);
        mSearchProductsLinLyt = (LinearLayout) view.findViewById(R.id.search_result_search_linLay);

        mFilterBy.setText(TextUtils.isEmpty(mFilterByTxt) && isAdded() ? getString(R.string.products_filter_header_none) : mFilterByTxt);
        mSortBy.setText(TextUtils.isEmpty(mSortByTxt) && isAdded() ? getString(R.string.products_filter_header_none) : "(" + mSortByTxt + ")");
        setClickListeners();

        mSearchProductsLinLyt.setOnClickListener(this);
        RecyclerView productListingRecyclerView = (RecyclerView) view.findViewById(R.id.product_listing_container);
        productListingRecyclerView.setHasFixedSize(false);
        productListingRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mProductListingAdapter.setRecyclerItemClickListener(this);
        mProductListingAdapter.setRecyclerOnPageEndListener(this);
        productListingRecyclerView.setAdapter(mProductListingAdapter);
        productListingRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {

            boolean isScrolledUp = false;

            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                isScrolledUp = dy > 0;
            }

            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                if (newState == AbsListView.OnScrollListener.SCROLL_STATE_FLING) {
                    onRecyclerViewFling(isScrolledUp);
                }
            }
        });

        logVisitEvent();
    }

    /**
     * Method that handles the Filter/Sort Linear layout visibility
     *
     * @param isScrolledUp based on the scroll up/bottom the Layout has to be made visible/invisible
     */
    protected void onRecyclerViewFling(boolean isScrolledUp) {
    }

    /**
     * Method that sets the Products count
     */
    protected void setProductsCount() {
        mSearchCountText.setText(mProductsCount == 1 ? mProductsCount + " product found"
                : mProductsCount + " products found");
    }

    /**
     * Method that registers for Filter/Sort click listeners
     */
    private void setClickListeners() {
        mFilterProducts.setOnClickListener(this);
        mSortProducts.setOnClickListener(this);
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {
            case ViewTypes.CommonViewType.PRODUCT_ITEM:
                switch (view.getId()) {
                    case R.id.top_selling_product_add_to_cart_tv:
                        mProductName = ((ProductDataModel) object).productName;
                        handleAddToCartClick((ProductDataModel) object);
                        break;
                    default:
                        handleProductItemClick((ProductDataModel) object);
                        break;
                }
                break;
            case ViewTypes.HomeViewType.VIEW_MORE_PRODUCTS:
                handleLoadMoreClick();
                break;
        }
    }

    /**
     * Method that handles the Add to cart button tap behaviour
     *
     * @param productDataModel the product information that helps to add the product into the cart using Quantity picker
     */
    private void handleAddToCartClick(final ProductDataModel productDataModel) {
        mVariantId = productDataModel.productId;
        mApiRequestManager.getCartItemQuantity(productDataModel.productId,
                new ApiRequestManager.IGetCartItemQuantityListener() {
                    @Override
                    public void cartItemQuantity(int quantity) {
                        if (quantity == 0) {
                            quantity = 1;
                        }
                        try {
                            AddToCartDialogFragment addToCartDialogFragment = new AddToCartDialogFragment();
                            addToCartDialogFragment.create(Utils.getStripInfo(productDataModel.innerPackagingQty,
                                    productDataModel.outerPackagingQty, ""),
                                    productDataModel.maxOrderQuantity, quantity);
                            addToCartDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
                        } catch (IllegalStateException illegalStateException) {
                            //Not to instantiate a fragment onSavedInstance
                        }
                    }
                });
    }

    /**
     * Method that requests for adding a product to the cart;If success, displays the success msg
     */
    public void performAddToCartRequest(int cartQuantity) {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performAddCartRequest(mVariantId, cartQuantity, new ApiRequestManager.IAddCartResultNotifier() {
            @Override
            public void onProductAdded() {
                FacebookManager.logFacebookAddToCartEvent(getActivity(), mProductName, mVariantId + "",
                        getString(R.string.facebook_events_parameter_currency));
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ADD_TO_CART_FROM_LISTING);
                mFragmentInteractionListener.hideBlockingProgressBar();
                Toast.makeText(getActivity().getApplicationContext(), getString(R.string.add_to_cart_success_msg),
                        Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onProductAddFailed() {
                mFragmentInteractionListener.hideBlockingProgressBar();
                Toast.makeText(getActivity().getApplicationContext(), getString(R.string.add_to_cart_failure_msg),
                        Toast.LENGTH_SHORT).show();
            }
        }, this, this);
    }

    /**
     * Method that loads the more products helps for pagination
     */
    private void handleLoadMoreClick() {
        mProductListingAdapter.notifyDataSetChanged();

        getAlogliaProduct();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.product_sort_linLayout:
                handleSortProducts();
                break;
            case R.id.product_filter_linLayout:
                handleFilterProducts();
                break;
            case R.id.search_result_search_linLay:
                Map<String, String> searchBarClickData = Utils.categoriesClickDataForAnalytics(Constants.SEARCH_RESULT_SCREEN_NAME,
                        FrankRossEvents.SEARCH_BAR_SCREEN_NAME_EVENT);
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_BAR_TAP_EVENT, searchBarClickData);
                closeFragment();
                break;
            default:
                break;
        }
    }

    /**
     * Method loads the PDP based on the flag isPharma
     */
    private void handleProductItemClick(ProductDataModel object) {
        startActivity(ProductDetailActivity.getActivityIntent(getActivity().getApplicationContext(),
                (object.isPharma) ? ProductDetailActivity.PHARMA_PRODUCT_DETAIL_FRAGMENT_ID
                        : ProductDetailActivity.NON_PHARMA_PRODUCT_DETAIL_FRAGMENT_ID,
                object.productId));
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);

    }

    /**
     * Method that launches the filter products screen
     */
    private void handleFilterProducts() {
        AlgoliaProductsFilterInfo algoliaProductsFilterInfo = (mAppliedFilterInfo != null) ? mAppliedFilterInfo : mAlgoliaProductFilterInfo;
        mFragmentInteractionListener.loadFragment(getId(), ProductFilterFragment.create(algoliaProductsFilterInfo,
                mIsSingleProduct, mListingFlow), ProductFilterFragment.class.getName(), R.anim.push_left_in, R.anim.push_left_out,
                BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    /**
     * Method that launches the sort products screen
     */
    private void handleSortProducts() {
        mFragmentInteractionListener.loadFragment(getId(), ProductSortFragment.create(mAlgoliaProductSortInfoList),
                null, R.anim.push_left_in, R.anim.push_left_out,
                FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    /**
     * Method to populate the Sort products screen data
     */
    private void getSortInfo() {
        new AsyncTask<Void, Void, List<ProductSortAdapter.SortDataItem>>() {
            @Override
            protected List<ProductSortAdapter.SortDataItem> doInBackground(Void... params) {
                ArrayList<ProductSortAdapter.SortDataItem> sortData = new ArrayList<>();
                if (getActivity() != null && getView() != null && isAdded()) {
                    ProductSortAdapter.SortDataItem dataItem = new ProductSortAdapter.SortDataItem();
                    dataItem.sortHeader = getString(R.string.products_sort_low_to_high);
                    sortData.add(dataItem);

                    dataItem = new ProductSortAdapter.SortDataItem();
                    dataItem.sortHeader = getString(R.string.products_sort_high_to_low);

                    sortData.add(dataItem);
                }
                return sortData;
            }

            @Override
            protected void onPostExecute(List<ProductSortAdapter.SortDataItem> sortData) {
                super.onPostExecute(sortData);
                mAlgoliaProductSortInfoList.addAll(sortData);
            }
        }.execute();
    }

    /**
     * Method that receives the callback from parent activity on Sort applied
     *
     * @param sortType the type of sort that was applied
     * @param header   the header text
     */
    public void onSortClick(SortType sortType, String header) {
        switch (sortType) {
            case LOW_TO_HIGH:
                getAscendingOrderedAlgoliaProduct();
                break;

            case HIGH_TO_LOW:
                getDescendingOrderedAlgoliaProduct();
                break;
        }
        mSortByTxt = header;
        if (mSortBy != null && isAdded())
            mSortBy.setText(TextUtils.isEmpty(mSortByTxt) ? getString(R.string.products_filter_header_none) :
                    "(" + mSortByTxt + ")");
    }

    /**
     * Method resets the filter and sort that are applied
     */
    private void resetAdapterData() {
        mProductListingScreenData.clear();
        mCurrentPageNumber = 0;
        mProductsCount = 0;
        mIsAllProductsFetched = false;
    }

    /**
     * Method to be invoked for applying the filter
     *
     * @param appliedFilterInfo the filter criteria to be applied on the algolia products
     */
    public void setAppliedFilter(AlgoliaProductsFilterInfo appliedFilterInfo) {
        mAppliedFilterInfo = appliedFilterInfo;
        mFilterByTxt = (appliedFilterInfo == null && isAdded()) ? getString(R.string.products_filter_header_none) :
                getString(R.string.products_filter_header_applied);

        if (mFilterBy != null)
            mFilterBy.setText(mFilterByTxt);
        resetAdapterData();
        mFragmentInteractionListener.showBlockingProgressBar();
        getAlogliaProduct();
    }

    /**
     * Method to sort the algolia products base on Price: High to Low
     */
    public void getDescendingOrderedAlgoliaProduct() {
        mCurrentSortType = SortType.HIGH_TO_LOW;
        resetAdapterData();
        mFragmentInteractionListener.showBlockingProgressBar();
        getAlogliaProduct();
    }

    /**
     * Method to sort the algolia products base on Price: Low to High
     */
    public void getAscendingOrderedAlgoliaProduct() {
        mCurrentSortType = SortType.LOW_TO_HIGH;
        resetAdapterData();
        mFragmentInteractionListener.showBlockingProgressBar();
        getAlogliaProduct();
    }

    /**
     * Method that requests for algolia products
     */
    private void getAlogliaProduct() {
        if (mAppliedFilterInfo == null && mCurrentSortType == SortType.NONE) {
            AlgoliaManager.IProductInfoWithFilterResultNotifier
                    productInfoWithFilterResultNotifier = new AlgoliaManager.IProductInfoWithFilterResultNotifier() {
                @Override
                public void onProductInfoFetched(final List<ProductDataModel> productList,
                                                 final AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                    if (getActivity() != null && getView() != null && isAdded()) {
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                mProductsCount = productList.size() > 0 ? productList.get(0).totalProducts : 0;
                                mSearchCountText.setText(productList.size() == 1 ? productList.size() + " product found"
                                        : productList.size() + " products found");
                                setProductsCount();

                                if (productList.size() > 0) {

                                    mIsSingleProduct = (mProductsCount == 1);
                                    mAlgoliaProductFilterInfo = algoliaProductsFilterInfo;
                                    disableFilterSort();

                                    mProductListingScreenData.addAll(productList);
                                    mProductListingAdapter.notifyDataSetChanged();

                                    if (productList.size() < ALGOLIA_PRODUCTS_COUNT)
                                        mIsAllProductsFetched = true;
                                } else if (mCurrentPageNumber == 0) {
                                    getView().findViewById(R.id.product_sort_filter_linLyt).setVisibility(View.GONE);
                                    mEmptyView.setVisibility(View.VISIBLE);
                                } else {
                                    mIsAllProductsFetched = true;
                                }

                                mFragmentInteractionListener.hideBlockingProgressBar();
                                mCurrentPageNumber++;
                            }
                        });
                    }
                }

                @Override
                public void onSearchError() {
                    if (getActivity() != null && getView() != null && isAdded()) {
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (getActivity() != null && getView() != null) {
                                    mFragmentInteractionListener.hideBlockingProgressBar();
                                    getView().findViewById(R.id.product_sort_filter_linLyt).setVisibility(View.GONE);
                                    showAlert(getString(R.string.no_connection_error));
                                }
                            }
                        });
                    }
                }
            };

            getAlgoliaProductsWithFilterInfo(productInfoWithFilterResultNotifier);

        } else {
            AlgoliaManager.IProductInfoResultNotifier productInfoResultNotifier = new AlgoliaManager.IProductInfoResultNotifier() {
                @Override
                public void onProductInfoFetched(final List<ProductDataModel> productList) {
                    if (getActivity() != null && getView() != null && isAdded()) {
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                mProductsCount = productList.size() > 0 ? productList.get(0).totalProducts : 0;
                                mSearchCountText.setText(mProductsCount == 1 ? mProductsCount + " product found"
                                        : mProductsCount + " products found");
                                setProductsCount();

                                if (productList.size() > 0) {

                                    mProductListingScreenData.addAll(productList);
                                    mProductListingAdapter.notifyDataSetChanged();
                                    mFragmentInteractionListener.hideBlockingProgressBar();

                                    if (productList.size() < ALGOLIA_PRODUCTS_COUNT)
                                        mIsAllProductsFetched = true;
                                } else if (mCurrentPageNumber == 0) {
                                    mEmptyView.setVisibility(View.VISIBLE);
                                    mEmptyView.setText(getString(R.string.product_listing_filter_empty_txt));
                                } else {
                                    mIsAllProductsFetched = true;
                                }

                                mFragmentInteractionListener.hideBlockingProgressBar();
                                mCurrentPageNumber++;
                            }
                        });
                    }
                }

                @Override
                public void onSearchError() {

                    if (getActivity() != null && getView() != null) {
                        getActivity().runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                mFragmentInteractionListener.hideBlockingProgressBar();
                                if (getView() != null && isAdded())
                                    getView().findViewById(R.id.product_sort_filter_linLyt).setVisibility(View.GONE);
                                showAlert(getString(R.string.no_connection_error));
                            }
                        });
                    }
                }
            };

            getAlgoliaProductsWithAppliedFilterInfo(productInfoResultNotifier);

        }
    }

    /**
     * Method that Disable/Enables the Filter-Sort tap and text colors
     */
    private void disableFilterSort() {
        if (isAdded() && (mIsSingleProduct ||
                (mAlgoliaProductFilterInfo != null &&
                        mAlgoliaProductFilterInfo.getBrandStatList().size() < 2 &&
                        mAlgoliaProductFilterInfo.getCategoryStatList().size() < 2 &&
                        ((mAlgoliaProductFilterInfo.getDiscountStats() != null &&
                                mAlgoliaProductFilterInfo.getDiscountStats().getMax() == 0 &&
                                mAlgoliaProductFilterInfo.getDiscountStats().getMin() == 0) ||
                                (mAlgoliaProductFilterInfo.getSalesPriceStats() != null &&
                                        mAlgoliaProductFilterInfo.getSalesPriceStats().getMax() == 0 &&
                                        mAlgoliaProductFilterInfo.getSalesPriceStats().getMin() == 0)) &&
                        (mAlgoliaProductFilterInfo.getSalesPriceStats() != null && mAlgoliaProductFilterInfo.getSalesPriceStats().getMax() ==
                                mAlgoliaProductFilterInfo.getSalesPriceStats().getMin()) &&
                        (mAlgoliaProductFilterInfo.getDiscountStats() != null && mAlgoliaProductFilterInfo.getDiscountStats().getMax() ==
                                mAlgoliaProductFilterInfo.getDiscountStats().getMin())
                ))) {

            mSortTitle.setTextColor(ContextCompat.getColor(getActivity(), R.color.common_header_text_color));
            mFilterTitle.setTextColor(ContextCompat.getColor(getActivity(), R.color.common_header_text_color));

            mSortProducts.setClickable(false);
            mFilterProducts.setClickable(false);

        } else {
            mSortTitle.setTextColor(ContextCompat.getColor(getActivity(), R.color.frankross_common_text_color));
            mFilterTitle.setTextColor(ContextCompat.getColor(getActivity(), R.color.frankross_common_text_color));

            mSortProducts.setClickable(true);
            mFilterProducts.setClickable(true);
        }
    }

    /**
     * Method that requests for the Algolia products without the applied filter details
     *
     * @param productInfoWithFilterResultNotifier the listener that is registered for the request
     */
    protected void getAlgoliaProductsWithFilterInfo(AlgoliaManager.IProductInfoWithFilterResultNotifier
                                                            productInfoWithFilterResultNotifier) {
        AlgoliaManager.getInstance().performGetNonPharmaCategoryProductsWithFilterInfo(
                getActivity().getApplicationContext(), mCategoryId,
                ALGOLIA_PRODUCTS_COUNT, mCurrentPageNumber, productInfoWithFilterResultNotifier);
    }

    /**
     * Method that requests for the Algolia products with the applied filter details
     *
     * @param productInfoResultNotifier the listener that is registered for the request
     */
    protected void getAlgoliaProductsWithAppliedFilterInfo(AlgoliaManager.
                                                                   IProductInfoResultNotifier
                                                                   productInfoResultNotifier) {
        AlgoliaManager.getInstance().performGetNonPharmaCategoryProductsWithAppliedFilterAndSortInfo(
                false, getActivity().getApplicationContext(), mCurrentSortType, mAppliedFilterInfo,
                mCategoryId, ALGOLIA_PRODUCTS_COUNT, mCurrentPageNumber,
                productInfoResultNotifier);
    }

    /**
     * Callback that helps for pagination
     */
    @Override
    public void onPageEnd(int position) {
        if (!mIsAllProductsFetched) {
            if (position % PRODUCTS_COUNT_PAGINATION == 0) {
                getAlogliaProduct();
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        //FrankRossAnalytics.getFrankRossTracker().logTimedEvent(FrankRossEvents.TIME_SPENT_PRODUCT_LISTING, null);
        mApiRequestManager.registerCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        //FrankRossAnalytics.getFrankRossTracker().endTimedEvent(FrankRossEvents.TIME_SPENT_PRODUCT_LISTING, null);
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
        mApiRequestManager.unregisterCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return Utils.getCapitalizedSentence(mCategoryName);
    }

    @Override
    public int getToolbarMenuId() {
        return R.menu.menu_pharmacy;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_search:
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_FROM_TOOLBAR_EVENT);
                        startActivity(SearchActivity.getActivityIntent(getActivity()));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;

                    case R.id.action_cart:
                        Map<String, String> cartClickData = Utils.cartToolbarClickDataForAnalytics(Constants.PRODUCT_LISTING_SCREEN_NAME,
                                FrankRossEvents.VIEW_CART_FROM_TOOLBAR_SCREEN_NAME);
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_CART_FROM_TOOLBAR_EVENT, cartClickData);
                        startActivity(CartActivity.getActivityIntent(getActivity().getApplicationContext(),
                                CartActivity.CART_FRAGMENT_ID));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;
                }
                return false;
            }
        };
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mProductsCount != 0)
            setProductsCount();

        disableFilterSort();
    }

    public enum ListingFlow {
        CATEGORY_LISTING,
        CATEGORY_SHOP_BY_BRAND,
        CATEGORY_FEATURED,
        CATEGORY_PROMOTIONAL_PRODUCTS,
        HOME_PROMOTIONAL_PRODUCTS,
        HOME_FEATURED,
        SEARCH_RESULT
    }
}
