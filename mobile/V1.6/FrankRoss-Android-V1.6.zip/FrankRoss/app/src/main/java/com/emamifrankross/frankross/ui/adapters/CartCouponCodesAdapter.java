/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 12/11/15.
 * <p/>
 * <p> Adapter class for Cart Applied Coupon Codes Section</p>
 * <p>Supports One View Types </p>
 * <p> 1 :  CART APPLIED COUPON CODE LIST ITEM VIEW TYPE </p>
 */
public class CartCouponCodesAdapter extends BaseRecyclerAdapter {

    public CartCouponCodesAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewHolderTypeList = new ArrayList<>(1);
        viewHolderTypeList.add(new AppliedCouponCodeViewHolderType());

        return viewHolderTypeList;
    }

    /**
     * CART APPLIED COUPON CODE LIST ITEM VIEW TYPE
     */
    public static class AppliedCouponCodeDataItem implements IViewType {

        public String couponCodeName = "";

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_APPLIED_COUPON_CODES_LIST_ITEM_VIEW_TYPE;
        }
    }

    private static class AppliedCouponCodeViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mAppliedCouponCode;
        private LinearLayout mCouponCodeWrapper;

        public AppliedCouponCodeViewHolder(View itemView) {
            super(itemView);
            mAppliedCouponCode = (RobotoTextView) itemView.findViewById(R.id.cart_couponcode_tv);
            mCouponCodeWrapper = (LinearLayout) itemView.findViewById(R.id.coupon_code_wrapper);
        }
    }

    private static class AppliedCouponCodeViewHolderType implements
            RecyclerViewDataBinder<AppliedCouponCodeViewHolder, AppliedCouponCodeDataItem> {

        @Override
        public AppliedCouponCodeViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_applied_coupon_code_item, parent, false);

            return new AppliedCouponCodeViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(AppliedCouponCodeViewHolder viewHolder,
                                         final AppliedCouponCodeDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mAppliedCouponCode.setText(data.couponCodeName);
            if (recyclerViewClickListener != null) {
                viewHolder.mCouponCodeWrapper.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_APPLIED_COUPON_CODES_LIST_ITEM_VIEW_TYPE;
        }
    }
}
