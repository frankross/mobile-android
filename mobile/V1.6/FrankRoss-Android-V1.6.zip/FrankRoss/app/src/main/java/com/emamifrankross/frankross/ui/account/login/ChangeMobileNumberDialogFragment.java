/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.account.login;

import android.app.Dialog;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.BaseDialogFragment;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gauthami on 10/7/15.
 */

/**
 * This class represents the UI for updating user mobile number
 */
public class ChangeMobileNumberDialogFragment extends BaseDialogFragment implements View.OnClickListener {

    public static final String TAG = ChangeMobileNumberDialogFragment.class.getSimpleName();

    private EditText mMobileNumber;
    private RobotoTextView mClearBtn;

    private IChangeNumberListener mChangeNumberListener;

    /**
     * Interface definition for a callback to be invoked when Change number view is clicked.
     */
    public interface IChangeNumberListener {
        /**
         * Called when Change number view is clicked.
         *
         * @param newNumber The new number as entered by the user
         */
        void onChangeNumber(String newNumber);
    }

    public static ChangeMobileNumberDialogFragment create(EnterOTPFragment enterOTPFragment) {
        ChangeMobileNumberDialogFragment changeMobileNumberDialogFragment = new ChangeMobileNumberDialogFragment();
        changeMobileNumberDialogFragment.mChangeNumberListener = enterOTPFragment;
        return changeMobileNumberDialogFragment;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_change_mobile_number_dialog;
    }

    @Override
    public void initViews(Dialog view) {
        mMobileNumber = (EditText) view.findViewById(R.id.change_number_dialog_mobile_num_et);
        RobotoTextView nextBtn = (RobotoTextView) view.findViewById(R.id.change_number_dialog_next_btn);
        mClearBtn = (RobotoTextView) view.findViewById(R.id.change_number_clear_txt_btn);

        mMobileNumber.addTextChangedListener(mMobileNumberTextChangeListener);
        nextBtn.setOnClickListener(this);
        mClearBtn.setOnClickListener(this);
    }

    /**
     * Text watcher for entered mobile number that helps in setting the clear button visibility
     */
    private TextWatcher mMobileNumberTextChangeListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            setClearButtonVisibility(charSequence);
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    };

    /**
     * Method that sets the visibility of clear button associated with the Mobile number
     *
     * @param charSequence that determines visibility of clear button
     */
    private void setClearButtonVisibility(CharSequence charSequence) {
        mClearBtn.setVisibility((!TextUtils.isEmpty(charSequence) && charSequence.length() > 0) ? View.VISIBLE : View.INVISIBLE);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.change_number_dialog_next_btn:
                if (validateRegistration()) {
                    mChangeNumberListener.onChangeNumber(mMobileNumber.getText().toString());
                    getDialog().dismiss();
                }
                break;
            case R.id.change_number_clear_txt_btn:
                mMobileNumber.getText().clear();
                break;
        }
    }

    /**
     * @return If false,displays the input error dialog with appropriate message;else true.
     */
    private boolean validateRegistration() {
        boolean isValid = true;

        if (!(Utils.isValidPhoneNumber(getUserMobileNumber()))) {
            mFragmentInteractionListener.showAlert(getString(R.string.error), getString(R.string.please_enter_a_valid_number),
                    getString(R.string.ok), null, null, null, false);
            isValid = false;
        }
        return isValid;
    }

    /**
     * @return returns user mobile number if not empty or null,else returns empty string
     */
    private String getUserMobileNumber() {
        String userMobileNumber = mMobileNumber.getText().toString();
        if (TextUtils.isEmpty(userMobileNumber)) return "";
        return userMobileNumber;
    }
}
