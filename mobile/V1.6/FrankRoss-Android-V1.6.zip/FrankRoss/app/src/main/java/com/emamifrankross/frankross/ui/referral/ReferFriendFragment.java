/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.referral;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiReferFriend;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.BranchManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.faq.FAQFragment;
import com.emamifrankross.frankross.ui.viewmodels.UserInformation;
import com.emamifrankross.frankross.utils.NetworkUtils;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gauthami on 2/5/16.
 */

/**
 * This class represents the UI for Refer a friend screen
 */
public class ReferFriendFragment extends ApiRequestBaseFragment implements IToolbar, View.OnClickListener {

    private RobotoTextView mInviteFriendsMessage;
    private LinearLayout mInviteFriendsContentLayout;

    private ApiReferFriend.Response mApiReferFriendData;

    public static ReferFriendFragment create() {
        return new ReferFriendFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFragmentInteractionListener.showBlockingProgressBar();

        //Check for empty user id -- to avoid the setting of null/empty user id to Branch
        if (TextUtils.isEmpty(Utils.getUserID(getActivity().getApplicationContext()))) {
            //If user id is empty -- get user id from User API & save in preference
            performUserInfoRequest();
        } else {
            performReferAFriendRequest();
        }

        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.REFER_FRIEND_SCREEN_VISIT_EVENT);
    }

    /**
     * Method that adds the User details to the UI data list
     */
    private void performUserInfoRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();

        mApiRequestManager.performUserInfoRequest(new ApiRequestManager.IGetUserInfoResultNotifier() {
            @Override
            public void onUserInfoFetched(UserInformation userInfo) {
                mFragmentInteractionListener.hideBlockingProgressBar();
                if (userInfo != null) {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    Utils.saveUserName(getActivity(), userInfo.userName);
                    Utils.saveUserMobileNUmber(getActivity(), userInfo.userMobileNumber);
                    Utils.saveUserID(getActivity(), userInfo.userId);
                    BranchManager.getBranchInstance(getActivity()).setIdentity(userInfo.userId);
                    performReferAFriendRequest();
                }
            }
        }, this, this);
    }


    /**
     * Method that requests for Referral details
     */
    private void performReferAFriendRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performReferFriendRequest(new ApiRequestManager.IReferFriendResultNotifier() {
            @Override
            public void onReferFriendFetched(ApiReferFriend.Response apiReferFriend) {
                if (apiReferFriend != null && apiReferFriend.getInviteInfo() != null) {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    mApiReferFriendData = apiReferFriend;
                    setData();
                }
            }
        }, this, this);
    }

    /**
     * Method that maps tha API data for Referral details to UI views
     */
    private void setData() {
        if (mApiReferFriendData != null) {
            mFragmentInteractionListener.hideBlockingProgressBar();
            mInviteFriendsContentLayout.setVisibility(View.VISIBLE);//until appropriate data received do not show layout
            mInviteFriendsMessage.setText(mApiReferFriendData.getInviteInfo().getMessage());
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_refer_friend, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initReferFriendView(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the views
     *
     * @param view the view that is associated with the Refer friend screen
     */
    private void initReferFriendView(View view) {
        mInviteFriendsMessage = (RobotoTextView) view.findViewById(R.id.invite_friends_message_tv);
        RobotoTextView inviteFriendsHowItWorks = (RobotoTextView) view.findViewById(R.id.invite_friends_how_it_works_tv);
        Button inviteFriendsBtn = (Button) view.findViewById(R.id.invite_friends_btn);
        mInviteFriendsContentLayout = (LinearLayout) view.findViewById(R.id.invite_friends_linLyt);

        inviteFriendsHowItWorks.setOnClickListener(this);
        inviteFriendsBtn.setOnClickListener(this);
        setData();
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        mApiRequestManager.registerCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
        mApiRequestManager.unregisterCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_refer_a_friend);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.invite_friends_btn:
                if (NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
                    FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.REFER_FRIEND_INVITE_FRIENDS_TAP_EVENT);

                    if (!TextUtils.isEmpty(Utils.getUserID(getActivity()))) {
                        if (mApiReferFriendData.getInviteInfo().isActive()) {
                            BranchManager.launchBranchSdkShareIntent(getActivity(),
                                    mApiReferFriendData.getSocialSharingDetails().getEmail_subject(),
                                    mApiReferFriendData.getSocialSharingDetails().getPromotional_message(),
                                    mApiRequestManager.getSettingsResponse().getReferralLinkTitle(),
                                    mApiRequestManager.getSettingsResponse().getReferralLinkDescription(),
                                    mApiRequestManager.getSettingsResponse().getReferralLinkImageUrl());
                        } else {
                            showAlert(mApiReferFriendData.getInviteInfo().getStatus_message());
                        }
                    }
                } else {
                    showAlert(getString(R.string.no_connection_error));
                }
                break;
            case R.id.invite_friends_how_it_works_tv:
                if (NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
                    FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.REFER_FRIEND_HOW_IT_WORKS_TAP_EVENT);
                    launchHowItWorksFragment();
                } else {
                    showAlert(getString(R.string.no_connection_error));
                }
                break;
            default:
                break;
        }
    }

    /**
     * Method that handles the click of 'How it works' button there by launching the FAQ screen
     * for Referral program
     */
    private void launchHowItWorksFragment() {
        long faqTopicID = mApiReferFriendData.getInviteInfo().getFaq_topic_id();
        if (faqTopicID != 0) {
            mFragmentInteractionListener.loadFragment(getId(),
                    FAQFragment.create(getString(R.string.drawer_menu_refer_a_friend), faqTopicID), null,
                    R.anim.push_left_in, R.anim.push_left_out,
                    FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
        }
    }
}
