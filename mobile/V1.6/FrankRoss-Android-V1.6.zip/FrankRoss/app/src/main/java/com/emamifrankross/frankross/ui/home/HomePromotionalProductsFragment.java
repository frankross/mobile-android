/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.home;

import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.aloglia.AlgoliaManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.pharmacy.ProductListingFragment;
import com.emamifrankross.frankross.ui.search.SearchActivity;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Utils;

import java.util.Map;

/**
 * Created by gowtham on 3/12/15.
 */

/**
 * This class represents the UI for Promotional products screen navigated from Home screen more tab
 */
public class HomePromotionalProductsFragment extends ProductListingFragment {

    private long mCategoryId = -1;
    private long mPromotionId = 0;

    public static HomePromotionalProductsFragment create(long promotionId) {
        HomePromotionalProductsFragment fragment = new HomePromotionalProductsFragment();
        fragment.setHomePromotionalProductsData(promotionId);
        return fragment;
    }

    private void setHomePromotionalProductsData(long promotionId) {
        mPromotionId = promotionId;
        mListingFlow = ListingFlow.HOME_PROMOTIONAL_PRODUCTS;
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.home_promotional_products_title);
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_search:
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_FROM_TOOLBAR_EVENT);
                        startActivity(SearchActivity.getActivityIntent(getActivity()));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;

                    case R.id.action_cart:
                        Map<String, String> cartClickData = Utils.cartToolbarClickDataForAnalytics(Constants.PRODUCT_LISTING_SCREEN_NAME,
                                FrankRossEvents.VIEW_CART_FROM_TOOLBAR_SCREEN_NAME);
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_CART_FROM_TOOLBAR_EVENT, cartClickData);
                        startActivity(CartActivity.getActivityIntent(getActivity(), CartActivity.CART_FRAGMENT_ID));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;
                }
                return false;
            }
        };
    }

    @Override
    protected void getAlgoliaProductsWithAppliedFilterInfo(AlgoliaManager.IProductInfoResultNotifier productInfoResultNotifier) {
        AlgoliaManager.getInstance().performGetNonPharmaCategoryProductsWithPromotionIdWithAppliedFilterAndSortInfo(
                getActivity().getApplicationContext(), mCurrentSortType, mAppliedFilterInfo
                , mPromotionId, mCategoryId, ALGOLIA_PRODUCTS_COUNT, mCurrentPageNumber, productInfoResultNotifier);
    }

    @Override
    protected void getAlgoliaProductsWithFilterInfo(AlgoliaManager.IProductInfoWithFilterResultNotifier productInfoWithFilterResultNotifier) {
        AlgoliaManager.getInstance().performGetNonPharmaCategoryProductsWithPromotionId(getActivity(), mPromotionId, mCategoryId,
                ALGOLIA_PRODUCTS_COUNT, mCurrentPageNumber, productInfoWithFilterResultNotifier);
    }
}
