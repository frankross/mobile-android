/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.referral;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;

/**
 * Created by gauthami on 2/5/16.
 */

/**
 * This class manages the fragment transactions for Refer a friend module based on the intents and its data
 */
public class ReferFriendActivity extends BaseActivity {

    public static final String INVITE_FRIENDS_FRAGMENT = "001";
    public static final String HOW_IT_WORKS_FRAGMENT = "002";

    private static final String EXTRA_FRAGMENT_ID = "fragment_id";

    private String mFragmentId = INVITE_FRIENDS_FRAGMENT;

    /**
     * Method to launch the Refer friends and How it works screen
     *
     * @param appContext the application context
     * @param fragmentId the fragment to be launched identified with an id
     * @return the intent associated with the Refer friend fragment
     */
    public static Intent getActivityIntent(Context appContext, String fragmentId) {
        Intent intent = new Intent(appContext, ReferFriendActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);

        return intent;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFragmentId = getIntent().getStringExtra(EXTRA_FRAGMENT_ID);
        initFragment(mFragmentId);
    }

    @Override
    public void onBackPressed() {
        if (mFragmentId.equals(HOW_IT_WORKS_FRAGMENT)) {
            mFragmentId = INVITE_FRIENDS_FRAGMENT;
            loadFragment(getFragmentContainerId(), ReferFriendFragment.create(), null,
                    R.anim.push_left_in, R.anim.push_left_out,
                    BaseFragment.FragmentTransactionType.REPLACE);
        } else {
            super.onBackPressed();
        }
    }

    private void initFragment(String fragmentId) {
        if (!TextUtils.isEmpty(fragmentId)) {
            switch (fragmentId) {
                case INVITE_FRIENDS_FRAGMENT:
                    loadFragment(getFragmentContainerId(),
                            ReferFriendFragment.create(), null, R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.REPLACE);
                    break;

                default:
                    break;

            }
        }
    }
}

