/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 1/4/16.
 */
public class ApiInitializePayment {

    public static class Request {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("payment_method")
        private String paymentMethod;

        @SerializedName("payment_instrument")
        private String paymentInstrument;

        @SerializedName("delivery_slot_id")
        private long deliverySlotId;

        @SerializedName("billing_address_id")
        private long deliveryAddressId;

        @SerializedName("shipping_address_id")
        private long shippingAddressId;

        @SerializedName("prescription_upload_id")
        private String prescriptionUploadId;

        public String getPaymentInstrument() {
            return paymentInstrument;
        }

        public void setPaymentInstrument(String paymentInstrument) {
            this.paymentInstrument = paymentInstrument;
        }

        public String getPaymentMethod() {
            return paymentMethod;
        }

        public void setPaymentMethod(String paymentMethod) {
            this.paymentMethod = paymentMethod;
        }

        public long getDeliverySlotId() {
            return deliverySlotId;
        }

        public void setDeliverySlotId(long deliverySlotId) {
            this.deliverySlotId = deliverySlotId;
        }

        public long getDeliveryAddressId() {
            return deliveryAddressId;
        }

        public void setDeliveryAddressId(long deliveryAddressId) {
            this.deliveryAddressId = deliveryAddressId;
        }

        public long getShippingAddressId() {
            return shippingAddressId;
        }

        public void setShippingAddressId(long shippingAddressId) {
            this.shippingAddressId = shippingAddressId;
        }

        public String getPrescriptionUploadId() {
            return prescriptionUploadId;
        }

        public void setPrescriptionUploadId(String prescriptionUploadId) {
            this.prescriptionUploadId = prescriptionUploadId;
        }
    }

    public static class Response {

        @SerializedName("order_id")
        private String orderId;

        @SerializedName("transaction_id")
        private String transactionId;

        public String getTransactionId() {
            return transactionId;
        }

        public void setTransactionId(String transactionId) {
            this.transactionId = transactionId;
        }

        public String getOrderId() {
            return orderId;
        }

        public void setOrderId(String orderId) {
            this.orderId = orderId;
        }
    }


    public static class ErrorResponse {

        @SerializedName("order")
        private Order order;

        public Order getOrder() {
            return order;
        }

        public void setOrder(Order order) {
            this.order = order;
        }

        public static class Order {
            @SerializedName("id")
            private int id;

            @SerializedName("errors")
            private List<String> errors = new ArrayList<>(1);

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public List<String> getErrors() {
                return errors;
            }

            public void setErrors(List<String> errors) {
                this.errors = errors;
            }
        }
    }
}
