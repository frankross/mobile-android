/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.support.v4.view.PagerAdapter;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;

/**
 * Created by gowtham on 17/12/15.
 */

/**
 * COMMON VIEW PAGER DATA ITEM
 */
public class ViewPagerDataItem implements BaseRecyclerAdapter.IViewType {

    public PagerAdapter viewPagerAdapter;

    @Override
    public int getViewType() {
        return ViewTypes.CommonViewType.VIEW_PAGER_ITEM;
    }
}
