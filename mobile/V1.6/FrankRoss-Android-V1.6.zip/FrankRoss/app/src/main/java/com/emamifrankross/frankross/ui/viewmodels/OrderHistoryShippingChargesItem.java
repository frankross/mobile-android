/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;

/**
 * Created by gauthami on 22/7/15.
 */

/**
 * Order history shipping charges data item
 */
public class OrderHistoryShippingChargesItem implements BaseRecyclerAdapter.IViewType {

    public String shippingChargesTxt = "";
    public String discountTotalTitle = "";
    public String shippingChargeDescription = "";
    public String rewardPointsDescription = "";
    public String paymentMethod = "";
    public String paymentInstrument = "";

    public boolean isChecked = true;
    public boolean isFullyPaidByWallet = false;
    public double rewardPoints = 0.0d;
    public double shippingCharge = 0.00d;
    public double discountTotal = 0.00d;

    @Override
    public int getViewType() {
        return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_PRODUCT_INFO_HEADER;
    }
}
