/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.home;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiLocation;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.LocationChooserAdapter;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IDrawerSlideController;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.products.ProductDetailActivity;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 21/7/15.
 */

/**
 * This class represents the UI for Location chooser screen
 */
public class LocationChooserFragment extends ApiRequestBaseFragment implements IToolbar {

    private static final String BRANCH_DEEP_LINK_VARIANT_ID = "variant_id";
    private static final String BRANCH_DEEP_LINK_SCREEN_NAME = "screen_name";
    private boolean mIsLocationsLoaded = false;
    private ILocationUpdateListener mLocationUpdateListener;
    private IDrawerSlideController mDrawerSlideController;
    private List<BaseRecyclerAdapter.IViewType> mLocationsList = new ArrayList<>();
    private LocationChooserAdapter.LocationChooserListItem mCurrentSelectedItem;
    private LocationChooserAdapter mLocationChooserAdapter;
    private long mVariantId = 0;
    private String mPdpScreenId = "";

    public static LocationChooserFragment create(Context appContext,
                                                 @Nullable List<LocationChooserAdapter.LocationChooserListItem> locationsList) {
        LocationChooserFragment fragment = new LocationChooserFragment();
        if (locationsList != null)
            fragment.setLocationsList(appContext, locationsList);

        return fragment;
    }

    public static LocationChooserFragment createBranchDeepLinkedInstance(long variantId, String screenId) {
        LocationChooserFragment fragment = new LocationChooserFragment();

        Bundle bundle = new Bundle();
        bundle.putLong(BRANCH_DEEP_LINK_VARIANT_ID, variantId);
        bundle.putString(BRANCH_DEEP_LINK_SCREEN_NAME, screenId);
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            mLocationUpdateListener = (ILocationUpdateListener) getActivity();
        } catch (ClassCastException exception) {
            throw new ClassCastException(context.toString()
                    + " must implement LocationUpdateListener");
        }
        try {
            mDrawerSlideController = (IDrawerSlideController) getActivity();
        } catch (ClassCastException exception) {
            throw new ClassCastException(context.toString()
                    + " must implement IDrawerSlideController");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();

        if (bundle != null) {
            mVariantId = bundle.getLong(BRANCH_DEEP_LINK_VARIANT_ID, 0);
            mPdpScreenId = bundle.getString(BRANCH_DEEP_LINK_SCREEN_NAME, "");
        }
        if (mDrawerSlideController != null)
            mDrawerSlideController.lockDrawer();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mDrawerSlideController != null)
            mDrawerSlideController.unlockDrawer();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mToolbarInteractionListener.updateToolbar(this);
        initViews(view);

        if (mLocationsList.size() == 0) {
            getLocations();
        }
    }

    /**
     * Method that gets the locations if there are more than one location;otherwise displays the Location alert
     */
    private void getLocations() {
        mFragmentInteractionListener.showBlockingProgressBar();

        mApiRequestManager.performGetLocationRequest(new ApiRequestManager.IGetLocationResultNotifier() {
            @Override
            public void onLocationFetched(List<LocationChooserAdapter.LocationChooserListItem> availableLocations, List<ApiLocation.Cities> cities) {
                mFragmentInteractionListener.hideBlockingProgressBar();
                mIsLocationsLoaded = true;

                if (availableLocations != null) {
                    if (availableLocations.size() == 1) {
                        mCurrentSelectedItem = availableLocations.get(0);
                        showLocationAlert();
                    } else {
                        setLocationsList(getActivity().getApplicationContext(), availableLocations);
                        mLocationChooserAdapter.notifyDataSetChanged();
                    }
                }

            }
        }, this, this);
    }

    private void showLocationAlert() {
        mFragmentInteractionListener.showAlert(getString(R.string.alert_delivery_location) + " " + mCurrentSelectedItem.LocationName + " only.",
                getString(R.string.more_cities_coming_soon), getString(R.string.got_it), "", null, null, true);
        saveLocationInfo();
        mFragmentInteractionListener.loadFragment(getId(), HomeFragment.create(), null,
                R.anim.push_left_in, R.anim.fade_out, FragmentTransactionType.REPLACE);
    }

    private void initViews(View view) {
        RecyclerView locationChooserRecyclerView = (RecyclerView) view.findViewById(R.id.home_container);
        locationChooserRecyclerView.setHasFixedSize(false);
        locationChooserRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mLocationChooserAdapter = new LocationChooserAdapter(mLocationsList);
        locationChooserRecyclerView.setAdapter(mLocationChooserAdapter);

        mLocationChooserAdapter.setRecyclerItemClickListener(new BaseRecyclerAdapter.RecyclerItemClickListener() {
            @Override
            public void onRecyclerItemClick(int position, View view, Object object) {
                if (object instanceof LocationChooserAdapter.LocationChooserListItem) {

                    for (BaseRecyclerAdapter.IViewType viewData : mLocationsList) {
                        if (viewData instanceof LocationChooserAdapter.LocationChooserListItem) {
                            ((LocationChooserAdapter.LocationChooserListItem) viewData).isSelected = false;
                        }
                    }
                    mCurrentSelectedItem = ((LocationChooserAdapter.LocationChooserListItem) object);
                    mCurrentSelectedItem.isSelected = true;
                    mLocationChooserAdapter.notifyDataSetChanged();
                }
            }
        });
    }

    private void addLocationFooter() {
        LocationChooserAdapter.LocationChooserFooterItem footerItem = new LocationChooserAdapter.LocationChooserFooterItem();
        mLocationsList.add(footerItem);
    }

    private void addLocationHeaderItem() {
        LocationChooserAdapter.LocationChooserHeaderItem headerItem = new LocationChooserAdapter.LocationChooserHeaderItem();
        mLocationsList.add(headerItem);
    }

    public void setLocationsList(Context context, List<LocationChooserAdapter.LocationChooserListItem> locationsList) {
        addLocationHeaderItem();

        String savedLocationName = Utils.getLocationName(context);
        boolean isFirst = true;

        for (LocationChooserAdapter.LocationChooserListItem item : locationsList) {

            if (TextUtils.isEmpty(savedLocationName)) {
                item.isSelected = isFirst;
                if (isFirst)
                    mCurrentSelectedItem = item;
                isFirst = false;
            } else if (item.LocationName.equals(savedLocationName)) {
                item.isSelected = true;
                mCurrentSelectedItem = item;
            }

            mLocationsList.add(item);
        }

        addLocationFooter();
    }

    private void saveLocationInfo() {
        if (mCurrentSelectedItem != null && getActivity() != null) {
            boolean isRefresh = false;
            String currentCity = Utils.getLocationName(getActivity().getApplicationContext());
            if (!TextUtils.isEmpty(currentCity) && !currentCity.contains(mCurrentSelectedItem.LocationName))
                isRefresh = true;

            Utils.saveLocationInfo(getActivity().getApplicationContext(), mCurrentSelectedItem.LocationName,
                    mCurrentSelectedItem.locationId);
            mLocationUpdateListener.updateLocation(isRefresh);
        }
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveLocationInfo();
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.select_location);
    }

    @Override
    public int getToolbarMenuId() {
        return R.menu.menu_location_chooser;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_done:
                        if (mIsLocationsLoaded) {
                            saveLocationInfo();
                            mFragmentInteractionListener.loadFragment(getId(), HomeFragment.create(), null,
                                    R.anim.push_left_in, R.anim.fade_out, BaseFragment.FragmentTransactionType.CLEAR_BACK_STACK_AND_REPLACE);
                            if (mVariantId != 0 && !TextUtils.isEmpty(mPdpScreenId))
                                handleProductDetailLaunch();
                        }
                        break;
                }

                return true;
            }
        };
    }

    private void handleProductDetailLaunch() {
        startActivityForResult(ProductDetailActivity.getActivityIntent(getActivity(),
                mPdpScreenId.equals(getResources().getString(R.string.pharma_product_share_using_branch)) ?
                        ProductDetailActivity.PHARMA_PRODUCT_DETAIL_FRAGMENT_ID :
                        ProductDetailActivity.NON_PHARMA_PRODUCT_DETAIL_FRAGMENT_ID, mVariantId),
                Constants.REQUEST_CODE_BRANCH_DEEPLINKING);
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    /**
     * Interface definition for a callback to be invoked when user updates the location
     */
    public interface ILocationUpdateListener {
        void updateLocation(boolean isRefresh);
    }
}
