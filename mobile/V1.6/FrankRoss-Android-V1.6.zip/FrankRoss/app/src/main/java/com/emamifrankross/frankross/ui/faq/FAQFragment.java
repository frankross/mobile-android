/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.faq;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.FAQ;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.customviews.AnimatedExpandableListView;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.search.SearchActivity;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by gauthami on 23/7/15.
 */

/**
 * This class represents the UI for FAQ screen for particular faq id
 */
public class FAQFragment extends ApiRequestBaseFragment implements IToolbar,
        ExpandableListView.OnGroupClickListener, ExpandableListView.OnGroupExpandListener {

    private static final String EXTRA_TOPIC_ID = "faq_topic_id";
    private static final String EXTRA_TOPIC_NAME = "faq_topic";

    private ExpandableListView mFaqExpandableListView;
    private FaqExpandableListAdapter mFaqExpandableListAdapter;
    private RobotoTextView mEmptyView;
    private List<FAQ.Faqs> mFaqList = new ArrayList<>(1);

    //To make only one parent expandable at a time
    private int mPreviousGroup = -1;
    private String mToolbarTitle = "";

    public static FAQFragment create(String faqTopic, long faqHelpTopicId) {
        FAQFragment fragment = new FAQFragment();

        Bundle bundle = new Bundle();
        bundle.putLong(EXTRA_TOPIC_ID, faqHelpTopicId);
        bundle.putString(EXTRA_TOPIC_NAME, faqTopic);
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        long faqTopicId = 0;

        if (getArguments() != null) {
            faqTopicId = getArguments().getLong(EXTRA_TOPIC_ID, -1);
            mToolbarTitle = getArguments().getString(EXTRA_TOPIC_NAME);
        }

        Map<String, String> faqVisitData = Utils.faqVisitDataForAnalytics(faqTopicId + "");
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.FAQ_VISIT_EVENT, faqVisitData);

        mFaqExpandableListAdapter = new FaqExpandableListAdapter();
        performFAQRequest(faqTopicId);
    }

    /**
     * Method that requests for the FAQ questions/answers
     *
     * @param faqTopicId the topic ID whose FAQs has to be displayed
     */
    private void performFAQRequest(long faqTopicId) {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetFAQListRequest(faqTopicId, new ApiRequestManager.IFAQResultNotifier() {

            @Override
            public void onFAQFetched(List<FAQ.Faqs> faqList) {
                mFragmentInteractionListener.hideBlockingProgressBar();
                if (faqList != null && faqList.size() > 0) {
                    mFaqList = faqList;
                    getSubCategoryData();
                } else {
                    mEmptyView.setText(getString(R.string.faq_empty_view_txt));
                    mEmptyView.setVisibility(View.VISIBLE);
                }
            }
        }, this, this);
    }

    /**
     * Method that constructs the expandable group/child data
     */
    private void getSubCategoryData() {
        List<GroupItem> items = new ArrayList<GroupItem>(1);

        for (int faqIndex = 0; faqIndex < mFaqList.size(); faqIndex++) {
            GroupItem item = new GroupItem();
            item.groupTitle = mFaqList.get(faqIndex).getQuestion();

            ChildItem child = new ChildItem();
            child.childTitle = mFaqList.get(faqIndex).getAnswer();

            item.childItems.add(child);

            items.add(item);
        }

        mFaqExpandableListAdapter.setData(items);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_faq, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mToolbarInteractionListener.updateToolbar(this);
        initViews(view);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    /**
     * Method that initializes the views
     *
     * @param view the view that is associated with the FAQ screen
     */
    private void initViews(View view) {
        mFaqExpandableListView = (ExpandableListView) view.findViewById(R.id.faq_expandable_list);
        mFaqExpandableListView.setAdapter(mFaqExpandableListAdapter);
        mFaqExpandableListView.setOnGroupClickListener(this);
        mFaqExpandableListView.setOnGroupExpandListener(this);
        mEmptyView = (RobotoTextView) view.findViewById(R.id.faq_empty_view_tv);
    }

    @Override
    public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
        if (mFaqExpandableListView.isGroupExpanded(groupPosition)) {
            mFaqExpandableListView.collapseGroup(groupPosition);
        } else {
            mFaqExpandableListView.expandGroup(groupPosition);
        }
        return true;
    }

    @Override
    public void onStart() {
        super.onStart();
        mApiRequestManager.registerCartCountChangeNotifier((BaseActivity) getActivity());
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        mApiRequestManager.unregisterCartCountChangeNotifier((BaseActivity) getActivity());
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return mToolbarTitle;
    }

    @Override
    public int getToolbarMenuId() {
        return R.menu.menu_pharmacy;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_search:
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_FROM_TOOLBAR_EVENT);
                        startActivity(new Intent(getActivity(), SearchActivity.class));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;

                    case R.id.action_cart:
                        Map<String, String> cartClickData = Utils.cartToolbarClickDataForAnalytics(Constants.FAQ_SCREEN_NAME,
                                FrankRossEvents.VIEW_CART_FROM_TOOLBAR_SCREEN_NAME);
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_CART_FROM_TOOLBAR_EVENT, cartClickData);
                        startActivity(CartActivity.getActivityIntent(getActivity().getApplicationContext(), CartActivity.CART_FRAGMENT_ID));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;
                }
                return false;
            }
        };
    }

    @Override
    public void onGroupExpand(int groupPosition) {
        if (groupPosition != mPreviousGroup)
            mFaqExpandableListView.collapseGroup(mPreviousGroup);
        mPreviousGroup = groupPosition;
    }

    private static class GroupItem {
        private String groupTitle;
        private List<ChildItem> childItems = new ArrayList<ChildItem>();
    }

    private static class ChildItem {
        private String childTitle;
    }

    private static class ChildHolder {
        private RobotoTextView childTitle;
        private LinearLayout childLinLyt;
    }

    private static class GroupHolder {
        private RobotoTextView groupTitle;
        private ImageView groupIndicator;
        private LinearLayout groupLinLyt;
        private View groupSeparator;
    }

    /**
     * Adapter for our list of {@link GroupItem}s.
     */
    public class FaqExpandableListAdapter extends AnimatedExpandableListView.AnimatedExpandableListAdapter {

        private static final int ICON_EXPAND_ROTATE_ANGLE = 180;
        private static final int ICON_COLLAPSE_ROTATE_ANGLE = 0;
        private List<GroupItem> items = new ArrayList<>(1);

        public FaqExpandableListAdapter() {
        }

        public void setData(List<GroupItem> items) {
            this.items = items;
            notifyDataSetChanged();
        }

        @Override
        public ChildItem getChild(int groupPosition, int childPosition) {
            return items.get(groupPosition).childItems.get(childPosition);
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public View getRealChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {
            ChildHolder holder;
            ChildItem item = getChild(groupPosition, childPosition);
            if (convertView == null) {
                holder = new ChildHolder();
                convertView = LayoutInflater.from(getActivity()).inflate(R.layout.faq_expandable_child_item, parent, false);
                holder.childTitle = (RobotoTextView) convertView.findViewById(R.id.faq_expandable_child_tv);
                holder.childLinLyt = (LinearLayout) convertView.findViewById(R.id.faq_expandable_child_parent_linLyt);
                convertView.setTag(holder);
            } else {
                holder = (ChildHolder) convertView.getTag();
            }

            holder.childTitle.setText(item.childTitle);

            return convertView;
        }

        @Override
        public int getRealChildrenCount(int groupPosition) {
            return items.get(groupPosition).childItems.size();
        }

        @Override
        public GroupItem getGroup(int groupPosition) {
            return items.get(groupPosition);
        }

        @Override
        public int getGroupCount() {
            return items.size();
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
            GroupHolder holder;
            GroupItem item = getGroup(groupPosition);
            if (convertView == null) {
                holder = new GroupHolder();
                convertView = LayoutInflater.from(getActivity()).inflate(R.layout.faq_expandable_group_item, parent, false);
                holder.groupTitle = (RobotoTextView) convertView.findViewById(R.id.faq_expandable_group_title_tv);
                holder.groupIndicator = (ImageView) convertView.findViewById(R.id.faq_expandable_group_expand_iv);
                holder.groupLinLyt = (LinearLayout) convertView.findViewById(R.id.faq_expandable_group_parent_linLyt);
                holder.groupSeparator = convertView.findViewById(R.id.faq_expandable_group_border);
                convertView.setTag(holder);
            } else {
                holder = (GroupHolder) convertView.getTag();
            }

            if (isExpanded) {
                holder.groupIndicator.setRotation(ICON_EXPAND_ROTATE_ANGLE);
                holder.groupLinLyt.setBackgroundColor(ContextCompat.getColor(convertView.getContext(), R.color.background_darker_grey));
                holder.groupTitle.setTextColor(ContextCompat.getColor(convertView.getContext(), R.color.common_sub_title_header_text_color));
                holder.groupSeparator.setVisibility(View.GONE);
            } else {
                holder.groupIndicator.setRotation(ICON_COLLAPSE_ROTATE_ANGLE);
                holder.groupLinLyt.setBackgroundColor(ContextCompat.getColor(convertView.getContext(), R.color.white_background));
                holder.groupTitle.setTextColor(ContextCompat.getColor(convertView.getContext(), R.color.pharmacy_dash_board_text_color));
                holder.groupSeparator.setVisibility(View.VISIBLE);
            }
            holder.groupTitle.setText(item.groupTitle);

            return convertView;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public boolean isChildSelectable(int arg0, int arg1) {
            return true;
        }

    }
}
