/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

import android.os.Bundle;
import android.view.View;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.core.network.IApiRequestCancel;

/**
 * Created by gowtham on 14/7/15.
 */
public abstract class ApiRequestBaseFragment extends BaseFragment implements IApiRequestCancel, IErrorHandler {

    protected ApiRequestManager mApiRequestManager;

    @Override
    public final String getRequestTag() {
        return this.toString();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mApiRequestManager = ApiRequestManager.getInstance(getActivity().getApplicationContext());
        mApiRequestManager.registerRequest(this);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        hide_keyboard(getActivity(), view);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mApiRequestManager.unregisterRequest(this);
    }


    @Override
    public <T> void handleError(AlertError<T> alertError, int statusCode) {
        mFragmentInteractionListener.hideBlockingProgressBar();

        if (alertError == null) return;
        mFragmentInteractionListener.showAlert(alertError.getErrorTitle(), alertError.getErrorMessage(),
                alertError.getPositiveButtonText(), alertError.getNegativeButtonText(), new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                        onErrorPositiveAction();
                    }
                }, new AlertDialogFragment.AlertNegativeActionListener() {
                    @Override
                    public void onNegativeAction() {
                        onErrorNegativeAction();
                    }
                }, true);
    }

    @Override
    public void handleCommonError(int errorResourceId) {
        mFragmentInteractionListener.hideBlockingProgressBar();
        String errorMessage = getString(errorResourceId);

        mFragmentInteractionListener.showAlert(null, errorMessage,
                "OK", null, new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                        onErrorAlertAction();
                    }
                }, null, true);

    }

    protected void showAlert(String alertMessage, AlertDialogFragment.AlertPositiveActionListener clickListener, boolean isCancelable) {
        mFragmentInteractionListener.showAlert(null, alertMessage, getString(R.string.ok), null, clickListener, null, isCancelable);
    }

    protected void onErrorPositiveAction() {

    }

    protected void onErrorNegativeAction() {

    }

    protected void onErrorAlertAction() {

    }
}
