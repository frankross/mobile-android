/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.account;

import android.app.Activity;
import android.app.Dialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.core.network.IApiRequestCancel;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;
import com.emamifrankross.frankross.ui.common.AlertError;
import com.emamifrankross.frankross.ui.common.BaseDialogFragment;
import com.emamifrankross.frankross.ui.common.IErrorHandler;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.NetworkUtils;
import com.emamifrankross.frankross.utils.PreferenceUtils;

/**
 * This class represents the UI for password verification dialog to edit the user info
 */
public class EditProfilePasswordDialogFragment extends BaseDialogFragment implements
        View.OnClickListener, IApiRequestCancel, IErrorHandler {

    private static final String KEY_USER_MOBILE_NUMBER = "mobile";

    protected ApiRequestManager mApiRequestManager;
    private IPasswordValidateListener mChangePasswordListener;

    private EditText mUserPassword;
    private Button mSubmitButton;

    private String mUserMobileNumber = "";

    /**
     * Interface definition for a callback to be invoked when validating the password
     */
    public interface IPasswordValidateListener {
        /**
         * Called when validate the password to change the mobile number
         *
         * @param password the password entered by the user
         */
        void onPasswordValidated(String password);

        /**
         * Called when the verify via OTP is clicked
         */
        void onVerifyViaOTPClick();
    }

    public static EditProfilePasswordDialogFragment create(String mobileNumber) {
        EditProfilePasswordDialogFragment editProfilePasswordDialogFragment = new
                EditProfilePasswordDialogFragment();
        Bundle bundle = new Bundle();
        bundle.putString(KEY_USER_MOBILE_NUMBER, mobileNumber);

        editProfilePasswordDialogFragment.setArguments(bundle);
        return editProfilePasswordDialogFragment;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mChangePasswordListener = (IPasswordValidateListener) activity;

        } catch (ClassCastException exception) {
            throw (exception);
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mApiRequestManager = ApiRequestManager.getInstance(getActivity().getApplicationContext());
        mApiRequestManager.registerRequest(this);

        if (getArguments() != null) {
            mUserMobileNumber = getArguments().getString(KEY_USER_MOBILE_NUMBER);
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mApiRequestManager.unregisterRequest(this);
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_edit_profile_password;
    }

    @Override
    public void initViews(Dialog view) {
        mUserPassword = (EditText) view.findViewById(R.id.edit_profile_password_user_mobile_number_tv);
        mSubmitButton = (Button) view.findViewById(R.id.edit_profile_passwrod_submit_btn);
        RobotoTextView verifyViaOTP = (RobotoTextView) view.findViewById(R.id.edit_profile_verify_via_otp_btn);
        verifyViaOTP.setOnClickListener(this);
        mSubmitButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.edit_profile_passwrod_submit_btn:
                if (TextUtils.isEmpty(mUserPassword.getText().toString())) {
                    mUserPassword.setError(getString(R.string.account_edit_profile_enter_password_msg));
                } else {
                    performSignIn();
                }
                break;
            case R.id.edit_profile_verify_via_otp_btn:
                getDialog().dismiss();
                mChangePasswordListener.onVerifyViaOTPClick();
                break;
        }
    }

    /**
     * Method requests for Log In with the password;If success, the password validated successfully
     * and the call back will be registered
     */
    private void performSignIn() {
        hide_keyboard(getActivity(), mSubmitButton);
        if (NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
            mFragmentInteractionListener.showBlockingProgressBar();
            mApiRequestManager.performLoginRequest(mUserMobileNumber, mUserPassword.getText().toString(), new ApiRequestManager.ILoginResultNotifier() {
                @Override
                public void onLoginCompleted(String accessToken) {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    getDialog().dismiss();

                    PreferenceUtils.saveStringIntoSharedPreference(getActivity().getApplicationContext(),
                            PreferenceUtils.PREFERENCE_KEY_ACCESS_TOKEN, accessToken);
                    mChangePasswordListener.onPasswordValidated(mUserPassword.getText().toString());
                }
            }, this, this);
        } else {
            mFragmentInteractionListener.showAlert(null, getString(R.string.please_check_your_network_connection),
                    getString(R.string.ok), null, new AlertDialogFragment.AlertPositiveActionListener() {
                        @Override
                        public void onPositiveAction() {

                        }
                    }, null, true);
        }
    }

    @Override
    public String getRequestTag() {
        return getClass().getName();
    }

    @Override
    public <T> void handleError(AlertError<T> alertError, int statusCode) {
        mFragmentInteractionListener.hideBlockingProgressBar();
        mUserPassword.setError(getString(R.string.account_edit_profile_enter_valid_password_msg));
    }

    @Override
    public void handleCommonError(int errorResourceId) {
        mFragmentInteractionListener.hideBlockingProgressBar();
        String errorMessage = getString(errorResourceId);
        mFragmentInteractionListener.showAlert(null, errorMessage,
                getString(R.string.ok), null, new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {

                    }
                }, null, true);
    }
}
