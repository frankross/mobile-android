/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ReorderReminderDetails;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryProductInfoHeaderViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryProductInfoViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryShippingChargesViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryTotalAmountViewDataBinder;
import com.emamifrankross.frankross.utils.FrankRossDateUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 15/7/15.
 * <p> Adapter class for Order History Details Section</p>
 * <p>Supports the Nine View Types </p>
 * <p> 1 : ORDER HISTORY VIEW TYPE </p>
 * <p> 2 : PRODUCT DETAIL HEADER ITEM VIEW TYPE</p>
 * <p> 3 : PRODUCT DETAIL ITEM VIEW TYPE </p>
 * <p> 4 : TOTAL AMOUNT VIEW TYPE </p>
 * <p> 5 : SHIPPING CHARGES VIEW TYPE </p>
 * <p> 6 : ORDER DELIVER TO VIEW TYPE </p>
 * <p> 7 : CANCEL ORDER VIEW TYPE </p>
 * <p> 8 : RE ORDER VIEW TYPE </p>
 * <p> 9 : DOCTOR PATIENT INFO VIEW TYPE </p>
 */
public class OrderHistoryDetailsAdapter extends BaseRecyclerAdapter {

    public OrderHistoryDetailsAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<BaseRecyclerAdapter.RecyclerViewDataBinder> getViewDataBinders() {
        ArrayList<RecyclerViewDataBinder> viewHolderTypes = new ArrayList<>(1);
        viewHolderTypes.add(new OrderHistoryViewHolderType());
        viewHolderTypes.add(new OrderHistoryProductInfoHeaderViewDataBinder());
        viewHolderTypes.add(new OrderHistoryProductInfoViewDataBinder());
        viewHolderTypes.add(new OrderHistoryShippingChargesViewDataBinder());
        viewHolderTypes.add(new OrderHistoryTotalAmountViewDataBinder());
        viewHolderTypes.add(new OrderHistoryDeliverToViewHolderType());
        viewHolderTypes.add(new CancelOrderViewDataBinder());
        viewHolderTypes.add(new ReOrderViewDataBinder());
        viewHolderTypes.add(new OrderDetailsDoctorPatientInfoViewDataBinder());
        return viewHolderTypes;
    }

    /**
     * ORDER HISTORY VIEW TYPE
     */

    public static class OrderHistoryItem implements IViewType {

        public String orderHistoryOrderDate = "";
        public String orderHistoryOrderDeliveryStatus = "";
        public String orderDeliverySlotDate = "";
        public String orderHistoryStatus = "";
        public long orderId = 0;
        public boolean isReOrderable = false;
        public boolean isOrderMismatched = false;

        @Override
        public int getViewType() {
            return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_VIEW_TYPE;
        }
    }

    private static class OrderHistoryViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mOrderHistoryDetailStatus;
        private RobotoTextView mOrderHistoryDetailDate;
        private RobotoTextView mOrderHistoryDetailsDeliveredBy;
        private ImageView mOrderHistoryDetailImage;

        private LinearLayout mDeliveredByLinLyt;
        private LinearLayout mOrderHistoryDetailsDeliveredByTxtLinLyt;

        public OrderHistoryViewHolder(View view) {
            super(view);
            mOrderHistoryDetailStatus = (RobotoTextView) view.findViewById(R.id.order_history_details_order_status_tv);
            mOrderHistoryDetailDate = (RobotoTextView) view.findViewById(R.id.order_history_details_order_date_tv);
            mOrderHistoryDetailImage = (ImageView) view.findViewById(R.id.order_progress_img_iv);
            mOrderHistoryDetailsDeliveredBy = (RobotoTextView) view.findViewById(R.id.order_history_details_delivered_by_date_tv);
            mDeliveredByLinLyt = (LinearLayout) view.findViewById(R.id.order_history_details_delivered_by_date_linLyt);
            mOrderHistoryDetailsDeliveredByTxtLinLyt = (LinearLayout) view.findViewById(R.id.order_history_details_delivered_by_txt_linLyt);
        }
    }

    private class OrderHistoryViewHolderType implements RecyclerViewDataBinder<OrderHistoryViewHolder,
            OrderHistoryItem> {

        @Override
        public OrderHistoryViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_history_detail_item, parent, false);
            return new OrderHistoryViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(OrderHistoryViewHolder viewHolder, final OrderHistoryItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mOrderHistoryDetailStatus.setText(data.orderHistoryOrderDeliveryStatus);
            viewHolder.mOrderHistoryDetailDate.setText(FrankRossDateUtils.getOrderFormattedDate(data.orderHistoryOrderDate));
            viewHolder.mOrderHistoryDetailsDeliveredBy.setText(data.orderDeliverySlotDate);

            if (data.orderHistoryStatus.equalsIgnoreCase("Complete")) {
                viewHolder.mOrderHistoryDetailImage.setVisibility(View.VISIBLE);
                viewHolder.mOrderHistoryDetailImage.setImageResource(R.mipmap.processing);
            } else if (data.orderHistoryStatus.equalsIgnoreCase("shipped")
                    || data.orderHistoryStatus.equalsIgnoreCase("out_for_delivery")
                    || data.orderHistoryStatus.equalsIgnoreCase("undelivered")) {
                viewHolder.mOrderHistoryDetailImage.setVisibility(View.VISIBLE);
                viewHolder.mOrderHistoryDetailImage.setImageResource(R.mipmap.shipped);
            } else if (data.orderHistoryStatus.equalsIgnoreCase("delivered")) {
                viewHolder.mOrderHistoryDetailStatus.setText(
                        viewHolder.mOrderHistoryDetailStatus.getContext().
                                getString(R.string.order_history_order_date) + " " + FrankRossDateUtils.getFormattedDate(data.orderHistoryOrderDate));
                viewHolder.mOrderHistoryDetailsDeliveredByTxtLinLyt.setVisibility(View.GONE);
                viewHolder.mOrderHistoryDetailDate.setVisibility(View.GONE);
                viewHolder.mOrderHistoryDetailImage.setVisibility(View.VISIBLE);
                viewHolder.mOrderHistoryDetailImage.setImageResource(R.mipmap.delivered);
            } else if (data.orderHistoryStatus.equalsIgnoreCase("cancelled")) {
                viewHolder.mOrderHistoryDetailStatus.setText(
                        viewHolder.mOrderHistoryDetailStatus.getContext().
                                getString(R.string.order_history_order_date) + " " + FrankRossDateUtils.getFormattedDate(data.orderHistoryOrderDate));
                viewHolder.mOrderHistoryDetailDate.setText(data.orderHistoryOrderDeliveryStatus);
                viewHolder.mDeliveredByLinLyt.setVisibility(View.GONE);
            } else if (data.orderHistoryStatus.equalsIgnoreCase("digitization_in_progress") || data.orderHistoryStatus.equalsIgnoreCase("digitisation_mismatch")) {
                viewHolder.mOrderHistoryDetailImage.setVisibility(View.VISIBLE);
                viewHolder.mOrderHistoryDetailImage.setImageResource(R.mipmap.approval);
            } else {
                viewHolder.mOrderHistoryDetailImage.setVisibility(View.GONE);
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_VIEW_TYPE;
        }
    }

    /**
     * ORDER DELIVER TO VIEW TYPE
     */

    public static class OrderHistoryDeliverToItem implements IViewType {

        public String deliverToCustomerName = "";
        public String deliverToCustomerAddress = "";
        public String deliverToCustomerMobileNumber = "";

        @Override
        public int getViewType() {
            return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_DELIVER_TO;
        }
    }

    private static class OrderHistoryDeliverToViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mDeliverToCustomerName;
        private RobotoTextView mDeliverToCustomerAddress;
        private RobotoTextView mDeliverToCustomerMobileNumber;

        public OrderHistoryDeliverToViewHolder(View view) {
            super(view);

            mDeliverToCustomerName = (RobotoTextView) view.findViewById(R.id.order_history_deliver_to_customer_name_tv);
            mDeliverToCustomerAddress = (RobotoTextView) view.findViewById(R.id.order_history_deliver_to_customer_address_tv);
            mDeliverToCustomerMobileNumber = (RobotoTextView) view.findViewById(R.id.order_history_deliver_to_customer_phone_number_tv);
        }
    }

    private class OrderHistoryDeliverToViewHolderType implements RecyclerViewDataBinder<OrderHistoryDeliverToViewHolder,
            OrderHistoryDeliverToItem> {
        @Override
        public OrderHistoryDeliverToViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_history_deliver_to, parent, false);
            return new OrderHistoryDeliverToViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(OrderHistoryDeliverToViewHolder viewHolder, final OrderHistoryDeliverToItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mDeliverToCustomerName.setText(data.deliverToCustomerName);
            viewHolder.mDeliverToCustomerAddress.setText(data.deliverToCustomerAddress);
            viewHolder.mDeliverToCustomerMobileNumber.setText(data.deliverToCustomerMobileNumber);
        }

        @Override
        public int getViewType() {
            return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_DELIVER_TO;
        }
    }

    /**
     * ORDER SHIPPED FROM VIEW TYPE
     */

    public static class OrderHistoryShippedFromItem implements IViewType {

        public String shippedFromCustomerName = "";
        public String shippedFromCustomerAddress = "";
        public String shippedFromCustomerMobileNumber = "";

        @Override
        public int getViewType() {
            return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_SHIPPED_FROM;
        }
    }

    public static class OrderHistoryShippedFromViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mShippedFromCustomerMobileNumber;
        private RobotoTextView mShippedFromCustomerName;
        private RobotoTextView mShippedFromCustomerAddress;

        public OrderHistoryShippedFromViewHolder(View view, Context context) {
            super(view);

            mShippedFromCustomerName = (RobotoTextView) view.findViewById(R.id.order_history_deliver_to_customer_name_tv);
            mShippedFromCustomerAddress = (RobotoTextView) view.findViewById(R.id.order_history_deliver_to_customer_address_tv);
            mShippedFromCustomerMobileNumber = (RobotoTextView) view.findViewById(R.id.order_history_deliver_to_customer_phone_number_tv);
            mShippedFromCustomerMobileNumber.setTextColor(ContextCompat.getColor(context, R.color.pharmacy_dash_board_text_color));
        }
    }

    private class OrderHistoryShippedFromViewHolderType implements RecyclerViewDataBinder<OrderHistoryShippedFromViewHolder,
            OrderHistoryShippedFromItem> {
        @Override
        public OrderHistoryShippedFromViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_history_deliver_to, parent, false);
            return new OrderHistoryShippedFromViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(OrderHistoryShippedFromViewHolder viewHolder, final OrderHistoryShippedFromItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
           /* viewHolder.mShippedFromCustomerName.setText(data.shippedFromCustomerName);
            viewHolder.mShippedFromCustomerAddress.setText(data.shippedFromCustomerAddress);
            viewHolder.mOrderHistoryDrugLicenceNumber.setText(data.shippedFromCustomerMobileNumber);*/
        }

        @Override
        public int getViewType() {
            return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_SHIPPED_FROM;
        }
    }

    /**
     * CANCEL ORDER VIEW TYPE
     */

    public static class CancelOrderDataItem implements IViewType {

        public String footerTxt = "";
        public boolean isPostPaid = false;

        @Override
        public int getViewType() {
            return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_PRODUCT_INFO_FOOTER;
        }
    }

    public static class CancelOrderViewHolder extends RecyclerView.ViewHolder {
        private Button mCancelOrder;

        public CancelOrderViewHolder(View view) {
            super(view);
            mCancelOrder = (Button) view.findViewById(R.id.order_history_re_order_iv);
        }
    }

    private static class CancelOrderViewDataBinder implements
            RecyclerViewDataBinder<CancelOrderViewHolder, CancelOrderDataItem> {

        @Override
        public CancelOrderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_details_re_order, parent, false);
            return new CancelOrderViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(CancelOrderViewHolder viewHolder, final CancelOrderDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mCancelOrder.setText(data.footerTxt);
            if (recyclerViewClickListener != null) {
                viewHolder.mCancelOrder.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_PRODUCT_INFO_FOOTER;
        }
    }

    /**
     * RE ORDER VIEW TYPE
     */
    public static class ReOrderDataItem implements IViewType {

        public ReorderReminderDetails reorderReminderDetails = null;
        public boolean isChecked = false;

        @Override
        public int getViewType() {
            return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_RE_ORDER;
        }
    }

    private static class ReOrderViewHolder extends RecyclerView.ViewHolder {
        private Switch mReOrderBtn;
        private LinearLayout mReorderReminderLinLay;
        private RobotoTextView mReOrderDescription;
        private RobotoTextView mReOrderEdit;
        private RobotoTextView mReOrderNextOn;

        public ReOrderViewHolder(View view) {
            super(view);
            mReOrderBtn = (Switch) view.findViewById(R.id.order_history_re_order_reminder_switch_btn);
            mReorderReminderLinLay = (LinearLayout) view.findViewById(R.id.reorder_reminder_info_layout);
            mReOrderEdit = (RobotoTextView) view.findViewById(R.id.order_history_re_order_reminder_edit_tv);
            mReOrderDescription = (RobotoTextView) view.findViewById(R.id.order_history_re_order_reminder_info_title_tv);
            mReOrderNextOn = (RobotoTextView) view.findViewById(R.id.order_history_re_order_reminder_next_on_tv);

            mReOrderBtn.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                    if (!b) {
                        mReorderReminderLinLay.setVisibility(View.GONE);
                    }
                }
            });
        }
    }

    private static class ReOrderViewDataBinder implements
            RecyclerViewDataBinder<ReOrderViewHolder, ReOrderDataItem> {

        @Override
        public ReOrderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_history_re_order, parent, false);
            return new ReOrderViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final ReOrderViewHolder viewHolder, final ReOrderDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            if (data.reorderReminderDetails != null) {
                viewHolder.mReOrderBtn.setChecked(true);
                viewHolder.mReorderReminderLinLay.setVisibility(View.VISIBLE);
                String descriptionText = "After every " + data.reorderReminderDetails.getReorderReminderDuration()
                        + " " + data.reorderReminderDetails.getReorderReminderUnit();
                viewHolder.mReOrderDescription.setText(descriptionText);

                String nextOn = "Next on " + FrankRossDateUtils.getOrderFormattedDate(data.reorderReminderDetails.getReorderReminderDate());
                viewHolder.mReOrderNextOn.setText(nextOn);
            } else {
                viewHolder.mReOrderBtn.setChecked(false);
                viewHolder.mReorderReminderLinLay.setVisibility(View.GONE);
            }

            if (recyclerViewClickListener != null) {
                viewHolder.mReOrderEdit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
                viewHolder.mReOrderNextOn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
                viewHolder.mReOrderBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        data.isChecked = viewHolder.mReOrderBtn.isChecked();
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_RE_ORDER;
        }
    }

    /**
     * DOCTOR PATIENT INFO VIEW TYPE
     */

    public static class OrderDetailsDoctorPatientInfoDataItem implements IViewType {

        public String doctorName = "";
        public String patientName = "";

        @Override
        public int getViewType() {
            return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_DOCTOR_PATIENT_INFO;
        }
    }

    public static class OrderDetailsDoctorPatientInfoViewHolder extends RecyclerView.ViewHolder {
        private RobotoTextView mDoctorName;
        private RobotoTextView mPatientName;

        private LinearLayout mDoctorInfoLinLay;
        private LinearLayout mPatientInfoLinLay;

        public OrderDetailsDoctorPatientInfoViewHolder(View view) {
            super(view);
            mDoctorName = (RobotoTextView) view.findViewById(R.id.order_history_details_doctor_name_tv);
            mPatientName = (RobotoTextView) view.findViewById(R.id.order_history_details_patient_name_tv);

            mDoctorInfoLinLay = (LinearLayout) view.findViewById(R.id.order_history_details_doctor_view);
            mPatientInfoLinLay = (LinearLayout) view.findViewById(R.id.order_history_details_patient_view);
        }
    }

    private static class OrderDetailsDoctorPatientInfoViewDataBinder implements
            RecyclerViewDataBinder<OrderDetailsDoctorPatientInfoViewHolder, OrderDetailsDoctorPatientInfoDataItem> {

        @Override
        public OrderDetailsDoctorPatientInfoViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_history_details_doctor_patient_info, parent, false);
            return new OrderDetailsDoctorPatientInfoViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(OrderDetailsDoctorPatientInfoViewHolder viewHolder, final OrderDetailsDoctorPatientInfoDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mDoctorName.setText(data.doctorName);
            viewHolder.mPatientName.setText(data.patientName);
            viewHolder.mDoctorInfoLinLay.setVisibility(TextUtils.isEmpty(data.doctorName) ? View.GONE : View.VISIBLE);
            viewHolder.mPatientInfoLinLay.setVisibility(TextUtils.isEmpty(data.patientName) ? View.GONE : View.VISIBLE);
        }

        @Override
        public int getViewType() {
            return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_DOCTOR_PATIENT_INFO;
        }
    }
}