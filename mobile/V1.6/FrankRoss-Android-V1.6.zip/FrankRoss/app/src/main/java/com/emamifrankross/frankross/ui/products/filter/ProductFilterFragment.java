/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.products.filter;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.aloglia.datamodel.AlgoliaProductsFilterInfo;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.ProductFilterAdapter;
import com.emamifrankross.frankross.ui.adapters.ProductSortAdapter;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.FilterSelectionStats;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.Stats;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.pharmacy.ProductListingFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 13/7/15.
 */

/**
 * This class represents the UI for Products filter screen
 */
public class ProductFilterFragment extends BaseFragment implements IToolbar, BaseRecyclerAdapter.RecyclerItemClickListener,
        View.OnClickListener {

    private List<BaseRecyclerAdapter.IViewType> mProductFilterData = new ArrayList<>();
    private ArrayList<BaseRecyclerAdapter.IViewType> brandData = new ArrayList<>();
    private ArrayList<BaseRecyclerAdapter.IViewType> categoryData = new ArrayList<>();
    private ProductFilterAdapter mFilterAdapter;
    private AlgoliaProductsFilterInfo mAlogoliaProductFilterInfo;
    private ProductFilterAdapter.FilterHeaderDataItem brandHeaderDataItem = new ProductFilterAdapter.FilterHeaderDataItem();
    private ProductFilterAdapter.FilterHeaderDataItem categoryHeaderDataItem = new ProductFilterAdapter.FilterHeaderDataItem();
    private IFilterFragmentActionListener mFilterFragmentActionListener;
    private ProductListingFragment.ListingFlow mListingFlow;

    private boolean mIsSingleProduct = false;
    private boolean mIsFilterBrandSelected = false;
    private boolean mIsReset = false;
    private boolean mIsFilterCategorySelected = false;

    public static ProductFilterFragment create(@NonNull AlgoliaProductsFilterInfo algoliaProductFilterInfo,
                                               boolean isSingleProduct, ProductListingFragment.ListingFlow isCategoryFlow) {
        ProductFilterFragment fragment = new ProductFilterFragment();
        fragment.setFilterInfo(algoliaProductFilterInfo, isSingleProduct, isCategoryFlow);

        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            mFilterFragmentActionListener = (IFilterFragmentActionListener) getActivity();
        } catch (ClassCastException classcastException) {
            throw new ClassCastException(context.toString()
                    + " must implement IFilterDetailFragmentActionListener");
        }
    }

    public void setFilterInfo(AlgoliaProductsFilterInfo algoliaProductsFilterInfo, boolean isSingleProduct,
                              ProductListingFragment.ListingFlow isCategoryFlow) {
        mAlogoliaProductFilterInfo = algoliaProductsFilterInfo;
        mIsSingleProduct = isSingleProduct;
        mListingFlow = isCategoryFlow;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setProductFilterData();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_product_filter, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    private void initViews(View view) {
        RecyclerView productFilterRecyclerView = (RecyclerView) view.findViewById(R.id.products_filter_recycler_view);
        Button filterApplyBtn = (Button) view.findViewById(R.id.filter_products_apply_btn);
        Button filterResetBtn = (Button) view.findViewById(R.id.filter_products_reset_btn);

        filterApplyBtn.setOnClickListener(this);
        filterResetBtn.setOnClickListener(this);

        productFilterRecyclerView.setHasFixedSize(false);
        productFilterRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mFilterAdapter = new ProductFilterAdapter(mProductFilterData);
        mFilterAdapter.setRecyclerItemClickListener(this);
        productFilterRecyclerView.setAdapter(mFilterAdapter);
    }

    /**
     * Method populates the Filter Info
     */
    private void setProductFilterData() {
        mFragmentInteractionListener.showBlockingProgressBar();
        new AsyncTask<Void, Void, ArrayList<BaseRecyclerAdapter.IViewType>>() {
            @Override
            protected ArrayList<BaseRecyclerAdapter.IViewType> doInBackground(Void... params) {
                ArrayList<BaseRecyclerAdapter.IViewType> productFilterData = new ArrayList<BaseRecyclerAdapter.IViewType>();

                //Add Category filter
                if (mListingFlow != ProductListingFragment.ListingFlow.CATEGORY_LISTING) {
                    if (mAlogoliaProductFilterInfo != null && mAlogoliaProductFilterInfo.getCategoryStatList() != null
                            && mAlogoliaProductFilterInfo.getCategoryStatList().size() > 1) {
                        categoryHeaderDataItem.filterHeader = getString(R.string.filter_header_category);

                        for (FilterSelectionStats categoryStats : mAlogoliaProductFilterInfo.getCategoryStatList()) {
                            ProductSortAdapter.FilterDetailDataItem brandDataItem = new ProductSortAdapter.FilterDetailDataItem();
                            brandDataItem.detailsDataHeader = categoryStats.getHeader();
                            brandDataItem.isChecked = !mIsReset && categoryStats.isSelected();
                            if (brandDataItem.isChecked && !mIsReset) {
                                mIsFilterCategorySelected = true;
                                categoryHeaderDataItem.selectedCount++;
                            }
                            categoryData.add(brandDataItem);
                        }

                        productFilterData.add(categoryHeaderDataItem);
                    }
                }

                //Add brand filter
                if (mAlogoliaProductFilterInfo != null && mAlogoliaProductFilterInfo.getBrandStatList() != null
                        && mAlogoliaProductFilterInfo.getBrandStatList().size() > 1) {
                    brandHeaderDataItem.filterHeader = getString(R.string.filter_header_brand);

                    for (FilterSelectionStats brandStats : mAlogoliaProductFilterInfo.getBrandStatList()) {
                        ProductSortAdapter.FilterDetailDataItem brandDataItem = new ProductSortAdapter.FilterDetailDataItem();
                        brandDataItem.detailsDataHeader = brandStats.getHeader();
                        brandDataItem.isChecked = !mIsReset && brandStats.isSelected();
                        if (brandDataItem.isChecked && !mIsReset) {
                            mIsFilterBrandSelected = true;
                            brandHeaderDataItem.selectedCount++;
                        }
                        brandData.add(brandDataItem);
                    }

                    productFilterData.add(brandHeaderDataItem);
                }

                //Requirement : If only single product is listed, then do not show the price and discount slider
                if (!mIsSingleProduct) {

                    //Add price slider
                    Stats salesPriceStats = mAlogoliaProductFilterInfo.getSalesPriceStats();
                    if (salesPriceStats != null && salesPriceStats.getMax() > 0) {
                        ProductFilterAdapter.FilterDoubleSeekBarPriceDataItem dataItem =
                                new ProductFilterAdapter.FilterDoubleSeekBarPriceDataItem();
                        dataItem.maxValue = (int) salesPriceStats.getMax();
                        dataItem.minValue = (int) salesPriceStats.getMin();
                        if (mIsReset) {
                            dataItem.selectedMaxValue = (int) salesPriceStats.getMax();
                            dataItem.selectedMinVlaue = (int) salesPriceStats.getMin();
                        } else {
                            dataItem.selectedMaxValue = (int) salesPriceStats.getSelectedMax();
                            dataItem.selectedMinVlaue = (int) salesPriceStats.getSelectedMin();
                        }
                        if (dataItem.maxValue != dataItem.minValue)
                            productFilterData.add(dataItem);
                    }

                    //Add discount slider
                    Stats discountStats = mAlogoliaProductFilterInfo.getDiscountStats();
                    if (discountStats != null && discountStats.getMax() > 0) {
                        ProductFilterAdapter.FilterDoubleSeekBarDiscountDataItem dataItem =
                                new ProductFilterAdapter.FilterDoubleSeekBarDiscountDataItem();
                        dataItem.maxValue = (int) discountStats.getMax();
                        dataItem.minValue = (int) discountStats.getMin();
                        if (mIsReset) {
                            dataItem.selectedMaxValue = (int) discountStats.getMax();
                            dataItem.selectedMinValue = (int) discountStats.getMin();
                        } else {
                            dataItem.selectedMaxValue = (int) discountStats.getSelectedMax();
                            dataItem.selectedMinValue = (int) discountStats.getSelectedMin();
                        }
                        if (dataItem.maxValue != dataItem.minValue)
                            productFilterData.add(dataItem);
                    }
                }

                return productFilterData;
            }

            @Override
            protected void onPostExecute(ArrayList<BaseRecyclerAdapter.IViewType> productFilterData) {
                super.onPostExecute(productFilterData);
                mProductFilterData.clear();
                mProductFilterData.addAll(productFilterData);
                mFilterAdapter.notifyDataSetChanged();
                mFragmentInteractionListener.hideBlockingProgressBar();
            }
        }.execute();
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {
            case ViewTypes.FilterViewType.FILTER_LIST_ITEM:
                loadFilterDetailsFragment(((ProductFilterAdapter.FilterHeaderDataItem) object).filterHeader);
                break;
            default:
                break;
        }
    }

    /**
     * Method launches the Filter sub details screen
     *
     * @param filterHeader the toolbar title for the screen
     */
    private void loadFilterDetailsFragment(String filterHeader) {
        if (filterHeader.contains(getString(R.string.filter_header_brand))) {
            if (!mIsFilterBrandSelected) {
                for (BaseRecyclerAdapter.IViewType brandDataItem : brandData) {
                    if (brandDataItem instanceof ProductSortAdapter.FilterDetailDataItem) {
                        ProductSortAdapter.FilterDetailDataItem brandItem =
                                (ProductSortAdapter.FilterDetailDataItem) brandDataItem;
                        brandItem.isChecked = false;
                    }
                }
            }

            mFragmentInteractionListener.loadFragment(getId(),
                    FilterDetailFragment.create(filterHeader, brandData),
                    null, R.anim.push_left_in, R.anim.fade_out,
                    FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
        } else if (filterHeader.contains(getString(R.string.filter_header_category))) {
            if (!mIsFilterCategorySelected) {
                for (BaseRecyclerAdapter.IViewType categoryDataItem : categoryData) {
                    if (categoryDataItem instanceof ProductSortAdapter.FilterDetailDataItem) {
                        ProductSortAdapter.FilterDetailDataItem categoryItem =
                                (ProductSortAdapter.FilterDetailDataItem) categoryDataItem;
                        categoryItem.isChecked = false;
                    }
                }
            }

            mFragmentInteractionListener.loadFragment(getId(),
                    FilterDetailFragment.create(filterHeader, categoryData),
                    null, R.anim.push_left_in, R.anim.fade_out,
                    FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
        }
    }

    /**
     * Method updates the count of filters applied
     *
     * @param isBrandSelected the flag to identify if the brands are selected
     */
    public void onFilterBrandSelected(boolean isBrandSelected) {
        mIsReset = false;
        if (isBrandSelected) {
            mIsFilterBrandSelected = true;
            brandHeaderDataItem.selectedCount = getSelectedCount(true);
            mFilterAdapter.notifyItemChanged(1);
        } else {
            mIsFilterCategorySelected = true;
            categoryHeaderDataItem.selectedCount = getSelectedCount(false);
            mFilterAdapter.notifyItemChanged(0);
        }
    }

    /**
     * Method to get the count of filters applied on the algolia products
     *
     * @param isBrandSelected the flag to identify if the brands are selected
     * @return the filter count
     */
    private int getSelectedCount(boolean isBrandSelected) {
        int selectedCount = 0;
        if (isBrandSelected) {
            for (BaseRecyclerAdapter.IViewType brandDataItem : brandData) {
                if (brandDataItem instanceof ProductSortAdapter.FilterDetailDataItem) {
                    ProductSortAdapter.FilterDetailDataItem brandItem =
                            (ProductSortAdapter.FilterDetailDataItem) brandDataItem;
                    if (brandItem.isChecked) {
                        selectedCount++;
                    }
                }
            }
        } else {
            for (BaseRecyclerAdapter.IViewType brandDataItem : categoryData) {
                if (brandDataItem instanceof ProductSortAdapter.FilterDetailDataItem) {
                    ProductSortAdapter.FilterDetailDataItem categoryItem =
                            (ProductSortAdapter.FilterDetailDataItem) brandDataItem;
                    if (categoryItem.isChecked) {
                        selectedCount++;
                    }
                }
            }
        }

        return selectedCount;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.filter_products_apply_btn:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.FILTER_APPLY_EVENT);
                onFilterApplied();
                break;
            case R.id.filter_products_reset_btn:
                onResetApplied();
                break;
        }
    }

    /**
     * Method defines the action to be performed when reset is applied
     */
    private void onResetApplied() {
        mProductFilterData.clear();
        mIsFilterBrandSelected = false;
        brandHeaderDataItem.selectedCount = 0;
        brandData.clear();

        mIsFilterCategorySelected = false;
        categoryHeaderDataItem.selectedCount = 0;
        categoryData.clear();

        mIsReset = true;
        setProductFilterData();
    }

    /**
     * Method defines the action to be performed when filter is applied
     */
    private void onFilterApplied() {
        new AsyncTask<Void, Void, AlgoliaProductsFilterInfo>() {
            @Override
            protected AlgoliaProductsFilterInfo doInBackground(Void... params) {
                AlgoliaProductsFilterInfo appliedFilterInfo = new AlgoliaProductsFilterInfo();

                for (BaseRecyclerAdapter.IViewType viewType : mProductFilterData) {
                    if (viewType instanceof ProductFilterAdapter.FilterDoubleSeekBarPriceDataItem) {
                        ProductFilterAdapter.FilterDoubleSeekBarPriceDataItem priceItem =
                                (ProductFilterAdapter.FilterDoubleSeekBarPriceDataItem) viewType;

                        Stats priceStats = new Stats();

                        if (priceItem.minValue != priceItem.selectedMinVlaue ||
                                priceItem.maxValue != priceItem.selectedMaxValue)
                            mIsReset = false;
                        priceStats.setMax(priceItem.maxValue);
                        priceStats.setMin(priceItem.minValue);
                        priceStats.setSelectedMax(priceItem.selectedMaxValue);
                        priceStats.setSelectedMin(priceItem.selectedMinVlaue);

                        appliedFilterInfo.setSalesPriceStats(priceStats);

                    } else if (viewType instanceof ProductFilterAdapter.FilterDoubleSeekBarDiscountDataItem) {
                        ProductFilterAdapter.FilterDoubleSeekBarDiscountDataItem discountItem =
                                (ProductFilterAdapter.FilterDoubleSeekBarDiscountDataItem) viewType;

                        Stats discountStats = new Stats();

                        if (discountItem.minValue != discountItem.selectedMinValue ||
                                discountItem.maxValue != discountItem.selectedMaxValue)
                            mIsReset = false;
                        discountStats.setMax(discountItem.maxValue);
                        discountStats.setMin(discountItem.minValue);
                        discountStats.setSelectedMax(discountItem.selectedMaxValue);
                        discountStats.setSelectedMin(discountItem.selectedMinValue);

                        appliedFilterInfo.setDiscountStats(discountStats);

                    } else if (viewType instanceof ProductFilterAdapter.FilterHeaderDataItem) {

                        if (((ProductFilterAdapter.FilterHeaderDataItem) viewType).
                                filterHeader.equals(getString(R.string.filter_header_category)) && categoryData != null) {
                            List<FilterSelectionStats> categoryStatsList = new ArrayList<>(1);
                            for (BaseRecyclerAdapter.IViewType categoryDataItem : categoryData) {

                                if (categoryDataItem instanceof ProductSortAdapter.FilterDetailDataItem) {
                                    ProductSortAdapter.FilterDetailDataItem categoryItem =
                                            (ProductSortAdapter.FilterDetailDataItem) categoryDataItem;
                                    FilterSelectionStats categoryDataStats = new FilterSelectionStats();
                                    categoryDataStats.setHeader(categoryItem.detailsDataHeader);
                                    categoryDataStats.setIsSelected(categoryItem.isChecked);

                                    categoryStatsList.add(categoryDataStats);
                                }
                            }

                            appliedFilterInfo.setCategoryStatList(categoryStatsList);
                        } else if (((ProductFilterAdapter.FilterHeaderDataItem) viewType).
                                filterHeader.equals(getString(R.string.filter_header_brand)) && brandData != null) {
                            List<FilterSelectionStats> brandStatsList = new ArrayList<>(1);
                            for (BaseRecyclerAdapter.IViewType brandDataItem : brandData) {

                                if (brandDataItem instanceof ProductSortAdapter.FilterDetailDataItem) {
                                    ProductSortAdapter.FilterDetailDataItem brandItem =
                                            (ProductSortAdapter.FilterDetailDataItem) brandDataItem;
                                    FilterSelectionStats brandDataStats = new FilterSelectionStats();
                                    brandDataStats.setHeader(brandItem.detailsDataHeader);
                                    brandDataStats.setIsSelected(brandItem.isChecked);

                                    brandStatsList.add(brandDataStats);
                                }
                            }

                            appliedFilterInfo.setBrandStatList(brandStatsList);
                        }
                    }
                }

                return appliedFilterInfo;
            }

            @Override
            protected void onPostExecute(AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                super.onPostExecute(algoliaProductsFilterInfo);
                if (getActivity() != null && getView() != null) {
                    closeFragment();
                    mFilterFragmentActionListener.onFilterApplied(algoliaProductsFilterInfo, mIsReset);
                }
            }
        }.execute();
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_filter);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    /**
     * Interface definition for a callback to be invoked when filter is applied
     */
    public interface IFilterFragmentActionListener {
        /**
         * Called when user sets reminder to reorder
         *
         * @param appliedFilterInfo the applied filter information
         * @param isReset           true if reset was clicked
         */
        void onFilterApplied(AlgoliaProductsFilterInfo appliedFilterInfo, boolean isReset);
    }
}
