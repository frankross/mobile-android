/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.utils;

import android.app.NotificationManager;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.text.Html;
import android.text.TextUtils;

public class IntentUtils {

    private static final String GOOGLE_MAP_PACKAGE_NAME = "com.google.android.apps.maps";
    private static final String GOOGLE_MAP_CLASS_NAME = "com.google.android.maps.MapsActivity";

    public static void launchPlayStoreToUpdate(Context appContext) {
        final String appPackageName = appContext.getPackageName(); // getPackageName() from Context or Activity object
        Intent updateIntent = new Intent();
        updateIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        updateIntent.setAction(Intent.ACTION_VIEW);
        try {
            updateIntent.setData(Uri.parse("market://details?id=" + appPackageName));
            appContext.startActivity(updateIntent);
        } catch (ActivityNotFoundException activityNotFoundException) {
            updateIntent.setData(Uri.parse("https://play.google.com/store/apps/details?id=" + appPackageName));
            appContext.startActivity(updateIntent);
        }
    }

    public static Intent getEmailIntent(String[] to, String subject, String message) {
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("message/rfc822");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, (to == null) ? new String[]{} : to); // recipients
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, (TextUtils.isEmpty(subject) ? "" : subject));
        emailIntent.putExtra(Intent.EXTRA_TEXT, Html.fromHtml(TextUtils.isEmpty(message) ? "" : message));
        return emailIntent;
    }

    public static void cancelNotification(Context activityContext, int notificationId) {
        if (activityContext == null) {
            return;
        }
        NotificationManager notificationManager = (NotificationManager) activityContext.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel(notificationId);
    }

    public static Intent getCameraLaunchIntent(Uri imageUri) {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        intent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);

        return intent;
    }

    public static Intent getGalleryLaunchIntent() {
        return new Intent(Intent.ACTION_PICK,
                android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
    }

    /**
     * Method that generates android's Standard navigation intent
     *
     * @param sourceLatitude       the source latitude
     * @param sourceLongitude      the source longitude
     * @param destinationLatitude  the destination latitude
     * @param destinationLongitude the destination longitude
     * @return the Google map navigation intent
     */
    public static Intent getNavigationIntent(double sourceLatitude, double sourceLongitude,
                                             double destinationLatitude, double destinationLongitude) {
        String link = "https://maps.google.com/maps?saddr=" + sourceLatitude + "," + sourceLongitude +
                "&daddr=" + destinationLatitude + "," + destinationLongitude + "&directionsmode=driving";
        Intent googleMapIntent = new Intent(android.content.Intent.ACTION_VIEW, Uri.parse(link));
        googleMapIntent.setClassName(GOOGLE_MAP_PACKAGE_NAME, GOOGLE_MAP_CLASS_NAME);

        return googleMapIntent;
    }

    /**
     * Method that generates android's Standard Call intent
     *
     * @param phoneNumber the phone number to which the call has to be made
     * @return the call intent
     */
    public static Intent getCallIntent(String phoneNumber) {
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:" + Uri.encode(phoneNumber)));

        return callIntent;
    }

    /**
     * Method that generates android's Standard Share intent if the share extension is not empty
     *
     * @param shareExtensionPackageName the share extension package name through which the content has to be shared
     * @param shareSubject              the share subject (Default android behaviour :
     *                                  This will be set to the share extension only if it is a mail client)
     * @param shareMessage              the share body/message
     * @return the share intent
     */
    public static Intent getOrderSuccessScreenSocialSharableIntent(String shareExtensionPackageName,
                                                                   String shareSubject,
                                                                   String shareMessage) {
        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("text/plain");
        if (!TextUtils.isEmpty(shareExtensionPackageName))
            shareIntent.setPackage(shareExtensionPackageName);
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, shareSubject);
        shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
        return shareIntent;
    }
}
