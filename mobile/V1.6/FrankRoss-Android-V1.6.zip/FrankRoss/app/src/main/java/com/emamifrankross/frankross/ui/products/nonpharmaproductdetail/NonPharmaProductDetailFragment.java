/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.products.nonpharmaproductdetail;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiNonPharmaProduct;
import com.emamifrankross.frankross.core.apimodels.ApiNotifyMe;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.BranchManager;
import com.emamifrankross.frankross.sdkmanager.FacebookManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.NonPharmaProductDetailAdapter;
import com.emamifrankross.frankross.ui.adapters.PharmaProductDetailAdapter;
import com.emamifrankross.frankross.ui.adapters.VariantSelectionAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.products.AddToCartDialogFragment;
import com.emamifrankross.frankross.ui.products.ProductDetailsBaseFragment;
import com.emamifrankross.frankross.ui.products.notify.NotifyMeDialogFragment;
import com.emamifrankross.frankross.ui.products.notify.NotifyMeSuccessDialogFragment;
import com.emamifrankross.frankross.ui.products.pharmaproductdetail.QuestionAndAnswerFragment;
import com.emamifrankross.frankross.ui.support.SupportActivity;
import com.emamifrankross.frankross.ui.viewmodels.ProductDataModel;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderItem;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.NetworkUtils;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by gauthami on 9/7/15.
 */

/**
 * This class represents the UI for Non pharma product detail
 */
public class NonPharmaProductDetailFragment extends ProductDetailsBaseFragment implements
        BaseRecyclerAdapter.RecyclerItemClickListener {

    private static final String TAG = NonPharmaProductDetailFragment.class.getSimpleName();
    private static final String BUNDLE_KEY_VARIANT_ID = "bundle_key_variant_id";
    private static final int INDEX_PRIMARY_VARIANT = 3;

    private long mVariantId;
    private boolean mIsAvailable = false;
    private boolean mIsNotifyMe = false;
    private boolean isSecondaryVariantExits = false;
    private String mSelectedPrimaryVariantValue = "";
    private String mSelectedSecondaryVariantValue = "";

    private NonPharmaProductDetailAdapter mNonPharmaProductDetailAdapter;
    private List<BaseRecyclerAdapter.IViewType> mNonPharmaProductDetailData = new ArrayList<>();
    private List<ApiNonPharmaProduct.Combination> mCombinationList = new ArrayList<>(1);
    private NonPharmaProductDetailAdapter.ProductVariantDataItem mSecondaryVariationTheme;
    private NonPharmaProductDetailAdapter.ProductVariantDataItem mPrimaryVariationTheme;
    private ApiNonPharmaProduct mNonPharmaProductDetail;

    public static NonPharmaProductDetailFragment create(long variantId) {
        NonPharmaProductDetailFragment fragment = new NonPharmaProductDetailFragment();
        Bundle bundle = new Bundle();
        bundle.putLong(BUNDLE_KEY_VARIANT_ID, variantId);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null)
            mVariantId = getArguments().getLong(BUNDLE_KEY_VARIANT_ID, 0);
        mNonPharmaProductDetailAdapter = new NonPharmaProductDetailAdapter(mNonPharmaProductDetailData);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.NON_PHARMA_PDP_VISIT_EVENT);
        getAdapterData();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    private void initViews(View view) {
        RecyclerView nonPharmaProductDetailRecyclerView = (RecyclerView) view.findViewById(R.id.product_detail_recycler_view);
        nonPharmaProductDetailRecyclerView.setHasFixedSize(false);
        nonPharmaProductDetailRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mNonPharmaProductDetailAdapter.setRecyclerItemClickListener(this);
        nonPharmaProductDetailRecyclerView.setAdapter(mNonPharmaProductDetailAdapter);
        mAddToCartLayout.setVisibility(mNonPharmaProductDetailData.size() > 0 ? View.VISIBLE : View.GONE);
        setAddToCartBtnState();
    }

    /**
     * Method that populates the Non pharma product detail screen data
     */
    private void getAdapterData() {
        if (NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
            getNonPharmaProductDetails();
        } else {
            showAlert(getString(R.string.please_check_your_network_connection));
        }
    }

    /**
     * Method that requests for Non Pharma product info
     */
    private void getNonPharmaProductDetails() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetNonPharmaProductDetailsRequest(mVariantId, new ApiRequestManager.IGetNonPharmaProductDetailResultNotifier() {

            @Override
            public void onNonPharmaProductDetailFetched(ApiNonPharmaProduct nonPharmaProductDetail) {
                if (isAdded())
                    getNonPharmaProductDetailAdapterData(nonPharmaProductDetail);
            }
        }, this, this);
    }

    /**
     * Method populates the data for Non Pharma product details
     */
    private void getNonPharmaProductDetailAdapterData(final ApiNonPharmaProduct nonPharmaProductDetail) {
        new AsyncTask<Void, Void, ArrayList<BaseRecyclerAdapter.IViewType>>() {
            @Override
            protected ArrayList<BaseRecyclerAdapter.IViewType> doInBackground(Void... params) {
                ArrayList<BaseRecyclerAdapter.IViewType> nonPharmaDetailData = new ArrayList<BaseRecyclerAdapter.IViewType>();

                /**
                 * Product details : Product name, Brand name, Sales price , Promotional price,
                 * Offer price and the product availability status
                 */
                NonPharmaProductDetailAdapter.ProductDetailsDataItem item =
                        new NonPharmaProductDetailAdapter.ProductDetailsDataItem();
                item.mNonPharmaProduct = nonPharmaProductDetail;
                mNonPharmaProductDetail = nonPharmaProductDetail;
                mIsAvailable = nonPharmaProductDetail.isAvailable();
                mIsNotifyMe = nonPharmaProductDetail.isNotifyMe();
                nonPharmaDetailData.add(item);

                /**
                 * Product image(s)
                 */
                NonPharmaProductDetailAdapter.NonPharmaProductImageViewPagerDataItem imageUrlsItem =
                        new NonPharmaProductDetailAdapter.NonPharmaProductImageViewPagerDataItem();
                imageUrlsItem.mNonPharmaProductImagePagerDataList = nonPharmaProductDetail.getProductImageUrls();
                nonPharmaDetailData.add(imageUrlsItem);

                nonPharmaDetailData.add(new RecyclerBorderItem(1));
                //Variants list
                mCombinationList.addAll(nonPharmaProductDetail.getVariationCombination());

                if (nonPharmaProductDetail.getVariationThemes() != null && nonPharmaProductDetail.getVariationThemes().size() > 0) {

                    if (nonPharmaProductDetail.getVariationThemes().get(0) != null
                            && nonPharmaProductDetail.getVariationThemes().get(0).getSupportedValues().size() > 0) {
                        addVariant(true, nonPharmaProductDetail.getVariationThemes().get(0), nonPharmaDetailData);
                    }

                    if (nonPharmaProductDetail.getVariationThemes().size() > 1
                            && nonPharmaProductDetail.getVariationThemes().get(1).getSupportedValues().size() > 0) {
                        isSecondaryVariantExits = true;
                        addVariant(false, nonPharmaProductDetail.getVariationThemes().get(1), nonPharmaDetailData);
                    }
                }

                /**
                 * Product Key feature(s)
                 */
                if (nonPharmaProductDetail.getKeyFeatures().size() > 0 && isAdded()) {
                    NonPharmaProductDetailAdapter.KeyFeaturesHeaderDataItem keyFeaturesHeaderDataItem =
                            new NonPharmaProductDetailAdapter.KeyFeaturesHeaderDataItem();
                    keyFeaturesHeaderDataItem.headerTitle = getString(R.string.non_pharma_header_key_features);
                    nonPharmaDetailData.add(keyFeaturesHeaderDataItem);

                    for (String keyFeature : nonPharmaProductDetail.getKeyFeatures()) {
                        NonPharmaProductDetailAdapter.KeyFeaturesDataItem keyFeaturesItem =
                                new NonPharmaProductDetailAdapter.KeyFeaturesDataItem();
                        keyFeaturesItem.keyFeature = keyFeature;
                        nonPharmaDetailData.add(keyFeaturesItem);
                    }
                }

                /**
                 * Product description with the ellipsize of max lines limited to 3;On clicking which,
                 * user will be navigated to detail description page
                 */
                if (!TextUtils.isEmpty(nonPharmaProductDetail.getProductDescription()) && isAdded()) {
                    PharmaProductDetailAdapter.QuestionAnswerViewDataItem descriptionItem =
                            new PharmaProductDetailAdapter.QuestionAnswerViewDataItem();
                    descriptionItem.question = getString(R.string.non_pharma_header_product_description);
                    descriptionItem.answer = nonPharmaProductDetail.getProductDescription();
                    nonPharmaDetailData.add(descriptionItem);
                }

                /**
                 * Product specification(s) : similar to Product key feature(s)
                 */
                if (nonPharmaProductDetail.getSpecifications().size() > 0 && isAdded()) {

                    nonPharmaDetailData.add(new RecyclerBorderItem(1));

                    NonPharmaProductDetailAdapter.KeyFeaturesHeaderDataItem keyFeaturesHeaderDataItem =
                            new NonPharmaProductDetailAdapter.KeyFeaturesHeaderDataItem();
                    keyFeaturesHeaderDataItem.headerTitle = getString(R.string.non_pharma_header_specs);
                    nonPharmaDetailData.add(keyFeaturesHeaderDataItem);

                    for (String specs : nonPharmaProductDetail.getSpecifications()) {
                        NonPharmaProductDetailAdapter.KeyFeaturesDataItem keyFeaturesItem =
                                new NonPharmaProductDetailAdapter.KeyFeaturesDataItem();
                        keyFeaturesItem.keyFeature = specs;
                        nonPharmaDetailData.add(keyFeaturesItem);
                    }

                    nonPharmaDetailData.add(new RecyclerBorderItem(1));
                }

                return nonPharmaDetailData;
            }

            @Override
            protected void onPostExecute(ArrayList<BaseRecyclerAdapter.IViewType> nonPharmaDetailData) {
                super.onPostExecute(nonPharmaDetailData);
                mNonPharmaProductDetailData.clear();
                mNonPharmaProductDetailData.addAll(nonPharmaDetailData);
                mNonPharmaProductDetailAdapter.notifyDataSetChanged();
                mFragmentInteractionListener.hideBlockingProgressBar();
                if (mNonPharmaProductDetailData.size() > 0)
                    mAddToCartLayout.setVisibility(View.VISIBLE);
                setAddToCartBtnState();
            }
        }.execute();
    }

    /**
     * Method to add the Variant information
     *
     * @param isPrimary           identifies if primary variant
     * @param variationTheme      the variation theme
     * @param nonPharmaDetailData the request data to be mapped to UI list
     */
    private void addVariant(boolean isPrimary, ApiNonPharmaProduct.VariationTheme variationTheme,
                            ArrayList<BaseRecyclerAdapter.IViewType> nonPharmaDetailData) {
        NonPharmaProductDetailAdapter.ProductVariantDataItem variant =
                new NonPharmaProductDetailAdapter.ProductVariantDataItem();
        variant.isPrimaryVariant = isPrimary;
        variant.variantName = variationTheme.getVariantDisplayName();
        if (isPrimary) {
            mPrimaryVariationTheme = variant;
            mSelectedPrimaryVariantValue = variationTheme.getSupportedValues().get(0);
            variant.variantValue = mSelectedPrimaryVariantValue;
        } else {
            mSecondaryVariationTheme = variant;
            mSelectedSecondaryVariantValue = getSupportedSecondaryVariantValue(
                    variationTheme.getSupportedValues(), mSelectedPrimaryVariantValue);
            variant.variantValue = mSelectedSecondaryVariantValue;
        }

        List<BaseRecyclerAdapter.IViewType> variantSelectionItems = new ArrayList<BaseRecyclerAdapter.IViewType>();
        for (String supportedValues : variationTheme.getSupportedValues()) {
            VariantSelectionAdapter.VariantSelectionItem variantItem =
                    new VariantSelectionAdapter.VariantSelectionItem();
            variantItem.variantName = supportedValues;
            if (isPrimary) {
                variantItem.state = (variantItem.variantName.equals(mSelectedPrimaryVariantValue))
                        ? VariantSelectionAdapter.VariantStates.SELECTED :
                        VariantSelectionAdapter.VariantStates.UNSELECTED;
            } else {
                variantItem.state = (variantItem.variantName.equals(mSelectedSecondaryVariantValue))
                        ? VariantSelectionAdapter.VariantStates.SELECTED :
                        VariantSelectionAdapter.VariantStates.UNSELECTED;
            }

            variantSelectionItems.add(variantItem);
        }

        variant.mVariantSupportedValues = variantSelectionItems;
        nonPharmaDetailData.add(variant);
        nonPharmaDetailData.add(new RecyclerBorderItem(1));
    }

    /**
     * Method to get the supported secondary variant value
     *
     * @param supportedValues        the supported values
     * @param selectedPrimaryVariant the selected primary variant
     * @return empty or the supported secondary value
     */
    private String getSupportedSecondaryVariantValue(List<String> supportedValues, String selectedPrimaryVariant) {
        for (String secondaryVariantValue : supportedValues) {
            for (ApiNonPharmaProduct.Combination combination : mCombinationList) {
                if (combination.getPrimaryVariantValue().equals(selectedPrimaryVariant) &&
                        combination.getSecondaryVariantValue().equals(secondaryVariantValue)) {
                    return secondaryVariantValue;
                }
            }
        }

        return "";
    }

    /**
     * Method to set the visibility state of Add to Cart button on the basis of product availability
     */
    private void setAddToCartBtnState() {
        if (mIsAvailable) {
            mAddToCart.setEnabled(true);
            mAddToCart.setTextColor(ContextCompat.getColor(getActivity(), R.color.white_background));
            mAddToCart.setText(getResources().getString(R.string.product_detail_add_to_cart_button_title));
        } else if (mIsNotifyMe) {
            mAddToCart.setEnabled(true);
            mAddToCart.setTextColor(ContextCompat.getColor(getActivity(), R.color.white_background));
            mAddToCart.setText(getResources().getString(R.string.product_detail_notify_me_button_title));
        }
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {
            case ViewTypes.CommonViewType.PRODUCT_ITEM:
                handleProductItemClick(object);
                break;

            case ViewTypes.ProductDetailViewType.QUESTION_AND_ANSWER:
                loadQuestionAndAnswerFragment((PharmaProductDetailAdapter.QuestionAnswerViewDataItem) object);
                break;

            case ViewTypes.ProductDetailViewType.PRODUCT_VARIANTS:
                showVariantDialog(object);
                break;
        }
    }

    /**
     * Method pops up the Variant selection dialog
     *
     * @param object the product variants data item object
     */
    private void showVariantDialog(Object object) {
        NonPharmaProductDetailAdapter.ProductVariantDataItem variantDataItem =
                (NonPharmaProductDetailAdapter.ProductVariantDataItem) object;
        List<BaseRecyclerAdapter.IViewType> variantSelectionItems = variantDataItem.mVariantSupportedValues;

        if (variantSelectionItems != null && variantSelectionItems.size() > 1) {
            if (variantDataItem.isPrimaryVariant) {
                VariantsDialogFragment variantsDialogFragment = new VariantsDialogFragment();
                variantsDialogFragment.create(variantDataItem.variantName, variantSelectionItems, true);
                variantsDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
            } else {
                if (variantSelectionItems.size() > 1) {

                    for (BaseRecyclerAdapter.IViewType selectionItem : variantSelectionItems) {
                        VariantSelectionAdapter.VariantSelectionItem selectionVariantItem =
                                (VariantSelectionAdapter.VariantSelectionItem) selectionItem;
                        selectionVariantItem.state = (!isSupportedSecondaryVariantValue(selectionVariantItem.variantName))
                                ? VariantSelectionAdapter.VariantStates.NOT_AVAILABLE : selectionVariantItem.state;
                    }

                    VariantsDialogFragment variantsDialogFragment = new VariantsDialogFragment();
                    variantsDialogFragment.create(variantDataItem.variantName, variantDataItem.mVariantSupportedValues, false);
                    variantsDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
                }
            }
        }
    }

    private boolean isSupportedSecondaryVariantValue(String secondaryVariantName) {

        for (ApiNonPharmaProduct.Combination combination : mCombinationList) {
            if (combination.getPrimaryVariantValue().equals(mSelectedPrimaryVariantValue) &&
                    combination.getSecondaryVariantValue().equals(secondaryVariantName)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Method to check if the variant is selected
     *
     * @param selectionItem the selected variant
     * @param isPrimaryItem if selected variant is the primary variant then true
     */
    public void onVariantSelected(VariantSelectionAdapter.VariantSelectionItem selectionItem, boolean isPrimaryItem) {
        if (isPrimaryItem) {
            mSelectedPrimaryVariantValue = selectionItem.variantName;

            if (isSecondaryVariantExits) {
                notifySelectedPrimaryValue();
                updatePrimaryVariantSelectionValue();

                if (isSupportedSecondaryVariantValue(mSelectedSecondaryVariantValue)) {
                    long variantId = getVariantId(mSelectedPrimaryVariantValue, mSelectedSecondaryVariantValue);
                    fetchProductDetails(variantId);
                } else {
                    List<BaseRecyclerAdapter.IViewType> variantSelectionItems = mSecondaryVariationTheme.mVariantSupportedValues;

                    String defaultSelectedValue = "";
                    for (BaseRecyclerAdapter.IViewType variantSelectionItem : variantSelectionItems) {
                        VariantSelectionAdapter.VariantSelectionItem selectionVariantItem =
                                (VariantSelectionAdapter.VariantSelectionItem) variantSelectionItem;

                        if (isSupportedSecondaryVariantValue(selectionVariantItem.variantName)) {
                            if (TextUtils.isEmpty(defaultSelectedValue)) {
                                defaultSelectedValue = selectionVariantItem.variantName;
                                selectionVariantItem.state = VariantSelectionAdapter.VariantStates.SELECTED;
                            } else {
                                selectionVariantItem.state = VariantSelectionAdapter.VariantStates.UNSELECTED;
                            }
                        } else {
                            selectionVariantItem.state = VariantSelectionAdapter.VariantStates.NOT_AVAILABLE;
                        }
                    }

                    mSelectedSecondaryVariantValue = (TextUtils.isEmpty(defaultSelectedValue))
                            ? mSelectedSecondaryVariantValue : defaultSelectedValue;

                    VariantsDialogFragment variantsDialogFragment = new VariantsDialogFragment();
                    variantsDialogFragment.create(mSecondaryVariationTheme.variantName,
                            mSecondaryVariationTheme.mVariantSupportedValues, false);
                    variantsDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
                }
            } else {
                long variantId = getVariantId(mSelectedPrimaryVariantValue, "");
                fetchProductDetails(variantId);
            }
        } else {
            mSelectedSecondaryVariantValue = selectionItem.variantName;
            long variantId = getVariantId(mSelectedPrimaryVariantValue, mSelectedSecondaryVariantValue);
            fetchProductDetails(variantId);
        }
    }

    /**
     * Method that receives the callback on Variants dialog dismissal
     *
     * @param isPrimaryVariant if there is any Primary variant then,select it by default;else show empty text
     */
    public void onVariantDialogDismissed(boolean isPrimaryVariant) {
        if (!isPrimaryVariant) {
            long variantId = getVariantId(mSelectedPrimaryVariantValue, mSelectedSecondaryVariantValue);
            if (mVariantId != 0 && mVariantId != variantId) {
                fetchProductDetails(variantId);
            }
        }
    }

    /**
     * Method that updates the primary variant for that product
     */
    private void updatePrimaryVariantSelectionValue() {
        List<BaseRecyclerAdapter.IViewType> primaryVariantSelectionItems = mPrimaryVariationTheme.mVariantSupportedValues;
        for (BaseRecyclerAdapter.IViewType variantSelectionItem : primaryVariantSelectionItems) {
            VariantSelectionAdapter.VariantSelectionItem selectionVariantItem =
                    (VariantSelectionAdapter.VariantSelectionItem) variantSelectionItem;
            selectionVariantItem.state = (selectionVariantItem.variantName.equals(mSelectedPrimaryVariantValue))
                    ? VariantSelectionAdapter.VariantStates.SELECTED : VariantSelectionAdapter.VariantStates.UNSELECTED;
        }
    }

    private void notifySelectedPrimaryValue() {
        BaseRecyclerAdapter.IViewType primaryVariantUIData = mNonPharmaProductDetailData.get(INDEX_PRIMARY_VARIANT);
        if (primaryVariantUIData instanceof NonPharmaProductDetailAdapter.ProductVariantDataItem) {
            NonPharmaProductDetailAdapter.ProductVariantDataItem productVariantDataItem =
                    (NonPharmaProductDetailAdapter.ProductVariantDataItem) primaryVariantUIData;
            productVariantDataItem.variantValue = mSelectedPrimaryVariantValue;
            mNonPharmaProductDetailAdapter.notifyItemChanged(INDEX_PRIMARY_VARIANT);
        }
    }

    private long getVariantId(String primaryVariantName, String secondaryVariantName) {
        for (ApiNonPharmaProduct.Combination combination : mCombinationList) {
            if (!isSecondaryVariantExits) {
                if (primaryVariantName.equals(combination.getPrimaryVariantValue())) {
                    return combination.getProductId();
                }
            } else {
                if (primaryVariantName.equals(combination.getPrimaryVariantValue())
                        && secondaryVariantName.equals(combination.getSecondaryVariantValue())) {
                    return combination.getProductId();
                }
            }
        }
        Toast.makeText(getActivity(), "Variant Logical Error", Toast.LENGTH_SHORT).show();
        return 0;
    }

    private void fetchProductDetails(long variantId) {
        mFragmentInteractionListener.showBlockingProgressBar();
        isSecondaryVariantExits = false;
        mSelectedPrimaryVariantValue = "";
        mSelectedSecondaryVariantValue = "";
        mCombinationList.clear();
        mNonPharmaProductDetailData.clear();
        mNonPharmaProductDetailAdapter.notifyDataSetChanged();
        mFragmentInteractionListener.hideBlockingProgressBar();
        mVariantId = variantId;
        getAdapterData();
    }


    private void handleProductItemClick(Object object) {
        ProductDataModel dataModel = (ProductDataModel) object;
        mFragmentInteractionListener.loadFragment(getId(),
                NonPharmaProductDetailFragment.create(dataModel.productId),
                null, R.anim.push_left_in, R.anim.push_left_out,
                FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    /**
     * Method loads a screen where detailed answer will be displayed
     */
    private void loadQuestionAndAnswerFragment(PharmaProductDetailAdapter.QuestionAnswerViewDataItem object) {
        mFragmentInteractionListener.loadFragment(getId(),
                QuestionAndAnswerFragment.create(object.question, object.answer),
                null, R.anim.push_left_in, R.anim.fade_out,
                FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    /**
     * Method that requests for adding a product to the cart;If success, displays the success msg
     */
    public void performAddToCartRequest(int cartQuantity) {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performAddCartRequest(mVariantId, cartQuantity, new ApiRequestManager.IAddCartResultNotifier() {

            @Override
            public void onProductAdded() {
                if (isAdded()) {
                    FacebookManager.logFacebookAddToCartEvent(getActivity(), mNonPharmaProductDetail.getProductName(),
                            mVariantId + "", getString(R.string.facebook_events_parameter_currency));
                    FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ADD_TO_CART_FROM_PDP);
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    Toast.makeText(getActivity().getApplicationContext(),
                            getString(R.string.add_to_cart_success_msg), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onProductAddFailed() {
                mFragmentInteractionListener.hideBlockingProgressBar();
                if (isAdded())
                    Toast.makeText(getActivity().getApplicationContext(),
                            getString(R.string.add_to_cart_failure_msg), Toast.LENGTH_SHORT).show();
            }
        }, this, this);
    }

    /**
     * Method that receives the callback from parent activity on notify me to the entered mobile number Done tap
     *
     * @param mobileNumber the mobile number to which the product related notification/sms will be sent
     */
    public void performNotifyMeNonSignedInUserRequest(String mobileNumber) {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performNotifyMeNonSignedInUserRequest(mVariantId, mobileNumber,
                new ApiRequestManager.INotifyMeNonSignedInUserResultNotifier() {
                    @Override
                    public void onNotifyMeNonSignedInUserRequestResultFetched(
                            ApiNotifyMe.Response apiNotifyMeNonSignedInUser) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.NOTIFY_ME_CONFIRM_TAP_EVENT);
                        showNotifyMeSuccessDialog();
                    }

                    @Override
                    public void onNotifyMeNonSignedInUserError(String errorMessage) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        showAlert(errorMessage);
                    }
                }, this, this);
    }

    /**
     * Method that requests for signed in users notify me
     */
    private void performNotifyMeSignedInUserRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performNotifyMeSignedInUserRequest(mVariantId,
                new ApiRequestManager.INotifyMeSignedInUserResultNotifier() {
                    @Override
                    public void onNotifyMeSignedInUserRequestResultFetched(
                            ApiNotifyMe.Response apiNotifyMeSignedInUser) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.NOTIFY_ME_CONFIRM_TAP_EVENT);
                        showNotifyMeSuccessDialog();
                    }

                    @Override
                    public void onNotifyMeSignedInUserError(String errorMessage) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        showAlert(errorMessage);
                    }
                }, this, this);
    }

    /**
     * Method that displays the Notify me dialog when product is inactive
     */
    private void showNotifyMeViaMobileNumberDialog() {
        try {
            NotifyMeDialogFragment notifyMeDialogFragment = new NotifyMeDialogFragment();
            notifyMeDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
        } catch (IllegalStateException illegalStateException) {
            //Not to instantiate a fragment onSavedInstance
        }
    }

    /**
     * Method that displays the Notify me success dialog
     */
    private void showNotifyMeSuccessDialog() {
        try {
            NotifyMeSuccessDialogFragment notifyMeSuccessDialogFragment = new NotifyMeSuccessDialogFragment();
            notifyMeSuccessDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
        } catch (IllegalStateException illegalStateException) {
            //Not to instantiate a fragment onSavedInstance
        }
    }

    @Override
    protected void onNotifyMeClicked() {
        super.onNotifyMeClicked();
        if (TextUtils.isEmpty(Utils.getUserID(getActivity().getApplicationContext()))) {
            showNotifyMeViaMobileNumberDialog();
        } else {
            performNotifyMeSignedInUserRequest();
        }
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.NOTIFY_ME_TAP_EVENT,
                Utils.notifyMeClickDataForAnalytics(!TextUtils.isEmpty(Utils.getUserID(getActivity().getApplicationContext()))));
    }

    @Override
    public void onAddToCartClicked() {
        super.onAddToCartClicked();
        if (NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
            if (mNonPharmaProductDetail != null) {
                mApiRequestManager.getCartItemQuantity(mNonPharmaProductDetail.getId(), new ApiRequestManager.IGetCartItemQuantityListener() {
                    @Override
                    public void cartItemQuantity(int quantity) {
                        if (quantity == 0) {
                            quantity = 1;
                        }

                        AddToCartDialogFragment addToCartDialogFragment = new AddToCartDialogFragment();
                        addToCartDialogFragment.create("",
                                mNonPharmaProductDetail.getMaxOrderableQuantity(), quantity);
                        addToCartDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
                    }
                });
            }
        } else {
            showAlert(getString(R.string.please_check_your_network_connection));
        }

       /* if (NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
            mApiRequestManager.getCartItemQuantity(mVariantId, new ApiRequestManager.IGetCartItemQuantityListener() {
                @Override
                public void cartItemQuantity(int quantity) {
                    if (quantity >= 0) {
                        quantity++;
                    } else {
                        quantity = 1;
                    }

                    if (quantity <= mMaxOrderableQty) {
                        performAddToCartRequest(quantity);
                    } else {
                        performAddToCartRequest(mMaxOrderableQty);
                    }
                }
            });
        } else {
            showAlert(getString(R.string.please_check_your_network_connection));
        }*/
    }

    @Override
    public void onSupportClicked() {
        super.onSupportClicked();
        startActivity(SupportActivity.getActivityIntent(getActivity().getApplicationContext()));
    }

    @Override
    protected void onCartClicked() {
        Map<String, String> cartClickData = Utils.cartToolbarClickDataForAnalytics(Constants.NON_PHARMA_PDP_SCREEN_NAME,
                FrankRossEvents.VIEW_CART_FROM_TOOLBAR_SCREEN_NAME);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_CART_FROM_TOOLBAR_EVENT, cartClickData);
        super.onCartClicked();
    }

    @Override
    protected void onProductDetailShareClicked() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PDP_SHARING_TAP_EVENT);
        if (NetworkUtils.isNetworkConnected(getActivity())) {

            String pdpShareSubject = mApiRequestManager.getSettingsResponse().getPdpShareSubject();
            String pdpShareText = mApiRequestManager.getSettingsResponse().getPdpShareText();

            String title = "";
            String description = "";
            String image_url = "";

            if (mNonPharmaProductDetail != null) {
                title = mNonPharmaProductDetail.getProductName();
                description = mNonPharmaProductDetail.getProductDescription();

                if (!mNonPharmaProductDetail.getProductImageUrls().isEmpty()) {
                    image_url = mNonPharmaProductDetail.getProductImageUrls().get(0);
                    image_url = image_url.replaceFirst("/normal/", "/small/");
                }
            }
            if (pdpShareSubject.contains(getResources().getString(R.string.settings_product_name_placeholder)))
                pdpShareSubject = pdpShareSubject.replaceAll(getResources().getString(R.string.settings_product_name_placeholder),
                        mNonPharmaProductDetail.getProductName());
            if (pdpShareText.contains(getResources().getString(R.string.settings_product_name_placeholder)))
                pdpShareText = pdpShareText.replaceAll(getResources().getString(R.string.settings_product_name_placeholder),
                        mNonPharmaProductDetail.getProductName());
            if (pdpShareText.contains(getString(R.string.settings_link_name_placeholder)))
                pdpShareText = pdpShareText.replaceAll(getResources().getString(R.string.settings_link_name_placeholder), "");

            BranchManager.showBranchShareSheetForPdp(getActivity(),
                    pdpShareSubject,
                    pdpShareText,
                    mVariantId, getString(R.string.non_pharma_product_share_using_branch), title, description, image_url);
        } else {
            showAlert(getString(R.string.no_connection_error));
        }
        super.onProductDetailShareClicked();
    }
}
