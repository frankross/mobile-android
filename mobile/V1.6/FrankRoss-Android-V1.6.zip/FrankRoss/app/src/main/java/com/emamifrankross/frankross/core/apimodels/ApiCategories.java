/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 17/7/15.
 */
public class ApiCategories {

    public static class Response {

        private List<BaseRecyclerAdapter.IViewType> uiDataList;

        private Category mOtcMedicine;

        private Category mMedicalAidsMedicine;

        @SerializedName("categories")
        private List<Category> categories;

        public List<Category> getCategories() {
            return categories;
        }

        public void setCategories(List<Category> categories) {
            this.categories = categories;
        }

        public List<BaseRecyclerAdapter.IViewType> getUiDataList() {
            return uiDataList;
        }

        public void setUiDataList(List<BaseRecyclerAdapter.IViewType> uiDataList) {
            this.uiDataList = uiDataList;
        }

        public Category getOtcMedicine() {
            return mOtcMedicine;
        }

        public void setOtcMedicine(Category otcMedicine) {
            this.mOtcMedicine = otcMedicine;
        }

        public Category getMedicalAidsMedicine() {
            return mMedicalAidsMedicine;
        }

        public void setMedicalAidsMedicine(Category medicalAidsMedicine) {
            this.mMedicalAidsMedicine = medicalAidsMedicine;
        }
    }

    public static class HomeCategoryResponse {
        private List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>(1);

        @SerializedName("categories")
        private List<HomeFeaturedCategory> homeFeaturedCategories = new ArrayList<>(1);

        @SerializedName("promotions")
        private List<Promotion> promotions = new ArrayList<>(1);

        public List<BaseRecyclerAdapter.IViewType> getUiDataList() {
            return uiDataList;
        }

        public List<Promotion> getPromotions() {
            return promotions;
        }

        public List<HomeFeaturedCategory> getHomeFeaturedCategories() {
            return homeFeaturedCategories;
        }

        public void setUiDataList(ArrayList<BaseRecyclerAdapter.IViewType> homeScreenUiData) {
            uiDataList = homeScreenUiData;
        }
    }

    public static class BaseCategoryResponse {

        private List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>(1);

        @SerializedName("categories")
        private List<BaseCategory> baseCategories = new ArrayList<>(1);

        public List<BaseRecyclerAdapter.IViewType> getUiDataList() {
            return uiDataList;
        }

        public void setUiDataList(List<BaseRecyclerAdapter.IViewType> uiDataList) {
            this.uiDataList = uiDataList;
        }

        public List<BaseCategory> getBaseCategories() {
            return baseCategories;
        }
    }

    public static class PrimaryCategoryResponse {
        private List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>(1);

        @SerializedName("category")
        private PrimaryCategory primaryCategory;

        public List<BaseRecyclerAdapter.IViewType> getUiDataList() {
            return uiDataList;
        }

        public void setUiDataList(List<BaseRecyclerAdapter.IViewType> uiDataList) {
            this.uiDataList = uiDataList;
        }

        public PrimaryCategory getPrimaryCategory() {
            return primaryCategory;
        }
    }

    public static class BaseCategory {
        @SerializedName("id")
        private int id;

        @SerializedName("name")
        private String name = "";

        @SerializedName("category_type")
        private String categoryType = "";

        @SerializedName("code")
        private String code = "";

        @SerializedName("pharmacy")
        private boolean isPharmacy;

        @SerializedName("category_image_url")
        private String categoryImageUrl = "";

        @SerializedName("sequence_id")
        private int sequenceId;

        @SerializedName("category_main_url")
        private String categoryMainUrl = "";


        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getCategoryType() {
            return categoryType;
        }

        public String getCode() {
            return code;
        }

        public boolean isPharmacy() {
            return isPharmacy;
        }

        public String getCategoryImageUrl() {
            return categoryImageUrl;
        }

    }

    public static class HomeFeaturedCategory extends BaseCategory {
        @SerializedName("home_page_sequence_id")
        private int homePageSequenceId;

        @SerializedName("home_page_icon_url")
        private String homePageIconUrl = "";

        public int getHomePageSequenceId() {
            return homePageSequenceId;
        }

        public String getHomePageIconUrl() {
            return homePageIconUrl;
        }
    }

    public static class PrimaryCategory extends BaseCategory {

        @SerializedName("popular_display_count")
        private int popularDisplayCount = 0;

        @SerializedName("banners")
        private List<Promotion> promotions = new ArrayList<>(1);

        @SerializedName("popular_brands")
        private List<PopularBrands> popularBrands = new ArrayList<>(1);

        @SerializedName("children")
        private ArrayList<SubCategory> subCategoryList = new ArrayList<>(1);

        public ArrayList<SubCategory> getSubCategoryList() {
            return subCategoryList;
        }

        public void setSubCategoryList(ArrayList<SubCategory> subCategoryList) {
            this.subCategoryList = subCategoryList;
        }

        public List<Promotion> getPromotions() {
            return promotions;
        }

        public List<PopularBrands> getPopularBrands() {
            return popularBrands;
        }

        public int getPopularDisplayCount() {
            return popularDisplayCount;
        }

        public void setPopularDisplayCount(int popularDisplayCount) {
            this.popularDisplayCount = popularDisplayCount;
        }
    }

    public static class Promotion {
        @SerializedName("id")
        private long promotionBannerId = 0;

        @SerializedName("promotion_id")
        private long promotionId = 0;

        @SerializedName("type")
        private String promotionType = "";

        @SerializedName("url")
        private String promotionImageUrl = "";

        @SerializedName("html_page")
        private String promotionWebUrl = "";

        public long getPromotionBannerId() {
            return promotionBannerId;
        }

        public String getPromotionImageUrl() {
            return promotionImageUrl;
        }

        public void setPromotionBannerId(long promotionBannerId) {
            this.promotionBannerId = promotionBannerId;
        }

        public void setPromotionImageUrl(String promotionImageUrl) {
            this.promotionImageUrl = promotionImageUrl;
        }

        public String getPromotionWebUrl() {
            return promotionWebUrl;
        }

        public void setPromotionWebUrl(String promotionWebUrl) {
            this.promotionWebUrl = promotionWebUrl;
        }

        public String getPromotionType() {
            return promotionType;
        }

        public void setPromotionType(String promotionType) {
            this.promotionType = promotionType;
        }

        public long getPromotionId() {
            return promotionId;
        }

        public void setPromotionId(long promotionId) {
            this.promotionId = promotionId;
        }
    }

    public static class PopularBrands {
        @SerializedName("brand_name")
        private String brandName = "";

        @SerializedName("brand_image_url")
        private String brandImageUrl = "";

        public String getBrandName() {
            return brandName;
        }

        public String getBrandImageUrl() {
            return brandImageUrl;
        }

        public void setBrandName(String brandName) {
            this.brandName = brandName;
        }

        public void setBrandImageUrl(String brandImageUrl) {
            this.brandImageUrl = brandImageUrl;
        }
    }

    public static class Category implements Serializable {

        @SerializedName("id")
        private int id;

        @SerializedName("name")
        private String name;

        @SerializedName("category_type")
        private String categoryType;

        @SerializedName("code")
        private String code;

        @SerializedName("category_image_url")
        private String categoryImageUrl;

        @SerializedName("pharmacy")
        private boolean isPharmacy;

        @SerializedName("children")
        private ArrayList<SubCategory> subCategoryList = new ArrayList<>(1);

        public boolean isPharmacy() {
            return isPharmacy;
        }

        public void setPharmacy(boolean pharmacy) {
            this.isPharmacy = pharmacy;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getCategoryType() {
            return categoryType;
        }

        public void setCategoryType(String categoryType) {
            this.categoryType = categoryType;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public ArrayList<SubCategory> getSubCategoryList() {
            return subCategoryList;
        }

        public void setSubCategoryList(ArrayList<SubCategory> subCategoryList) {
            this.subCategoryList = subCategoryList;
        }

        public String getCategoryImageUrl() {
            return categoryImageUrl;
        }
    }

    public static class SubCategory implements Serializable {
        @SerializedName("id")
        private int id;

        @SerializedName("name")
        private String name;

        @SerializedName("category_type")
        private String categoryType;

        @SerializedName("code")
        private String code;

        @SerializedName("pharmacy")
        private boolean pharmacy;

        @SerializedName("children")
        private List<Children> children = new ArrayList<>(1);

        public boolean isPharmacy() {
            return pharmacy;
        }

        public void setPharmacy(boolean pharmacy) {
            this.pharmacy = pharmacy;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getCategoryType() {
            return categoryType;
        }

        public void setCategoryType(String categoryType) {
            this.categoryType = categoryType;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        public List<Children> getGrandChildren() {
            return children;
        }

        public void setGrandChildren(List<Children> children) {
            this.children = children;
        }
    }

    public static class Children implements Serializable {
        @SerializedName("id")
        private long id;

        @SerializedName("name")
        private String name;

        @SerializedName("category_type")
        private String categoryType;

        @SerializedName("code")
        private String code;

        @SerializedName("pharmacy")
        private boolean pharmacy;

        public boolean isPharmacy() {
            return pharmacy;
        }

        public void setPharmacy(boolean pharmacy) {
            this.pharmacy = pharmacy;
        }

        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getCategoryType() {
            return categoryType;
        }

        public void setCategoryType(String categoryType) {
            this.categoryType = categoryType;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }
    }
}
