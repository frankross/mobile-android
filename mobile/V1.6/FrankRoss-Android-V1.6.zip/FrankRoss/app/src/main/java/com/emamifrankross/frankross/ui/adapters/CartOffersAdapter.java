/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.graphics.Typeface;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.StyleSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.toolbox.NetworkImageView;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.Cart;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.customviews.VolleySingleton;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 29/6/15.
 * <p> Adapter class for  Cart Offers View Pager Item Section in Cart </p>
 * <p>Supports the One View Types </p>
 * <p> 1 : CART OFFERS VIEW PAGER ITEM VIEW TYPE</p>
 */
public class CartOffersAdapter extends PagerAdapter implements View.OnClickListener {

    private List<Cart.CartPromotion> mCartOffersData = new ArrayList<>();

    public CartOffersAdapter(List<Cart.CartPromotion> cartOffersData) {
        mCartOffersData = cartOffersData;
    }

    @Override
    public int getCount() {
        return mCartOffersData.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        ViewPager pager = (ViewPager) container;
        int count = pager.getChildCount();

        View view = LayoutInflater.from(container.getContext()).inflate(R.layout.cart_offer_header, container, false);
        initCartOffersViews(view, position);
        pager.addView(view, count > position ? position : count);

        return view;
    }

    @Override
    public void onClick(View view) {
    }

    private void initCartOffersViews(View view, int position) {
        RobotoTextView checkOutHeader = (RobotoTextView) view.findViewById(R.id.cart_offer_header_tv);
        NetworkImageView cartOfferImage = (NetworkImageView) view.findViewById(R.id.cart_offer_header_iv);

        if (!TextUtils.isEmpty(mCartOffersData.get(position).getOfferImageUrl())) {
            cartOfferImage.setImageUrl(mCartOffersData.get(position).getOfferImageUrl(),
                    VolleySingleton.getInstance(cartOfferImage.getContext()).getImageLoader());
        }
        cartOfferImage.setDefaultImageResId(R.drawable.product_logo);
        cartOfferImage.setErrorImageResId(R.drawable.product_logo);

        SpannableString spannableOfferString = new SpannableString(TextUtils.isEmpty(
                mCartOffersData.get(position).getMainText()) ? "" :
                mCartOffersData.get(position).getMainText());
        spannableOfferString.setSpan(new StyleSpan(Typeface.BOLD), 0, spannableOfferString.length(), 0);
        checkOutHeader.append(spannableOfferString);
        checkOutHeader.append("\n");
        checkOutHeader.append(TextUtils.isEmpty(mCartOffersData.get(position).getSubText()) ? "" :
                mCartOffersData.get(position).getSubText());

        cartOfferImage.setVisibility(TextUtils.isEmpty(mCartOffersData.get(position).getOfferImageUrl()) ? View.GONE : View.VISIBLE);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
}
