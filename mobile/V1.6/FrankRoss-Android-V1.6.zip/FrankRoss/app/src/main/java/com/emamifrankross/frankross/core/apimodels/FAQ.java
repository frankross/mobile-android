/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 4/3/16.
 */
public class FAQ {

    @SerializedName("name")
    private String name;

    @SerializedName("faqs")
    private List<Faqs> faqs = new ArrayList<>(1);

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<Faqs> getFaqs() {
        return faqs;
    }

    public void setFaqs(List<Faqs> faqs) {
        this.faqs = faqs;
    }

    public static class Faqs {

        @SerializedName("question")
        private String question;

        @SerializedName("answer")
        private String answer;

        @SerializedName("top_query")
        private boolean top_query;

        @SerializedName("position")
        private int position;

        public String getQuestion() {
            return question;
        }

        public void setQuestion(String question) {
            this.question = question;
        }

        public String getAnswer() {
            return answer;
        }

        public void setAnswer(String answer) {
            this.answer = answer;
        }

        public boolean isTop_query() {
            return top_query;
        }

        public void setTop_query(boolean top_query) {
            this.top_query = top_query;
        }

        public int getPosition() {
            return position;
        }

        public void setPosition(int position) {
            this.position = position;
        }
    }
}
