/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.pharmacy;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.aloglia.AlgoliaManager;
import com.emamifrankross.frankross.core.aloglia.datamodel.AlgoliaProductsFilterInfo;
import com.emamifrankross.frankross.core.apimodels.ApiCategories;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.NewFeaturedProductsAdapter;
import com.emamifrankross.frankross.ui.adapters.PharmacyCategoryAdapter;
import com.emamifrankross.frankross.ui.adapters.PharmacyTopBrandsAdapter;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.WebViewFragment;
import com.emamifrankross.frankross.ui.home.LooperService;
import com.emamifrankross.frankross.ui.products.ProductDetailActivity;
import com.emamifrankross.frankross.ui.search.SearchActivity;
import com.emamifrankross.frankross.ui.viewmodels.CommonRecyclerHeaderItem;
import com.emamifrankross.frankross.ui.viewmodels.HorizontalRecyclerViewItem;
import com.emamifrankross.frankross.ui.viewmodels.HorizontalScrollerViewMoreDataItem;
import com.emamifrankross.frankross.ui.viewmodels.ProductDataModel;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderItem;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Log;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by gowtham on 6/11/15.
 */

/**
 * This class represents the UI for Sub categories listing screen navigated from Category listing screen
 */
public class PharmaCategoryFragment extends ApiRequestBaseFragment implements BaseRecyclerAdapter.RecyclerItemClickListener,
        IToolbar {

    private static final String TAG = PharmaCategoryFragment.class.getSimpleName();
    private static final int CATEGORY_FEATURED_PRODUCTS_VIEW_HEIGHT = 193;
    private static final int CATEGORY_FEATURED_PRODUCTS_VIEW_MORE_HEIGHT = 120;
    private static final String EXTRA_CATEGORY_ID = "category_id";
    private static int INITIAL_CATEGORY_ADD_LIMIT = 5;
    private static int PRODUCT_LIMIT = 6;

    private ArrayList<ApiCategories.SubCategory> mCategoryList = new ArrayList<>(1);
    private ArrayList<BaseRecyclerAdapter.IViewType> mUiDataList = new ArrayList<>(1);

    private List<ApiCategories.PopularBrands> mPopularBrands;
    private List<ApiCategories.Promotion> mPromotions;
    private PharmacyCategoryAdapter.TopOffersAutoScrollDataItem mOfferBannerItem;
    private List<ProductDataModel> mFeaturedProductsList;

    private PharmacyCategoryAdapter mPharmacyCategoryAdapter;

    private long mCategoryId;

    private int mAddMoreCategoryIndex = 0;
    private int mPreviousExpandedViewPosition = -1;

    private String mCategoryName = "";

    private boolean mIsAllCategoryShown = false;
    private boolean mIsBinded = false;

    private ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.d(TAG, "on Service Connected");
            if (service != null && service instanceof LooperService.LooperBinder) {
                final LooperService.LooperBinder looperBinder = (LooperService.LooperBinder) service;
                mPharmacyCategoryAdapter.setLooperBinder(looperBinder);

                looperBinder.startLooping(new LooperService.ILoopNotifier() {
                    @Override
                    public void onLoop() {
                        Log.d(TAG, " on loop Please notify the view pager");

                        if (mPharmacyCategoryAdapter != null) {
                            mPharmacyCategoryAdapter.onScrollNext();
                        }
                    }
                });
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.d(TAG, "on Service Disconnected");
        }
    };

    public static PharmaCategoryFragment create(ApiCategories.Category category, long categoryId) {
        PharmaCategoryFragment pharmaCategoryFragment = new PharmaCategoryFragment();

        Bundle bundle = new Bundle();
        bundle.putLong(EXTRA_CATEGORY_ID, category != null ? category.getId() : categoryId);

        pharmaCategoryFragment.setArguments(bundle);
        return pharmaCategoryFragment;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mOfferBannerItem != null) {
            bindLooperService();
        }
    }

    private void bindLooperService() {
        mIsBinded = true;
        Intent intent = new Intent(this.getActivity(), LooperService.class);
        getActivity().bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mIsBinded) {
            unbindService();
        }
    }

    private void unbindService() {
        getActivity().unbindService(mServiceConnection);
        mIsBinded = false;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle bundle = getArguments();
        if (bundle != null && bundle.getLong(EXTRA_CATEGORY_ID) != -1) {
            mCategoryId = bundle.getLong(EXTRA_CATEGORY_ID);
        }

        mOfferBannerItem = null;
        mUiDataList = new ArrayList<>(1);
        mPharmacyCategoryAdapter = new PharmacyCategoryAdapter(mUiDataList);
        ApiRequestManager apiRequestManager = ApiRequestManager.getInstance(getActivity().getApplicationContext());
        apiRequestManager.setLoopingDelay(Constants.AUTO_SCROLL_INITIAL_DELAY);
        getPrimaryCategoryList();
    }

    private void getPrimaryCategoryList() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetPrimaryCategoriesRequest(mCategoryId, new ApiRequestManager.IGetPrimaryCategoriesResultNotifier() {
            @Override
            public void onPrimaryCategoriesAndPromotionFetched(ApiCategories.PrimaryCategoryResponse primaryCategoryResponse) {

                if (primaryCategoryResponse != null && primaryCategoryResponse.getPrimaryCategory() != null
                        && primaryCategoryResponse.getPrimaryCategory().getSubCategoryList() != null) {

                    //For Show More button display
                    INITIAL_CATEGORY_ADD_LIMIT = primaryCategoryResponse.getPrimaryCategory().getPopularDisplayCount();

                    //For toolbar title
                    mCategoryName = primaryCategoryResponse.getPrimaryCategory().getName();

                    //API data
                    mCategoryList = primaryCategoryResponse.getPrimaryCategory().getSubCategoryList();
                    mPopularBrands = primaryCategoryResponse.getPrimaryCategory().getPopularBrands();
                    mPromotions = primaryCategoryResponse.getPrimaryCategory().getPromotions();

                    generateUIData();
                } else {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    mPharmacyCategoryAdapter.notifyDataSetChanged();
                }
            }
        }, this, this);
    }

    /**
     * Method that handles the addition of UI data item to the list based on API response
     */
    private void generateUIData() {
        new AsyncTask<Void, Void, Void>() {

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                mUiDataList.clear();
                mPharmacyCategoryAdapter.notifyDataSetChanged();
                mFragmentInteractionListener.showBlockingProgressBar();
            }

            @Override
            protected Void doInBackground(Void... params) {

                List<String> bannerUrls = new ArrayList<String>();
                List<Long> bannerPromotionIds = new ArrayList<Long>();

                if (mPromotions != null && mPromotions.size() != 0) {
                    mOfferBannerItem = new PharmacyCategoryAdapter.TopOffersAutoScrollDataItem();

                    for (ApiCategories.Promotion promotion : mPromotions) {
                        bannerUrls.add(promotion.getPromotionImageUrl());
                        bannerPromotionIds.add(promotion.getPromotionBannerId());
                    }

                    mOfferBannerItem.mBanner = mPromotions;
                    if (mOfferBannerItem != null) {
                        mUiDataList.add(mOfferBannerItem);
                        bindLooperService();
                    }
                }

                if (mCategoryList.size() < INITIAL_CATEGORY_ADD_LIMIT) {
                    addAllCategories();
                    addBrands();
                } else {
                    addCategories();
                    addViewMoreOrLessView();
                    addBrands();
                }

                return null;
            }

            private void addViewMoreOrLessView() {
                PharmacyCategoryAdapter.ShowAllCategoryViewItem showAllCategoryViewItem =
                        new PharmacyCategoryAdapter.ShowAllCategoryViewItem();
                showAllCategoryViewItem.isAllCategoryShown = mIsAllCategoryShown;
                mUiDataList.add(showAllCategoryViewItem);
            }

            private void addCategories() {
                int addCount = 0;
                for (ApiCategories.SubCategory subCategory : mCategoryList) {
                    if (addCount == INITIAL_CATEGORY_ADD_LIMIT) {
                        mAddMoreCategoryIndex = mUiDataList.size();
                        break;
                    }
                    PharmacyCategoryAdapter.ExpandableGroupItem groupItem =
                            new PharmacyCategoryAdapter.ExpandableGroupItem();
                    groupItem.category = subCategory;
                    groupItem.isExpanded = false;

                    mUiDataList.add(groupItem);
                    addCount++;
                }
            }

            private void addAllCategories() {
                for (ApiCategories.SubCategory subCategory : mCategoryList) {
                    PharmacyCategoryAdapter.ExpandableGroupItem groupItem =
                            new PharmacyCategoryAdapter.ExpandableGroupItem();
                    groupItem.category = subCategory;
                    groupItem.isExpanded = false;

                    mUiDataList.add(groupItem);
                }
            }

            private void addBrands() {
                if (mPopularBrands != null && mPopularBrands.size() != 0) {
                    PharmacyCategoryAdapter.PharmacyHorizontalScrollerDataItem brandItem =
                            new PharmacyCategoryAdapter.PharmacyHorizontalScrollerDataItem();
                    brandItem.popularBrands = mPopularBrands;
                    mUiDataList.add(brandItem);
                }
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                mFragmentInteractionListener.hideBlockingProgressBar();
                mPharmacyCategoryAdapter.notifyDataSetChanged();
                mToolbarInteractionListener.updateToolbar(PharmaCategoryFragment.this);
                //To fetch the category based featured products
                getAlgoliaProducts();
            }
        }.execute();
    }

    /**
     * Method that requests for five algolia products based on the category
     */
    private void getAlgoliaProducts() {
        mFragmentInteractionListener.showBlockingProgressBar();
        AlgoliaManager.getInstance().performGetNonPharmaCategoryProducts(getActivity(), true, mCategoryId,
                PRODUCT_LIMIT, 0, new AlgoliaManager.IProductInfoWithFilterResultNotifier() {
                    @Override
                    public void onProductInfoFetched(final List<ProductDataModel> productList,
                                                     AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                        if (getActivity() != null && getView() != null) {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    mFeaturedProductsList = productList;
                                    mToolbarInteractionListener.updateToolbar(PharmaCategoryFragment.this);
                                    generateMappedFeaturedProducts();
                                }
                            });
                        }
                    }

                    @Override
                    public void onSearchError() {
                        if (getActivity() != null && getView() != null) {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    mFragmentInteractionListener.hideBlockingProgressBar();
                                    showAlert(getString(R.string.no_connection_error));
                                }
                            });
                        }
                    }
                });
    }

    /**
     * Method that generates a mapped UI list for Featured products of particular category
     */
    private void generateMappedFeaturedProducts() {
        if (mFeaturedProductsList != null && mFeaturedProductsList.size() > 0) {
            mUiDataList.add(new CommonRecyclerHeaderItem(getString(R.string.home_featured_products)));
            mUiDataList.add(new RecyclerBorderItem(2));

            List<BaseRecyclerAdapter.IViewType> featuredProductDataModel = new ArrayList<>();
            boolean isViewMore = false;
            if (mFeaturedProductsList.size() > PRODUCT_LIMIT - 1) {
                mFeaturedProductsList.remove(mFeaturedProductsList.size() - 1);
                isViewMore = true;
            }

            for (ProductDataModel model : mFeaturedProductsList) {
                NewFeaturedProductsAdapter.HomeFeaturedProductsDataItem featuredProductsDataItem
                        = new NewFeaturedProductsAdapter.HomeFeaturedProductsDataItem();
                featuredProductsDataItem.productId = model.productId;
                featuredProductsDataItem.productBrandOrManufacturerName = model.productBrandOrManufacturerName;
                featuredProductsDataItem.productIconImageUrl = model.productIconImageUrl;
                featuredProductsDataItem.isAddToCartVisible = model.isAddToCartVisible;
                featuredProductsDataItem.productSellingPrice = model.productSellingPrice;
                featuredProductsDataItem.productActualPrice = model.productActualPrice;
                featuredProductsDataItem.productName = model.productName;
                featuredProductsDataItem.productDiscountPercent = model.productDiscountPercent;
                featuredProductsDataItem.productImageUrl = model.productImageUrl;
                featuredProductsDataItem.isPharma = model.isPharma;
                featuredProductDataModel.add(featuredProductsDataItem);
            }

            if (isViewMore) {
                HorizontalScrollerViewMoreDataItem viewMoreDataItem = new HorizontalScrollerViewMoreDataItem();
                viewMoreDataItem.viewHeight = CATEGORY_FEATURED_PRODUCTS_VIEW_MORE_HEIGHT;
                viewMoreDataItem.isCategory = false;
                featuredProductDataModel.add(viewMoreDataItem);
            }

            HorizontalRecyclerViewItem featuredProductsDataItem = new HorizontalRecyclerViewItem();
            featuredProductsDataItem.mHorizontalRecyclerViewAdapter =
                    new NewFeaturedProductsAdapter(featuredProductDataModel);
            featuredProductsDataItem.mHorizontalRecyclerViewAdapter.setRecyclerItemClickListener(this);
            featuredProductsDataItem.viewHeight = CATEGORY_FEATURED_PRODUCTS_VIEW_HEIGHT;
            mUiDataList.add(featuredProductsDataItem);

            mUiDataList.add(new RecyclerBorderItem(1));
            mPharmacyCategoryAdapter.notifyDataSetChanged();
        }
        mFragmentInteractionListener.hideBlockingProgressBar();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_pharmacy_category, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    private void initViews(View view) {
        RecyclerView pharmacyRecyclerView = (RecyclerView) view.findViewById(R.id.pharmacy_category_container);
        pharmacyRecyclerView.setHasFixedSize(false);
        pharmacyRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mPharmacyCategoryAdapter.setRecyclerItemClickListener(this);
        pharmacyRecyclerView.setAdapter(mPharmacyCategoryAdapter);
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return mCategoryName;
    }

    @Override
    public int getToolbarMenuId() {
        return R.menu.menu_pharmacy;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_search:
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_FROM_TOOLBAR_EVENT);
                        startActivity(SearchActivity.getActivityIntent(getActivity()));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;

                    case R.id.action_cart:
                        Map<String, String> cartClickData = Utils.cartToolbarClickDataForAnalytics(Constants.PHARMA_SUB_CATEGORY_SCREEN_NAME,
                                FrankRossEvents.VIEW_CART_FROM_TOOLBAR_SCREEN_NAME);
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_CART_FROM_TOOLBAR_EVENT, cartClickData);
                        startActivity(CartActivity.getActivityIntent(getActivity().getApplicationContext(),
                                CartActivity.CART_FRAGMENT_ID));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;
                }
                return false;
            }
        };
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {

        if (object instanceof PharmacyCategoryAdapter.ExpandableGroupItem) {

            if (mPreviousExpandedViewPosition != position) {
                if (mPreviousExpandedViewPosition != -1) {
                    if (mUiDataList.size() > mPreviousExpandedViewPosition &&
                            mUiDataList.get(mPreviousExpandedViewPosition) != null &&
                            mUiDataList.get(mPreviousExpandedViewPosition) instanceof
                                    PharmacyCategoryAdapter.ExpandableGroupItem) {

                        //Collapse the previous expanded item
                        PharmacyCategoryAdapter.ExpandableGroupItem previousExpandedItem =
                                (PharmacyCategoryAdapter.ExpandableGroupItem)
                                        mUiDataList.get(mPreviousExpandedViewPosition);
                        previousExpandedItem.isExpanded = false;
                        mPharmacyCategoryAdapter.notifyItemChanged(mPreviousExpandedViewPosition);
                    }
                }
                //expand the clicked item
                PharmacyCategoryAdapter.ExpandableGroupItem expandableGroupItem =
                        (PharmacyCategoryAdapter.ExpandableGroupItem) object;
                Map<String, String> categoriesClickData = Utils.
                        categoriesClickDataForAnalytics(expandableGroupItem.category.getName(),
                                FrankRossEvents.CATEGORY_LEVEL2_NAME_EVENT);
                FrankRossAnalytics.getFrankRossTracker().logEvent(mCategoryName, categoriesClickData);

                mPreviousExpandedViewPosition = position;
                mPharmacyCategoryAdapter.notifyItemChanged(position);
            } else {
                //Collapse the item: Previous expanded item position is equal to clicked item
                mPharmacyCategoryAdapter.notifyItemChanged(position);
            }

        } else if (object instanceof ApiCategories.Children) {

            //Children item
            ApiCategories.Children child = (ApiCategories.Children) object;
            long categoryId = child.getId();
            String categoryName = child.getName();
            handleNonPharmaProductListing(categoryId, categoryName);

        } else if (object instanceof PharmacyCategoryAdapter.ShowAllCategoryViewItem) {

            //View More/Less Item
            mIsAllCategoryShown = ((PharmacyCategoryAdapter.ShowAllCategoryViewItem) object).isAllCategoryShown;
            if (((PharmacyCategoryAdapter.ShowAllCategoryViewItem) object).isAllCategoryShown) {
                int index = mAddMoreCategoryIndex;
                for (int categoryListIndex = INITIAL_CATEGORY_ADD_LIMIT; categoryListIndex < mCategoryList.size(); categoryListIndex++) {
                    ApiCategories.SubCategory subCategory = mCategoryList.get(categoryListIndex);
                    PharmacyCategoryAdapter.ExpandableGroupItem groupItem =
                            new PharmacyCategoryAdapter.ExpandableGroupItem();
                    groupItem.category = subCategory;
                    groupItem.isExpanded = false;

                    mUiDataList.add(index, groupItem);
                    index++;
                }

                mPharmacyCategoryAdapter.notifyItemRangeInserted(mAddMoreCategoryIndex,
                        mCategoryList.size() - INITIAL_CATEGORY_ADD_LIMIT);
            } else {
                int endIndex = mAddMoreCategoryIndex + mCategoryList.size() - INITIAL_CATEGORY_ADD_LIMIT - 1;
                for (int index = endIndex; index >= mAddMoreCategoryIndex; index--) {
                    mUiDataList.remove(index);
                }

                mPharmacyCategoryAdapter.notifyItemRangeRemoved(mAddMoreCategoryIndex,
                        mCategoryList.size() - INITIAL_CATEGORY_ADD_LIMIT);
            }

        } else if (object instanceof PharmacyTopBrandsAdapter.PharmacyTopBrandsDataItem) {

            //Top brand Item
            PharmacyTopBrandsAdapter.PharmacyTopBrandsDataItem pharmacyTopBrandsDataItem =
                    (PharmacyTopBrandsAdapter.PharmacyTopBrandsDataItem) object;
            handleTopBrandsClick(pharmacyTopBrandsDataItem.topBrandName);

        } else if (object instanceof PharmacyCategoryAdapter.TopOffersAutoScrollDataItem) {

            //Category Banner item
            handlePromotionItemsClick((PharmacyCategoryAdapter.TopOffersAutoScrollDataItem) object, position);

        } else if (object instanceof HorizontalScrollerViewMoreDataItem) {

            //Category Featured products View More item
            handleCategoryFeaturedProductsClick();

        } else if (object instanceof NewFeaturedProductsAdapter.HomeFeaturedProductsDataItem) {
            handleProductItemClick(((NewFeaturedProductsAdapter.HomeFeaturedProductsDataItem) object).productId,
                    ((NewFeaturedProductsAdapter.HomeFeaturedProductsDataItem) object).isPharma);
        } else {
            mPharmacyCategoryAdapter.notifyDataSetChanged();
        }
    }

    /**
     * Method to handle promotions click
     *
     * @param topOffersDataItem the category screen auto scroll data item
     * @param position          determines which banner item was clicked
     */
    private void handlePromotionItemsClick(PharmacyCategoryAdapter.TopOffersAutoScrollDataItem topOffersDataItem, int position) {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.CATEGORY_BANNER_TAP_EVENT);

        long promotionId;
        String webUrl;
        //long categoryId = mCategory == null ? mCategoryId : mCategory.getId();

        if (topOffersDataItem.mBanner.get(position) != null &&
                topOffersDataItem.mBanner.get(position).getPromotionId() != 0) {

            promotionId = topOffersDataItem.mBanner.get(position).getPromotionId();
            startActivity(ProductListingActivity.getActivityIntentForCategoryPromotionalProducts(getActivity().getApplicationContext(),
                    ProductListingActivity.PROMOTIONAL_PRODUCTS_FRAGMENT_ID, promotionId, mCategoryId, mCategoryName));
            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);

        } else if (topOffersDataItem.mBanner.get(position) != null &&
                !TextUtils.isEmpty(topOffersDataItem.mBanner.get(position).getPromotionWebUrl())) {

            webUrl = topOffersDataItem.mBanner.get(position).getPromotionWebUrl();
            mFragmentInteractionListener.loadFragment(getId(),
                    WebViewFragment.create(webUrl,
                            getString(R.string.home_promotion_details)),
                    null, R.anim.push_left_in, R.anim.fade_out,
                    BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
        }
    }

    /**
     * Method to handle top brand click
     *
     * @param brandName the brand name that was clicked
     */
    private void handleTopBrandsClick(String brandName) {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.CATEGORY_SHOP_BY_BRAND_TAP_EVENT);
        startActivity(ProductListingActivity.getActivityIntentForShopByBrandProducts(getActivity().getApplicationContext(),
                ProductListingActivity.SHOP_BY_BRAND_PRODUCT_LISTING_FRAGMENT_ID, mCategoryId, brandName));
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    /**
     * Method to handle sub category item click
     */
    private void handleNonPharmaProductListing(long categoryId, String categoryName) {
        Map<String, String> categoriesClickData = Utils.categoriesClickDataForAnalytics(categoryName,
                FrankRossEvents.CATEGORY_LEVEL3_NAME_EVENT);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.CATEGORY_LEVEL3_TAP_EVENT, categoriesClickData);
        startActivity(ProductListingActivity.getActivityIntent(categoryId, categoryName, getActivity().getApplicationContext(),
                ProductListingActivity.PRODUCT_LIST_FRAGMENT_ID));
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    /**
     * Method to handle the product click
     */
    private void handleProductItemClick(long variantId, boolean isPharma) {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.CATEGORY_FEATURED_PRODUCTS_TAP_EVENT);
        startActivity(ProductDetailActivity.getActivityIntent(getActivity().getApplicationContext(),
                isPharma ? ProductDetailActivity.PHARMA_PRODUCT_DETAIL_FRAGMENT_ID
                        : ProductDetailActivity.NON_PHARMA_PRODUCT_DETAIL_FRAGMENT_ID, variantId));
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    /**
     * Method to handle the category More featured products item
     */
    private void handleCategoryFeaturedProductsClick() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_MORE_CATEGORIES_FEATURED_PRODUCTS_TAP_EVENT);
        startActivity(ProductListingActivity.getActivityIntentForFeaturedProducts(getActivity().getApplicationContext(),
                ProductListingActivity.FEATURED_PRODUCTS_LISTING_FRAGMENT_ID, mCategoryId));
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }
}
