/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;

/**
 * Created by gowtham on 26/7/15.
 */

/**
 * COMMON RECYCLER BORDER ITEM
 */
public class RecyclerBorderItem implements BaseRecyclerAdapter.IViewType {

    public int leftMarginInPx = 0;
    public int rightMarginInPx = 0;
    public int heightInPx = 1;
    public int borderBackground = R.color.border_background_color;

    public RecyclerBorderItem(int heightInPx) {
        this.heightInPx = heightInPx;
    }

    @Override
    public int getViewType() {
        return ViewTypes.CommonViewType.BORDER_ITEM;
    }
}
