/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;

/**
 * Created by gauthami on 22/7/15.
 */

/**
 * Order history product info data item
 */
public class OrderHistoryProductInfoItem implements BaseRecyclerAdapter.IViewType {

    public String productName;
    public int productQuantity;
    public double productPrice;
    public int maxOrderableQty;
    public long variantId;
    public boolean isPharma;
    public boolean isActive;
    public int numberOfItems;

    @Override
    public int getViewType() {
        return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_PRODUCT_ITEM;
    }
}