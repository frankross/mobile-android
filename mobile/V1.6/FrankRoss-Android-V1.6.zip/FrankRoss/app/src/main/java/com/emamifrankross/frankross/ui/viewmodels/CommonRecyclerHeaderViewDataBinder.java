/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;

/**
 * Created by gowtham on 22/7/15.
 */

/**
 * Common Header Item that contains the header text center aligned data binder
 */
public class CommonRecyclerHeaderViewDataBinder implements BaseRecyclerAdapter.RecyclerViewDataBinder<CommonRecyclerHeaderViewHolder,
        CommonRecyclerHeaderItem> {
    @Override
    public CommonRecyclerHeaderViewHolder getViewHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.common_header_text_layout, parent, false);

        return new CommonRecyclerHeaderViewHolder(view);
    }

    @Override
    public void bindDataToViewHolder(CommonRecyclerHeaderViewHolder viewHolder,
                                     CommonRecyclerHeaderItem data, int position,
                                     BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {
        viewHolder.mAddressHeader.setText(data.addressHeader);
    }

    @Override
    public int getViewType() {
        return ViewTypes.CommonViewType.COMMON_HEADER_TEXT;
    }
}
