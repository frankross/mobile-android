/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.utils.Utils;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by gowtham on 7/8/15.
 */
public class ApiOrdersList {

    public static class Response {

        private List<BaseRecyclerAdapter.IViewType> uiDataList;

        @SerializedName("orders")
        private List<Order> orderList;

        @SerializedName("page_info")
        private PageInfo pageInfo;

        public List<Order> getOrderList() {
            return orderList;
        }

        public void setOrderList(List<Order> orderList) {
            this.orderList = orderList;
        }

        public List<BaseRecyclerAdapter.IViewType> getUiDataList() {
            return uiDataList;
        }

        public void setUiDataList(List<BaseRecyclerAdapter.IViewType> uiDataList) {
            this.uiDataList = uiDataList;
        }

        public PageInfo getPageInfo() {
            return pageInfo;
        }
    }

    public static class OrderItem {
        @SerializedName("variant_name")
        private String variantName;

        @SerializedName("variant_id")
        private int variantId;

        @SerializedName("quantity")
        private int quantity;

        public String getVariantName() {
            return variantName;
        }

        public void setVariantName(String variantName) {
            this.variantName = variantName;
        }

        public int getVariantId() {
            return variantId;
        }

        public void setVariantId(int variantId) {
            this.variantId = variantId;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }
    }

    public static class Order {

        @SerializedName("id")
        private int id;

        @SerializedName("state")
        private String state;

        @SerializedName("is_cancellable")
        private boolean isCancellable;

        @SerializedName("is_returnable")
        private boolean isReturnable;

        @SerializedName("is_reorderable")
        private boolean isReorderable;

        @SerializedName("is_mismatched")
        private boolean isMismatched;

        @SerializedName("state_display_name")
        private String stateDisplayName;

        @SerializedName("state_bucket")
        private String stateBucket;

        @SerializedName("confirmed_on")
        private String confirmedOn;

        @SerializedName("total")
        private String total;

        @SerializedName("line_items")
        private List<OrderItem> orderItems;

        @SerializedName("reorder_reminder")
        private boolean reorderReminder;

        @SerializedName("reorder_reminder_details")
        private ReorderReminderDetails reorderReminderDetails;

        @SerializedName("doctor_names")
        private String doctorName = "";

        @SerializedName("patient_name")
        private String patientName = "";

        public double getTotal() {
            return Utils.getDoubleValue(total);
        }

        public void setTotal(String total) {
            this.total = total;
        }

        public List<OrderItem> getOrderItems() {
            return orderItems;
        }

        public void setOrderItems(List<OrderItem> orderItems) {
            this.orderItems = orderItems;
        }

        public ReorderReminderDetails getReorderReminderDetails() {
            return reorderReminderDetails;
        }

        public void setReorderReminderDetails(ReorderReminderDetails reorderReminderDetails) {
            this.reorderReminderDetails = reorderReminderDetails;
        }

        public boolean getReorderable() {
            return isReorderable;
        }

        public void setReorderable(boolean reorderable) {
            this.isReorderable = reorderable;
        }

        public String getStateBucket() {
            return stateBucket;
        }

        public void setStateBucket(String stateBucket) {
            this.stateBucket = stateBucket;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public boolean getReorderReminder() {
            return reorderReminder;
        }

        public void setReorderReminder(boolean reorderReminder) {
            this.reorderReminder = reorderReminder;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public boolean getCancellable() {
            return isCancellable;
        }

        public void setCancellable(boolean cancellable) {
            this.isCancellable = cancellable;
        }

        public boolean getReturnable() {
            return isReturnable;
        }

        public void setReturnable(boolean returnable) {
            this.isReturnable = returnable;
        }

        public boolean getMismatched() {
            return isMismatched;
        }

        public void setMismatched(boolean mismatched) {
            this.isMismatched = mismatched;
        }

        public String getStateDisplayName() {
            return stateDisplayName;
        }

        public void setStateDisplayName(String stateDisplayName) {
            this.stateDisplayName = stateDisplayName;
        }

        public String getConfirmedOn() {
            return confirmedOn;
        }

        public void setConfirmedOn(String confirmedOn) {
            this.confirmedOn = confirmedOn;
        }

        public String getDoctorName() {
            return doctorName;
        }

        public String getPatientName() {
            return patientName;
        }
    }

    public static class PageInfo {

        @SerializedName("total_records")
        private int totalRecords = 0;

        @SerializedName("records_per_page")
        private int recordsPerPage = 0;

        @SerializedName("current_page_no")
        private int currentPageNumber = 0;

        @SerializedName("total_pages")
        private int totalPages = 0;

        public int getTotalPages() {
            return totalPages;
        }

        public int getCurrentPageNumber() {
            return currentPageNumber;
        }

        public int getRecordsPerPage() {
            return recordsPerPage;
        }

        public int getTotalRecords() {
            return totalRecords;
        }
    }
}
