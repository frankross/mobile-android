/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.order;

import android.os.Bundle;
import android.view.View;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiOrderDetail;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.ui.cart.CartFragment;
import com.emamifrankross.frankross.ui.cart.CartUploadPrescriptionFragment;
import com.emamifrankross.frankross.ui.cart.PlaceOrderDialogFragment;
import com.emamifrankross.frankross.ui.checkout.CheckOutDeliveryAddressFragment;
import com.emamifrankross.frankross.ui.common.BaseFragment;

/**
 * Created by gowtham on 24/9/15.
 */

/**
 * This class represents the UI for Revised order screen
 */
public class OrderRevisedFragment extends CartFragment {

    private static final String TAG = OrderRevisedFragment.class.getName();
    private static final String BUNDLE_KEY_FOR_ORDER_ID = "orderId";
    private static final String BUNDLE_KEY_DOCTOR_NAME = "doctorName";
    private static final String BUNDLE_KEY_PATIENT_NAME = "patientName";

    private long mAddressId = -1;
    private long mOrderId = -1;
    private long mDeliverySlotId = -1;

    private String mDoctorName = "";
    private String mPatientName = "";
    private boolean mIsOrderWithoutPrescription = false;

    public static OrderRevisedFragment create(String doctorName, String patientName, long orderId) {
        OrderRevisedFragment fragment = new OrderRevisedFragment();

        Bundle bundle = new Bundle();
        bundle.putLong(BUNDLE_KEY_FOR_ORDER_ID, orderId);
        bundle.putString(BUNDLE_KEY_DOCTOR_NAME, doctorName);
        bundle.putString(BUNDLE_KEY_PATIENT_NAME, patientName);

        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void performRequest() {
        if (getArguments() != null) {
            mOrderId = getArguments().getLong(BUNDLE_KEY_FOR_ORDER_ID);
            mDoctorName = getArguments().getString(BUNDLE_KEY_DOCTOR_NAME);
            mPatientName = getArguments().getString(BUNDLE_KEY_PATIENT_NAME);
        }
        performOrderHistoryDetailsRequest();
    }

    @Override
    protected void initViews(View view) {
        super.initViews(view);
        mPlaceOrderBtn.setText(R.string.update_order);
    }

    @Override
    public void performPlaceOrder() {

        if (mIsUploadPrescription) {
            if (mIsOrderWithoutPrescription) {
                PlaceOrderDialogFragment placeOrderDialogFragment = PlaceOrderDialogFragment.create(mDoctorName, mPatientName,
                        mOrderId, mAddressId, mDeliverySlotId,
                        CheckOutDeliveryAddressFragment.CartFlow.REVISED_ORDER);
                placeOrderDialogFragment.show(getChildFragmentManager(), TAG);
            } else {
                mFragmentInteractionListener.loadFragment(getId(), CartUploadPrescriptionFragment.create(mDoctorName, mPatientName,
                        mOrderId, -1, -1, CheckOutDeliveryAddressFragment.CartFlow.REVISED_ORDER),
                        null, R.anim.push_left_in, R.anim.fade_out,
                        BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
            }
        } else {
            mFragmentInteractionListener.loadFragment(getId(), CheckOutDeliveryAddressFragment.create(mDoctorName, mPatientName, mOrderId,
                    mAddressId, mDeliverySlotId, -1, CheckOutDeliveryAddressFragment.CartFlow.REVISED_ORDER),
                    CheckOutDeliveryAddressFragment.TAG, R.anim.push_left_in, R.anim.fade_out,
                    BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
        }
    }

    /**
     * Method that requests for Order details
     */
    private void performOrderHistoryDetailsRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performRevisedOrderDetailsRequest(mOrderId, new ApiRequestManager.IRevisedOderDetailsResultNotifier() {
            @Override
            public void onRevisedOrderDetailsFetched(ApiOrderDetail.Response response) {
                mFragmentInteractionListener.hideBlockingProgressBar();
                if (response != null && response.getUiDataList().size() > 0) {
                    mAddressId = response.getOrderDetails().getBillingAddress().getId();
                    if (response.getOrderDetails() != null && response.getOrderDetails().getDeliverySlot() != null)
                        mDeliverySlotId = response.getOrderDetails().getDeliverySlot().getId();
                    mIsOrderWithoutPrescription = response.getOrderDetails().isOrderWithoutPrescription();
                    populateCartData(response.getUiDataList());
                }
            }
        }, this, this);
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.revised_order);
    }
}
