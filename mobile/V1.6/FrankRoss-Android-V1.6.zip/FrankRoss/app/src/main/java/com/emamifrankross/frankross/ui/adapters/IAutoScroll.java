/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

/**
 * Created by gauthami on 13/1/16.
 */
public interface IAutoScroll {
        void scrollNext();
}
