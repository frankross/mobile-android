/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.graphics.Paint;
import android.support.v4.view.GestureDetectorCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.android.volley.toolbox.NetworkImageView;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.customviews.VolleySingleton;
import com.emamifrankross.frankross.ui.viewmodels.ProductDataModel;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 30/6/15.
 * <p> Adapter class for Featured Products Section in Home </p>
 * <p>Supports the One View Types </p>
 * <p> 1 : PRODUCT VIEW TYPE</p>
 */
public class HomeFeaturedProductsAdapter extends PagerAdapter {

    private List<BaseRecyclerAdapter.IViewType> mFeaturedProducts = new ArrayList<>(1);
    private BaseRecyclerAdapter.RecyclerItemClickListener mRecyclerItemClickListener;

    public HomeFeaturedProductsAdapter(List<BaseRecyclerAdapter.IViewType> featuredProducts) {
        mFeaturedProducts.addAll(featuredProducts);
    }

    public void setOnRecyclerItemClickListener(BaseRecyclerAdapter.RecyclerItemClickListener recyclerItemClickListener) {
        mRecyclerItemClickListener = recyclerItemClickListener;
    }

    @Override
    public int getCount() {
        return mFeaturedProducts.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        ViewPager pager = (ViewPager) container;
        int count = pager.getChildCount();
        View view = LayoutInflater.from(container.getContext()).inflate(R.layout.top_selling_product_list_item, container, false);
        initViews(view, (ProductDataModel) mFeaturedProducts.get(position), position);
        pager.addView(view, count > position ? position : count);
        return view;
    }

    private void initViews(final View view, final ProductDataModel productDataModel, final int position) {
        if(productDataModel != null){
            RobotoTextView mProductActualAmount = (RobotoTextView) view.findViewById(R.id.top_selling_product_price_tv);
            RobotoTextView mProductOfferAmount = (RobotoTextView) view.findViewById(R.id.top_selling_product_offer_price_tv);
            RobotoTextView mProductDiscount = (RobotoTextView) view.findViewById(R.id.top_selling_product_offer_tv);
            NetworkImageView mProductImage = (NetworkImageView) view.findViewById(R.id.top_selling_product_icon_iv);
            RobotoTextView mProductName = (RobotoTextView) view.findViewById(R.id.top_selling_product_title_tv);
            RobotoTextView mProductBrandOrManufacturerName = (RobotoTextView) view.findViewById(R.id.top_selling_product_brand_tv);

            mProductActualAmount.setPaintFlags(mProductActualAmount.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            mProductImage.setDefaultImageResId(R.drawable.product_logo);
            mProductImage.setErrorImageResId(R.drawable.product_logo);

            mProductName.setText(productDataModel.productName);
            mProductBrandOrManufacturerName.setText(productDataModel.productBrandOrManufacturerName);
            Animation fadeInAnimation = AnimationUtils.loadAnimation(mProductImage.getContext(), R.anim.fade_in);
            mProductImage.startAnimation(fadeInAnimation);
            mProductImage.setImageUrl(productDataModel.productImageUrl, VolleySingleton.getInstance(mProductImage.getContext()).getImageLoader());
            mProductOfferAmount.setText(Utils.addRupeeSymbol(mProductOfferAmount.getContext(), "",
                    Utils.getFormattedDouble(productDataModel.productSellingPrice)));

            if (productDataModel.productDiscountPercent == 0) {
                mProductDiscount.setVisibility(View.GONE);
                mProductActualAmount.setVisibility(View.GONE);
            } else {
                mProductDiscount.setVisibility(View.VISIBLE);
                mProductActualAmount.setVisibility(View.VISIBLE);
                mProductDiscount.setText(Utils.getDiscountFormattedDouble(productDataModel.productDiscountPercent) + "% off");
                mProductActualAmount.setText(Utils.addRupeeSymbol(mProductOfferAmount.getContext(), "",
                        Utils.getFormattedDouble(productDataModel.productActualPrice)));
            }

            final GestureDetectorCompat mDetector = new GestureDetectorCompat(view.getContext(), new GestureDetector.OnGestureListener() {
                @Override
                public boolean onDown(MotionEvent e) {
                    return true;
                }

                @Override
                public void onShowPress(MotionEvent e) {

                }

                @Override
                public boolean onSingleTapUp(MotionEvent e) {
                    return true;
                }

                @Override
                public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                    return true;
                }

                @Override
                public void onLongPress(MotionEvent e) {

                }

                @Override
                public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                    return false;
                }
            });

            mDetector.setOnDoubleTapListener(new GestureDetector.OnDoubleTapListener() {
                @Override
                public boolean onSingleTapConfirmed(MotionEvent e) {
                    if (mRecyclerItemClickListener != null) {
                        mRecyclerItemClickListener.onRecyclerItemClick(position, view, productDataModel);
                    }
                    return true;
                }

                @Override
                public boolean onDoubleTap(MotionEvent e) {
                    return true;
                }

                @Override
                public boolean onDoubleTapEvent(MotionEvent e) {
                    return true;
                }
            });

            view.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    mDetector.onTouchEvent(event);
                    return true;
                }
            });
        /*    view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (mRecyclerItemClickListener != null) {
                        mRecyclerItemClickListener.onRecyclerItemClick(position, v, productDataModel);
                    }
                }
            });*/
        }
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
}