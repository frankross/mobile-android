/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;

/**
 * Created by gowtham on 29/6/15.
 */
public interface IFragmentInteractionListener {

    void loadFragment(int fragmentContainerId, BaseFragment fragment,
                      @Nullable String tag, int enterAnimId, int exitAnimId,
                      BaseFragment.FragmentTransactionType fragmentTransactionType);

    void loadDialogFragment(DialogFragment fragment,
                            @Nullable String tag);

    void showAlert(String title, String message, String positiveBtnText,
                   String negativeBtnText,
                   AlertDialogFragment.AlertPositiveActionListener alertPositiveActionListener,
                   AlertDialogFragment.AlertNegativeActionListener alertNegativeActionListener,
                   boolean isCancelable);

    void showBlockingProgressBar();

    void hideBlockingProgressBar();

    boolean isProgressBarShowing();

    void hideFragment(BaseFragment fragment);
}
