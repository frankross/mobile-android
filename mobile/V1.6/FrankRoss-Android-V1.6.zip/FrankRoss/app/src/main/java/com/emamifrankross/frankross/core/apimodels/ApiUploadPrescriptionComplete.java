/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

/**
 * Created by gowtham on 6/8/15.
 */
public class ApiUploadPrescriptionComplete {

    public static class Response {

    }
}
