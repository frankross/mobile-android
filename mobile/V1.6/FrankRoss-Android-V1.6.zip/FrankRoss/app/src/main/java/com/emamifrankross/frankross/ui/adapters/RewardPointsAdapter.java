/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.SpannableStringBuilder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderDataBinder;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 29/3/16.
 * <p> Adapter class for Reward points Section</p>
 * <p> Supports the Five View Types </p>
 * <p> 1 : REWARD POINTS HEADER VIEW TYPE </p>
 * <p> 2 : REWARD POINTS INVITE FRIENDS VIEW TYPE </p>
 * <p> 3 : REWARD POINTS TRANSACTION HEADER VIEW TYPE </p>
 * <p> 4 : REWARD POINTS TRANSACTION VIEW TYPE </p>
 * <p> 5 : COMMON BORDER VIEW TYPE </p>
 */
public class RewardPointsAdapter extends BaseRecyclerAdapter {

    public RewardPointsAdapter(@NonNull List<BaseRecyclerAdapter.IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<BaseRecyclerAdapter.RecyclerViewDataBinder> getViewDataBinders() {
        ArrayList<BaseRecyclerAdapter.RecyclerViewDataBinder> viewHolderTypes = new ArrayList<>(1);
        viewHolderTypes.add(new RewardPointsInfoViewHolderType());
        viewHolderTypes.add(new RecyclerBorderDataBinder());
        viewHolderTypes.add(new RewardPointsInviteFriendsViewHolderType());
        viewHolderTypes.add(new RewardPointsTransactionHeaderViewHolderType());
        viewHolderTypes.add(new RewardPointsTransactionsViewHolderType());
        return viewHolderTypes;
    }

    /**
     * REWARD POINTS HEADER VIEW TYPE
     */
    public static class RewardPointsInfoDataItem implements IViewType {

        public double earnedRewardPoints;
        public double spentRewardPoints;
        public double availableRewardPoints;

        @Override
        public int getViewType() {
            return ViewTypes.RewardPointsViewType.REWARD_POINTS_VIEW_TYPE;
        }
    }

    public static class RewardPointsInfoViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mEarnedRewardPoints;
        private RobotoTextView mSpentRewardPoints;
        private RobotoTextView mAvailableRewardPoints;

        public RewardPointsInfoViewHolder(View view) {
            super(view);
            mEarnedRewardPoints = (RobotoTextView) view.findViewById(R.id.reward_points_earned_tv);
            mSpentRewardPoints = (RobotoTextView) view.findViewById(R.id.reward_points_spend_tv);
            mAvailableRewardPoints = (RobotoTextView) view.findViewById(R.id.reward_points_available_tv);
        }
    }

    private class RewardPointsInfoViewHolderType implements RecyclerViewDataBinder<RewardPointsInfoViewHolder,
            RewardPointsInfoDataItem> {
        @Override
        public RewardPointsInfoViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.reward_points_info, parent, false);
            return new RewardPointsInfoViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(RewardPointsInfoViewHolder viewHolder, final RewardPointsInfoDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            Context context = viewHolder.mAvailableRewardPoints.getContext();
            viewHolder.mEarnedRewardPoints.setText(Utils.addRupeeSymbol(context, "",
                    Utils.getFormattedDouble(data.earnedRewardPoints)));
            viewHolder.mAvailableRewardPoints.setText(Utils.addRupeeSymbol(context, "",
                    Utils.getFormattedDouble(data.availableRewardPoints)));
            viewHolder.mSpentRewardPoints.setText(Utils.addRupeeSymbol(context, "",
                    Utils.getFormattedDouble(data.spentRewardPoints)));
        }

        @Override
        public int getViewType() {
            return ViewTypes.RewardPointsViewType.REWARD_POINTS_VIEW_TYPE;
        }
    }

    /**
     * REWARD POINTS INVITE FRIENDS VIEW TYPE
     */
    public static class RewardPointsInviteFriendsDataItem implements IViewType {

        public String rewardPointsCode = "";
        public String rewardPointsSubHeader = "";
        public String rewardPointsHeader = "";

        @Override
        public int getViewType() {
            return ViewTypes.RewardPointsViewType.REWARD_POINTS_INVITE_FRIENDS_VIEW_TYPE;
        }
    }

    public static class RewardPointsInviteFriendsViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mRewardPointsHeader;
        private RobotoTextView mRewardPointsSubHeader;
        private RobotoTextView mRewardPointsCode;
        private Button mInviteFriends;

        public RewardPointsInviteFriendsViewHolder(View view) {
            super(view);
            mRewardPointsHeader = (RobotoTextView) view.findViewById(R.id.reward_points_invite_friends_header_tv);
            mRewardPointsCode = (RobotoTextView) view.findViewById(R.id.reward_points_user_code_tv);
            mRewardPointsSubHeader = (RobotoTextView) view.findViewById(R.id.reward_points_invite_friends_sub_header_tv);
            mInviteFriends = (Button) view.findViewById(R.id.reward_points_invite_friends_btn);
        }
    }

    private class RewardPointsInviteFriendsViewHolderType implements RecyclerViewDataBinder<RewardPointsInviteFriendsViewHolder,
            RewardPointsInviteFriendsDataItem> {
        @Override
        public RewardPointsInviteFriendsViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.reward_points_invite_friends, parent, false);
            return new RewardPointsInviteFriendsViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(RewardPointsInviteFriendsViewHolder viewHolder, final RewardPointsInviteFriendsDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            //viewHolder.mRewardPointsHeader.setText(data.rewardPointsHeader);
            viewHolder.mRewardPointsCode.setText(data.rewardPointsCode);
            viewHolder.mRewardPointsSubHeader.setText(data.rewardPointsSubHeader);

            if (recyclerViewClickListener != null) {
                viewHolder.mInviteFriends.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.RewardPointsViewType.REWARD_POINTS_INVITE_FRIENDS_VIEW_TYPE;
        }
    }

    /**
     * REWARD POINTS TRANSACTION HEADER VIEW TYPE
     */
    public static class RewardPointsTransactionHeaderDataItem implements IViewType {

        @Override
        public int getViewType() {
            return ViewTypes.RewardPointsViewType.REWARD_POINTS_TRANSACTIONS_HEADER_VIEW_TYPE;
        }
    }

    public static class RewardPointsTransactionHeaderViewHolder extends RecyclerView.ViewHolder {

        public RewardPointsTransactionHeaderViewHolder(View view) {
            super(view);
        }
    }

    private class RewardPointsTransactionHeaderViewHolderType implements RecyclerViewDataBinder<RewardPointsTransactionHeaderViewHolder,
            RewardPointsTransactionHeaderDataItem> {
        @Override
        public RewardPointsTransactionHeaderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.reward_points_transactions_header, parent, false);
            return new RewardPointsTransactionHeaderViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(RewardPointsTransactionHeaderViewHolder viewHolder, final RewardPointsTransactionHeaderDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {

        }

        @Override
        public int getViewType() {
            return ViewTypes.RewardPointsViewType.REWARD_POINTS_TRANSACTIONS_HEADER_VIEW_TYPE;
        }
    }

    /**
     * REWARD POINTS TRANSACTION VIEW TYPE
     */
    public static class RewardPointsTransactionsDataItem implements IViewType {

        public String transactionDate = "";
        public String transactionSummary = "";
        public String transactionType = "";
        public double transactionAmount = 0;

        @Override
        public int getViewType() {
            return ViewTypes.RewardPointsViewType.REWARD_POINTS_TRANSACTIONS_VIEW_TYPE;
        }
    }

    public static class RewardPointsTransactionsViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mTransactionDate;
        private RobotoTextView mTransactionSummary;
        private RobotoTextView mTransactionType;

        public RewardPointsTransactionsViewHolder(View view) {
            super(view);
            mTransactionDate = (RobotoTextView) view.findViewById(R.id.reward_points_transaction_item_date_tv);
            mTransactionSummary = (RobotoTextView) view.findViewById(R.id.reward_points_transaction_item_summary_tv);
            mTransactionType = (RobotoTextView) view.findViewById(R.id.reward_points_transaction_item_type_tv);
        }
    }

    private class RewardPointsTransactionsViewHolderType implements RecyclerViewDataBinder<RewardPointsTransactionsViewHolder,
            RewardPointsTransactionsDataItem> {
        @Override
        public RewardPointsTransactionsViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.reward_points_transaction_item, parent, false);
            return new RewardPointsTransactionsViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(RewardPointsTransactionsViewHolder viewHolder, final RewardPointsTransactionsDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mTransactionDate.setText(data.transactionDate);
            String amountPrefix = data.transactionType.equalsIgnoreCase("credit") ? "+ " : "- ";
            SpannableStringBuilder amount = Utils.addRupeeSymbol(viewHolder.mTransactionType.getContext(), amountPrefix,
                    Utils.getFormattedDouble(data.transactionAmount));
            viewHolder.mTransactionType.setText(amount);
            viewHolder.mTransactionSummary.setText(data.transactionSummary);
            viewHolder.mTransactionType.setTextColor(ContextCompat.getColor(viewHolder.mTransactionType.getContext(),
                    data.transactionType.equalsIgnoreCase("credit") ? R.color.frankross_common_text_color :
                            R.color.prescription_reference_expired_txt_color));
        }

        @Override
        public int getViewType() {
            return ViewTypes.RewardPointsViewType.REWARD_POINTS_TRANSACTIONS_VIEW_TYPE;
        }
    }
}
