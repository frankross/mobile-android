/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.db;

import android.content.Context;
import android.os.AsyncTask;

/**
 * This class is responsible for executing the provided database query operation in secondary thread
 * and notify the result back to ui in MainThread.
 */
public class QueryExecutor extends AsyncTask<Void, Void, Void> {

	private Object mData;
	private Context mContext = null;
	private DBQuery mQuery = null;

	public QueryExecutor(Context context, DBQuery query) {
		mContext = context;
		mQuery = query;
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();
	}

	@Override
	protected Void doInBackground(Void... params) {
		SQLiteHelper frankRossSQLiteHelper = SQLiteHelper.getHelperInstance(mContext);
		mData = frankRossSQLiteHelper.executeQuery(mQuery);
		return null;
	}

	@Override
	protected void onPostExecute(Void result) {
		super.onPostExecute(result);
		if (mQuery != null && mQuery.getDataBaseResultNotifier() != null) {
			mQuery.getDataBaseResultNotifier().OnDataBaseDataUpdated(mData);
		}
	}

	public Object executeSynchronously() {
		SQLiteHelper frankRossSQLiteHelper = SQLiteHelper.getHelperInstance(mContext);
		Object data = frankRossSQLiteHelper.executeQuery(mQuery);
		if (mQuery != null) {
			return data;
		}
		return null;
	}
}
