/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 13/7/15.
 * <p> Adapter class for Product sort Section</p>
 * <p>Supports the Two View Types </p>
 * <p> 1 : SORT ITEM VIEW TYPE </p>
 * <p> 2 : FILTER DETAIL ITEM VIEW TYPE </p>
 */
public class ProductSortAdapter extends BaseRecyclerAdapter {

    public ProductSortAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewDataBinderList = new ArrayList<>(1);
        viewDataBinderList.add(new SortHeaderViewDataBinder());
        viewDataBinderList.add(new FilterDetailHeaderViewDataBinder());
        return viewDataBinderList;
    }

    /**
     * SORT ITEM VIEW TYPE
     */
    public static class SortDataItem implements IViewType {

        public String sortHeader;
        public boolean isChecked = false;

        @Override
        public int getViewType() {
            return ViewTypes.SortViewType.SORT_LIST_ITEM;
        }
    }

    private static class SortHeaderViewHolder extends RecyclerView.ViewHolder {

        private ImageView mSortIndicator;
        private RobotoTextView mSortHeaderText;

        private LinearLayout mProductSortLinLyt;

        public SortHeaderViewHolder(View itemView, Context context) {
            super(itemView);
            mSortIndicator = (ImageView) itemView.findViewById(R.id.sort_indicator_iv);
            mSortHeaderText = (RobotoTextView) itemView.findViewById(R.id.sort_by_text_tv);
            mProductSortLinLyt = (LinearLayout) itemView.findViewById(R.id.sort_products_linLyt);

            mSortHeaderText.setTextColor(ContextCompat.getColor(context, R.color.pharmacy_dash_board_text_color));
            mSortHeaderText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        }
    }

    private static class SortHeaderViewDataBinder implements
            RecyclerViewDataBinder<SortHeaderViewHolder, SortDataItem> {

        @Override
        public SortHeaderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sort_products_list_item, parent, false);

            return new SortHeaderViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(final SortHeaderViewHolder viewHolder,
                                         final SortDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mSortHeaderText.setText(data.sortHeader);
            viewHolder.mSortIndicator.setImageResource((data.isChecked) ? R.mipmap.select : R.drawable.abc_list_divider_mtrl_alpha);
            Context context = viewHolder.mSortHeaderText.getContext();
            viewHolder.mSortHeaderText.setTextColor(ContextCompat.getColor(context,
                    data.isChecked ? R.color.pharmacy_sort_selected_text_color
                            : R.color.pharmacy_dash_board_text_color));

            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        data.isChecked = true;
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.SortViewType.SORT_LIST_ITEM;
        }
    }


    /**
     * FILTER DETAIL ITEM VIEW TYPE
     */
    public static class FilterDetailDataItem implements IViewType {

        public String detailsDataHeader;
        public boolean isChecked = false;

        @Override
        public int getViewType() {
            return ViewTypes.FilterViewType.FILTER_DETAILS_DATA_ITEM;
        }
    }

    private static class FilterDetailHeaderViewHolder extends RecyclerView.ViewHolder {

        private ImageView mSortIndicator;
        private RobotoTextView mSortHeaderText;

        private LinearLayout mProductSortLinLyt;

        public FilterDetailHeaderViewHolder(View itemView, Context context) {
            super(itemView);
            mSortIndicator = (ImageView) itemView.findViewById(R.id.sort_indicator_iv);
            mSortHeaderText = (RobotoTextView) itemView.findViewById(R.id.sort_by_text_tv);
            mProductSortLinLyt = (LinearLayout) itemView.findViewById(R.id.sort_products_linLyt);

            mSortHeaderText.setTextColor(ContextCompat.getColor(context, R.color.pharmacy_dash_board_text_color));
            mSortHeaderText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        }
    }

    private static class FilterDetailHeaderViewDataBinder implements
            RecyclerViewDataBinder<FilterDetailHeaderViewHolder, FilterDetailDataItem> {

        @Override
        public FilterDetailHeaderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sort_products_list_item, parent, false);

            return new FilterDetailHeaderViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(final FilterDetailHeaderViewHolder viewHolder,
                                         final FilterDetailDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mSortHeaderText.setText(data.detailsDataHeader);
            viewHolder.mSortIndicator.setImageResource(data.isChecked ? R.mipmap.select :
                    R.drawable.abc_list_divider_mtrl_alpha);
            Context context = viewHolder.mSortHeaderText.getContext();
            viewHolder.mSortHeaderText.setTextColor(ContextCompat.getColor(context,
                    data.isChecked ? R.color.pharmacy_sort_selected_text_color
                            : R.color.pharmacy_dash_board_text_color));

            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        data.isChecked = !data.isChecked;
                        viewHolder.mSortIndicator.setImageResource(data.isChecked ? R.mipmap.select :
                                R.drawable.abc_list_divider_mtrl_alpha);
                        Context context = viewHolder.mSortHeaderText.getContext();
                        viewHolder.mSortHeaderText.setTextColor(ContextCompat.getColor(context,
                                data.isChecked ? R.color.pharmacy_sort_selected_text_color
                                        : R.color.pharmacy_dash_board_text_color));
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.FilterViewType.FILTER_DETAILS_DATA_ITEM;
        }
    }
}

