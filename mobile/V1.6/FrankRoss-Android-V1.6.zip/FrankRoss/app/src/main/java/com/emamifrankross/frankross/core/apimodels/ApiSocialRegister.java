/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gauthami on 20/5/16.
 */
public class ApiSocialRegister {

    public static class Request {

        @SerializedName("user")
        private User user;

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        public User getUser() {
            return user;
        }

        public void setUser(User user) {
            this.user = user;
        }

        public static class User {

            @SerializedName("email")
            private String email;

            @SerializedName("primary_phone")
            private String primary_phone;

            @SerializedName("name")
            private String name;

            @SerializedName("primary_phone_type")
            private String primary_phone_type = "Mobile";

            @SerializedName("social_login_uid")
            private String social_login_uid;

            @SerializedName("social_login_provider")
            private String social_login_provider;

            @SerializedName("social_auth_token")
            private String social_auth_token;

            public String getEmail() {
                return email;
            }

            public void setEmail(String email) {
                this.email = email;
            }

            public String getPrimary_phone() {
                return primary_phone;
            }

            public void setPrimary_phone(String primary_phone) {
                this.primary_phone = primary_phone;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getPrimary_phone_type() {
                return primary_phone_type;
            }

            public void setPrimary_phone_type(String primary_phone_type) {
                this.primary_phone_type = primary_phone_type;
            }

            public String getSocial_login_uid() {
                return social_login_uid;
            }

            public void setSocial_login_uid(String social_login_uid) {
                this.social_login_uid = social_login_uid;
            }

            public String getSocial_login_provider() {
                return social_login_provider;
            }

            public void setSocial_login_provider(String social_login_provider) {
                this.social_login_provider = social_login_provider;
            }

            public String getSocial_auth_token() {
                return social_auth_token;
            }

            public void setSocial_auth_token(String social_auth_token) {
                this.social_auth_token = social_auth_token;
            }
        }
    }
}
