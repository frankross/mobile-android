/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 11/8/15.
 */
public class ApiOrderCancel {

    public static class Request {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("reason")
        private String reason = "";

        @SerializedName("remarks")
        private String remarks = "";

        public String getReason() {
            return reason;
        }

        public String getRemarks() {
            return remarks;
        }

        public void setReason(String reason) {
            this.reason = reason;
        }

        public void setRemarks(String remarks) {
            this.remarks = remarks;
        }
    }

    public static class Response {

        @SerializedName("message")
        private String message = "";

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}
