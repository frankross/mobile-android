/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.db;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;

import com.emamifrankross.frankross.core.db.tables.BaseTable;
import com.emamifrankross.frankross.core.db.tables.CartCacheTable;
import com.emamifrankross.frankross.core.db.tables.DataBaseTableConstants;
import com.emamifrankross.frankross.core.db.tables.SearchSuggestionTable;
import com.emamifrankross.frankross.utils.Log;

import java.text.ParseException;

/**
 * Database Helper class manages the All the database operations. its begginig point for accessing application Database.
 */
public class SQLiteHelper extends SQLiteOpenHelper implements IDataBaseOperation.DBOperationsID,
        DataBaseTableConstants.TableID {
    private static final String DATABASE_NAME = "frankross";
    private static final int DATABASE_VERSION = 1;
    private static final String TAG = SQLiteHelper.class.getName();

    private static SQLiteHelper mPayWithSQLiteHelper = null;

    private static final byte DB_STATE_READABLE = 111;
    private static final byte DB_STATE_WRITABLE = 112;

    public static SQLiteHelper getHelperInstance(Context context) {
        if (mPayWithSQLiteHelper == null) {
            mPayWithSQLiteHelper = new SQLiteHelper(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        return mPayWithSQLiteHelper;
    }

    private SQLiteHelper(Context context, String name,
                         CursorFactory factory, int version) {
        super(context, DATABASE_NAME, factory, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        createTables(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d(TAG, "Upgrading DataBase :" + DATABASE_NAME
                + "\n OldVersion :" + oldVersion + "\n New Version :"
                + newVersion);
    }


    private synchronized SQLiteDatabase getDb(byte state) {
        if (state == DB_STATE_READABLE) {
            return getReadableDatabase();
        } else {
            return getWritableDatabase();
        }
    }

    public synchronized Object executeQuery(DBQuery query) {

        Object data = null;
        switch (query.getOperationId()) {
            case INSERT:
                data = insert(query.getTableId(), query);
                break;

            case SELECT:
                data = select(query.getTableId(), query);
                break;

            case UPDATE:
                data = update(query.getTableId(), query);
                break;

            case DELETE:
                data = delete(query.getTableId(), query);
                break;

            case RAW:
                data = raw(query.getTableId(), query);
                break;

            default:
                // Toast.makeText(mContext, "UNKNOWN DATABASE OPERATION.",
                // Toast.LENGTH_SHORT).show();
                break;
        }
        return data;
    }

    private BaseTable getTable(int tableId) {

        switch (tableId) {
            case ID_CART_CACHE_TABLE:
                return new CartCacheTable();

            case ID_SEARCH_SUGGESTIONS_TABLE:
                return new SearchSuggestionTable();
        }
        return null;
    }

    public synchronized long insert(int tableId, DBQuery insertQuery) {
        SQLiteDatabase db = getDb(DB_STATE_WRITABLE);
        BaseTable table = getTable(tableId);
        long data = 0;

        if (db != null && table != null) {

            try {
                data = table.insert(db, insertQuery);
            } catch (ClassCastException e) {
                e.printStackTrace();
            } catch (ParseException e) {
                e.printStackTrace();
            }

            db.close();
        }

        return data;
    }

    public synchronized <T> T select(int tableId, DBQuery selectQuery) {
        SQLiteDatabase db = getDb(DB_STATE_WRITABLE);
        BaseTable table = getTable(tableId);
        T data = null;

        try {
            if (db != null && table != null) {
                data = table.select(db, selectQuery);
                db.close();
            }
        } catch (SQLiteException sqliteException) {

            db.beginTransaction();
            try {
                db.execSQL("ALTER TABLE " + SearchSuggestionTable.TABLE_SEARCH_SUGGESTION_OLD_TABLE +
                        " RENAME TO " + SearchSuggestionTable.TABLE_SEARCH_SUGGESTION + ";");
                db.setTransactionSuccessful();
            } finally {
                db.endTransaction();
            }
        }
        return data;
    }

    public synchronized int update(int tableId, DBQuery updateQuery) {
        SQLiteDatabase db = getDb(DB_STATE_WRITABLE);
        BaseTable table = getTable(tableId);
        int data = 0;

        if (db != null && table != null) {
            try {
                data = table.update(db, updateQuery);
            } catch (ParseException e) {
                e.printStackTrace();
            } catch (ClassCastException e) {
                e.printStackTrace();
            }
            db.close();
        }
        return data;
    }

    private void createTables(SQLiteDatabase db) {
        Log.d(TAG, "Create Tables");
        try {
            new SearchSuggestionTable().create(db);
            new CartCacheTable().create(db);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public synchronized int delete(int tableId, DBQuery deleteQuery) {
        SQLiteDatabase db = getDb(DB_STATE_WRITABLE);
        BaseTable table = getTable(tableId);
        int data = 0;

        if (db != null && table != null) {
            data = table.delete(db, deleteQuery);
            db.close();
        }

        return data;
    }


    public synchronized Object raw(int tableId, DBQuery rawQuery) {
        SQLiteDatabase db = getDb(DB_STATE_WRITABLE);
        BaseTable table = getTable(tableId);
        Object data = 0;

        if (db != null && table != null) {
            data = table.raw(db, rawQuery);
            db.close();
        }

        return data;
    }


    public static int getDatabaseVersion() {
        return DATABASE_VERSION;
    }
}
