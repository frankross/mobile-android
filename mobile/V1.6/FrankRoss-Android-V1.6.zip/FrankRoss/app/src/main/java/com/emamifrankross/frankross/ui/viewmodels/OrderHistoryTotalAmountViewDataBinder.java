/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

/**
 * Created by gauthami on 22/7/15.
 */

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.utils.Utils;

/**
 * COMMON TOTAL AMOUNT VIEW TYPE
 * Common Total amount Header : contains two texts
 */
public class OrderHistoryTotalAmountViewDataBinder implements BaseRecyclerAdapter.RecyclerViewDataBinder<
        OrderHistoryTotalAmountViewHolder,
        OrderHistoryTotalAmountItem> {
    @Override
    public OrderHistoryTotalAmountViewHolder getViewHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_history_product_info_header,
                parent, false);

        return new OrderHistoryTotalAmountViewHolder(view);
    }

    @Override
    public void bindDataToViewHolder(OrderHistoryTotalAmountViewHolder viewHolder,
                                     final OrderHistoryTotalAmountItem data,
                                     final int position, final BaseRecyclerAdapter.RecyclerItemClickListener
                                             recyclerViewClickListener) {
        viewHolder.mTotalAmtTitle.setText(data.totalAmtTitle);
        viewHolder.mTotalAmt.setText(Utils.addRupeeSymbol(viewHolder.mTotalAmt.getContext(), "",
                Utils.getFormattedDouble(data.totalAmt)));
    }

    @Override
    public int getViewType() {
        return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_TOTAL_AMOUNT;
    }
}