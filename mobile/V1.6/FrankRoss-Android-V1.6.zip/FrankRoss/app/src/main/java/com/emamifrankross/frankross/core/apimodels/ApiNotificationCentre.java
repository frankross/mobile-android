/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import android.text.TextUtils;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 24/10/16.
 */
public class ApiNotificationCentre {

    public static class Response {

        @SerializedName("notifications")
        private List<Notifications> notifications;

        private List<BaseRecyclerAdapter.IViewType> uiData = new ArrayList<>();

        public List<BaseRecyclerAdapter.IViewType> getUiData() {
            return uiData;
        }

        public void setUiData(List<BaseRecyclerAdapter.IViewType> uiData) {
            this.uiData = uiData;
        }

        public List<Notifications> getNotifications() {
            return notifications;
        }

        public void setNotifications(List<Notifications> notifications) {
            this.notifications = notifications;
        }

        public static class Payload {

            @SerializedName("is_pharma")
            private boolean isPharma;

            @SerializedName("order_id")
            private String order_id;

            @SerializedName("prescription_id")
            private String prescription_id;

            @SerializedName("promotion_id")
            private String promotion_id;

            @SerializedName("category_id")
            private String category_id;

            @SerializedName("image_url")
            private String image_url;

            @SerializedName("page_link")
            private String page_link;

            @SerializedName("coupon_code")
            private String coupon_code;

            @SerializedName("variant_id")
            private String variant_id;

            public long getPromotion_id() {
                if (TextUtils.isEmpty(promotion_id)) {
                    return 0;
                }
                return Long.parseLong(promotion_id);
            }

            public long getCategory_id() {
                if (TextUtils.isEmpty(category_id)) {
                    return 0;
                }
                return Long.parseLong(category_id);
            }

            public String getImage_url() {
                return image_url;
            }

            public String getPage_link() {
                return page_link;
            }

            public long getVariant_id() {
                if (TextUtils.isEmpty(variant_id)) {
                    return 0;
                }
                return Long.parseLong(variant_id);
            }

            public boolean getIsPharma() {
                return isPharma;
            }

            public String getCoupon_code() {
                return coupon_code;
            }

            public long getPrescription_id() {
                if (TextUtils.isEmpty(promotion_id)) {
                    return 0;
                }
                return Long.parseLong(promotion_id);
            }

            public long getOrder_id() {
                if (TextUtils.isEmpty(order_id)) {
                    return 0;
                }
                return Long.parseLong(order_id);
            }
        }

        public static class Notifications {

            @SerializedName("id")
            private int id;

            @SerializedName("message")
            private String message;

            @SerializedName("sent_at")
            private String sent_at;

            @SerializedName("city_id")
            private int city_id;

            @SerializedName("payload")
            private Payload payload;

            @SerializedName("header")
            private String header;

            @SerializedName("promotion_type")
            private String promotion_type;

            @SerializedName("expiry_date")
            private String expiry_date;

            @SerializedName("notification_type")
            private int notificationType;

            public int getId() {
                return id;
            }

            public String getMessage() {
                return message;
            }

            public String getSent_at() {
                return sent_at;
            }

            public int getCity_id() {
                return city_id;
            }

            public Payload getPayload() {
                return payload;
            }

            public String getHeader() {
                return header;
            }

            public String getPromotion_type() {
                return promotion_type;
            }

            public String getExpiry_date() {
                return expiry_date;
            }

            public int getNotificationType() {
                return notificationType;
            }
        }
    }
}
