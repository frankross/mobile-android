/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.core.network.UrlConstants;
import com.emamifrankross.frankross.utils.Utils;
import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 17/11/15.
 */
public class ApiDeviceRegister {

    private ApiDeviceRegister() {
    }

    public static class Request {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        public Request(String deviceToken) {
            device.token = deviceToken;
        }

        @SerializedName("device")
        private Device device = new Device();

        public Device getDevice() {
            return device;
        }

        private static class Device {

            @SerializedName("device_type")
            private String deviceType = "android";

            @SerializedName("token")
            private String token = "";

            @SerializedName("app_version")
            private String appVersion = Utils.getCapitalizedSentence(UrlConstants.API_VERSION);
        }
    }


    public static class Response {

        @SerializedName("device")
        private Device device = new Device();

        public Device getDevice() {
            return device;
        }

        public static class Device {

            @SerializedName("id")
            private long id;

            @SerializedName("device_type")
            private String deviceType = "android";

            @SerializedName("token")
            private String token = "";

            public long getId() {
                return id;
            }

            public String getDeviceType() {
                return deviceType;
            }

            public String getToken() {
                return token;
            }
        }
    }
}
