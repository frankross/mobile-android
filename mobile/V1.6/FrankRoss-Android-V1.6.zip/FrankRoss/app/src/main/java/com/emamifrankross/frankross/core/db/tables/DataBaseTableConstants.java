/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.db.tables;

public class DataBaseTableConstants {

    public interface TableID {
        byte ID_NONE =  51;
        byte ID_SEARCH_SUGGESTIONS_TABLE = 52;
        byte ID_CART_CACHE_TABLE = 53;
    }
}
