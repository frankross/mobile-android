/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;


import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 16/7/15.
 */
public class ApiAddress {

    public static class Request {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("address")
        private Address mAddress;

        public Address getAddress() {
            return mAddress;
        }

        public void setAddress(Address address) {
            this.mAddress = address;
        }
    }

    public static class DefaultRequest {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("address")
        private PutAddress mAddress;

        public PutAddress getAddress() {
            return mAddress;
        }

        public void setAddress(PutAddress address) {
            this.mAddress = address;
        }

        public static class PutAddress {
            public PutAddress(boolean isDefault) {
                mAddress = (isDefault) ? 1 : 0;
            }

            public String toJsonString() {
                return new Gson().toJson(this);
            }

            @SerializedName("default")
            private int mAddress = 0;

            public int getAddress() {
                return mAddress;
            }

            public void setAddress(int mAddress) {
                this.mAddress = mAddress;
            }
        }
    }

    public static class Response {

        @SerializedName("address")
        private Address mAddress;

        public Address getAddress() {
            return mAddress;
        }

        private static class Address {

            @SerializedName("id")
            private long id;

            public void setId(long id) {
                this.id = id;
            }
        }
    }

    public static class DefaultResponse {

    }
}
