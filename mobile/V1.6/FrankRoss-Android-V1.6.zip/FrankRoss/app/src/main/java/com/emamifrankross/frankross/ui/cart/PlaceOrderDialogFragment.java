/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.cart;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.checkout.CheckOutDeliveryAddressFragment;
import com.emamifrankross.frankross.ui.common.BaseDialogFragment;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

/**
 * Created by gauthami on 10/7/15.
 */

/**
 * This class represents the UI for Upload prescription now/at the delivery
 */
public class PlaceOrderDialogFragment extends BaseDialogFragment implements View.OnClickListener {

    public static final String TAG = PlaceOrderDialogFragment.class.getSimpleName();

    private static final String BUNDLE_KEY_ORDER_ID = "orderId";
    private static final String BUNDLE_KEY_ADDRESS_ID = "addressId";
    private static final String BUNDLE_KEY_DELIVERY_SLOT_ID = "deliveryId";
    private static final String BUNDLE_KEY_DOCTOR_NAME = "doctorName";
    private static final String BUNDLE_KEY_PATIENT_NAME = "patientName";

    private long mOrderId = -1;
    private long mAddressId = -1;
    private long mDeliverySlotId = -1;

    private String mPatientName;
    private String mDoctorName;
    private CheckOutDeliveryAddressFragment.CartFlow mCartFlow = CheckOutDeliveryAddressFragment.CartFlow.CART;

    public static PlaceOrderDialogFragment create(String doctorName, String patientName, long orderId,
                                                  long addressId, long deliverySlotId,
                                                  CheckOutDeliveryAddressFragment.CartFlow flow) {
        PlaceOrderDialogFragment fragment = new PlaceOrderDialogFragment();

        Bundle bundle = new Bundle();
        bundle.putLong(BUNDLE_KEY_ORDER_ID, orderId);
        bundle.putLong(BUNDLE_KEY_ADDRESS_ID, addressId);
        bundle.putLong(BUNDLE_KEY_DELIVERY_SLOT_ID, deliverySlotId);

        bundle.putString(BUNDLE_KEY_DOCTOR_NAME, doctorName);
        bundle.putString(BUNDLE_KEY_PATIENT_NAME, patientName);

        fragment.setCartFlow(flow);
        fragment.setArguments(bundle);
        return fragment;
    }

    public void setCartFlow(CheckOutDeliveryAddressFragment.CartFlow flow) {
        mCartFlow = flow;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_place_order_dialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            mOrderId = bundle.getLong(BUNDLE_KEY_ORDER_ID);
            mAddressId = bundle.getLong(BUNDLE_KEY_ADDRESS_ID);
            mDeliverySlotId = bundle.getLong(BUNDLE_KEY_DELIVERY_SLOT_ID);

            mDoctorName = bundle.getString(BUNDLE_KEY_DOCTOR_NAME);
            mPatientName = bundle.getString(BUNDLE_KEY_PATIENT_NAME);
        }
    }

    @Override
    public void initViews(Dialog view) {
        RobotoTextView uploadNow = (RobotoTextView) view.findViewById(R.id.cart_upload_prescription_now_tv);
        RobotoTextView atDelivery = (RobotoTextView) view.findViewById(R.id.cart_prescription_at_delivery_tv);

        uploadNow.setOnClickListener(this);
        atDelivery.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.cart_upload_prescription_now_tv:
                getDialog().dismiss();
                handleUploadPrescriptionClick();
                break;
            case R.id.cart_prescription_at_delivery_tv:
                getDialog().dismiss();
                handleDeliveryClick();
                break;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    /**
     * Method that navigates to Check out delivery address screen;also captures the click event for analytics
     */
    private void handleDeliveryClick() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.AT_TIME_OF_DELIVERY_CLICK_EVENT);
        mFragmentInteractionListener.loadFragment(getParentFragment().getId(),
                CheckOutDeliveryAddressFragment.create(mDoctorName, mPatientName,
                        mOrderId, mAddressId, mDeliverySlotId, -1, mCartFlow),
                CheckOutDeliveryAddressFragment.TAG, R.anim.push_left_in, R.anim.fade_out,
                BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    /**
     * Method that navigates to Upload prescription cart screen;also captures the click event for analytics
     */
    private void handleUploadPrescriptionClick() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.UPLOAD_PRESCRIPTION_NOW_EVENT);
        mFragmentInteractionListener.loadFragment(getParentFragment().getId(),
                CartUploadPrescriptionFragment.create(mDoctorName, mPatientName,
                        mOrderId, mAddressId, mDeliverySlotId, mCartFlow),
                null, R.anim.push_left_in, R.anim.fade_out,
                BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }
}
