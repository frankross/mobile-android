/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 11/8/15.
 */
public class ApiOrderReminder {

    public static class Request {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("duration_unit")
        private String duration_unit;

        @SerializedName("duration")
        private String duration;

        public String getDuration_unit() {
            return duration_unit;
        }

        public void setDuration_unit(String duration_unit) {
            this.duration_unit = duration_unit;
        }

        public String getDuration() {
            return duration;
        }

        public void setDuration(String duration) {
            this.duration = duration;
        }
    }

    public static class Response {

        @SerializedName("message")
        private String SuccessMessage;

        public String getSuccessMessage() {
            return SuccessMessage;
        }

        public void setSuccessMessage(String successMessage) {
            SuccessMessage = successMessage;
        }
    }
}
