/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.pharmacy;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.aloglia.datamodel.AlgoliaProductsFilterInfo;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.ICartQuantityNotifier;
import com.emamifrankross.frankross.ui.common.SortType;
import com.emamifrankross.frankross.ui.home.HomeFeaturedProductsFragment;
import com.emamifrankross.frankross.ui.home.HomePromotionalProductsFragment;
import com.emamifrankross.frankross.ui.products.filter.FilterDetailFragment;
import com.emamifrankross.frankross.ui.products.filter.ProductFilterFragment;
import com.emamifrankross.frankross.ui.products.sort.ProductSortFragment;
import com.emamifrankross.frankross.ui.search.SearchResultFragment;

/**
 * Created by gowtham on 5/7/15.
 */

/**
 * This class manages the fragment transactions for Product listing based on the intents and its data
 */
public class ProductListingActivity extends BaseActivity implements FilterDetailFragment.IFilterDetailFragmentActionListener,
        ProductFilterFragment.IFilterFragmentActionListener, ProductSortFragment.ISortClickListener, ICartQuantityNotifier {

    public static final String PRODUCT_LIST_FRAGMENT_ID = "001";
    public static final String PROMOTIONAL_PRODUCTS_FRAGMENT_ID = "002";
    public static final String FEATURED_PRODUCTS_LISTING_FRAGMENT_ID = "003";
    public static final String SHOP_BY_BRAND_PRODUCT_LISTING_FRAGMENT_ID = "004";
    public static final String SEARCH_PRODUCTS_LISTING_FRAGMENT_ID = "005";

    private static final String EXTRA_FRAGMENT_ID = "fragment_id";
    private static final String EXTRA_CATEGORY_ID = "category_Id";
    private static final String EXTRA_CATEGORY_NAME = "category_title";
    private static final String EXTRA_PROMOTIONAL_ID = "promotional_id";
    private static final String EXTRA_BRAND_NAME = "brand_name";
    private static final String EXTRA_SEARCH_TERM = "search_term";

    /**
     * Common product Listing Fragment
     *
     * @param categoryId      the MC3 category id
     * @param subCategoryName the MC3 category name
     * @param appContext      the application context
     * @param fragmentId      the fragment ID
     * @return intent associated to the mapped fragment id
     */
    public static Intent getActivityIntent(long categoryId,
                                           String subCategoryName,
                                           Context appContext,
                                           String fragmentId) {
        Intent intent = new Intent(appContext, ProductListingActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);
        intent.putExtra(EXTRA_CATEGORY_ID, categoryId);
        intent.putExtra(EXTRA_CATEGORY_NAME, subCategoryName);
        return intent;
    }

    /**
     * Home Banner tap -- Promotional Products Fragment
     *
     * @param appContext  the application context
     * @param fragmentId  the fragment ID
     * @param promotionId the promotion ID whose product will be listed
     * @return intent associated to the mapped fragment id
     */
    public static Intent getActivityIntentForHomePromotionalProducts(Context appContext,
                                                                     String fragmentId,
                                                                     long promotionId) {
        Intent intent = new Intent(appContext, ProductListingActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);
        intent.putExtra(EXTRA_PROMOTIONAL_ID, promotionId);
        return intent;
    }

    /**
     * Category Banner tap -- Promotional Products Fragment
     *
     * @param appContext      the application context
     * @param fragmentId      the fragment ID
     * @param promotionId     the promotion ID whose product will be listed
     * @param categoryId      the MC3 category id
     * @param subCategoryName the MC3 category name
     * @return intent associated to the mapped fragment id
     */
    public static Intent getActivityIntentForCategoryPromotionalProducts(Context appContext,
                                                                         String fragmentId,
                                                                         long promotionId,
                                                                         long categoryId,
                                                                         String subCategoryName) {
        Intent intent = new Intent(appContext, ProductListingActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);
        intent.putExtra(EXTRA_PROMOTIONAL_ID, promotionId);
        intent.putExtra(EXTRA_CATEGORY_ID, categoryId);
        intent.putExtra(EXTRA_CATEGORY_NAME, subCategoryName);
        return intent;
    }

    /**
     * Featured Products tap -- Featured Products Fragment(Home/Category)
     *
     * @param appContext the application context
     * @param fragmentId the fragment ID
     * @param categoryId the MC3 category id
     * @return intent associated to the mapped fragment id
     */
    public static Intent getActivityIntentForFeaturedProducts(Context appContext,
                                                              String fragmentId,
                                                              long categoryId) {
        Intent intent = new Intent(appContext, ProductListingActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);
        intent.putExtra(EXTRA_CATEGORY_ID, categoryId);
        return intent;
    }

    /**
     * Brand image tap -- Shop By Branch Products Fragment
     *
     * @param appContext the application context
     * @param fragmentId the fragment ID
     * @param categoryId the MC3 category id
     * @param brandName  the Brand name
     * @return intent associated to the mapped fragment id
     */
    public static Intent getActivityIntentForShopByBrandProducts(Context appContext,
                                                                 String fragmentId,
                                                                 long categoryId,
                                                                 String brandName) {
        Intent intent = new Intent(appContext, ProductListingActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);
        intent.putExtra(EXTRA_CATEGORY_ID, categoryId);
        intent.putExtra(EXTRA_BRAND_NAME, brandName);
        return intent;
    }

    /**
     * Search result tap -- Search Result Fragment
     *
     * @param appContext the application context
     * @param fragmentId the fragment ID
     * @param searchTerm the search term from search box
     * @return intent associated to the mapped fragment id
     */
    public static Intent getActivityIntentForSearchResultProducts(Context appContext,
                                                                  String fragmentId,
                                                                  String searchTerm) {
        Intent intent = new Intent(appContext, ProductListingActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);
        intent.putExtra(EXTRA_SEARCH_TERM, searchTerm);
        return intent;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        if (intent != null) {
            String fragmentId = intent.getStringExtra(EXTRA_FRAGMENT_ID);
            long categoryId = intent.getLongExtra(EXTRA_CATEGORY_ID, -1l);
            String categoryName = intent.getStringExtra(EXTRA_CATEGORY_NAME);
            long promotionalId = intent.getLongExtra(EXTRA_PROMOTIONAL_ID, -1);
            String brandName = intent.getStringExtra(EXTRA_BRAND_NAME);
            String searchTerm = intent.getStringExtra(EXTRA_SEARCH_TERM);
            initFragment(fragmentId, categoryId, categoryName, promotionalId, brandName, searchTerm);
        }
    }

    private void initFragment(String fragmentId, long categoryId, String categoryName, long promotionalId,
                              String brandName, String searchTerm) {
        if (!TextUtils.isEmpty(fragmentId)) {

            switch (fragmentId) {
                case PRODUCT_LIST_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(), ProductListingFragment.create(categoryId, categoryName),
                            ProductListingFragment.class.getName(),
                            R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.ADD);
                    break;

                case PROMOTIONAL_PRODUCTS_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(),
                            categoryId == -1 ? HomePromotionalProductsFragment.create(promotionalId)
                                    : CategoryPromotionalProductsFragment.create(categoryId, promotionalId, categoryName),
                            ProductListingFragment.class.getName(),
                            R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.ADD);
                    break;

                case FEATURED_PRODUCTS_LISTING_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(), categoryId == -1 ?
                                    HomeFeaturedProductsFragment.create() :
                                    CategoryFeaturedProductsFragment.create(categoryId), ProductListingFragment.class.getName(),
                            R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.ADD);
                    break;

                case SHOP_BY_BRAND_PRODUCT_LISTING_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(), CategoryBrandsProductsFragment.create(categoryId, brandName),
                            ProductListingFragment.class.getName(),
                            R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.ADD);
                    break;

                case SEARCH_PRODUCTS_LISTING_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(), SearchResultFragment.create(searchTerm),
                            ProductListingFragment.class.getName(),
                            R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.ADD);
                    break;

                default:
                    break;

            }
        }
    }

    /**
     * Callback to be invoked on selected Filter sub category
     *
     * @param isBrandSelected the boolean that identifies the brand selection
     */
    @Override
    public void onFilterDetailsSelected(boolean isBrandSelected) {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(ProductFilterFragment.class.getName());
        if (fragment != null && fragment instanceof ProductFilterFragment) {
            ((ProductFilterFragment) fragment).onFilterBrandSelected(isBrandSelected);
        }
    }

    /**
     * Callback to be invoked on applying the filter
     *
     * @param appliedFilterInfo the applied filter information
     * @param isReset           true if reset was clicked
     */
    @Override
    public void onFilterApplied(AlgoliaProductsFilterInfo appliedFilterInfo, boolean isReset) {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(ProductListingFragment.class.getName());
        if (fragment != null && fragment instanceof ProductListingFragment) {
            ((ProductListingFragment) fragment).setAppliedFilter(isReset ? null : appliedFilterInfo);
        }
    }

    /**
     * Callback to be invoked on sort applied
     *
     * @param sortType the sort type
     * @param header   the sort header text
     */
    @Override
    public void onSortClick(SortType sortType, String header) {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(ProductListingFragment.class.getName());
        if (fragment != null && fragment instanceof ProductListingFragment) {
            ((ProductListingFragment) fragment).onSortClick(sortType, header);
        }
    }

    /**
     * Callback to be invoked on Adding a product to the cart using the picker
     *
     * @param cartQuantity the quantity of the product to be added
     */
    @Override
    public void onAddToCartClick(int cartQuantity) {
        BaseFragment fragment = (BaseFragment) getSupportFragmentManager().findFragmentById(getFragmentContainerId());
        if (fragment != null) {
            if (fragment instanceof ProductListingFragment) {
                ProductListingFragment searchResultFragment = (ProductListingFragment)
                        getSupportFragmentManager().findFragmentById(getFragmentContainerId());
                searchResultFragment.performAddToCartRequest(cartQuantity);
            }
        }
    }
}
