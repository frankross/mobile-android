/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

/**
 * Created by gauthami on 22/7/15.
 */

/**
 * Order history shipping charges item view holder
 */
public class OrderHistoryShippingChargesViewHolder extends RecyclerView.ViewHolder {

    public RobotoTextView mShippingChargesTitle;
    public RobotoTextView mShippingCharge;
    public LinearLayout mDiscountTotalLinLyt;
    public RobotoTextView mDiscountTotal;
    public RobotoTextView mDiscountTotalTitle;
    public RobotoTextView mRewardPoints;
    public LinearLayout mRewardPointsLinLyt;

    public OrderHistoryShippingChargesViewHolder(View view, Context context) {
        super(view);

        mShippingCharge = (RobotoTextView) view.findViewById(R.id.order_history_shipping_amount_tv);
        mShippingChargesTitle = (RobotoTextView) view.findViewById(R.id.order_history_shipping_title_tv);

        mDiscountTotal = (RobotoTextView) view.findViewById(R.id.order_history_discount_amount_tv);
        mDiscountTotalTitle = (RobotoTextView) view.findViewById(R.id.order_history_discount_title_tv);
        mDiscountTotalLinLyt = (LinearLayout) view.findViewById(R.id.order_history_discount_linLyt);

        mShippingChargesTitle.setTextColor(ContextCompat.getColor(context, R.color.cart_shipping_details_text_color));
        mShippingCharge.setTextColor(ContextCompat.getColor(context, R.color.common_sub_header_text_color));

        mRewardPointsLinLyt = (LinearLayout) view.findViewById(R.id.order_history_reward_points_linLyt);
        mRewardPoints = (RobotoTextView) view.findViewById(R.id.order_history_reward_points_tv);
    }
}

