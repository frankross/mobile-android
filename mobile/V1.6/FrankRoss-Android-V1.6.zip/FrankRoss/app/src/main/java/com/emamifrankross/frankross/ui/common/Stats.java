/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 3/9/15.
 */
public class Stats {

    public Stats() {
    }

    public Stats(Stats stats) {
        max = stats.max;
        min = stats.min;
        avg = stats.avg;
        selectedMax = stats.selectedMax;
        selectedMin = stats.selectedMin;
    }

    @SerializedName("max")
    private double max = 0;

    private double selectedMax = max;

    @SerializedName("min")
    private double min = 0;

    private double selectedMin = min;

    @SerializedName("avg")
    private double avg = 0;

    public double getMax() {
        return Math.ceil(max);
    }

    public void setMax(double max) {
        this.max = max;
    }

    public double getMin() {
        return Math.floor(min);
    }

    public void setMin(double min) {
        this.min = min;
    }

    public double getAvg() {
        return avg;
    }

    public void setAvg(double avg) {
        this.avg = avg;
    }

    public double getSelectedMax() {
        return selectedMax;
    }

    public void setSelectedMax(double selectedMax) {
        this.selectedMax = selectedMax;
    }

    public double getSelectedMin() {
        return selectedMin;
    }

    public void setSelectedMin(double selectedMin) {
        this.selectedMin = selectedMin;
    }
}
