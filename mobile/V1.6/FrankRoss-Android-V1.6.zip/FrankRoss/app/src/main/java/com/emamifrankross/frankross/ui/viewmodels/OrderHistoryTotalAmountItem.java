/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;

/**
 * Created by gauthami on 22/7/15.
 */

/**
 * Order history total item data item
 */
public class OrderHistoryTotalAmountItem implements BaseRecyclerAdapter.IViewType {

    public double totalAmt;
    public String totalAmtTitle;

    @Override
    public int getViewType() {
        return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_TOTAL_AMOUNT;
    }
}

