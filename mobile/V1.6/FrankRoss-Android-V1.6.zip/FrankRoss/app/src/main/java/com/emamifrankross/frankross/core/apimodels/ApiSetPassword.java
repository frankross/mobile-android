/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 25/8/15.
 */
public class ApiSetPassword {

    public static class Request {
        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("otp")
        private String otp;

        @SerializedName("user")
        private User user;

        public String getOtp() {
            return otp;
        }

        public void setOtp(String otp) {
            this.otp = otp;
        }

        public User getUser() {
            return user;
        }

        public void setUser(User user) {
            this.user = user;
        }

        public static class User {
            @SerializedName("new_password")
            private String newPassword;

            public String getNewPassword() {
                return newPassword;
            }

            public void setNewPassword(String newPassword) {
                this.newPassword = newPassword;
            }
        }
    }

    public static class EmailRequest extends Request {

        public EmailRequest(String emailId) {
            this.email = emailId;
        }

        @SerializedName("email")
        private String email;

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }
    }

    public static class NumberRequest extends Request {

        public NumberRequest(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }

        @SerializedName("phone_number")
        private String phoneNumber;

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }
    }

    public static class Response {

    }
}
