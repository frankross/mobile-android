/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by gowtham on 7/8/15.
 */
public class DigitisedPrescription {

    @SerializedName("id")
    private long id = 0;

    @SerializedName("isExpired")
    private int isExpired = 0;

    @SerializedName("patientName")
    private String patientName = "";

    @SerializedName("expiryDate")
    private String expiryDate = "";

    @SerializedName("dosage")
    private List<String> dosage;

    @SerializedName("refNo")
    private String presRefNo = "";

    @SerializedName("moreCount")
    private String moreCount = "";

    @SerializedName("doctorName")
    private String doctorName = "";

    @SerializedName("date")
    private String date;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getIsExpired() {
        return isExpired;
    }

    public void setIsExpired(int isExpired) {
        this.isExpired = isExpired;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public List<String> getDosage() {
        return dosage;
    }

    public void setDosage(List<String> dosage) {
        this.dosage = dosage;
    }

    public String getPresRefNo() {
        return presRefNo;
    }

    public void setPresRefNo(String presRefNo) {
        this.presRefNo = presRefNo;
    }

    public String getMoreCount() {
        return moreCount;
    }

    public void setMoreCount(String moreCount) {
        this.moreCount = moreCount;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getDate() {
        return date;
    }

    public String getFormattedDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
