/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 23/2/16.
 */
public class ApiOffer {

    public class Response {

        @SerializedName("offers")
        private List<Offer> offersList;

        private List<BaseRecyclerAdapter.IViewType> uiData = new ArrayList<>();

        public List<Offer> getOffersList() {
            return offersList;
        }

        public List<BaseRecyclerAdapter.IViewType> getUiData() {
            return uiData;
        }

        public void setUiData(List<BaseRecyclerAdapter.IViewType> uiData) {
            this.uiData = uiData;
        }
    }
}
