/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.checkout;

import com.emamifrankross.frankross.core.apimodels.Address;
import com.emamifrankross.frankross.ui.adapters.AccountAdapter;

import java.util.List;

/**
 * Created by gauthami on 10/8/15.
 */

/**
 * Interface definition for a callback to be invoked when a address is selected or refreshed
 */
public interface ICheckOutAddressNotifier {
    /**
     * Called when delivery address is selected
     *
     * @param address the selected delivery address
     */
    void onAddressSelect(AccountAdapter.AccountAddressItem address);

    /**
     * Called when delivery address is refreshed
     *
     * @param uiAddressList the selected delivery address list
     */
    void onAddressListRefresh(List<AccountAdapter.AccountAddressItem> uiAddressList, List<Address> addressList);

}
