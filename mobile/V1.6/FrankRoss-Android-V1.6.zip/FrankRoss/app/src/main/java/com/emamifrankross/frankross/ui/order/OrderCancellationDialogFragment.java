/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.order;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.TextView;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.BaseDialogFragment;
import com.emamifrankross.frankross.ui.customviews.AnimatedExpandableListView;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 3/9/15.
 */

/**
 * This class represents the UI for Order cancellation dialog that consists of
 * Order cancel reasons drop down and Order cancel reason edit box
 */
public class OrderCancellationDialogFragment extends BaseDialogFragment implements View.OnClickListener,
        ExpandableListView.OnChildClickListener {

    private AnimatedExpandableListView mOrderCancelReason;
    private EditText mOrderCancelComment;
    private RobotoTextView mOrderCancelErrorTv;
    private CancelOrderAdapter mCancelOrderAdapter;
    private IOrderCancelSubmitListener mIRemindOrderDoneClickNotifier;
    private List<String> mOrderCancelReasonsList = new ArrayList<>();
    private List<GroupItem> items = new ArrayList<>();
    private String mSelectedReason = "";
    private GroupItem mGroupItem;
    private boolean mIsPostPay = false;

    public static OrderCancellationDialogFragment create(IOrderCancelSubmitListener orderCancelSubmitListener,
                                                         List<String> reasonList, boolean isPostPay) {
        OrderCancellationDialogFragment fragment = new OrderCancellationDialogFragment();
        fragment.mIRemindOrderDoneClickNotifier = orderCancelSubmitListener;
        fragment.mOrderCancelReasonsList = reasonList;
        fragment.mIsPostPay = isPostPay;
        return fragment;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_order_cancellation_dialog;
    }

    @Override
    public void initViews(Dialog dialog) {
        mOrderCancelReason = (AnimatedExpandableListView) dialog.findViewById(R.id.order_cancellation_reason_exp_list_view);
        mOrderCancelComment = (EditText) dialog.findViewById(R.id.order_cancellation_comment_et);
        mOrderCancelErrorTv = (RobotoTextView) dialog.findViewById(R.id.order_cancellation_error_tv);
        RobotoTextView orderCancelSubmitBtn = (RobotoTextView) dialog.findViewById(R.id.order_cancellation_dialog_submit_btn);
        RobotoTextView orderCancellationPostPayMessage = (RobotoTextView) dialog.findViewById(R.id.order_cancellation_dialog_postpay_tv);
        orderCancelSubmitBtn.setOnClickListener(this);
        mOrderCancelReason.setOnChildClickListener(this);
        mCancelOrderAdapter = new CancelOrderAdapter(getActivity());
        mCancelOrderAdapter.setData(items);
        mOrderCancelReason.setAdapter(mCancelOrderAdapter);

        orderCancellationPostPayMessage.setVisibility(mIsPostPay ? View.VISIBLE : View.GONE);

        mOrderCancelReason.setOnGroupClickListener(new ExpandableListView.OnGroupClickListener() {

            @Override
            public boolean onGroupClick(ExpandableListView parent, View v, int groupPosition, long id) {
                hide_keyboard(getActivity().getApplicationContext(), v);
                if (parent.isGroupExpanded(groupPosition)) {
                    mOrderCancelReason.collapseGroupWithAnimation(groupPosition);
                } else {
                    mOrderCancelReason.expandGroupWithAnimation(groupPosition);
                }
                return true;
            }

        });
        populateData();
    }

    /**
     * Method that populates the Order Cancellation Dialog UI with API data
     */
    private void populateData() {
        mGroupItem = new GroupItem();
        mGroupItem.title = getString(R.string.order_cancel_select_reason);
        for (String reason : mOrderCancelReasonsList) {
            ChildItem child = new ChildItem();
            child.title = reason;
            mGroupItem.items.add(child);
        }
        items.add(mGroupItem);
        mCancelOrderAdapter.notifyDataSetChanged();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.order_cancellation_dialog_submit_btn:
                if (isValidData()) {
                    getDialog().dismiss();
                    mFragmentInteractionListener.showBlockingProgressBar();
                    mIRemindOrderDoneClickNotifier.onOrderCancelListener(mSelectedReason,
                            mOrderCancelComment.getText().toString());
                }
                break;
        }
    }

    @Override
    public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
        mOrderCancelErrorTv.setVisibility(View.GONE);
        mGroupItem.title = mOrderCancelReasonsList.get(childPosition);
        mSelectedReason = mOrderCancelReasonsList.get(childPosition);
        mCancelOrderAdapter.notifyDataSetChanged();

        if (parent.isGroupExpanded(groupPosition)) {
            mOrderCancelReason.collapseGroupWithAnimation(groupPosition);
        } else {
            mOrderCancelReason.expandGroupWithAnimation(groupPosition);
        }
        return true;
    }

    /**
     * Method to validate the mandatory field;if false, displays the error text
     *
     * @return the flag that determines the validity of data - appropriate reason selected or not
     */
    private boolean isValidData() {
        if (mGroupItem.title.equals(getString(R.string.order_cancel_select_reason))) {
            mOrderCancelErrorTv.setVisibility(View.VISIBLE);
            return false;
        }

        mOrderCancelErrorTv.setVisibility(View.GONE);
        return true;
    }

    /**
     * Interface definition for a callback to be invoked if order has to be cancelled
     */
    public interface IOrderCancelSubmitListener {
        /**
         * Callback to be invoked if user requests for order cancellation
         *
         * @param reason  the mandatory field;reason for cancelling the order
         * @param comment the optional field; editable field for entering the comments if any
         */
        void onOrderCancelListener(String reason, String comment);
    }

    private static class GroupItem {
        String title;
        List<ChildItem> items = new ArrayList<ChildItem>();
    }

    private static class ChildItem {
        String title;
    }

    private static class ChildHolder {
        TextView title;
    }

    private static class GroupHolder {
        TextView title;
    }

    /**
     * Adapter class to display the cancellation reasons in an expandable list view
     */
    public class CancelOrderAdapter extends AnimatedExpandableListView.AnimatedExpandableListAdapter {

        private LayoutInflater mLayoutInflater;
        private List<GroupItem> mGroupItems;

        public CancelOrderAdapter(Context context) {
            mLayoutInflater = LayoutInflater.from(context);
        }

        public void setData(List<GroupItem> items) {
            this.mGroupItems = items;
        }

        @Override
        public ChildItem getChild(int groupPosition, int childPosition) {
            return mGroupItems.get(groupPosition).items.get(childPosition);
        }

        @Override
        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        @Override
        public View getRealChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView,
                                     ViewGroup parent) {
            ChildHolder holder;
            ChildItem item = getChild(groupPosition, childPosition);
            if (convertView == null) {
                holder = new ChildHolder();
                convertView = mLayoutInflater.inflate(R.layout.custom_drop_down_item, parent, false);
                holder.title = (TextView) convertView.findViewById(R.id.drop_down_text);
                convertView.setTag(holder);
            } else {
                holder = (ChildHolder) convertView.getTag();
            }

            holder.title.setText(item.title);

            return convertView;
        }

        @Override
        public int getRealChildrenCount(int groupPosition) {
            return mGroupItems.get(groupPosition).items.size();
        }

        @Override
        public GroupItem getGroup(int groupPosition) {
            return mGroupItems.get(groupPosition);
        }

        @Override
        public int getGroupCount() {
            return mGroupItems.size();
        }

        @Override
        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        @Override
        public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {
            GroupHolder holder;
            GroupItem item = getGroup(groupPosition);
            if (convertView == null) {
                holder = new GroupHolder();
                convertView = mLayoutInflater.inflate(R.layout.order_cancel_group_item, parent, false);
                holder.title = (TextView) convertView.findViewById(R.id.order_cancel_group_title_tv);
                convertView.setTag(holder);
            } else {
                holder = (GroupHolder) convertView.getTag();
            }
            holder.title.setTextColor(ContextCompat.getColor(convertView.getContext(),
                    item.title.contains(getString(R.string.order_cancel_select_reason)) ?
                            R.color.common_header_text_color : R.color.black_text_color));
            holder.title.setText(item.title);

            return convertView;
        }

        @Override
        public boolean hasStableIds() {
            return true;
        }

        @Override
        public boolean isChildSelectable(int arg0, int arg1) {
            return true;
        }
    }
}
