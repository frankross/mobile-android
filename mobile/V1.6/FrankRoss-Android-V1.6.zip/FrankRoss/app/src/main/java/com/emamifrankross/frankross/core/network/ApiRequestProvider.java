/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.network;

import android.text.TextUtils;

import com.android.volley.DefaultRetryPolicy;
import com.emamifrankross.frankross.core.apimodels.Address;
import com.emamifrankross.frankross.core.apimodels.ApiAddress;
import com.emamifrankross.frankross.core.apimodels.ApiCart;
import com.emamifrankross.frankross.core.apimodels.ApiCartCheckout;
import com.emamifrankross.frankross.core.apimodels.ApiCategories;
import com.emamifrankross.frankross.core.apimodels.ApiChangeNumber;
import com.emamifrankross.frankross.core.apimodels.ApiCityDetails;
import com.emamifrankross.frankross.core.apimodels.ApiCommonError;
import com.emamifrankross.frankross.core.apimodels.ApiDeliverySlot;
import com.emamifrankross.frankross.core.apimodels.ApiDeviceRegister;
import com.emamifrankross.frankross.core.apimodels.ApiFAQ;
import com.emamifrankross.frankross.core.apimodels.ApiFulfillmentCenter;
import com.emamifrankross.frankross.core.apimodels.ApiGetAddress;
import com.emamifrankross.frankross.core.apimodels.ApiHomeBanner;
import com.emamifrankross.frankross.core.apimodels.ApiInitializePayment;
import com.emamifrankross.frankross.core.apimodels.ApiLocation;
import com.emamifrankross.frankross.core.apimodels.ApiLogin;
import com.emamifrankross.frankross.core.apimodels.ApiLogout;
import com.emamifrankross.frankross.core.apimodels.ApiNewTag;
import com.emamifrankross.frankross.core.apimodels.ApiNonPharmaProduct;
import com.emamifrankross.frankross.core.apimodels.ApiNotificationCentre;
import com.emamifrankross.frankross.core.apimodels.ApiNotificationCount;
import com.emamifrankross.frankross.core.apimodels.ApiNotifyMe;
import com.emamifrankross.frankross.core.apimodels.ApiOffer;
import com.emamifrankross.frankross.core.apimodels.ApiOrder;
import com.emamifrankross.frankross.core.apimodels.ApiOrderCancel;
import com.emamifrankross.frankross.core.apimodels.ApiOrderDetail;
import com.emamifrankross.frankross.core.apimodels.ApiOrderReminder;
import com.emamifrankross.frankross.core.apimodels.ApiOrdersList;
import com.emamifrankross.frankross.core.apimodels.ApiPaymentFailure;
import com.emamifrankross.frankross.core.apimodels.ApiPharmaProduct;
import com.emamifrankross.frankross.core.apimodels.ApiPrescriptionDescription;
import com.emamifrankross.frankross.core.apimodels.ApiPrescriptionList;
import com.emamifrankross.frankross.core.apimodels.ApiProduct;
import com.emamifrankross.frankross.core.apimodels.ApiRecentPharmaOrdersList;
import com.emamifrankross.frankross.core.apimodels.ApiReferFriend;
import com.emamifrankross.frankross.core.apimodels.ApiRegister;
import com.emamifrankross.frankross.core.apimodels.ApiResendOtp;
import com.emamifrankross.frankross.core.apimodels.ApiRewardPoints;
import com.emamifrankross.frankross.core.apimodels.ApiSetPassword;
import com.emamifrankross.frankross.core.apimodels.ApiSettings;
import com.emamifrankross.frankross.core.apimodels.ApiSocialLogin;
import com.emamifrankross.frankross.core.apimodels.ApiSocialRegister;
import com.emamifrankross.frankross.core.apimodels.ApiStatus;
import com.emamifrankross.frankross.core.apimodels.ApiStoreLocator;
import com.emamifrankross.frankross.core.apimodels.ApiUpdateUserInformation;
import com.emamifrankross.frankross.core.apimodels.ApiUpdateUserPassword;
import com.emamifrankross.frankross.core.apimodels.ApiUploadPrescription;
import com.emamifrankross.frankross.core.apimodels.ApiUploadPrescriptionComplete;
import com.emamifrankross.frankross.core.apimodels.ApiUserInformation;
import com.emamifrankross.frankross.core.apimodels.ApiVerifyOtp;
import com.emamifrankross.frankross.core.apimodels.Cart;
import com.emamifrankross.frankross.core.apimodels.DeliverySlot;
import com.emamifrankross.frankross.core.apimodels.DigitisedPrescription;
import com.emamifrankross.frankross.core.apimodels.FAQ;
import com.emamifrankross.frankross.core.apimodels.HelpTopics;
import com.emamifrankross.frankross.core.apimodels.Offer;
import com.emamifrankross.frankross.core.apimodels.OrderDetails;
import com.emamifrankross.frankross.core.apimodels.PaymentMethods;
import com.emamifrankross.frankross.core.apimodels.RecentPharmaProduct;
import com.emamifrankross.frankross.core.apimodels.RequestCartItem;
import com.emamifrankross.frankross.core.apimodels.RewardTransaction;
import com.emamifrankross.frankross.core.apimodels.Store;
import com.emamifrankross.frankross.gcm.NotificationTypes;
import com.emamifrankross.frankross.ui.adapters.AccountAdapter;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.CartRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.CheckOutDeliverySlotAdapter;
import com.emamifrankross.frankross.ui.adapters.CheckOutSummaryAdapter;
import com.emamifrankross.frankross.ui.adapters.FaqTopQueryAdapter;
import com.emamifrankross.frankross.ui.adapters.HomeFeaturedCategoriesAdapter;
import com.emamifrankross.frankross.ui.adapters.LocationChooserAdapter;
import com.emamifrankross.frankross.ui.adapters.NotificationCenterAdapter;
import com.emamifrankross.frankross.ui.adapters.OffersAdapter;
import com.emamifrankross.frankross.ui.adapters.OrderHistoryAdapter;
import com.emamifrankross.frankross.ui.adapters.OrderHistoryDetailsAdapter;
import com.emamifrankross.frankross.ui.adapters.PharmacyRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.PrescriptionAdapter;
import com.emamifrankross.frankross.ui.adapters.PrescriptionDetailsAdapter;
import com.emamifrankross.frankross.ui.adapters.PrescriptionFilterAdapter;
import com.emamifrankross.frankross.ui.adapters.RewardPointsAdapter;
import com.emamifrankross.frankross.ui.adapters.StoreLocatorAdapter;
import com.emamifrankross.frankross.ui.viewmodels.CommonRecyclerHeaderItem;
import com.emamifrankross.frankross.ui.viewmodels.HorizontalScrollerViewMoreDataItem;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryProductInfoHeaderItem;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryProductInfoItem;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryShippingChargesItem;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryTotalAmountItem;
import com.emamifrankross.frankross.ui.viewmodels.ProductDataModel;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderItem;
import com.emamifrankross.frankross.ui.viewmodels.UserInformation;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.FrankRossDateUtils;
import com.emamifrankross.frankross.utils.Utils;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by gowtham on 9/7/15.
 */

/**
 * This class constructs a Gson request with the request type, request url,
 * request headers, request body and request content type and
 * provides this Gson request to the manager
 */
public class ApiRequestProvider implements NotificationTypes {

    private static final String EQUALS = "=";
    private static final String AMPERSEND = "&";

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to get the
     * api health status. Cast success response to {@link ApiStatus.Response} in
     * {@link FRGsonRequest.SuccessResponseListener<ApiStatus.Response>}
     * <p/>
     * </p>
     *
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiStatus.Response, ApiCommonError> getApiStatusRequest(
            FRGsonRequest.SuccessResponseListener<ApiStatus.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {

        FRGsonRequest.IAPIRequest request = new FRGsonRequest.IAPIRequest() {

            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/status";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return getAccessHeader();
            }

            @Override
            public String getRequestBody() {
                return "";
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiStatus.Response, ApiCommonError> apiGsonRequest =
                new FRGsonRequest<ApiStatus.Response, ApiCommonError>(
                        request, ApiStatus.Response.class, ApiCommonError.class, successResponseListener,
                        errorResponseListener, requestTag);

        return apiGsonRequest;
    }

    /**
     * Creates and returns  {@link FRGsonRequest} used for registering device with Push notification
     *
     * @param postRequestBody       : Which passes GCM token frankross api server.
     *                              * @param successResponseListener listener to notify success response
     * @param errorResponseListener listener to notify error response
     * @param requestTag            tag of the request, needed for handling the request cancel
     * @return @link FRGsonRequest}
     */
    public static FRGsonRequest<ApiDeviceRegister.Response, ApiCommonError> getDeviceRegisterRequest(
            final ApiDeviceRegister.Request postRequestBody,
            final FRGsonRequest.SuccessResponseListener<ApiDeviceRegister.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest request = new FRGsonRequest.IAPIRequest() {

            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/devices";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return getAccessHeader();
            }

            @Override
            public String getRequestBody() {
                return postRequestBody.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiDeviceRegister.Response, ApiCommonError> apiGsonRequest =
                new FRGsonRequest<ApiDeviceRegister.Response, ApiCommonError>(
                        request, ApiDeviceRegister.Response.class, ApiCommonError.class, successResponseListener,
                        errorResponseListener, requestTag);

        return apiGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to log in
     * to the Frank Ross app.
     * in {@link FRGsonRequest.SuccessResponseListener<ApiLogin.Response>}
     * <p/>
     * </p>
     *
     * @param loginRequest            {@link JSONObject} of login user details
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiLogin.Response, ApiCommonError> getLoginRequest(
            final ApiLogin.Request loginRequest,
            FRGsonRequest.SuccessResponseListener<ApiLogin.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {

        FRGsonRequest.IAPIRequest request = new FRGsonRequest.IAPIRequest() {

            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/login";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return getAccessHeader();
            }

            @Override
            public String getRequestBody() {
                return loginRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiLogin.Response, ApiCommonError> loginGsonRequest =
                new FRGsonRequest<ApiLogin.Response, ApiCommonError>(
                        request, ApiLogin.Response.class, ApiCommonError.class, successResponseListener,
                        errorResponseListener, requestTag);

        return loginGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to log in to the Frank Ross app.
     * </p>
     *
     * @param gcmToken                gcm token
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiLogout.Response, ApiCommonError> getLogoutRequest(
            final String gcmToken,
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiLogout.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {

        FRGsonRequest.IAPIRequest request = new FRGsonRequest.IAPIRequest() {

            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/devices/" + gcmToken + "/unlink";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiLogout.Response, ApiCommonError> loginGsonRequest =
                new FRGsonRequest<ApiLogout.Response, ApiCommonError>(
                        request, ApiLogout.Response.class, ApiCommonError.class, successResponseListener,
                        errorResponseListener, requestTag);

        return loginGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to register
     * to the Frank Ross app
     * in {@link FRGsonRequest.SuccessResponseListener<ApiRegister.Response>}
     * <p/>
     * </p>
     *
     * @param registerRequest         {@link JSONObject} of registration user details
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiRegister.Response, ApiRegister.Response> getRegisterRequest(
            final ApiRegister.Request registerRequest,
            FRGsonRequest.SuccessResponseListener<ApiRegister.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiRegister.Response> errorResponseListener,
            String requestTag) {

        FRGsonRequest.IAPIRequest request = new FRGsonRequest.IAPIRequest() {

            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/user";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return getAccessHeader();
            }

            @Override
            public String getRequestBody() {
                return registerRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiRegister.Response, ApiRegister.Response> registerGsonRequest =
                new FRGsonRequest<ApiRegister.Response, ApiRegister.Response>(
                        request, ApiRegister.Response.class, ApiRegister.Response.class, successResponseListener,
                        errorResponseListener, requestTag);

        return registerGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to verify the otp.
     * Cast success response to {@link ApiVerifyOtp.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiVerifyOtp.Response>}
     * <p/>
     * </p>
     *
     * @param otp                     the user entered otp
     * @param verifyOtpRequest        {@link JSONObject} of the user details
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param header                  headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiVerifyOtp.Response, ApiVerifyOtp.ErrorResponse> getVerifyOtpForEmailRequest(
            final String otp,
            final ApiVerifyOtp.Request verifyOtpRequest,
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiVerifyOtp.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiVerifyOtp.ErrorResponse> errorResponseListener,
            String requestTag) {

        FRGsonRequest.IAPIRequest request = new FRGsonRequest.IAPIRequest() {

            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/otps/" + otp + "/verify";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return verifyOtpRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiVerifyOtp.Response, ApiVerifyOtp.ErrorResponse> verifyOtpGsonRequest =
                new FRGsonRequest<ApiVerifyOtp.Response, ApiVerifyOtp.ErrorResponse>(
                        request, ApiVerifyOtp.Response.class, ApiVerifyOtp.ErrorResponse.class, successResponseListener,
                        errorResponseListener, requestTag);

        return verifyOtpGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to create an otp.
     * Cast success response to {@link ApiResendOtp.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiResendOtp.Response>}
     * <p/>
     * </p>
     *
     * @param resendOtpRequest        {@link JSONObject} of the user details
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param header                  headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiResendOtp.Response, ApiCommonError> getCreateOtpForEmailRequest(
            final ApiResendOtp.Request resendOtpRequest,
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiResendOtp.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {

        FRGsonRequest.IAPIRequest request = new FRGsonRequest.IAPIRequest() {

            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/otps";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return resendOtpRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiResendOtp.Response, ApiCommonError> resendOtpGsonRequest =
                new FRGsonRequest<ApiResendOtp.Response, ApiCommonError>(
                        request, ApiResendOtp.Response.class, ApiCommonError.class, successResponseListener,
                        errorResponseListener, requestTag);

        return resendOtpGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to set the password.
     * Cast success response to {@link ApiSetPassword.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiSetPassword.Response>}
     * <p/>
     * </p>
     *
     * @param forgotPasswordRequest   {@link JSONObject} of the user details
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiSetPassword.Response, ApiCommonError> getSetPasswordRequest(
            final ApiSetPassword.Request forgotPasswordRequest,
            FRGsonRequest.SuccessResponseListener<ApiSetPassword.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest locationRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/user/password_using_otp";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return getAccessHeader();
            }

            @Override
            public String getRequestBody() {
                return forgotPasswordRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiSetPassword.Response, ApiCommonError> setPasswordGsonRequest =
                new FRGsonRequest<ApiSetPassword.Response, ApiCommonError>(
                        locationRequest, ApiSetPassword.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag);

        return setPasswordGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to get the
     * locations info.Cast success response to {@link ApiLocation.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiLocation.Response>}
     * <p/>
     * </p>
     *
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiLocation.Response, ApiCommonError> getLocationRequest(
            FRGsonRequest.SuccessResponseListener<ApiLocation.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {

        FRGsonRequest.IAPIRequest locationRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return getAccessHeader();
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiLocation.Response, ApiCommonError> locationGsonRequest =
                new FRGsonRequest<ApiLocation.Response, ApiCommonError>(
                        locationRequest, ApiLocation.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiLocation.Response postProcess(ApiLocation.Response response) {
                        mapLocationUiData(response);

                        return super.postProcess(response);
                    }
                };

        return locationGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to get the
     * city details.Cast success response to {@link ApiCityDetails.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiCityDetails.Response>}
     * <p/>
     * </p>
     *
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiCityDetails.Response, ApiCommonError> getCityDetailsRequest(
            final long cityId,
            FRGsonRequest.SuccessResponseListener<ApiCityDetails.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {

        FRGsonRequest.IAPIRequest locationRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/" + cityId;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return getAccessHeader();
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiCityDetails.Response, ApiCommonError> cityDetailsGsonRequest =
                new FRGsonRequest<ApiCityDetails.Response, ApiCommonError>(
                        locationRequest, ApiCityDetails.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag);

        return cityDetailsGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to get
     * the user information.Cast success response to {@link ApiUserInformation.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiUserInformation.Response>}
     * <p/>
     * </p>
     *
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param header                  headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiUserInformation.Response, ApiCommonError> getUserInformationRequest(
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiUserInformation.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest locationRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/user";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiUserInformation.Response, ApiCommonError> locationGsonRequest =
                new FRGsonRequest<ApiUserInformation.Response, ApiCommonError>(
                        locationRequest, ApiUserInformation.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiUserInformation.Response postProcess(ApiUserInformation.Response response) {

                        if (response != null && response.getUser() != null) {
                            UserInformation userInfo = new UserInformation();
                            userInfo.userId = response.getUser().getId();
                            userInfo.userMailId = response.getUser().getEmail();
                            userInfo.userMobileNumber = response.getUser().getPrimary_phone();
                            userInfo.userName = response.getUser().getName();
                            response.setUiData(userInfo);
                        }

                        return super.postProcess(response);
                    }
                };

        return locationGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to update
     * the user information.Cast success response to {@link ApiUpdateUserInformation.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiUpdateUserInformation.Response>}
     * <p/>
     * </p>
     *
     * @param updateUserRequest       {@link JSONObject} of the user details to be updated
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param header                  headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiUpdateUserInformation.Response, ApiCommonError> getUpdateUserInformationRequest(
            final ApiUpdateUserInformation.Request updateUserRequest,
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiUpdateUserInformation.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest locationRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/user";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return updateUserRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiUpdateUserInformation.Response, ApiCommonError> updateUserInformationGsonRequest = new FRGsonRequest<>(
                locationRequest, ApiUpdateUserInformation.Response.class, ApiCommonError.class,
                successResponseListener, errorResponseListener, requestTag);

        return updateUserInformationGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to update
     * the user password.Cast success response to {@link ApiUpdateUserPassword.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiUpdateUserPassword.Response>}
     * <p/>
     * </p>
     *
     * @param updateUserPasswordRequest {@link JSONObject} of the user details
     * @param successResponseListener   listener to notify success response
     * @param errorResponseListener     listener to notify error response
     * @param header                    headers with accessToken
     * @param requestTag                tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiUpdateUserPassword.Response, ApiCommonError> getUpdateUserPasswordRequest(
            final ApiUpdateUserPassword.Request updateUserPasswordRequest,
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiUpdateUserPassword.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest locationRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/user/password";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return updateUserPasswordRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiUpdateUserPassword.Response, ApiCommonError> updatePasswordGsonRequest = new FRGsonRequest<>(
                locationRequest, ApiUpdateUserPassword.Response.class, ApiCommonError.class,
                successResponseListener, errorResponseListener, requestTag);

        return updatePasswordGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to update
     * the user phone number.Cast success response to {@link ApiChangeNumber.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiChangeNumber.Response>}
     * <p/>
     * </p>
     *
     * @param changeNumberRequest     {@link JSONObject} of the user change number details
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiChangeNumber.Response, ApiCommonError> getChangeNumberRequest(
            final ApiChangeNumber.Request changeNumberRequest,
            FRGsonRequest.SuccessResponseListener<ApiChangeNumber.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest locationRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/user/primary_phone";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return getAccessHeader();
            }

            @Override
            public String getRequestBody() {
                return changeNumberRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiChangeNumber.Response, ApiCommonError> changeNumberGsonRequest = new FRGsonRequest<>(
                locationRequest, ApiChangeNumber.Response.class, ApiCommonError.class,
                successResponseListener, errorResponseListener, requestTag);

        return changeNumberGsonRequest;

    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to get the delivery
     * addresses.Cast success response to {@link ApiGetAddress.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiGetAddress.Response>}
     * <p/>
     * </p>
     *
     * @param cityId                  the city id
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param header                  headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiGetAddress.Response, ApiCommonError> getDeliveryAddressRequest(
            final int cityId,
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiGetAddress.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/" + cityId + "/addresses";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiGetAddress.Response, ApiCommonError> getAddressGsonRequest =
                new FRGsonRequest<ApiGetAddress.Response, ApiCommonError>(
                        getAddressRequest, ApiGetAddress.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiGetAddress.Response postProcess(ApiGetAddress.Response response) {
                        if (response != null && response.getAddressList() != null && response.getAddressList().size() > 0) {
                            List<AccountAdapter.AccountAddressItem> uiDataList = new ArrayList<>(response.getAddressList().size());

                            for (Address apiAddress : response.getAddressList()) {
                                AccountAdapter.AccountAddressItem addressItem = new AccountAdapter.AccountAddressItem();
                                addressItem.addressId = apiAddress.getId();
                                addressItem.userName = apiAddress.getFullName();
                                addressItem.mobileNumber = "+91 " + apiAddress.getPhoneNumber();
                                addressItem.isDefaultAddress = apiAddress.isDefaultValue();
                                addressItem.fullAddress = apiAddress.getFullAddress();
                                addressItem.addressCategory = apiAddress.getAddressType();
                                addressItem.areaId = apiAddress.getArea().getId();
                                addressItem.isActive = apiAddress.getArea().isActive();

                                uiDataList.add(addressItem);
                            }

                            response.setUiData(uiDataList);
                        }
                        return super.postProcess(response);
                    }
                };

        return getAddressGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to add a new delivery
     * address.Cast success response to {@link ApiAddress.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiAddress.Response>}
     * <p/>
     * </p>
     *
     * @param cityId                  the city id
     * @param addAddressRequestData   {@link JSONObject} of the delivery address to be added
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param header                  headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiAddress.Response, ApiCommonError> addDeliveryAddressRequest(
            final int cityId, final ApiAddress.Request addAddressRequestData,
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiAddress.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {

        FRGsonRequest.IAPIRequest addAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/" + cityId + "/addresses";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return addAddressRequestData.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiAddress.Response, ApiCommonError> addAddressGsonRequest =
                new FRGsonRequest<ApiAddress.Response, ApiCommonError>(
                        addAddressRequest, ApiAddress.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag);

        return addAddressGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to update a delivery
     * address.Cast success response to {@link ApiAddress.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiAddress.Response>}
     * <p/>
     * </p>
     *
     * @param cityId                   the city id
     * @param updateAddressRequestData {@link JSONObject} of the updated delivery address
     * @param successResponseListener  listener to notify success response
     * @param errorResponseListener    listener to notify error response
     * @param header                   headers with accessToken
     * @param requestTag               tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiAddress.Response, ApiCommonError> updateDeliveryAddressRequest(
            final int cityId, final ApiAddress.Request updateAddressRequestData,
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiAddress.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            final String requestTag) {

        FRGsonRequest.IAPIRequest addAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/"
                        + cityId + "/addresses/" + updateAddressRequestData.getAddress().getId();
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return updateAddressRequestData.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiAddress.Response, ApiCommonError> addAddressGsonRequest =
                new FRGsonRequest<ApiAddress.Response, ApiCommonError>(
                        addAddressRequest, ApiAddress.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag);

        return addAddressGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to update a delivery
     * address.Cast success response to {@link ApiAddress.DefaultResponse}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiAddress.DefaultResponse>}
     * <p/>
     * </p>
     *
     * @param addressId               the id of the address to be set as default
     * @param setAsDefaultRequestData {@link JSONObject} of the delivery address
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param header                  headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiAddress.DefaultResponse, ApiCommonError> defaultAddressRequest(
            final String addressId,
            final int cityId, final ApiAddress.DefaultRequest setAsDefaultRequestData,
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiAddress.DefaultResponse> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {

        FRGsonRequest.IAPIRequest addAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/"
                        + cityId + "/addresses/" + addressId;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return setAsDefaultRequestData.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiAddress.DefaultResponse, ApiCommonError> addAddressGsonRequest =
                new FRGsonRequest<ApiAddress.DefaultResponse, ApiCommonError>(
                        addAddressRequest, ApiAddress.DefaultResponse.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag);

        return addAddressGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to delete an
     * address.Cast success response to {@link ApiAddress.DefaultResponse}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiAddress.DefaultResponse>}
     * <p/>
     * </p>
     *
     * @param cityId                  the city id
     * @param addressId               the id of the address to be deleted
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param header                  headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiAddress.DefaultResponse, ApiCommonError> getDeleteDeliveryAddressRequest(
            final int cityId, final long addressId,
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiAddress.DefaultResponse> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            final String requestTag) {

        FRGsonRequest.IAPIRequest addAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.DEL;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/"
                        + cityId + "/addresses/" + addressId;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiAddress.DefaultResponse, ApiCommonError> addAddressGsonRequest =
                new FRGsonRequest<ApiAddress.DefaultResponse, ApiCommonError>(
                        addAddressRequest, ApiAddress.DefaultResponse.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag);

        return addAddressGsonRequest;
    }


    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to get the
     * delivery slots.Cast success response to {@link ApiDeliverySlot.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiDeliverySlot.Response>}
     * <p/>
     * </p>
     *
     * @param areaId                  the areaId of the delivery address selected by the user
     * @param cityId                  the city id
     * @param prescriptionId          to check if prescription is uploaded for the order
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param header                  headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiDeliverySlot.Response, ApiCommonError> getDeliverySlotRequest(
            final int areaId, final int cityId,
            final long prescriptionId, final int fulFillmentCenterId,
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiDeliverySlot.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getDeliverySlotRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                String withPrescription = (prescriptionId < 0) ? "false" : "true";

                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/"
                        + cityId + "/delivery_slots?area_id=" + areaId + "&with_prescription=" + withPrescription
                        + "&fulfillment_center_id=" + fulFillmentCenterId;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiDeliverySlot.Response, ApiCommonError> updatePasswordGsonRequest =
                new FRGsonRequest<ApiDeliverySlot.Response, ApiCommonError>(
                        getDeliverySlotRequest, ApiDeliverySlot.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiDeliverySlot.Response postProcess(ApiDeliverySlot.Response response) {
                        mapDeliverySlotUIData(response);
                        return super.postProcess(response);
                    }

                };

        return updatePasswordGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to get the home screen
     * banner image urls.Cast success response to {@link ApiHomeBanner.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiHomeBanner.Response>}
     * <p/>
     * </p>
     *
     * @param cityId                  the city id
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiHomeBanner.Response, ApiCommonError> getHomeBannersRequest(
            final int cityId, FRGsonRequest.SuccessResponseListener<ApiHomeBanner.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getBannerRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/cities/" + cityId + "/banners";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return null;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiHomeBanner.Response, ApiCommonError> bannerGsonRequest =
                new FRGsonRequest<ApiHomeBanner.Response, ApiCommonError>(
                        getBannerRequest, ApiHomeBanner.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiHomeBanner.Response postProcess(ApiHomeBanner.Response response) {
                        mapBannerUiData(response);
                        return super.postProcess(response);
                    }
                };

        return bannerGsonRequest;
    }

    /**
     * GET CATEGORIES
     * <p>
     * Creates and returns {@link FRGsonRequest} used to get categories.
     * Cast success response to {@link ApiCategories.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiCategories.Response>}
     * <p/>
     * </p>
     *
     * @param currentCityId           the city id
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiCategories.Response, ApiCommonError> getCategoriesRequest(
            final int currentCityId, FRGsonRequest.SuccessResponseListener<ApiCategories.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getCategoriesRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/cities/" + currentCityId + "/categories";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return null;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiCategories.Response, ApiCommonError> categoriesGsonRequest =
                new FRGsonRequest<ApiCategories.Response, ApiCommonError>(
                        getCategoriesRequest, ApiCategories.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiCategories.Response postProcess(ApiCategories.Response response) {
                        mapCategoryUIData(response);

                        return super.postProcess(response);
                    }
                };

        return categoriesGsonRequest;
    }

    /**
     * GET HOME CATEGORIES AND PROMOTIONS.
     *
     * @param cityId                  the city id
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiCategories.HomeCategoryResponse, ApiCommonError> getHomeFeaturedCategoriesRequest(
            final int cityId, FRGsonRequest.SuccessResponseListener<ApiCategories.HomeCategoryResponse> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getBaseCategoriesRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/cities/" + cityId + "/categories/featured";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return getAccessHeader();
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiCategories.HomeCategoryResponse, ApiCommonError> baseCategoryGsonRequest =
                new FRGsonRequest<ApiCategories.HomeCategoryResponse, ApiCommonError>(
                        getBaseCategoriesRequest, ApiCategories.HomeCategoryResponse.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiCategories.HomeCategoryResponse postProcess(ApiCategories.HomeCategoryResponse response) {
                        mapHomeCategoryUIData(response);
                        return super.postProcess(response);
                    }
                };

        return baseCategoryGsonRequest;
    }

    /**
     * GET BASE CATEGORIES
     *
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiCategories.BaseCategoryResponse, ApiCommonError> getBaseCategoriesRequest(
            FRGsonRequest.SuccessResponseListener<ApiCategories.BaseCategoryResponse> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getBaseCategoriesRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/categories";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return null;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiCategories.BaseCategoryResponse, ApiCommonError> baseCategoryGsonRequest =
                new FRGsonRequest<ApiCategories.BaseCategoryResponse, ApiCommonError>(
                        getBaseCategoriesRequest, ApiCategories.BaseCategoryResponse.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiCategories.BaseCategoryResponse postProcess(ApiCategories.BaseCategoryResponse response) {

                        return super.postProcess(response);
                    }
                };

        return baseCategoryGsonRequest;
    }


    /**
     * GET PRIMARY CATEGORIES
     *
     * @param categoryId              the city id
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiCategories.PrimaryCategoryResponse, ApiCommonError> getPrimaryCategoriesRequest(
            final long categoryId, final int cityId,
            FRGsonRequest.SuccessResponseListener<ApiCategories.PrimaryCategoryResponse> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getBaseCategoriesRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/cities/" + cityId + "/categories/" + categoryId;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return null;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiCategories.PrimaryCategoryResponse, ApiCommonError> primaryCategoryGsonRequest = new FRGsonRequest<ApiCategories.PrimaryCategoryResponse, ApiCommonError>(
                getBaseCategoriesRequest, ApiCategories.PrimaryCategoryResponse.class, ApiCommonError.class,
                successResponseListener, errorResponseListener, requestTag) {
            @Override
            protected ApiCategories.PrimaryCategoryResponse postProcess(ApiCategories.PrimaryCategoryResponse response) {
                return super.postProcess(response);
            }
        };

        return primaryCategoryGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to get the
     * cart calculations.Cast success response to {@link ApiCart.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiCart.Response>}
     * <p/>
     * </p>
     *
     * @param requestCartItems        {@link JSONObject} of the cart info
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiCart.Response, ApiCommonError> getCartCalculationRequest(
            final int cityId, final List<RequestCartItem> requestCartItems,
            FRGsonRequest.SuccessResponseListener<ApiCart.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest cartApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/"
                        + cityId + "/cart_calculations?" + getRequestParams(requestCartItems);
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return null;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiCart.Response, ApiCommonError> cartCalculationsGsonRequest =
                new FRGsonRequest<ApiCart.Response, ApiCommonError>(
                        cartApiRequest, ApiCart.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiCart.Response postProcess(ApiCart.Response response) {
                        mapCartUIData(response);
                        return super.postProcess(response);
                    }
                };

        return cartCalculationsGsonRequest;
    }

    private static String getRequestParams(List<RequestCartItem> requestCartItems) {
        StringBuilder requestParams = new StringBuilder();
        int index = 0;
        for (RequestCartItem cartItem : requestCartItems) {
            requestParams.append("line_items[][variant_id]")
                    .append(EQUALS)
                    .append(cartItem.getVariantId())
                    .append(AMPERSEND)
                    .append("line_items[][quantity]")
                    .append(EQUALS)
                    .append(cartItem.getQuantity());

            if (index < requestCartItems.size() - 1) requestParams.append(AMPERSEND);
            index++;
        }
        return requestParams.toString();
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to add or update
     * the cart.Cast success response to {@link ApiCart.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiCart.Response>}
     * <p/>
     * </p>
     *
     * @param cityId                  the city id
     * @param cartRequest             {@link JSONObject} of the cart info
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param header                  headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiCart.Response, ApiCommonError> getAddOrUpdateCartRequest(
            final int cityId, final ApiCart.Request cartRequest,
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiCart.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest cartApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/"
                        + cityId + "/cart";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return cartRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiCart.Response, ApiCommonError> cartGsonRequest =
                new FRGsonRequest<ApiCart.Response, ApiCommonError>(
                        cartApiRequest, ApiCart.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiCart.Response postProcess(ApiCart.Response response) {
                        mapCartUIData(response);
                        return super.postProcess(response);
                    }
                };

        return cartGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to get the
     * delivery slots.Cast success response to {@link ApiDeliverySlot.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiDeliverySlot.Response>}
     * <p/>
     * </p>
     *
     * @param cityId                  the city id
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param header                  headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiFulfillmentCenter.Response, ApiCommonError> getFulfillmentCenterRequest(
            final ApiFulfillmentCenter.Request fulfillmentCenterRequest, final int cityId,
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiFulfillmentCenter.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getFulfillmentCenterRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/"
                        + cityId + "/cart/update_address_and_fullfillment_center";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return fulfillmentCenterRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        return new FRGsonRequest<ApiFulfillmentCenter.Response, ApiCommonError>(
                getFulfillmentCenterRequest, ApiFulfillmentCenter.Response.class, ApiCommonError.class,
                successResponseListener, errorResponseListener, requestTag) {
            @Override
            protected ApiFulfillmentCenter.Response postProcess(ApiFulfillmentCenter.Response response) {
                return super.postProcess(response);
            }

        };
    }

    public static String getCartStripInfo(String innerPackagingQuantity, String outerPackagingQuantity) {
        if (!TextUtils.isEmpty(outerPackagingQuantity) && !TextUtils.isEmpty(innerPackagingQuantity)) {
            String quantity = outerPackagingQuantity.substring(0, 1);
            String strip = outerPackagingQuantity.substring(1);
            return strip + "(" + quantity + "x" + innerPackagingQuantity + ")";
        } else if (TextUtils.isEmpty(outerPackagingQuantity) && !TextUtils.isEmpty(innerPackagingQuantity)) {
            return innerPackagingQuantity;
        } else if (!TextUtils.isEmpty(outerPackagingQuantity) && TextUtils.isEmpty(innerPackagingQuantity)) {
            return outerPackagingQuantity.substring(1);
        }

        return "";
    }

    public static String getStripInfo(String innerPackagingQuantity, String outerPackagingQuantity) {
        if (!TextUtils.isEmpty(outerPackagingQuantity) && !TextUtils.isEmpty(innerPackagingQuantity)) {
            return outerPackagingQuantity + " X " + innerPackagingQuantity;
        } else if (TextUtils.isEmpty(outerPackagingQuantity) && !TextUtils.isEmpty(innerPackagingQuantity)) {
            return innerPackagingQuantity;
        } else if (!TextUtils.isEmpty(outerPackagingQuantity) && TextUtils.isEmpty(innerPackagingQuantity)) {
            return outerPackagingQuantity;
        }

        return "";
    }

    private static String getProductStatus(boolean prescriptionAvailable, boolean prescriptionRequired) {
        if (prescriptionRequired) {
            if (prescriptionAvailable) {
                return "Prescription present";
            } else {
                return "Prescription required";
            }
        }

        return "";
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to get
     * the cart information.Cast success response to {@link ApiCart.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiCart.Response>}
     * <p/>
     * </p>
     *
     * @param cityId                  the city id
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param headers                 headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiCart.Response, ApiCommonError> getCartItemsRequest(
            final int cityId, final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiCart.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest cartApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/"
                        + cityId + "/cart";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiCart.Response, ApiCommonError> cartGsonRequest =
                new FRGsonRequest<ApiCart.Response, ApiCommonError>(
                        cartApiRequest, ApiCart.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiCart.Response postProcess(ApiCart.Response response) {
                        mapCartUIData(response);
                        return super.postProcess(response);
                    }
                };

        return cartGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to delete a
     * cart item.Cast success response to {@link ApiCart.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiCart.Response>}
     * <p/>
     * </p>
     *
     * @param variantId               the unique id that identifies each product
     * @param cityId                  the city id
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param headers                 headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiCart.Response, ApiCommonError> getDeleteCartItemRequest(
            final long variantId, final int cityId, final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiCart.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest cartApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.DEL;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/"
                        + cityId + "/cart/" + variantId;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiCart.Response, ApiCommonError> cartGsonRequest =
                new FRGsonRequest<ApiCart.Response, ApiCommonError>(
                        cartApiRequest, ApiCart.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiCart.Response postProcess(ApiCart.Response response) {
                        mapCartUIData(response);
                        return super.postProcess(response);
                    }
                };

        return cartGsonRequest;
    }

    /**
     * APPLY COUPON CODE
     * <p>
     * Creates and returns {@link FRGsonRequest} used to apply coupon to cart.
     * <p/>
     * </p>
     *
     * @param coupon                  coupon value
     * @param cityId                  the city id
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param headers                 headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiCart.Response, ApiCommonError> getApplyCouponCodeRequest(
            final String coupon, final int cityId, final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiCart.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest cartApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/"
                        + cityId + "/cart/coupon";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return new ApiCart.CouponRequest(coupon).toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiCart.Response, ApiCommonError> applyCouponCodeGsonRequest =
                new FRGsonRequest<ApiCart.Response, ApiCommonError>(
                        cartApiRequest, ApiCart.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiCart.Response postProcess(ApiCart.Response response) {
                        mapCartUIData(response);
                        return super.postProcess(response);
                    }
                };

        return applyCouponCodeGsonRequest;
    }

    /**
     * DELETE COUPON CODE
     * <p>
     * Creates and returns {@link FRGsonRequest} used to delete coupon to cart.
     * <p/>
     * </p>
     *
     * @param coupon                  coupon value
     * @param cityId                  the city id
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param headers                 headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiCart.Response, ApiCommonError> getDeleteCouponCodeRequest(
            final String coupon, final int cityId, final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiCart.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest cartApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.DEL;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/"
                        + cityId + "/cart/coupon?coupon_code=" + coupon;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiCart.Response, ApiCommonError> deleteCouponCodeGsonRequest =
                new FRGsonRequest<ApiCart.Response, ApiCommonError>(
                        cartApiRequest, ApiCart.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiCart.Response postProcess(ApiCart.Response response) {
                        mapCartUIData(response);
                        return super.postProcess(response);
                    }
                };

        return deleteCouponCodeGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to checkout the
     * cart.Cast success response to {@link ApiCartCheckout.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiCartCheckout.Response>}
     * <p/>
     * </p>
     *
     * @param checkOutRequest         cart checkout information
     * @param cityId                  the city id
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param headers                 headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiCartCheckout.Response, ApiCartCheckout.ErrorResponse> getCartCheckoutRequest(
            final int cityId, final ApiCartCheckout.Request checkOutRequest,
            final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiCartCheckout.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCartCheckout.ErrorResponse> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getOrderListApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/"
                        + cityId + "/cart/checkout";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return checkOutRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiCartCheckout.Response, ApiCartCheckout.ErrorResponse> getCartCheckoutGsonRequest =
                new FRGsonRequest<ApiCartCheckout.Response, ApiCartCheckout.ErrorResponse>(
                        getOrderListApiRequest, ApiCartCheckout.Response.class, ApiCartCheckout.ErrorResponse.class,
                        successResponseListener, errorResponseListener, requestTag);

        return getCartCheckoutGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to complete
     * the order.Cast success response to {@link ApiOrder.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiOrder.Response>}
     * <p/>
     * </p>
     *
     * @param orderId                 identifies each order uniquely
     * @param placeOrderRequest       order information
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param headers                 headers with accessToken
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiOrder.Response, ApiOrder.ErrorResponse> getOrderPlaceRequest(
            final long orderId,
            final ApiOrder.Request placeOrderRequest, final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiOrder.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiOrder.ErrorResponse> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getOrderListApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/orders/"
                        + orderId + "/complete";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return placeOrderRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiOrder.Response, ApiOrder.ErrorResponse> placeOrderGsonRequest =
                new FRGsonRequest<ApiOrder.Response, ApiOrder.ErrorResponse>(
                        getOrderListApiRequest, ApiOrder.Response.class, ApiOrder.ErrorResponse.class,
                        successResponseListener, errorResponseListener, requestTag);

        return placeOrderGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to revise
     * the order.Cast success response to {@link ApiOrder.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiOrder.Response>}
     * </p>
     *
     * @param orderId                 identifies each order uniquely
     * @param reviseOrderRequest      {@link JSONObject} of the order info
     * @param headers                 headers with accessToken
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiOrder.Response, ApiOrder.ErrorResponse> getReviseOrderRequest(
            final long orderId,
            final ApiOrder.Request reviseOrderRequest, final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiOrder.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiOrder.ErrorResponse> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getOrderListApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/orders/"
                        + orderId + "/revise";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return reviseOrderRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiOrder.Response, ApiOrder.ErrorResponse> reviseOrderGsonRequest =
                new FRGsonRequest<ApiOrder.Response, ApiOrder.ErrorResponse>(
                        getOrderListApiRequest, ApiOrder.Response.class, ApiOrder.ErrorResponse.class,
                        successResponseListener, errorResponseListener, requestTag);

        return reviseOrderGsonRequest;
    }


    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to cancel
     * the order.Cast success response to {@link ApiOrderCancel.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiOrderCancel.Response>}
     * <p/>
     *
     * @param orderId                 identifies each order uniquely
     * @param cancelOrderRequest      {@link JSONObject} of the cancel order with reason for cancellation
     * @param headers                 headers with accessToken
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiOrderCancel.Response, ApiCommonError> getOrderCancelRequest(
            final long orderId,
            final ApiOrderCancel.Request cancelOrderRequest, final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiOrderCancel.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getOrderListApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/orders/"
                        + orderId + "/cancel";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return cancelOrderRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiOrderCancel.Response, ApiCommonError> cancelOrderGsonRequest =
                new FRGsonRequest<ApiOrderCancel.Response, ApiCommonError>(
                        getOrderListApiRequest, ApiOrderCancel.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag);

        return cancelOrderGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to list of orders.
     * Cast success response to {@link ApiOrdersList.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiOrdersList.Response>}
     * <p/>
     *
     * @param currentPage             the current page count
     * @param recordsPerPage          the records per page
     * @param headers                 headers with accessToken.
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   error response listener to notify the error result (other than 200 status code).
     * @param requestTag              tag of the request, needed for handling the request cancel.     @return list of orders
     */
    public static FRGsonRequest<ApiOrdersList.Response, ApiCommonError> getPaginatedOrderListRequest(
            final int currentPage, final int recordsPerPage, final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiOrdersList.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getOrderListApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/orders?page=" + currentPage + "&per_page=" + recordsPerPage;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiOrdersList.Response, ApiCommonError> getOrderGsonRequest =
                new FRGsonRequest<ApiOrdersList.Response, ApiCommonError>(
                        getOrderListApiRequest, ApiOrdersList.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiOrdersList.Response postProcess(ApiOrdersList.Response response) {
                        if (response != null && response.getOrderList() != null) {
                            List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>();
                            for (ApiOrdersList.Order order : response.getOrderList()) {
                                OrderHistoryAdapter.OrderHistoryItem orderHistoryItem = new OrderHistoryAdapter.OrderHistoryItem();
                                orderHistoryItem.order = order;

                                uiDataList.add(orderHistoryItem);
                            }
                            response.setUiDataList(uiDataList);
                        }
                        return super.postProcess(response);
                    }
                };

        return getOrderGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the details
     * of an order.Cast success response to {@link ApiOrderDetail.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiOrderDetail.Response>}
     * <p/>
     *
     * @param orderId                 identifies each order uniquely
     * @param headers                 headers with accessToken
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiOrderDetail.Response, ApiCommonError> getOrderDetailsRequest(
            final long orderId, final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiOrderDetail.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getOrderListApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/orders/" + orderId;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiOrderDetail.Response, ApiCommonError> getOrderDetailGsonRequest =
                new FRGsonRequest<ApiOrderDetail.Response, ApiCommonError>(
                        getOrderListApiRequest, ApiOrderDetail.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiOrderDetail.Response postProcess(ApiOrderDetail.Response response) {
                        mapOrderDetailsUIData(response);
                        return super.postProcess(response);
                    }
                };

        return getOrderDetailGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the details
     * of an revised order.Cast success response to {@link ApiOrderDetail.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiOrderDetail.Response>}
     * <p/>
     *
     * @param orderId                 identifies each order uniquely
     * @param headers                 headers with accessToken
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiOrderDetail.Response, ApiCommonError> getRevisedOrderDetailsRequest(
            final long orderId, final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiOrderDetail.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getOrderListApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/orders/" + orderId;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiOrderDetail.Response, ApiCommonError> getOrderDetailGsonRequest =
                new FRGsonRequest<ApiOrderDetail.Response, ApiCommonError>(
                        getOrderListApiRequest, ApiOrderDetail.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiOrderDetail.Response postProcess(ApiOrderDetail.Response response) {
                        mapRevisedOrderCartData(response);

                        return super.postProcess(response);
                    }
                };

        return getOrderDetailGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to set the reminder
     * for re order.Cast success response to {@link ApiOrderReminder.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiOrderReminder.Response>}
     * <p/>
     *
     * @param orderId                 identifies each order uniquely
     * @param headers                 headers with accessToken
     * @param orderReminderRequest    {@link JSONObject} of the reorder reminder
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiOrderReminder.Response, ApiCommonError> getOrderReminderRequest(
            final long orderId, final Map<String, String> headers,
            final ApiOrderReminder.Request orderReminderRequest,
            FRGsonRequest.SuccessResponseListener<ApiOrderReminder.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getOrderListApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/orders/" + orderId + "/reminder";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return orderReminderRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiOrderReminder.Response, ApiCommonError> getOrderDetailGsonRequest =
                new FRGsonRequest<ApiOrderReminder.Response, ApiCommonError>(
                        getOrderListApiRequest, ApiOrderReminder.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag);

        return getOrderDetailGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to delete the reminder
     * for re order.Cast success response to {@link ApiOrderReminder.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiOrderReminder.Response>}
     * <p/>
     *
     * @param orderId                 identifies each order uniquely
     * @param headers                 headers with accessToken
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiOrderReminder.Response, ApiCommonError> getOrderReminderDeleteRequest(
            final long orderId, final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiOrderReminder.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getOrderListApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.DEL;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/orders/" + orderId + "/reminder";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiOrderReminder.Response, ApiCommonError> getOrderDetailGsonRequest =
                new FRGsonRequest<ApiOrderReminder.Response, ApiCommonError>(
                        getOrderListApiRequest, ApiOrderReminder.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag);

        return getOrderDetailGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the recent
     * orders.Cast success response to {@link ApiRecentPharmaOrdersList.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiRecentPharmaOrdersList.Response>}
     * <p/>
     *
     * @param cityId                  the city id
     * @param headers                 headers with accessToken
     * @param recentItemsCount        the number of products to be fetched
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiRecentPharmaOrdersList.Response, ApiCommonError> getRecentPharmaProducts(
            final int cityId, final int recentItemsCount,
            final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiRecentPharmaOrdersList.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getRecentOrdersListApiRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/" + cityId
                        + "/recent_pharma_orders?count=" + recentItemsCount;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiRecentPharmaOrdersList.Response, ApiCommonError> getOrderDetailGsonRequest =
                new FRGsonRequest<ApiRecentPharmaOrdersList.Response, ApiCommonError>(
                        getRecentOrdersListApiRequest, ApiRecentPharmaOrdersList.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiRecentPharmaOrdersList.Response postProcess(ApiRecentPharmaOrdersList.Response response) {
                        mapRecentPharmaOrdersUiData(response);
                        return super.postProcess(response);
                    }
                };

        return getOrderDetailGsonRequest;

    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list of
     * prescriptions.Cast success response to {@link ApiPrescriptionList.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiPrescriptionList.Response>}
     * <p/>
     *
     * @param headers                 headers with accessToken
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel     @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiPrescriptionList.Response, ApiCommonError> getPrescriptionListRequest(
            final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiPrescriptionList.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest prescriptionListRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/prescriptions";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiPrescriptionList.Response, ApiCommonError> prescriptionListGsonRequest =
                new FRGsonRequest<ApiPrescriptionList.Response, ApiCommonError>(
                        prescriptionListRequest, ApiPrescriptionList.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiPrescriptionList.Response postProcess(ApiPrescriptionList.Response response) {
                        mapPrescriptionListUIData(response);

                        return super.postProcess(response);
                    }
                };

        return prescriptionListGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the details of
     * a prescription.Cast success response to {@link ApiPrescriptionDescription.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiPrescriptionDescription.Response>}
     * <p/>
     *
     * @param prescriptionId          the details of the prescription with prescription id
     * @param headers                 headers with accessToken
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiPrescriptionDescription.Response, ApiCommonError> getPrescriptionDetailsRequest(
            final long prescriptionId, final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiPrescriptionDescription.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest prescriptionDescriptionRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/prescriptions/" + prescriptionId;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiPrescriptionDescription.Response, ApiCommonError> prescriptionDescriptionGsonRequest =
                new FRGsonRequest<ApiPrescriptionDescription.Response, ApiCommonError>(
                        prescriptionDescriptionRequest, ApiPrescriptionDescription.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {

                    @Override
                    protected ApiPrescriptionDescription.Response postProcess(ApiPrescriptionDescription.Response response) {
                        mapPrescriptionDetailsUIData(response);

                        return super.postProcess(response);
                    }
                };

        return prescriptionDescriptionGsonRequest;
    }

    /**
     * Its Http Post request for Uploading an PRESCRIPTIONS.
     *
     * @param currentCityId           the city id
     * @param request                 : Json EmailRequest body : content to be uploaded
     * @param headers                 : headers with accessToken
     * @param successResponseListener : success response listener to notify the result under 200  status code.
     * @param errorResponseListener   : listener to notify error response
     * @param requestTag              : tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */

    public static FRGsonRequest<ApiUploadPrescription.PostResponse, ApiCommonError> getUploadPrescriptionRequest(
            final int currentCityId, final ApiUploadPrescription.PostRequest request,
            final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiUploadPrescription.PostResponse> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest prescriptionRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/" +
                        currentCityId + "/prescription_uploads";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return request.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiUploadPrescription.PostResponse, ApiCommonError> uploadPrescriptionRequest =
                new FRGsonRequest<ApiUploadPrescription.PostResponse, ApiCommonError>(
                        prescriptionRequest, ApiUploadPrescription.PostResponse.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag);
        uploadPrescriptionRequest.setRetryPolicy(new DefaultRetryPolicy(60000, 1, 1));


        return uploadPrescriptionRequest;
    }

    /**
     * Its Http Put request for Uploading an PRESCRIPTIONS with given ID.
     *
     * @param currentCityId           the city id
     * @param uploadPrescriptionId    : uploads an image to existing prescription.
     * @param request                 : Json EmailRequest body : content to be uploaded
     * @param headers                 : headers with accessToken
     * @param successResponseListener : success response listener to notify the result under 200  status code.
     * @param errorResponseListener   : listener to notify error response
     * @param requestTag              : tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */

    public static FRGsonRequest<ApiUploadPrescription.PutResponse, ApiCommonError> getUploadPrescriptionRequest(
            final int currentCityId, final long uploadPrescriptionId, final ApiUploadPrescription.PutRequest request,
            final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiUploadPrescription.PutResponse> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest prescriptionRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/" +
                        currentCityId + "/prescription_uploads/" + uploadPrescriptionId;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return request.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiUploadPrescription.PutResponse, ApiCommonError> uploadPrescriptionRequest =
                new FRGsonRequest<ApiUploadPrescription.PutResponse, ApiCommonError>(
                        prescriptionRequest, ApiUploadPrescription.PutResponse.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag);

        return uploadPrescriptionRequest;
    }

    /**
     * Its Http Put EmailRequest to complete the Upload Prescription.
     *
     * @param currentCityId           the city id
     * @param uploadPrescriptionId    : id of the prescription to be marked as completed
     * @param headers                 : headers with access token
     * @param successResponseListener : success response listener
     * @param errorResponseListener   : listener to notify error response
     * @param requestTag              : tag name of the request
     * @return GsonRequest  to complete the upload prescription
     */

    public static FRGsonRequest<ApiUploadPrescriptionComplete.Response, ApiCommonError> getUploadPrescriptionCompleteRequest
    (
            final int currentCityId, final long uploadPrescriptionId, final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<ApiUploadPrescriptionComplete.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest prescriptionRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/" +
                        currentCityId + "/prescription_uploads/"
                        + uploadPrescriptionId + "/complete";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return "{}";
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiUploadPrescriptionComplete.Response, ApiCommonError> uploadPrescriptionCompleteRequest =
                new FRGsonRequest<ApiUploadPrescriptionComplete.Response, ApiCommonError>(
                        prescriptionRequest, ApiUploadPrescriptionComplete.Response.class,
                        ApiCommonError.class, successResponseListener, errorResponseListener, requestTag);

        return uploadPrescriptionCompleteRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the details of
     * a product.Cast success response to {@link ApiPrescriptionDescription.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiPrescriptionDescription.Response>}
     * <p/>
     *
     * @param cityId    the city id
     * @param variantId the unique id that identifies each product
     * @return - {@link FRGsonRequest}
     */

    private static FRGsonRequest.IAPIRequest getProductRequest(final int cityId, final long variantId) {
        return new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/" + cityId + "/variants/" + variantId;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return null;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the reasons for
     * cancelling the order.Cast success response to {List<String>}
     * <p/>
     *
     * @param headers                 headers with access token
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<List<String>, ApiCommonError> getOrderCancellationReasonsRequest(
            final Map<String, String> headers,
            FRGsonRequest.SuccessResponseListener<List<String>> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest getCancellationReasonsRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/orders/cancellation_reasons";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return headers;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        Type successType = new TypeToken<List<String>>() {
        }.getType();

        FRGsonRequest<List<String>, ApiCommonError> getOrderCancellationReasonGsonRequest =
                new FRGsonRequest<List<String>, ApiCommonError>(
                        getCancellationReasonsRequest, successType, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag);

        return getOrderCancellationReasonGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param longitude               user location longitude
     * @param latitude                user location latitude
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiStoreLocator.Response, ApiCommonError> getStoreLocatorRequest
    (
            final double longitude, final double latitude,
            final Map<String, String> header,
            FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/stores?lat=" + latitude + "&long=" + longitude;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiStoreLocator.Response, ApiCommonError> getStoreLocatorGsonRequest = new FRGsonRequest<ApiStoreLocator.Response, ApiCommonError>(
                getAddressRequest, ApiStoreLocator.Response.class, ApiCommonError.class,
                successResponseListener, errorResponseListener, requestTag) {
            @Override
            protected ApiStoreLocator.Response postProcess(ApiStoreLocator.Response response) {
                if (response != null && response.getStoresList() != null && response.getStoresList().size() > 0) {
                    List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>(response.getStoresList().size());

                    for (Store store : response.getStoresList()) {
                        StoreLocatorAdapter.StoreAddressDataItem storeAddressItem = new StoreLocatorAdapter.StoreAddressDataItem();
                        storeAddressItem.storeAddressTitle = store.getName();
                        storeAddressItem.storeFullAddress = store.getAddress();
                        storeAddressItem.storeTimings = store.getTimings();
                        storeAddressItem.storeDistance = store.getTimings();
                        storeAddressItem.latitude = store.getLat();
                        storeAddressItem.longitude = store.getLongitude();
                        storeAddressItem.phoneNumbers.addAll(store.getPhone());

                        uiDataList.add(storeAddressItem);
                    }

                    response.setUiData(uiDataList);
                }

                return super.postProcess(response);
            }
        };

        return getStoreLocatorGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiOffer.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiOffer.Response>}
     * <p/>
     *
     * @param currentCityId           the city id
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiOffer.Response, ApiCommonError> getOffersRequest
    (final int currentCityId, final Map<String, String> header,
     FRGsonRequest.SuccessResponseListener<ApiOffer.Response> successResponseListener,
     FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
     String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/cities/"
                        + currentCityId + "/offers";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiOffer.Response, ApiCommonError> getOffersGsonRequest = new FRGsonRequest<ApiOffer.Response, ApiCommonError>(
                getAddressRequest, ApiOffer.Response.class, ApiCommonError.class,
                successResponseListener, errorResponseListener, requestTag) {
            @Override
            protected ApiOffer.Response postProcess(ApiOffer.Response response) {
                if (response != null && response.getOffersList() != null && response.getOffersList().size() > 0) {
                    List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>(response.getOffersList().size());

                    for (Offer offer : response.getOffersList()) {
                        uiDataList.add(new RecyclerBorderItem(Constants.OFFERS_ITEM_BORDER_HEIGHT));
                        OffersAdapter.OffersDataItem offersDataItem = new OffersAdapter.OffersDataItem();
                        offersDataItem.offerPromoCode = offer.getCoupon_code();
                        offersDataItem.offerWebUrl = offer.getHtml_link();
                        offersDataItem.offerPromotionId = offer.getPromotion_id();
                        offersDataItem.offerImageUrl = offer.getImage_url();
                        offersDataItem.listable = offer.isListable();

                        uiDataList.add(offersDataItem);
                    }

                    response.setUiData(uiDataList);
                }

                return super.postProcess(response);
            }
        };

        return getOffersGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param faqTopicId              the faq topic id
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiFAQ.Response, ApiCommonError> getFAQRequest
    (final long faqTopicId, final Map<String, String> header,
     FRGsonRequest.SuccessResponseListener<ApiFAQ.Response> successResponseListener,
     FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
     String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/faq_topics/" + faqTopicId;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiFAQ.Response, ApiCommonError> getFAQGsonRequest = new FRGsonRequest<ApiFAQ.Response, ApiCommonError>(
                getAddressRequest, ApiFAQ.Response.class, ApiCommonError.class,
                successResponseListener, errorResponseListener, requestTag) {
            @Override
            protected ApiFAQ.Response postProcess(ApiFAQ.Response response) {
                return super.postProcess(response);
            }
        };

        return getFAQGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiFAQ.Response, ApiCommonError> getFAQHomeRequest
    (final Map<String, String> header,
     FRGsonRequest.SuccessResponseListener<ApiFAQ.Response> successResponseListener,
     FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
     String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/faq_topics";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiFAQ.Response, ApiCommonError> getFAQGsonRequest = new FRGsonRequest<ApiFAQ.Response, ApiCommonError>(
                getAddressRequest, ApiFAQ.Response.class, ApiCommonError.class,
                successResponseListener, errorResponseListener, requestTag) {
            @Override
            protected ApiFAQ.Response postProcess(ApiFAQ.Response response) {
                if (response != null) {
                    List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>(1);
                    if (response.getTopQueryList() != null && response.getTopQueryList().size() > 0) {

                        uiDataList.add(new CommonRecyclerHeaderItem("Top queries"));
                        uiDataList.add(new RecyclerBorderItem(1));

                        for (FAQ.Faqs faq : response.getTopQueryList()) {
                            FaqTopQueryAdapter.FAQTopQueryAlternateDataItem faqTopQueryAlternateDataItem =
                                    new FaqTopQueryAdapter.FAQTopQueryAlternateDataItem();
                            faqTopQueryAlternateDataItem.faqHelpTopic = faq.getQuestion();
                            faqTopQueryAlternateDataItem.faqTopicAnswer = faq.getAnswer();
                            uiDataList.add(faqTopQueryAlternateDataItem);
                        }
                    }

                    if (response.getHelpTopicsList() != null && response.getTopQueryList().size() > 0) {
                        uiDataList.add(new CommonRecyclerHeaderItem("Help topics"));
                        uiDataList.add(new RecyclerBorderItem(1));
                        for (HelpTopics helpTopics : response.getHelpTopicsList()) {
                            FaqTopQueryAdapter.FAQHelpTopicsDataItem helpTopicsDataItem =
                                    new FaqTopQueryAdapter.FAQHelpTopicsDataItem();
                            helpTopicsDataItem.faqHelpTopicId = helpTopics.getId();
                            helpTopicsDataItem.faqHelpTopic = helpTopics.getName();
                            uiDataList.add(helpTopicsDataItem);
                        }
                    }
                    response.setUiData(uiDataList);
                }

                return super.postProcess(response);
            }
        };

        return getFAQGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiRewardPoints.Response, ApiCommonError> getRewardPointsRequest
    (final Map<String, String> header,
     FRGsonRequest.SuccessResponseListener<ApiRewardPoints.Response> successResponseListener,
     FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
     String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/customer/health_wallet";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiRewardPoints.Response, ApiCommonError> getRewardPointsGsonRequest =
                new FRGsonRequest<ApiRewardPoints.Response, ApiCommonError>(
                        getAddressRequest, ApiRewardPoints.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiRewardPoints.Response postProcess(ApiRewardPoints.Response response) {
                        if (response != null) {
                            mapRewardPointsUIdData(response);
                        }

                        return super.postProcess(response);
                    }
                };

        return getRewardPointsGsonRequest;
    }

    private static void mapRewardPointsUIdData(ApiRewardPoints.Response response) {
        List<BaseRecyclerAdapter.IViewType> uiDataList =
                new ArrayList<>(1);

        RewardPointsAdapter.RewardPointsInfoDataItem rewardPointsInfoDataItem =
                new RewardPointsAdapter.RewardPointsInfoDataItem();
        rewardPointsInfoDataItem.earnedRewardPoints = response.getEarnedRewardPoints();
        rewardPointsInfoDataItem.spentRewardPoints = response.getSpendRewardPoints();
        rewardPointsInfoDataItem.availableRewardPoints = response.getAvailableRewardPoints();
        uiDataList.add(rewardPointsInfoDataItem);

      /*  RewardPointsAdapter.RewardPointsInviteFriendsDataItem rewardPointsInviteFriendsDataItem =
                new RewardPointsAdapter.RewardPointsInviteFriendsDataItem();
        rewardPointsInviteFriendsDataItem.rewardPointsCode = response.getInviteCode();
        rewardPointsInviteFriendsDataItem.rewardPointsSubHeader = response.getInviteDescription();
        uiDataList.add(rewardPointsInviteFriendsDataItem);
        uiDataList.add(new RecyclerBorderItem(1));*/

        if (response.getRewardPointsList() != null && response.getRewardPointsList().size() > 0) {
            uiDataList.add(new RewardPointsAdapter.RewardPointsTransactionHeaderDataItem());
            uiDataList.add(new RecyclerBorderItem(1));

            for (RewardTransaction rewardTransaction : response.getRewardPointsList()) {

                RewardPointsAdapter.RewardPointsTransactionsDataItem rewardPointsTransactionsDataItem =
                        new RewardPointsAdapter.RewardPointsTransactionsDataItem();
                rewardPointsTransactionsDataItem.transactionDate = rewardTransaction.getTransactionDate();
                rewardPointsTransactionsDataItem.transactionSummary = rewardTransaction.getTransactionSummary();
                rewardPointsTransactionsDataItem.transactionType = rewardTransaction.getTransactionType();
                rewardPointsTransactionsDataItem.transactionAmount = rewardTransaction.getTransactionAmount();
                uiDataList.add(rewardPointsTransactionsDataItem);
            }
        }

        uiDataList.add(new RecyclerBorderItem(1));
        response.setUiData(uiDataList);
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiCart.Response, ApiCommonError> getUpdateWalletRequest
    (final long orderId,
     final ApiCart.UpdateWalletRequest updateWalletRequest, final Map<String, String> header,
     FRGsonRequest.SuccessResponseListener<ApiCart.Response> successResponseListener,
     FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
     String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/orders/" + orderId + "/update_wallet";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return updateWalletRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiCart.Response, ApiCommonError> getUpdateWalletGsonRequest =
                new FRGsonRequest<ApiCart.Response, ApiCommonError>(
                        getAddressRequest, ApiCart.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiCart.Response postProcess(ApiCart.Response response) {
                        mapOrderDetailsCheckOutSummaryUIData(response);

                        return super.postProcess(response);
                    }
                };

        return getUpdateWalletGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiReferFriend.Response, ApiCommonError>
    getReferFriendRequest(final Map<String, String> header,
                          FRGsonRequest.SuccessResponseListener<ApiReferFriend.Response> successResponseListener,
                          FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
                          String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/referral_codes";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return "";
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiReferFriend.Response, ApiCommonError> getUpdateWalletGsonRequest =
                new FRGsonRequest<ApiReferFriend.Response, ApiCommonError>(
                        getAddressRequest, ApiReferFriend.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiReferFriend.Response postProcess(ApiReferFriend.Response response) {
                        return super.postProcess(response);
                    }
                };

        return getUpdateWalletGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiSettings.Response, ApiCommonError>
    getSettingsRequest(final Map<String, String> header,
                       FRGsonRequest.SuccessResponseListener<ApiSettings.Response> successResponseListener,
                       FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
                       String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/application_settings";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return "";
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiSettings.Response, ApiCommonError> getUpdateWalletGsonRequest =
                new FRGsonRequest<ApiSettings.Response, ApiCommonError>(
                        getAddressRequest, ApiSettings.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiSettings.Response postProcess(ApiSettings.Response response) {
                        return super.postProcess(response);
                    }
                };

        return getUpdateWalletGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param apiNewTagRequest        the new tag request data
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiNewTag.Response, ApiCommonError>
    getNewFeaturesListRequest(final ApiNewTag.Request apiNewTagRequest, final Map<String, String> header,
                              FRGsonRequest.SuccessResponseListener<ApiNewTag.Response> successResponseListener,
                              FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
                              String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/feature_tags/fetch";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return apiNewTagRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiNewTag.Response, ApiCommonError> getUpdateWalletGsonRequest =
                new FRGsonRequest<ApiNewTag.Response, ApiCommonError>(
                        getAddressRequest, ApiNewTag.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiNewTag.Response postProcess(ApiNewTag.Response response) {
                        return super.postProcess(response);
                    }
                };

        return getUpdateWalletGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiInitializePayment.Response, ApiInitializePayment.ErrorResponse> getInitializePaymentRequest
    (final long orderId, final ApiInitializePayment.Request initializePaymentRequest, final Map<String, String> header,
     FRGsonRequest.SuccessResponseListener<ApiInitializePayment.Response> successResponseListener,
     FRGsonRequest.ErrorResponseListener<ApiInitializePayment.ErrorResponse> errorResponseListener,
     String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/orders/" + orderId + "/initiate_payment";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return initializePaymentRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiInitializePayment.Response, ApiInitializePayment.ErrorResponse> getUpdateWalletGsonRequest =
                new FRGsonRequest<ApiInitializePayment.Response, ApiInitializePayment.ErrorResponse>(
                        getAddressRequest, ApiInitializePayment.Response.class, ApiInitializePayment.ErrorResponse.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiInitializePayment.Response postProcess(ApiInitializePayment.Response response) {

                        return super.postProcess(response);
                    }
                };

        return getUpdateWalletGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiCart.Response, ApiCommonError> getPaymentFailureRequest
    (final long orderId, final ApiPaymentFailure.Request paymentFailureRequest, final Map<String, String> header,
     FRGsonRequest.SuccessResponseListener<ApiCart.Response> successResponseListener,
     FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
     String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/orders/" + orderId + "/payment_failed";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return paymentFailureRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiCart.Response, ApiCommonError> getPaymentFailureGsonRequest =
                new FRGsonRequest<ApiCart.Response, ApiCommonError>(
                        getAddressRequest, ApiCart.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiCart.Response postProcess(ApiCart.Response response) {

                        return super.postProcess(response);
                    }
                };

        return getPaymentFailureGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to log in
     * to the Frank Ross app.
     * in {@link FRGsonRequest.SuccessResponseListener<ApiLogin.Response>}
     * <p/>
     * </p>
     *
     * @param loginRequest            {@link JSONObject} of login user details
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiLogin.Response, ApiSocialLogin.ErrorResponse> getSocialLoginRequest(
            final ApiSocialLogin.Request loginRequest,
            FRGsonRequest.SuccessResponseListener<ApiLogin.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiSocialLogin.ErrorResponse> errorResponseListener,
            String requestTag) {

        FRGsonRequest.IAPIRequest request = new FRGsonRequest.IAPIRequest() {

            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/login/social";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return getAccessHeader();
            }

            @Override
            public String getRequestBody() {
                return loginRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiLogin.Response, ApiSocialLogin.ErrorResponse> loginGsonRequest =
                new FRGsonRequest<ApiLogin.Response, ApiSocialLogin.ErrorResponse>(
                        request, ApiLogin.Response.class, ApiSocialLogin.ErrorResponse.class, successResponseListener,
                        errorResponseListener, requestTag);

        return loginGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to register
     * to the Frank Ross app
     * in {@link FRGsonRequest.SuccessResponseListener<ApiRegister.Response>}
     * <p/>
     * </p>
     *
     * @param registerRequest         {@link JSONObject} of registration user details
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiRegister.Response, ApiRegister.Response> getSocialRegisterRequest(
            final ApiSocialRegister.Request registerRequest,
            FRGsonRequest.SuccessResponseListener<ApiRegister.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiRegister.Response> errorResponseListener,
            String requestTag) {

        FRGsonRequest.IAPIRequest request = new FRGsonRequest.IAPIRequest() {

            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/user/social_signup";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return getAccessHeader();
            }

            @Override
            public String getRequestBody() {
                return registerRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiRegister.Response, ApiRegister.Response> registerGsonRequest =
                new FRGsonRequest<ApiRegister.Response, ApiRegister.Response>(
                        request, ApiRegister.Response.class, ApiRegister.Response.class, successResponseListener,
                        errorResponseListener, requestTag);

        return registerGsonRequest;
    }

    /**
     * <p>
     * Creates and returns {@link FRGsonRequest} used to update
     * the user phone number.Cast success response to {@link ApiChangeNumber.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiChangeNumber.Response>}
     * <p/>
     * </p>
     *
     * @param changeNumberRequest     {@link JSONObject} of the user change number details
     * @param successResponseListener listener to notify success response
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiChangeNumber.Response, ApiCommonError> getSocialUserChangeNumberRequest(
            final ApiChangeNumber.SocialUserRequest changeNumberRequest,
            FRGsonRequest.SuccessResponseListener<ApiChangeNumber.Response> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest.IAPIRequest locationRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION + "/user/social_user_primary_phone";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return getAccessHeader();
            }

            @Override
            public String getRequestBody() {
                return changeNumberRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiChangeNumber.Response, ApiCommonError> changeNumberGsonRequest = new FRGsonRequest<>(
                locationRequest, ApiChangeNumber.Response.class, ApiCommonError.class,
                successResponseListener, errorResponseListener, requestTag);

        return changeNumberGsonRequest;

    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiNotifyMe.Response, ApiCommonError> getNotifyMeSignedInUserRequest
    (final long cityId, final ApiNotifyMe.NotifyMeSignedInUserRequest notifyMeSignedInUserRequest, final Map<String, String> header,
     FRGsonRequest.SuccessResponseListener<ApiNotifyMe.Response> successResponseListener,
     FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
     String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/cities/" + cityId + "/variants/" +
                        notifyMeSignedInUserRequest.getVariantId() + "/notify_me";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return notifyMeSignedInUserRequest.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiNotifyMe.Response, ApiCommonError> getNotifyMeSignedInGsonRequest =
                new FRGsonRequest<ApiNotifyMe.Response, ApiCommonError>(
                        getAddressRequest, ApiNotifyMe.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiNotifyMe.Response postProcess(ApiNotifyMe.Response response) {

                        return super.postProcess(response);
                    }
                };

        return getNotifyMeSignedInGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiNotifyMe.Response, ApiCommonError> getNotifyMeNonSignedInUserRequest
    (final long cityId, final ApiNotifyMe.NotifyMeNonSignedInUserRequest apiNotifyMeNonSignedInUser, final Map<String, String> header,
     FRGsonRequest.SuccessResponseListener<ApiNotifyMe.Response> successResponseListener,
     FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
     String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.POST;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/cities/" + cityId + "/variants/" +
                        apiNotifyMeNonSignedInUser.getVariantId() + "/notify_me";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return apiNotifyMeNonSignedInUser.toJsonString();
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiNotifyMe.Response, ApiCommonError> getNotifyMeSignedInGsonRequest =
                new FRGsonRequest<ApiNotifyMe.Response, ApiCommonError>(
                        getAddressRequest, ApiNotifyMe.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiNotifyMe.Response postProcess(ApiNotifyMe.Response response) {

                        return super.postProcess(response);
                    }
                };

        return getNotifyMeSignedInGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param notificationsCount      the notification unread count
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiNotificationCentre.Response, ApiCommonError> getNotificationCentreRequest
    (final long cityId, final int notificationsCount, final Map<String, String> header,
     FRGsonRequest.SuccessResponseListener<ApiNotificationCentre.Response> successResponseListener,
     FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
     String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/cities/" + cityId + "/in_app_notifications/";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiNotificationCentre.Response, ApiCommonError> getNotificationCenterGsonRequest =
                new FRGsonRequest<ApiNotificationCentre.Response, ApiCommonError>(
                        getAddressRequest, ApiNotificationCentre.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiNotificationCentre.Response postProcess(ApiNotificationCentre.Response response) {
                        mapNotificationCenterUIdData(response, notificationsCount);
                        return super.postProcess(response);
                    }
                };

        return getNotificationCenterGsonRequest;
    }


    private static void mapNotificationCenterUIdData(ApiNotificationCentre.Response response, int notificationsCount) {
        List<BaseRecyclerAdapter.IViewType> uiDataList =
                new ArrayList<>(1);

        if (response.getNotifications() != null && response.getNotifications().size() > 0) {

            int notificationItem = 0;

            for (ApiNotificationCentre.Response.Notifications notification : response.getNotifications()) {

                switch (notification.getNotificationType()) {

                    case DIGITISATION_FAILURE:
                    case CART_PREPARED:
                    case ORDER_REVISION:
                    case ORDER_STATUS_UPDATE:
                    case GENERAL_PROMOTION_SPECIFIC_USER:
                    case GENERAL_PROMOTION_ALL_USER:
                    case HOME:
                    case CATEGORY:
                    case PROMOTION_PRODUCT_LISTING:
                    case HOME_COPY_CODE:
                    case CATEGORY_COPY_CODE:
                    case REFER_A_FRIEND:
                    case HEALTH_ARTICLES:
                        mapNotificationDefaultItem(notification, uiDataList, notificationItem, notificationsCount);
                        break;
                    case HTML_PAGE:
                        mapNotificationsOfferItem(notification, uiDataList, notificationItem, notificationsCount);
                        break;
                    case PRODUCT_DETAIL:
                        mapNotificationsProductDetailItem(notification, uiDataList, notificationItem, notificationsCount);
                        break;
                    default:
                        mapNotificationDefaultItem(notification, uiDataList, notificationItem, notificationsCount);
                        break;
                }

                notificationItem++;

            }
        } else {
            uiDataList.add(new NotificationCenterAdapter.EmptyNotificationsDataItem());
        }
        response.setUiData(uiDataList);
    }

    private static void mapNotificationsProductDetailItem(ApiNotificationCentre.Response.Notifications notification,
                                                          List<BaseRecyclerAdapter.IViewType> uiDataList,
                                                          int notificationItem, int notificationsCount) {
        //Type 4
        NotificationCenterAdapter.NotificationsProductDetailDataItem productDetailDataItem =
                new NotificationCenterAdapter.NotificationsProductDetailDataItem();

        productDetailDataItem.notificationDate = FrankRossDateUtils.getNotificationsFormattedDate(notification.getSent_at());
        productDetailDataItem.notificationImageUrl = notification.getPayload().getImage_url();
        productDetailDataItem.notificationTitle = notification.getHeader();
        productDetailDataItem.notificationSubTitle = notification.getMessage();
        productDetailDataItem.notificationId = notification.getId();
        productDetailDataItem.notificationType = notification.getNotificationType();
        productDetailDataItem.notificationPromoCode = notification.getPayload().getCoupon_code();
        productDetailDataItem.promotionId = notification.getPayload().getPromotion_id();
        productDetailDataItem.notificationWebUrl = notification.getPayload().getPage_link();
        productDetailDataItem.orderId = notification.getPayload().getOrder_id();
        productDetailDataItem.prescriptionId = notification.getPayload().getPrescription_id();

        productDetailDataItem.variantId = notification.getPayload().getVariant_id();
        productDetailDataItem.categoryId = notification.getPayload().getCategory_id();

        productDetailDataItem.isPharma = notification.getPayload().getIsPharma();
        productDetailDataItem.isRead = !(notificationItem < notificationsCount);

        uiDataList.add(productDetailDataItem);
        uiDataList.add(new RecyclerBorderItem(Constants.NOTIFICATIONS_ITEM_BORDER_HEIGHT));
    }

    private static void mapNotificationsBackInStockItem(ApiNotificationCentre.Response.Notifications notification,
                                                        List<BaseRecyclerAdapter.IViewType> uiDataList,
                                                        int notificationItem, int notificationsCount) {
        //Type 3
        NotificationCenterAdapter.NotificationsBackInStockDataItem backInStockDataItem =
                new NotificationCenterAdapter.NotificationsBackInStockDataItem();

        backInStockDataItem.notificationDate = FrankRossDateUtils.getNotificationsFormattedDate(notification.getSent_at());
        backInStockDataItem.notificationImageUrl = notification.getPayload().getImage_url();
        backInStockDataItem.notificationTitle = notification.getHeader();
        backInStockDataItem.notificationSubTitle = notification.getMessage();
        backInStockDataItem.notificationId = notification.getId();
        backInStockDataItem.notificationType = notification.getNotificationType();
        backInStockDataItem.notificationPromoCode = notification.getPayload().getCoupon_code();
        backInStockDataItem.promotionId = notification.getPayload().getPromotion_id();
        backInStockDataItem.notificationWebUrl = notification.getPayload().getPage_link();
        backInStockDataItem.orderId = notification.getPayload().getOrder_id();
        backInStockDataItem.prescriptionId = notification.getPayload().getPrescription_id();

        backInStockDataItem.variantId = notification.getPayload().getVariant_id();
        backInStockDataItem.categoryId = notification.getPayload().getCategory_id();

        backInStockDataItem.isPharma = notification.getPayload().getIsPharma();
        backInStockDataItem.isRead = !(notificationItem < notificationsCount);

        uiDataList.add(backInStockDataItem);
        uiDataList.add(new RecyclerBorderItem(Constants.NOTIFICATIONS_ITEM_BORDER_HEIGHT));
    }

    private static void mapNotificationsOfferItem(ApiNotificationCentre.Response.Notifications notification,
                                                  List<BaseRecyclerAdapter.IViewType> uiDataList,
                                                  int notificationItem, int notificationsCount) {
        //Type 1
        NotificationCenterAdapter.NotificationsOfferDataItem notificationsProductListingDataItem =
                new NotificationCenterAdapter.NotificationsOfferDataItem();

        notificationsProductListingDataItem.notificationDate = FrankRossDateUtils.getNotificationsFormattedDate(notification.getSent_at());
        notificationsProductListingDataItem.notificationImageUrl = notification.getPayload().getImage_url();
        notificationsProductListingDataItem.notificationTitle = notification.getHeader();
        notificationsProductListingDataItem.notificationSubTitle = notification.getMessage();
        notificationsProductListingDataItem.notificationId = notification.getId();
        notificationsProductListingDataItem.notificationType = notification.getNotificationType();
        notificationsProductListingDataItem.notificationPromoCode = notification.getPayload().getCoupon_code();
        notificationsProductListingDataItem.promotionId = notification.getPayload().getPromotion_id();
        notificationsProductListingDataItem.notificationWebUrl = notification.getPayload().getPage_link();
        notificationsProductListingDataItem.orderId = notification.getPayload().getOrder_id();
        notificationsProductListingDataItem.prescriptionId = notification.getPayload().getPrescription_id();

        notificationsProductListingDataItem.variantId = notification.getPayload().getVariant_id();
        notificationsProductListingDataItem.categoryId = notification.getPayload().getCategory_id();

        notificationsProductListingDataItem.isPharma = notification.getPayload().getIsPharma();
        notificationsProductListingDataItem.isRead = !(notificationItem < notificationsCount);

        uiDataList.add(notificationsProductListingDataItem);
        uiDataList.add(new RecyclerBorderItem(Constants.NOTIFICATIONS_ITEM_BORDER_HEIGHT));
    }

    private static void mapNotificationDefaultItem(ApiNotificationCentre.Response.Notifications notification,
                                                   List<BaseRecyclerAdapter.IViewType> uiDataList,
                                                   int notificationItem, int notificationsCount) {
        //Type 2
        NotificationCenterAdapter.NotificationsDefaultDataItem defaultDataItem =
                new NotificationCenterAdapter.NotificationsDefaultDataItem();

        defaultDataItem.notificationDate = FrankRossDateUtils.getNotificationsFormattedDate(notification.getSent_at());
        defaultDataItem.notificationImageUrl = notification.getPayload().getImage_url();
        defaultDataItem.notificationTitle = notification.getHeader();
        defaultDataItem.notificationSubTitle = notification.getMessage();
        defaultDataItem.notificationId = notification.getId();
        defaultDataItem.notificationType = notification.getNotificationType();
        defaultDataItem.notificationWebUrl = notification.getPayload().getPage_link();
        defaultDataItem.notificationPromoCode = notification.getPayload().getCoupon_code();
        defaultDataItem.promotionId = notification.getPayload().getPromotion_id();
        defaultDataItem.orderId = notification.getPayload().getOrder_id();
        defaultDataItem.prescriptionId = notification.getPayload().getPrescription_id();

        defaultDataItem.variantId = notification.getPayload().getVariant_id();
        defaultDataItem.categoryId = notification.getPayload().getCategory_id();

        defaultDataItem.isPharma = notification.getPayload().getIsPharma();
        defaultDataItem.isRead = !(notificationItem < notificationsCount);

        uiDataList.add(defaultDataItem);
        uiDataList.add(new RecyclerBorderItem(Constants.NOTIFICATIONS_ITEM_BORDER_HEIGHT));
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param header                headers with access token
     * @param errorResponseListener listener to notify error response
     * @param requestTag            tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiNotificationCount.Response, ApiCommonError> getNotificationsReadRequest
    (final long cityId, final String deviceToken, final Map<String, String> header,
     FRGsonRequest.SuccessResponseListener<ApiNotificationCount.Response> successResponseListener,
     FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
     String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.PUT;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/cities/" + cityId + "/in_app_notifications/" + deviceToken;
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiNotificationCount.Response, ApiCommonError> getNotificationCenterGsonRequest =
                new FRGsonRequest<ApiNotificationCount.Response, ApiCommonError>(
                        getAddressRequest, ApiNotificationCount.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiNotificationCount.Response postProcess(ApiNotificationCount.Response response) {
                        return super.postProcess(response);
                    }
                };

        return getNotificationCenterGsonRequest;
    }

    /**
     * <p/>
     * Creates and returns {@link FRGsonRequest} used to get the list
     * of stores.Cast success response to {@link ApiStoreLocator.Response}
     * in {@link FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>}
     * <p/>
     *
     * @param header                  headers with access token
     * @param successResponseListener success response listener to notify the result under 200  status code.
     * @param errorResponseListener   listener to notify error response
     * @param requestTag              tag of the request, needed for handling the request cancel
     * @return - {@link FRGsonRequest}
     */
    public static FRGsonRequest<ApiNotificationCount.Response, ApiCommonError> getNotificationsCountRequest
    (final long cityId, final String deviceToken, final Map<String, String> header,
     FRGsonRequest.SuccessResponseListener<ApiNotificationCount.Response> successResponseListener,
     FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
     String requestTag) {

        FRGsonRequest.IAPIRequest getAddressRequest = new FRGsonRequest.IAPIRequest() {
            @Override
            public FRGsonRequest.MethodType getRequestMethodType() {
                return FRGsonRequest.MethodType.GET;
            }

            @Override
            public String getRequestUrl() {
                return UrlConstants.getBaseUrl() + "/api/" + UrlConstants.API_VERSION +
                        "/customer/cities/" + cityId + "/in_app_notifications/" + deviceToken + "/count";
            }

            @Override
            public Map<String, String> getRequestHeaders() {
                return header;
            }

            @Override
            public String getRequestBody() {
                return null;
            }

            @Override
            public FRGsonRequest.ContentType getContentType() {
                return FRGsonRequest.ContentType.JSON;
            }
        };

        FRGsonRequest<ApiNotificationCount.Response, ApiCommonError> getNotificationCenterGsonRequest =
                new FRGsonRequest<ApiNotificationCount.Response, ApiCommonError>(
                        getAddressRequest, ApiNotificationCount.Response.class, ApiCommonError.class,
                        successResponseListener, errorResponseListener, requestTag) {
                    @Override
                    protected ApiNotificationCount.Response postProcess(ApiNotificationCount.Response response) {
                        return super.postProcess(response);
                    }
                };

        return getNotificationCenterGsonRequest;
    }

    /**
     * PHARMACY PRODUCT DETAILS
     */
    public static FRGsonRequest<ApiPharmaProduct, ApiCommonError> getPharmaProductDetails(
            final long variantId, final int cityId,
            FRGsonRequest.SuccessResponseListener<ApiPharmaProduct> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {

        FRGsonRequest<ApiPharmaProduct, ApiCommonError> pharmaProductDetailsRequest = new FRGsonRequest<ApiPharmaProduct, ApiCommonError>(
                getProductRequest(cityId, variantId), successResponseListener, errorResponseListener, requestTag) {
            @Override
            protected ApiPharmaProduct parseSuccessResponse(String json) {

                return parsePharmaProduct(json);
            }

            @Override
            protected ApiCommonError parseErrorResponse(String json) {
                return parseProductDetailsError(json);
            }
        };

        return pharmaProductDetailsRequest;
    }

    /**
     * NON PHARMACY PRODUCT DETAILS
     */
    public static FRGsonRequest<ApiNonPharmaProduct, ApiCommonError> getNonPharmaProductDetails
    (
            final long variantId, final int cityId,
            FRGsonRequest.SuccessResponseListener<ApiNonPharmaProduct> successResponseListener,
            FRGsonRequest.ErrorResponseListener<ApiCommonError> errorResponseListener,
            String requestTag) {
        FRGsonRequest<ApiNonPharmaProduct, ApiCommonError> nonPharmaProductDetailsRequest = new FRGsonRequest<ApiNonPharmaProduct, ApiCommonError>(
                getProductRequest(cityId, variantId), successResponseListener, errorResponseListener, requestTag) {
            @Override
            protected ApiNonPharmaProduct parseSuccessResponse(String json) {

                return parseNonPharmaProduct(json);
            }

            @Override
            protected ApiCommonError parseErrorResponse(String json) {
                return parseProductDetailsError(json);
            }
        };

        return nonPharmaProductDetailsRequest;
    }

    private static ApiPharmaProduct parsePharmaProduct(String json) {
        ApiPharmaProduct pharmaProduct = new ApiPharmaProduct();
        try {
            JSONObject responseJson = new JSONObject(json);

            JSONObject variantJson = responseJson.optJSONObject("variant");
            if (variantJson != null) {

                /**
                 * Parse common properties
                 */
                parseCommonProductInfo(pharmaProduct, variantJson);

                /**
                 * Parse Pharma properties
                 */
                JSONObject propertyObject = variantJson.optJSONObject("properties");
                if (propertyObject != null) {
                    parsePharmacyProductProperties(pharmaProduct, propertyObject);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return pharmaProduct;
    }

    private static void parsePharmacyProductProperties(ApiPharmaProduct pharmaProduct,
                                                       JSONObject propertyObject) throws JSONException {
        /**
         * parse and set th Basic Info
         */
        StringBuilder activeIngredients = new StringBuilder();
        StringBuilder activeIngredient = new StringBuilder();

        if (propertyObject.optJSONObject("active_ingredient1") != null &&
                !propertyObject.getJSONObject("active_ingredient1").isNull("value") &&
                !TextUtils.isEmpty(propertyObject.getJSONObject("active_ingredient1").optString("value"))) {
            activeIngredients.append("&#8226;  ")
                    .append(propertyObject.getJSONObject("active_ingredient1").optString("value"))
                    .append("<br>");

            activeIngredient.append(
                    propertyObject.getJSONObject("active_ingredient1").optString("value"));
        }

        if (propertyObject.optJSONObject("active_ingredient2") != null &&
                !propertyObject.getJSONObject("active_ingredient2").isNull("value") &&
                !TextUtils.isEmpty(propertyObject.getJSONObject("active_ingredient2").optString("value"))) {
            activeIngredients.append("&#8226;  ").append(
                    propertyObject.getJSONObject("active_ingredient2").optString("value"))
                    .append("<br>");
            pharmaProduct.getBasicInfo().setHasMultipleActiveIngredient(true);
        }

        if (propertyObject.optJSONObject("active_ingredient3") != null &&
                !propertyObject.getJSONObject("active_ingredient3").isNull("value") &&
                !TextUtils.isEmpty(propertyObject.getJSONObject("active_ingredient3").optString("value")))
            activeIngredients.append("&#8226;  ").append(
                    propertyObject.getJSONObject("active_ingredient3").optString("value"))
                    .append("<br>");

        if (propertyObject.optJSONObject("active_ingredient4") != null &&
                !propertyObject.getJSONObject("active_ingredient4").isNull("value") &&
                !TextUtils.isEmpty(propertyObject.getJSONObject("active_ingredient4").optString("value")))
            activeIngredients.append("&#8226;  ").append(
                    propertyObject.getJSONObject("active_ingredient4").optString("value"))
                    .append("<br>");

        pharmaProduct.getBasicInfo().setActiveIngredients(activeIngredients.toString());
        pharmaProduct.getBasicInfo().setActiveIngredient(activeIngredient.toString());

        if (propertyObject.optJSONObject("item_form") != null)
            pharmaProduct.getBasicInfo().setForm(
                    propertyObject.getJSONObject("item_form").optString("value"));

        if (propertyObject.optJSONObject("route_of_administration") != null)
            pharmaProduct.getBasicInfo().setRouteOfAdmin(
                    propertyObject.getJSONObject("route_of_administration").optString("value"));

        if (propertyObject.optJSONObject("why_prescribe") != null)
            pharmaProduct.getBasicInfo().setWhyPrescribe(
                    propertyObject.getJSONObject("why_prescribe").optString("value"));

        if (propertyObject.optJSONObject("directions_usage") != null)
            pharmaProduct.getBasicInfo().setHowItShouldBeTaken(
                    propertyObject.getJSONObject("directions_usage").optString("value"));

        if (propertyObject.optJSONObject("recommended_dosage") != null)
            pharmaProduct.getBasicInfo().setRecommendedDosage(
                    propertyObject.getJSONObject("recommended_dosage").optString("value"));


        /**
         * Parse and set the More Info.
         */

        if (propertyObject.optJSONObject("when_is_it_not_to_be_taken") != null)
            pharmaProduct.getMoreInfo().setWhenItIsNotToBeTaken(
                    propertyObject.getJSONObject("when_is_it_not_to_be_taken").optString("value"));

        if (propertyObject.optJSONObject("warnings_and_precaution") != null)
            pharmaProduct.getMoreInfo().setWarningAndPrecautions(
                    propertyObject.getJSONObject("warnings_and_precaution").optString("value"));

        if (propertyObject.optJSONObject("side_effects") != null)
            pharmaProduct.getMoreInfo().setSideEffects(
                    propertyObject.getJSONObject("side_effects").optString("value"));

        if (propertyObject.optJSONObject("other_precautions") != null)
            pharmaProduct.getMoreInfo().setOtherPrecautions(
                    propertyObject.getJSONObject("other_precautions").optString("value"));


        /**
         * Other Info Required
         */

      /*  if (propertyObject.optJSONObject("max_order_quantity") != null)
            pharmaProduct.setMaxOrderableQuantity(
                    propertyObject.getJSONObject("max_order_quantity").optInt("value"));*/

        if (propertyObject.optJSONObject("main_image_url") != null)
            pharmaProduct.getProductImageUrls().add(
                    propertyObject.getJSONObject("main_image_url").optString("value"));

        if (propertyObject.optJSONObject("inner_package_quantity") != null)
            pharmaProduct.setInnerPackageQuantity(
                    propertyObject.getJSONObject("inner_package_quantity").optString("value"));

        if (propertyObject.optJSONObject("outer_package_quantity") != null)
            pharmaProduct.setOuterPackageQuantity(
                    propertyObject.getJSONObject("outer_package_quantity").optString("value"));

        if (propertyObject.optJSONObject("prescription_required") != null)
            pharmaProduct.setIsPrescriptionRequired(
                    propertyObject.getJSONObject("prescription_required").optBoolean("value"));

    }

    private static ApiNonPharmaProduct parseNonPharmaProduct(String json) {
        ApiNonPharmaProduct apiNonPharmaProduct = new ApiNonPharmaProduct();
        try {
            JSONObject responseJson = new JSONObject(json);

            JSONObject variantJson = responseJson.optJSONObject("variant");
            if (variantJson != null) {
                /**
                 * Parse common properties
                 */
                parseCommonProductInfo(apiNonPharmaProduct, variantJson);

                apiNonPharmaProduct.setProductDescription(variantJson.optString("product_description"));

                /**
                 * Parse and Set variation theme
                 */
                JSONArray themeArray = variantJson.optJSONArray("variation_theme");
                if (themeArray != null && themeArray.length() > 0) {

                    for (int index = 0; index < themeArray.length(); index++) {
                        ApiNonPharmaProduct.VariationTheme variationTheme = new ApiNonPharmaProduct.VariationTheme();
                        variationTheme.setVariationPropertyName(themeArray.optString(index));

                        apiNonPharmaProduct.getVariationThemes().add(variationTheme);
                        if (index == 2) break;
                    }
                }

                /**
                 * Parse the Non pharmacy product properties
                 */
                JSONObject propertyObject = variantJson.optJSONObject("properties");
                if (variantJson.optJSONObject("properties") != null) {
                    parseNonPharmacyProductProperties(apiNonPharmaProduct, propertyObject);
                }

                /**
                 * Parse Other Variants
                 */
                JSONArray otherVariantsJsonArray = variantJson.optJSONArray("other_variants");
                if (otherVariantsJsonArray != null) {
                    boolean hasOnlyPrimaryVariant = (apiNonPharmaProduct.getVariationThemes().size() == 1);
                    parseNonPharmacyProductOtherVariants(apiNonPharmaProduct, otherVariantsJsonArray);
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return apiNonPharmaProduct;
    }

    private static void parseCommonProductInfo(ApiProduct apiProduct, JSONObject variantJson) throws JSONException {
        apiProduct.setId(variantJson.optLong("id"));
        apiProduct.setPrimaryCategoryId(variantJson.optLong("primary_category_id"));
        apiProduct.setProductName(variantJson.optString("name"));
        apiProduct.setBrandName(variantJson.optString("brand_name"));
        apiProduct.setManufacturerName(variantJson.optString("manufacturer_name"));
        apiProduct.setProductType(variantJson.optString("product_type"));
        apiProduct.setMrpPrice(variantJson.optDouble("mrp"));
        apiProduct.setSellingPrice(variantJson.optDouble("sales_price"));
        apiProduct.setPromotionalPrice(variantJson.optDouble("promotional_price"));
        apiProduct.setMaxOrderableQuantity(variantJson.optInt("max_orderable_quantity"));
        apiProduct.setDiscount(variantJson.optDouble("discount_percent"));
        apiProduct.setIsAvailable(variantJson.optBoolean("available", true));
        apiProduct.setIsNotifyMe(variantJson.optBoolean("notify_me", false));
        apiProduct.setIsCashBack(variantJson.optBoolean("cash_back", false));
        apiProduct.setProductCashBackMessage(variantJson.optString("cash_back_desc"));
        apiProduct.setProductInventoryLabel(variantJson.optString("inventory_label"));
        apiProduct.setProductDescription(variantJson.optString("product_description"));

        JSONArray imagesArray = variantJson.optJSONArray("images");
        if (imagesArray != null) {
            List<String> productImages = apiProduct.getProductImageUrls();
            for (int index = 0; index < imagesArray.length(); index++) {
                productImages.add((String) imagesArray.get(index));
            }
            apiProduct.setProductImageUrls(productImages);
        }
    }

    private static void parseNonPharmacyProductOtherVariants(ApiNonPharmaProduct apiNonPharmaProduct,
                                                             JSONArray otherVariantsJsonArray) throws JSONException {
        for (int index = 0; index < otherVariantsJsonArray.length(); index++) {
            JSONObject otherVariantObject = otherVariantsJsonArray.optJSONObject(index);
            if (otherVariantObject != null) {
                long variantId = otherVariantObject.optLong("id");

                int maxOrderableQuantity = otherVariantObject.optInt("max_orderable_quantity");
                if (maxOrderableQuantity > 0) {
                    /**
                     * Parse the Variant theme properties in other variants
                     */
                    JSONObject propertyObject = otherVariantObject.optJSONObject("properties");
                    if (propertyObject != null) {

                        ApiNonPharmaProduct.Combination combination = new ApiNonPharmaProduct.Combination();
                        combination.setProductId(variantId);
                        boolean isPrimaryVariantValueSet = false;

                        for (ApiNonPharmaProduct.VariationTheme variationTheme : apiNonPharmaProduct.getVariationThemes()) {
                            String propertyKey = variationTheme.getVariationPropertyName();

                            if (propertyObject.optJSONObject(propertyKey) != null) {
                                JSONObject variationPropertyObject = propertyObject.getJSONObject(propertyKey);

                                String variationValue = variationPropertyObject.optString("value");
                                if (!variationTheme.getSupportedValues().contains(variationValue)) {
                                    variationTheme.getSupportedValues().add(variationValue);
                                }


                                if (!isPrimaryVariantValueSet) {
                                    combination.setPrimaryVariantValue(variationPropertyObject.optString("value"));
                                    isPrimaryVariantValueSet = true;
                                } else {
                                    combination.setSecondaryVariantValue(variationPropertyObject.optString("value"));
                                }
                            }
                        }

                        if (!TextUtils.isEmpty(combination.getPrimaryVariantValue())) {
                            apiNonPharmaProduct.getVariationCombination().add(combination);
                        }
                    }
                }
            }
        }
    }


    private static void parseNonPharmacyProductProperties(ApiNonPharmaProduct apiNonPharmaProduct,
                                                          JSONObject propertyObject) throws JSONException {
        /**
         * Parse the primary and second Variant theme Properties
         */
        ApiNonPharmaProduct.Combination combination = new ApiNonPharmaProduct.Combination();
        combination.setProductId(apiNonPharmaProduct.getId());
        boolean isPrimaryVariantValueSet = false;

        for (ApiNonPharmaProduct.VariationTheme variationTheme : apiNonPharmaProduct.getVariationThemes()) {
            String propertyKey = variationTheme.getVariationPropertyName();

            if (propertyObject.optJSONObject(propertyKey) != null) {
                JSONObject variationPropertyObject = propertyObject.getJSONObject(propertyKey);

                variationTheme.setVariantDisplayName(variationPropertyObject.optString("display_name"));
                variationTheme.getSupportedValues().add(variationPropertyObject.optString("value"));

                if (!isPrimaryVariantValueSet) {
                    combination.setPrimaryVariantValue(variationPropertyObject.optString("value"));
                    isPrimaryVariantValueSet = true;
                } else {
                    combination.setSecondaryVariantValue(variationPropertyObject.optString("value"));
                }
            }
        }
        apiNonPharmaProduct.getVariationCombination().add(combination);

        /**
         * Parse and Set Key features
         */
        for (int index = 0; index <= 10; index++) {
            String key = "product_feature" + (index + 1);

            if (propertyObject.optJSONObject(key) != null) {
                apiNonPharmaProduct.getKeyFeatures().add(propertyObject.getJSONObject(key).optString("value"));
            }
        }

        if (propertyObject.optJSONObject("outer_package_quantity") != null) {
            apiNonPharmaProduct.setVariantValue(
                    propertyObject.getJSONObject("outer_package_quantity").optString("value"));
        }

        /**
         * Other Info Required
         */
        if (propertyObject.optJSONObject("prescription_required") != null)
            apiNonPharmaProduct.setIsPrescriptionRequired(
                    propertyObject.getJSONObject("prescription_required").optBoolean("value"));
    }


    private static ApiCommonError parseProductDetailsError(String json) {
        ApiCommonError apiCommonError = new ApiCommonError();
        try {
            JSONObject responseJson = new JSONObject(json);
            if (responseJson != null)
                apiCommonError.setErrorMessage(responseJson.optString("message"));
        } catch (JSONException e) {
            e.printStackTrace();
            apiCommonError.setErrorMessage("Data format error");
        }

        return apiCommonError;
    }


    private static void mapPrescriptionDetailsUIData(ApiPrescriptionDescription.Response response) {
        if (response != null) {
            List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>();
            PrescriptionDetailsAdapter.PrescriptionInfoDataItem prescriptionDetailsItem = new PrescriptionDetailsAdapter.PrescriptionInfoDataItem();
            prescriptionDetailsItem.prescriptionReferenceNumber = response.getRefNo();
            prescriptionDetailsItem.presNumber = response.getId();
            prescriptionDetailsItem.doctor = response.getDoctor();
            prescriptionDetailsItem.patient = response.getPatient();
            prescriptionDetailsItem.prescriptionExpiryDate = response.getExpiryDate();
            prescriptionDetailsItem.prescriptionDate = response.getDate();
            uiDataList.add(prescriptionDetailsItem);

            if (response.getMedicines() != null && response.getMedicines().size() > 0) {
                for (ApiPrescriptionDescription.Response.Medicines medicine : response.getMedicines()) {
                    PrescriptionDetailsAdapter.PrescriptionDosageDataItem dosageDataItem = new PrescriptionDetailsAdapter.PrescriptionDosageDataItem();
                    dosageDataItem.prescriptionMedicineName = medicine.getMedicineName();
                    dosageDataItem.prescriptionMedicineDays = medicine.getDuration();
                    dosageDataItem.presMedicineVariantId = medicine.getVariantId();
                    dosageDataItem.presMedicineQuantity = medicine.getQuantity();
                    dosageDataItem.prescMedicineListSize = response.getMedicines().size();

                    dosageDataItem.prescriptionMedicineQuantity = (!TextUtils.isEmpty(medicine.getQuantity()) ? medicine.getQuantity() : "") +
                            (!TextUtils.isEmpty(medicine.getQuantity()) && !TextUtils.isEmpty(medicine.getFoodInstruction()) ? ", " : "") +
                            (!TextUtils.isEmpty(medicine.getFoodInstruction()) ? medicine.getFoodInstruction() : "");

                    StringBuilder timings = new StringBuilder();
                    if (!TextUtils.isEmpty(medicine.getFrequency())) {
                        timings.append(medicine.getFrequency());
                    }

                    if (medicine.isTimeMorning()) {
                        timings.append(", ");
                        timings.append("morning");
                    }

                    if (medicine.isTimeAfternoon()) {
                        if (medicine.isTimeEvening() || medicine.isTimeNight()) {
                            timings.append(", ");
                            timings.append("afternoon");
                        } else {
                            timings.append(" and ");
                            timings.append("afternoon");
                        }
                    }

                    if (medicine.isTimeEvening()) {
                        if (medicine.isTimeNight()) {
                            timings.append(", ");
                            timings.append("evening");
                        } else {
                            timings.append(" and ");
                            timings.append("evening");
                        }
                    }

                    if (medicine.isTimeNight()) {
                        timings.append(" and ");
                        timings.append("night");
                    }

                    dosageDataItem.prescriptionMedicineTimings = timings.toString();
                    uiDataList.add(dosageDataItem);
                }
            }

            if (!TextUtils.isEmpty(response.getSymptoms())) {
                PrescriptionDetailsAdapter.PrescriptionNotesDataItem note = new PrescriptionDetailsAdapter.PrescriptionNotesDataItem();
                note.notesHeader = "Symptoms";
                note.noteDescription = response.getSymptoms();
                uiDataList.add(note);
            }

            if (!TextUtils.isEmpty(response.getDiagnosis())) {
                PrescriptionDetailsAdapter.PrescriptionNotesDataItem note = new PrescriptionDetailsAdapter.PrescriptionNotesDataItem();
                note.notesHeader = "Diagnosis";
                note.noteDescription = response.getDiagnosis();
                uiDataList.add(note);
            }

            if (!TextUtils.isEmpty(response.getTestsPrescribed())) {
                PrescriptionDetailsAdapter.PrescriptionNotesDataItem note = new PrescriptionDetailsAdapter.PrescriptionNotesDataItem();
                note.notesHeader = "Test prescribed";
                note.noteDescription = response.getTestsPrescribed();
                uiDataList.add(note);
            }

            if (!TextUtils.isEmpty(response.getNotesAndDirections())) {
                PrescriptionDetailsAdapter.PrescriptionNotesDataItem note = new PrescriptionDetailsAdapter.PrescriptionNotesDataItem();
                note.notesHeader = "Notes and directions";
                note.noteDescription = response.getNotesAndDirections();
                uiDataList.add(note);
            }

            if (!TextUtils.isEmpty(response.getRemarks())) {
                PrescriptionDetailsAdapter.PrescriptionRemarksDataItem remarks = new PrescriptionDetailsAdapter.PrescriptionRemarksDataItem();
                remarks.remarks = "Remarks: " + response.getRemarks();
                uiDataList.add(remarks);
            }

            //uiDataList.add(new PrescriptionDetailsAdapter.PrescriptionDeleteDataItem());

            response.setUiDataList(uiDataList);
        }
    }

    private static void mapDeliverySlotUIData(ApiDeliverySlot.Response response) {
        if (response != null && response.getDeliverySlots() != null) {
            List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>();
            String slotDate = "";
            for (DeliverySlot deliverySlots : response.getDeliverySlots()) {
                CheckOutDeliverySlotAdapter.CheckOutDeliverySlotHeaderDataItem headerItem = new CheckOutDeliverySlotAdapter.CheckOutDeliverySlotHeaderDataItem();
                if (!deliverySlots.getSlot_date().equals(slotDate)) {
                    slotDate = deliverySlots.getSlot_date();
                    headerItem.deliverySlotHeader = FrankRossDateUtils.getDayOfWeek(deliverySlots.getSlot_date()) + ", " +
                            FrankRossDateUtils.getDeliverySlotFormattedDate(deliverySlots.getSlot_date());
                    uiDataList.add(headerItem);
                }
                CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem dataItem = new CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem();
                dataItem.deliverySlotId = deliverySlots.getId();
                dataItem.deliverySlotHeader = FrankRossDateUtils.getDayOfWeek(deliverySlots.getSlot_date()) + ", " +
                        FrankRossDateUtils.getDeliverySlotFormattedDate(deliverySlots.getSlot_date());
                dataItem.deliverySlotTime = deliverySlots.getSlot_description();
                uiDataList.add(dataItem);
            }
            response.setUiDataList(uiDataList);
        }
    }

    private static void mapCartUIData(ApiCart.Response response) {
        if (response != null && response.getCart() != null) {
            /* Get cart list items */
            List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>();
            Cart cart = response.getCart();
            Cart.Coupon appliedCoupon = null;

            if (cart.getCartItems().size() > 0) {

                //Add promotions
                if (cart.getCartPromotionList() != null && cart.getCartPromotionList().size() > 0) {
                    int index = 0, couponIndex = -1;
                    for (Cart.CartPromotion cartPromotion : cart.getCartPromotionList()) {
                        if (cartPromotion.getCoupon().getStatus().equalsIgnoreCase("applied") ||
                                cartPromotion.getCoupon().getStatus().equalsIgnoreCase("Ineligible")) {
                            appliedCoupon = cartPromotion.getCoupon();
                            couponIndex = index;

                            break;
                        }
                        index++;
                    }

                    if (couponIndex >= 0)
                        cart.getCartPromotionList().remove(couponIndex);

                    if (cart.getCartPromotionList().size() > 0) {
                        CartRecyclerAdapter.CartOffersViewPagerDataItem offersViewPagerDataItem = new CartRecyclerAdapter.CartOffersViewPagerDataItem();
                        offersViewPagerDataItem.mCartOffersData = cart.getCartPromotionList();
                        uiDataList.add(offersViewPagerDataItem);

                        uiDataList.add(new RecyclerBorderItem(1));
                    }
                }

                // Add Cart Line items
                for (Cart.ResponseCartItem cartItem : cart.getCartItems()) {

                    if (cartItem.isActive()) {
                        CartRecyclerAdapter.CartDataItem dataItem;
                        if (cartItem.getQuantity() > cartItem.getMaxOrderableQuantity()) {
                            if (cartItem.getMaxOrderableQuantity() == 0) {
                                dataItem = new CartRecyclerAdapter.CartItemUnavailableDataItem();
                            } else {
                                dataItem = new CartRecyclerAdapter.CartDataStockItem();
                            }
                        } else {
                            dataItem = new CartRecyclerAdapter.CartDataItem();
                        }
                        dataItem.productName = cartItem.getVariantName();
                        if (cartItem.getDiscountAmount() > 0 || cartItem.getDiscountPercent() > 0) {
                            dataItem.productPrice = cartItem.getPromotionalPrice();
                        } else {
                            dataItem.productPrice = cartItem.getSalesPrice();
                        }
                        dataItem.innerPackagingQty = cartItem.getInnerPackageQuantity();
                        dataItem.outerPackagingQty = cartItem.getOuterPackageQuantity();
                        dataItem.productQuantity = cartItem.getQuantity();
                        dataItem.productStatus = getProductStatus(cartItem.getPrescriptionAvailable(), cartItem.getPrescriptionRequired());
                        dataItem.productStripInfo = getCartStripInfo(cartItem.getInnerPackageQuantity(), cartItem.getOuterPackageQuantity()
                        );
                        dataItem.productTotalPrice = cartItem.getTotal();
                        dataItem.variantId = cartItem.getVariantId();
                        dataItem.prescriptionRequired = cartItem.getPrescriptionRequired();
                        dataItem.prescriptionAvailable = cartItem.getPrescriptionAvailable();
                        dataItem.prescriptionMessage = TextUtils.isEmpty(cartItem.getPrescriptionMessage()) ?
                                getProductStatus(cartItem.getPrescriptionAvailable(), cartItem.getPrescriptionRequired())
                                : cartItem.getPrescriptionMessage();
                        dataItem.maxOrderableQty = cartItem.getMaxOrderableQuantity();
                        dataItem.unitOfSale = cartItem.getUnitOfSale();
                        dataItem.isActive = cartItem.isActive();
                        dataItem.isPharma = cartItem.isPharma();
                        dataItem.isCashBack = cartItem.isCashBack();
                        dataItem.cashBackMessage = cartItem.getCashBackSummary();

                        uiDataList.add(dataItem);
                    } else {
                        CartRecyclerAdapter.CartInActiveDataItem dataItem = new CartRecyclerAdapter.CartInActiveDataItem();
                        dataItem.productName = cartItem.getVariantName();
                        dataItem.variantId = cartItem.getVariantId();
                        uiDataList.add(dataItem);
                    }
                }
            }

            if (!uiDataList.isEmpty()) {
                CartRecyclerAdapter.CartCouponCodeDataItem couponCodeDataItem = new CartRecyclerAdapter.CartCouponCodeDataItem();
                if (appliedCoupon != null) {
                    if (appliedCoupon.getStatus().equalsIgnoreCase("Ineligible")) {
                        couponCodeDataItem.isIneligible = true;
                        couponCodeDataItem.isApplied = false;
                    } else {
                        couponCodeDataItem.isIneligible = false;
                        couponCodeDataItem.isApplied = true;
                    }

                    couponCodeDataItem.enteredCouponCode = appliedCoupon.getCode();
                    couponCodeDataItem.mCouponMessage = appliedCoupon.getMessage();
                } else {
                    couponCodeDataItem.isApplied = false;
                    couponCodeDataItem.isIneligible = false;
                    couponCodeDataItem.mCouponMessage = "";
                }
                uiDataList.add(couponCodeDataItem);

                CartRecyclerAdapter.CartOrderSummaryDataItem orderSummaryDataItem = new CartRecyclerAdapter.CartOrderSummaryDataItem();
                orderSummaryDataItem.productItemsTotal = cart.getCartItemsTotal();
                orderSummaryDataItem.shippingCharges = cart.getShippingTotal();
                orderSummaryDataItem.orderTotal = cart.getCartTotal();
                orderSummaryDataItem.discountTotal = cart.getDiscountTotal();
                orderSummaryDataItem.shippingDescription = cart.getShippingDescription();
                orderSummaryDataItem.promotionalDiscountTotal = cart.getOfferDiscountTotal();
                orderSummaryDataItem.isOrderWithoutPrescription = cart.isOrderWithoutPrescription();
                orderSummaryDataItem.orderId = cart.getOrderId();
                orderSummaryDataItem.cashBackCartSummary = cart.getCashBackSummary();
                orderSummaryDataItem.isCashBack = cart.isCashBack();

                uiDataList.add(orderSummaryDataItem);
            }

            response.setUiDataList(uiDataList);
        }
    }

    private static void mapOrderDetailsCheckOutSummaryUIData(ApiCart.Response cartResponse) {
        ArrayList<BaseRecyclerAdapter.IViewType> checkoutSummaryScreenData = new ArrayList<BaseRecyclerAdapter.IViewType>();
        if (cartResponse != null && cartResponse.getCart() != null
                && cartResponse.getCart().getCartItems() != null
                && cartResponse.getCart().getCartItems().size() > 0) {

            checkoutSummaryScreenData.add(new OrderHistoryProductInfoHeaderItem());

            for (Cart.ResponseCartItem cartItem : cartResponse.getCart().getCartItems()) {
                OrderHistoryProductInfoItem orderItem = new OrderHistoryProductInfoItem();
                orderItem.productName = cartItem.getVariantName();
                if (cartItem.getDiscountAmount() > 0) {
                    orderItem.productPrice = (cartItem.getQuantity() * cartItem.getPromotionalPrice());
                } else {
                    orderItem.productPrice = (cartItem.getQuantity() * cartItem.getSalesPrice());
                }
                orderItem.productQuantity = cartItem.getQuantity();
                orderItem.maxOrderableQty = cartItem.getMaxOrderableQuantity();
                orderItem.numberOfItems = cartResponse.getCart().getCartItems().size();

                checkoutSummaryScreenData.add(orderItem);
            }

            OrderHistoryShippingChargesItem shippingChargesItem = new OrderHistoryShippingChargesItem();
            shippingChargesItem.shippingCharge = cartResponse.getCart().getShippingTotal();
            shippingChargesItem.shippingChargesTxt = "Shipping charges";
            shippingChargesItem.shippingChargeDescription = cartResponse.getCart().getShippingDescription();
            shippingChargesItem.discountTotalTitle = "Additional discount";
            shippingChargesItem.discountTotal = cartResponse.getCart().getOfferDiscountTotal();
            shippingChargesItem.rewardPoints = cartResponse.getCart().getWalletAmount();
            shippingChargesItem.isChecked = cartResponse.getCart().isApplyWallet();
            shippingChargesItem.isFullyPaidByWallet = cartResponse.getCart().isFullyPaidByWallet();
            if (cartResponse.getCart().isFullyPaidByWallet()) {
                shippingChargesItem.paymentInstrument = cartResponse.getCart().getPayments().get(0).getPayment_instrument();
                shippingChargesItem.paymentMethod = cartResponse.getCart().getPayments().get(0).getPayment_method();
            }
            checkoutSummaryScreenData.add(shippingChargesItem);

            OrderHistoryTotalAmountItem totalAmountItem = new OrderHistoryTotalAmountItem();
            totalAmountItem.totalAmtTitle = "Order total";
            totalAmountItem.totalAmt = cartResponse.getCart().getNetPayableAmount();
            checkoutSummaryScreenData.add(totalAmountItem);

            if (cartResponse.getCart().getWalletAmount() != 0.0d) {
                checkoutSummaryScreenData.add(new RecyclerBorderItem(1));

                CheckOutSummaryAdapter.CheckOutRewardPointsItem checkOutRewardPointsItem =
                        new CheckOutSummaryAdapter.CheckOutRewardPointsItem();
                checkOutRewardPointsItem.checkBoxText = cartResponse.getCart().getWalletAmount();
                checkOutRewardPointsItem.checkBoxState = cartResponse.getCart().isApplyWallet();
                checkoutSummaryScreenData.add(checkOutRewardPointsItem);
            }

            checkoutSummaryScreenData.add(new RecyclerBorderItem(1));

            if (cartResponse.getCart().getPaymentMethods().size() > 0) {
                boolean allUnChecked = false;
                for (PaymentMethods paymentMethods : cartResponse.getCart().getPaymentMethods()) {
                    if (paymentMethods.isChecked()) allUnChecked = true;
                }
                if (!allUnChecked)
                    cartResponse.getCart().getPaymentMethods().get(0).setIsChecked(true);

                if (cartResponse.getCart().getPaymentMethods().size() > 0) {
                    checkoutSummaryScreenData.add(new CheckOutSummaryAdapter.CheckOutPayUsingItem());
                    for (PaymentMethods paymentMethods : cartResponse.getCart().getPaymentMethods()) {

                        CheckOutSummaryAdapter.CheckOutSummaryRadioButtonDataItem radioDataItem =
                                new CheckOutSummaryAdapter.CheckOutSummaryRadioButtonDataItem();
                        radioDataItem.paymentType = paymentMethods.getPaymentType();
                        radioDataItem.paymentMethod = paymentMethods;
                        radioDataItem.isSelected = paymentMethods.isChecked();
                        radioDataItem.paymentMethods = cartResponse.getCart().getPaymentMethods();
                        checkoutSummaryScreenData.add(radioDataItem);
                    }
                }
            }
        }
        cartResponse.setUiDataList(checkoutSummaryScreenData);
    }

    private static void mapOrderDetailsUIData(ApiOrderDetail.Response response) {
        if (response != null) {
            ArrayList<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<BaseRecyclerAdapter.IViewType>();

            OrderDetails order = response.getOrderDetails();
            OrderHistoryDetailsAdapter.OrderHistoryItem productInfo = new OrderHistoryDetailsAdapter.OrderHistoryItem();
            productInfo.orderId = order.getId();
            productInfo.orderHistoryOrderDate = order.getConfirmedOnDate();
            productInfo.orderHistoryOrderDeliveryStatus = order.getStateDisplayName();
            productInfo.orderHistoryStatus = order.getState();
            productInfo.isReOrderable = order.isReorderable();
            productInfo.isOrderMismatched = order.isMismatched();

            StringBuilder deliverySlotDate = new StringBuilder();
            if (order.getDeliverySlot() != null) {
                deliverySlotDate.append(" ").
                        append(FrankRossDateUtils.getOrderFormattedDate(order.getDeliverySlot().getSlot_date())).
                        append(" ").append(order.getDeliverySlot().getSlot_description());

            }
            productInfo.orderDeliverySlotDate = deliverySlotDate.toString();

            uiDataList.add(productInfo);

            uiDataList.add(new OrderHistoryProductInfoHeaderItem());

            for (OrderDetails.OrderProductItem product : order.getOrderProductItems()) {
                OrderHistoryProductInfoItem orderedProductInfo = new OrderHistoryProductInfoItem();
                orderedProductInfo.variantId = product.getVariantId();
                orderedProductInfo.productName = product.getVariantName();
                orderedProductInfo.productQuantity = product.getQuantity();
                orderedProductInfo.isPharma = product.isPharma();
                orderedProductInfo.isActive = product.isActive();

                if (product.getDiscountAmount() > 0) {
                    orderedProductInfo.productPrice = product.getPromotionalPrice();
                } else {
                    orderedProductInfo.productPrice = product.getSalesPrice();
                }
                uiDataList.add(orderedProductInfo);
            }

            OrderHistoryShippingChargesItem shippingChargesItem = new OrderHistoryShippingChargesItem();
            shippingChargesItem.shippingCharge = order.getShippingTotal();
            shippingChargesItem.shippingChargesTxt = "Shipping charges";
            shippingChargesItem.discountTotal = order.getPromotionalDiscountTotal();
            shippingChargesItem.discountTotalTitle = "Additional discount";
            shippingChargesItem.rewardPoints = order.getWalletAmount();
            shippingChargesItem.isChecked = order.isApplyWallet();
            shippingChargesItem.isFullyPaidByWallet = order.isFullyPaidByWallet();
            if (order.isFullyPaidByWallet()) {
                shippingChargesItem.paymentInstrument = order.getPayments().get(0).getPayment_instrument();
                shippingChargesItem.paymentMethod = order.getPayments().get(0).getPayment_method();
            }
            uiDataList.add(shippingChargesItem);

            OrderHistoryTotalAmountItem totalAmountItem = new OrderHistoryTotalAmountItem();
            totalAmountItem.totalAmtTitle = "Order total";
            totalAmountItem.totalAmt = order.getTotal();
            uiDataList.add(totalAmountItem);

            if (!TextUtils.isEmpty(order.getDoctorName()) || !TextUtils.isEmpty(order.getPatientName())) {
                OrderHistoryDetailsAdapter.OrderDetailsDoctorPatientInfoDataItem doctorPatientInfoDataItem =
                        new OrderHistoryDetailsAdapter.OrderDetailsDoctorPatientInfoDataItem();
                response.setDoctorName(order.getDoctorName());
                response.setPatientName(order.getPatientName());
                doctorPatientInfoDataItem.doctorName = order.getDoctorName();
                doctorPatientInfoDataItem.patientName = order.getPatientName();
                uiDataList.add(doctorPatientInfoDataItem);
            }

            OrderHistoryDetailsAdapter.OrderHistoryDeliverToItem deliverToItem = new OrderHistoryDetailsAdapter.OrderHistoryDeliverToItem();
            deliverToItem.deliverToCustomerName = order.getBillingAddress().getFullName();
            deliverToItem.deliverToCustomerAddress = order.getBillingAddress().getFullAddress();
            deliverToItem.deliverToCustomerMobileNumber = Utils.getFormattedMobileNumber(order.getBillingAddress().getPhoneNumber());
            uiDataList.add(deliverToItem);

            OrderHistoryDetailsAdapter.ReOrderDataItem reOrderItem = new OrderHistoryDetailsAdapter.ReOrderDataItem();
            reOrderItem.reorderReminderDetails = (order.isReorderReminder()) ? order.getReorderReminderDetails() : null;
            uiDataList.add(reOrderItem);

            if (order.isCancellable()) {
                OrderHistoryDetailsAdapter.CancelOrderDataItem cancelOrderItem = new OrderHistoryDetailsAdapter.CancelOrderDataItem();
                cancelOrderItem.footerTxt = "Cancel this order";
                cancelOrderItem.isPostPaid = !TextUtils.isEmpty(order.getPaymentMethod()) &&
                        order.getPaymentMethod().equalsIgnoreCase("prepaid");
                uiDataList.add(cancelOrderItem);
            }

            if (order.isReturnable()) {
                OrderHistoryDetailsAdapter.CancelOrderDataItem cancelOrderItem = new OrderHistoryDetailsAdapter.CancelOrderDataItem();
                cancelOrderItem.footerTxt = "Return this order";
                uiDataList.add(cancelOrderItem);
            }

            response.setUiDataList(uiDataList, order.getOrderProductItems());
        }
    }

    private static void mapRevisedOrderCartData(ApiOrderDetail.Response response) {
        if (response != null) {
            ArrayList<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<BaseRecyclerAdapter.IViewType>();
            OrderDetails order = response.getOrderDetails();

            if (order.getFailedPrescriptionDetails() != null && order.getFailedPrescriptionDetails().size() > 0) {

                CartRecyclerAdapter.OrderFailureReasonHeaderDataItem orderFailureReasonHeaderDataItem =
                        new CartRecyclerAdapter.OrderFailureReasonHeaderDataItem();
                orderFailureReasonHeaderDataItem.headerTitle = "Failure reasons";
                uiDataList.add(orderFailureReasonHeaderDataItem);

                for (OrderDetails.FailedPrescriptionDetails failedPrescriptionDetails : order.getFailedPrescriptionDetails()) {
                    if (failedPrescriptionDetails != null && !TextUtils.isEmpty(failedPrescriptionDetails.getEscalationReason())) {
                        CartRecyclerAdapter.OrderFailureReasonDataItem cancellationReasonItem =
                                new CartRecyclerAdapter.OrderFailureReasonDataItem();
                        cancellationReasonItem.cancellationReason = failedPrescriptionDetails.getEscalationReason();
                        uiDataList.add(cancellationReasonItem);
                    }
                }

                uiDataList.add(new RecyclerBorderItem(10));
            }/* else {

                CartRecyclerAdapter.OrderFailureReasonHeaderDataItem orderFailureReasonHeaderDataItem =
                        new CartRecyclerAdapter.OrderFailureReasonHeaderDataItem();
                orderFailureReasonHeaderDataItem.headerTitle = "Failure Reasons";
                uiDataList.add(orderFailureReasonHeaderDataItem);

                CartRecyclerAdapter.OrderFailureReasonDataItem cancellationReasonItem =
                        new CartRecyclerAdapter.OrderFailureReasonDataItem();
                cancellationReasonItem.cancellationReason = "reason 1";
                uiDataList.add(cancellationReasonItem);

                cancellationReasonItem =
                        new CartRecyclerAdapter.OrderFailureReasonDataItem();
                cancellationReasonItem.cancellationReason = "reason 2";
                uiDataList.add(cancellationReasonItem);

                cancellationReasonItem =
                        new CartRecyclerAdapter.OrderFailureReasonDataItem();
                cancellationReasonItem.cancellationReason = "reason 3";
                uiDataList.add(cancellationReasonItem);
            }

            //Add Border
            uiDataList.add(new RecyclerBorderItem(10));

            CartRecyclerAdapter.OrderFailureReasonHeaderDataItem orderFailureReasonHeaderDataItem =
                    new CartRecyclerAdapter.OrderFailureReasonHeaderDataItem();
            orderFailureReasonHeaderDataItem.headerTitle = "Item List";
            uiDataList.add(orderFailureReasonHeaderDataItem);

            //Add Border
            uiDataList.add(new RecyclerBorderItem(3));*/

            if (order != null) {
                for (OrderDetails.OrderProductItem product : order.getOrderProductItems()) {
                    CartRecyclerAdapter.RevisedOrderCartDataItem revisedOrderCartDataItem = new CartRecyclerAdapter.RevisedOrderCartDataItem();

                    revisedOrderCartDataItem.productName = product.getVariantName();
                    if (product.getDiscountAmount() > 0) {
                        revisedOrderCartDataItem.productPrice = product.getPromotionalPrice();
                    } else {
                        revisedOrderCartDataItem.productPrice = product.getSalesPrice();
                    }

                    revisedOrderCartDataItem.innerPackagingQty = product.getInnerPackageQuantity();
                    revisedOrderCartDataItem.outerPackagingQty = product.getOuterPackageQuantity();
                    revisedOrderCartDataItem.productQuantity = product.getQuantity();
                    revisedOrderCartDataItem.productStatus = getProductStatus(product.isPrescriptionAvailable(), product.isPrescriptionRequired());
                    revisedOrderCartDataItem.productStripInfo = getCartStripInfo(product.getInnerPackageQuantity(), product.getOuterPackageQuantity());
                    revisedOrderCartDataItem.productTotalPrice = product.getTotal();
                    revisedOrderCartDataItem.variantId = product.getVariantId();
                    revisedOrderCartDataItem.prescriptionRequired = product.isPrescriptionRequired();
                    revisedOrderCartDataItem.prescriptionAvailable = product.isPrescriptionAvailable();
                    revisedOrderCartDataItem.prescriptionMessage = TextUtils.isEmpty(product.getPrescriptionMessage()) ?
                            getProductStatus(product.isPrescriptionAvailable(), product.isPrescriptionRequired())
                            : product.getPrescriptionMessage();
                    revisedOrderCartDataItem.maxOrderableQty = product.getMaxOrderableQuantity();
                    revisedOrderCartDataItem.unitOfSale = product.getUnitOfSale();
                    revisedOrderCartDataItem.isActive = product.isActive();
                    revisedOrderCartDataItem.isPharma = product.isPharma();
                    revisedOrderCartDataItem.isCashBack = product.isCashBack();
                    revisedOrderCartDataItem.cashBackMessage = product.getCashBackSummary();
                    uiDataList.add(revisedOrderCartDataItem);
                }

                CartRecyclerAdapter.CartOrderSummaryDataItem orderSummaryDataItem = new CartRecyclerAdapter.CartOrderSummaryDataItem();
                orderSummaryDataItem.productItemsTotal = order.getLineItemsTotal();
                orderSummaryDataItem.shippingCharges = order.getShippingTotal();
                orderSummaryDataItem.orderTotal = order.getTotal();
                orderSummaryDataItem.discountTotal = order.getDiscountTotal();
                orderSummaryDataItem.promotionalDiscountTotal = order.getPromotionalDiscountTotal();
                orderSummaryDataItem.shippingDescription = order.getShippingDescription();
                orderSummaryDataItem.cashBackCartSummary = order.getCashBackSummary();
                orderSummaryDataItem.isCashBack = order.isCashBack();
                orderSummaryDataItem.orderId = order.getId();

                uiDataList.add(orderSummaryDataItem);
            }

            response.setUiDataList(uiDataList, order.getOrderProductItems());
        }
    }

    private static void mapPrescriptionListUIData(ApiPrescriptionList.Response response) {
        if (response != null) {
            List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>(1);

            List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> doctorNames = new ArrayList<>();
            List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> patientNames = new ArrayList<>();

            if (response.getUnDigitisedImageUrls() != null && response.getUnDigitisedImageUrls().size() > 0) {
                PrescriptionAdapter.UnDigitisedPrescriptionPagerDataItem item = new PrescriptionAdapter.UnDigitisedPrescriptionPagerDataItem();
                item.mUnDigitisedPrescriptionsUrlList = response.getUnDigitisedImageUrls();
                uiDataList.add(item);
                uiDataList.add(new PrescriptionAdapter.PrescriptionUploadItem());
            }

            if (response.getDigitisedPrescriptions() != null && response.getDigitisedPrescriptions().size() > 0) {

                PrescriptionAdapter.PrescriptionFilterDataItem showFiltersDataItem = new PrescriptionAdapter.PrescriptionFilterDataItem();
                uiDataList.add(showFiltersDataItem);

                for (DigitisedPrescription digitisedPrescription : response.getDigitisedPrescriptions()) {

                    PrescriptionAdapter.PrescriptionInfoDataItem infoDataItem =
                            new PrescriptionAdapter.PrescriptionInfoDataItem();
                    infoDataItem.digitisedPrescription = digitisedPrescription;

                    PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem doctorPrescriptionDataItem =
                            new PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem();
                    doctorPrescriptionDataItem.isChecked = false;
                    doctorPrescriptionDataItem.prescriptionFilterSubHeader = digitisedPrescription.getDoctorName();
                    doctorPrescriptionDataItem.prescriptionFilterHeader = "Doctor";

                    if (!TextUtils.isEmpty(digitisedPrescription.getDoctorName()) &&
                            !doctorNames.contains(doctorPrescriptionDataItem)) {
                        doctorNames.add(doctorPrescriptionDataItem);
                    }

                    PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem patientPrescriptionDataItem =
                            new PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem();
                    patientPrescriptionDataItem.isChecked = false;
                    patientPrescriptionDataItem.prescriptionFilterSubHeader = digitisedPrescription.getPatientName();
                    patientPrescriptionDataItem.prescriptionFilterHeader = "Patient";

                    if (!TextUtils.isEmpty(digitisedPrescription.getPatientName()) &&
                            !patientNames.contains(patientPrescriptionDataItem)) {

                        patientNames.add(patientPrescriptionDataItem);
                    }
                    uiDataList.add(infoDataItem);
                }
            }
            response.setDoctorNamesList(doctorNames);
            response.setPatientNamesList(patientNames);

            response.setUiDataList(uiDataList);
        }
    }

    private static void mapRecentPharmaOrdersUiData(ApiRecentPharmaOrdersList.Response response) {
        if (response != null && response.getRecentPharmaProducts() != null
                && response.getRecentPharmaProducts().size() > 0) {
            List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>(1);

            for (RecentPharmaProduct recentPharmaProduct : response.getRecentPharmaProducts()) {
                ProductDataModel productData = new ProductDataModel();
                productData.isPharma = true;
                productData.productId = recentPharmaProduct.getId();
                productData.productName = recentPharmaProduct.getName();
                productData.productBrandOrManufacturerName = recentPharmaProduct.getManufacturerName();
                productData.productImageUrl = recentPharmaProduct.getMainImageUrl();
                productData.maxOrderQuantity = recentPharmaProduct.getMaxOrderableQty();
                productData.unitOfSale = recentPharmaProduct.getUnitOfSale();
                productData.innerPackagingQty = recentPharmaProduct.getInnerPackagingQty();
                productData.isAvailable = recentPharmaProduct.isAvailable();
                productData.isAddToCartVisible = recentPharmaProduct.getMaxOrderableQty() != -1;
                productData.isCashBack = recentPharmaProduct.isCashBack();
                productData.cashBackMessage = recentPharmaProduct.getCashBackMessage();

                if (recentPharmaProduct.getDiscountPercent() == 0) {
                    productData.productSellingPrice = recentPharmaProduct.getSalesPrice();
                    productData.productActualPrice = recentPharmaProduct.getMrp();
                    productData.productDiscountPercent = recentPharmaProduct.getDiscountPercent();
                } else {
                    productData.productSellingPrice = recentPharmaProduct.getPromotionalPrice();
                    productData.productActualPrice = recentPharmaProduct.getMrp();
                    productData.productDiscountPercent = recentPharmaProduct.getDiscountPercent();
                }

                uiDataList.add(productData);
            }

            response.setUiDataList(uiDataList);
        }
    }

    private static void mapCategoryUIData(ApiCategories.Response response) {
        if (response != null && response.getCategories() != null) {
            ArrayList<BaseRecyclerAdapter.IViewType> pharmacyScreenData = new ArrayList<BaseRecyclerAdapter.IViewType>();
            //pharmacyScreenData.add(new PharmacyRecyclerAdapter.PharmacyDashBoardItem());

            for (ApiCategories.Category category : response.getCategories()) {
                PharmacyRecyclerAdapter.PharmacyListItem item = new PharmacyRecyclerAdapter.PharmacyListItem();
                item.mCategory = category;

               /* if (item.mCategory.getCode().equals("FR-MC1-943")
                        || item.mCategory.getId() == 943 || item.mCategory.getName().equals("medical aids & devices")) {
                    response.setMedicalAidsMedicine(item.mCategory);
                } else if (item.mCategory.getCode().equals("FR-MC1-909") //OTC
                        || item.mCategory.getId() == 909 || item.mCategory.getName().equals("over the counter (otc) medicines")) {
                    response.setOtcMedicine(item.mCategory);
                }*/

                pharmacyScreenData.add(item);
            }

            response.setUiDataList(pharmacyScreenData);
        }
    }

    private static void mapHomeCategoryUIData(ApiCategories.HomeCategoryResponse response) {
        if (response != null && response.getHomeFeaturedCategories().size() > 0) {
            ArrayList<BaseRecyclerAdapter.IViewType> featuredCategoryDataList = new ArrayList<BaseRecyclerAdapter.IViewType>();

            //Create home featured categories ui data model.

            for (ApiCategories.HomeFeaturedCategory category : response.getHomeFeaturedCategories()) {
                HomeFeaturedCategoriesAdapter.HomeFeaturedCategoryDataItem featuredCategoryDataItem = new HomeFeaturedCategoriesAdapter.HomeFeaturedCategoryDataItem();
                featuredCategoryDataItem.categoryId = category.getId();
                featuredCategoryDataItem.topCategoryName = category.getName();
                featuredCategoryDataItem.topCategoryUrl = category.getHomePageIconUrl();

                featuredCategoryDataList.add(featuredCategoryDataItem);
            }

            HorizontalScrollerViewMoreDataItem viewMoreCategoryDataItem = new HorizontalScrollerViewMoreDataItem();
            viewMoreCategoryDataItem.viewHeight = 120;
            viewMoreCategoryDataItem.isCategory = true;
            featuredCategoryDataList.add(viewMoreCategoryDataItem);

            response.setUiDataList(featuredCategoryDataList);
        }
    }

    private static void mapBannerUiData(ApiHomeBanner.Response response) {
        List<List<ApiHomeBanner.Banner>> uiDataList = new ArrayList<>();

        if (response != null && response.getHomeBannerList() != null && response.getHomeBannerList().size() > 0) {
            uiDataList.add(response.getHomeBannerList());
        }

        if (response != null && response.getHomeStoreList() != null && response.getHomeStoreList().size() > 0) {
            uiDataList.add(response.getHomeStoreList());
        }
        response.setUiDataList(uiDataList);
    }

    private static void mapLocationUiData(ApiLocation.Response response) {
        if (response != null && response.getCities() != null && response.getCities().size() > 0) {
            List<LocationChooserAdapter.LocationChooserListItem> uiDataList = new ArrayList<>(response.getCities().size());
            for (ApiLocation.Cities city : response.getCities()) {
                LocationChooserAdapter.LocationChooserListItem listItem = new LocationChooserAdapter.LocationChooserListItem();
                listItem.LocationName = city.getName();
                listItem.locationId = city.getId();
                uiDataList.add(listItem);
            }
            response.setUiData(uiDataList);
        }
    }

    private static Map<String, String> getAccessHeader() {
        HashMap<String, String> requestHeader = new HashMap<>();
        requestHeader.put("Access", "application/json");

        return requestHeader;
    }
}
