/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.customviews;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.support.v4.content.ContextCompat;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.widget.TextView;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gauthami on 25/6/15.
 */
public class CircularProgressBarWithText extends TextView {

    private String mHeaderText;
    private String mHeaderTextColor;
    private String mTimeText;
    private String mTimeTextColor;
    private String mFont;
    private float mProgressSweepAngle;

    private static final float FULL_SWEEP_ANGLE = 360f;
    private static final float INITIAL_SWEEP_ANGLE = 0f;
    private static final float INITIAL_PROGRESS_SWEEP_ANGLE = 270f;
    private int mWidth;

    private Context mContext;

    public CircularProgressBarWithText(Context context) {
        this(context, null, 0);
    }

    public CircularProgressBarWithText(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public CircularProgressBarWithText(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        mContext = context;
        init(attrs);
    }

    @SuppressWarnings("ResourceType")
    private void init(AttributeSet attrs) {
        TypedArray a = getContext().obtainStyledAttributes(
                attrs,
                R.styleable.CircularTextView);
        if (a != null) {
            mHeaderText = a.getString(0);
            mHeaderTextColor = a.getString(1);
            mTimeText = a.getString(2);
            mTimeTextColor = a.getString(3);
            mProgressSweepAngle = a.getFloat(4, R.styleable.CircularTextView_sweepAngle);
            mFont = a.getString(5);
        }
        a.recycle();
    }


    public void setSweepAngle(float sweepAngle) {
        this.mProgressSweepAngle = sweepAngle;
    }

    public void setHeaderText(String headerText) {
        this.mHeaderText = headerText;
    }

    public void setTimeText(String timeText) {
        this.mTimeText = timeText;
    }

    public void setHeaderTextColor(String headerTextColor) {
        this.mHeaderTextColor = headerTextColor;
    }

    public void setTimeColor(String timeColor) {
        this.mTimeTextColor = timeColor;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        drawCircle(canvas);
    }

    private void drawCircle(Canvas canvas) {
        Rect rect = canvas.getClipBounds();
        canvas.drawColor(Color.WHITE);
        Paint p = new Paint();
        p.setAntiAlias(true);
        p.setColor(Color.RED);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(4.5f);

        //find its center
        float centerX = rect.centerX();
        float centerY = rect.centerY();

        //find midpoint and radius of rectangle
        float x = rect.width();
        float y = rect.height();

        RectF rectF = new RectF();
        float padding = 25;

        if (x < y) {
            float squareTop = centerY - (x / 2);
            float squareBottom = centerY + (x / 2);
            rectF.set(rect.left + padding, squareTop + padding, rect.right - padding, squareBottom - padding);
        } else {
            float squareLeft = centerX - (y / 2);
            float squareRight = centerX + (y / 2);
            rectF.set(squareLeft + padding, rect.top + padding, squareRight - padding, rect.bottom - padding);
        }
/*
        p.setStyle(Paint.Style.FILL_AND_STROKE);
        canvas.drawRect(rectF, p);*/

        float radius = Math.min(rectF.width(), rectF.height()) / 2;


        //draw path
        Path path = new Path();
        path.addArc(rectF, INITIAL_SWEEP_ANGLE, FULL_SWEEP_ANGLE);
        Paint strokePaint = new Paint();
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setStrokeWidth(10);
        strokePaint.setColor(Color.GRAY);
        strokePaint.setShadowLayer(4f, 0, 2, Color.GRAY);
        canvas.drawPath(path, strokePaint);

        Path path1 = new Path();
        path1.addArc(rectF, INITIAL_PROGRESS_SWEEP_ANGLE, mProgressSweepAngle);
        strokePaint.setStrokeWidth(12);
        strokePaint.setColor(ContextCompat.getColor(mContext, R.color.frankross_green));
        canvas.drawPath(path1, strokePaint);

        //draw rectangle using center to fit the text
        float quadrant1X = 0, quadrant1Y = 0;
        quadrant1X = (float) (radius * Math.cos(45 * Math.PI / 180F))
                + rect.centerX();
        quadrant1Y = (float) (radius * Math.sin(45 * Math.PI / 180F))
                + rect.centerY();

        float quadrant2X = 0, quadrant2Y = 0;
        quadrant2X = (float) (radius * Math.cos(135 * Math.PI / 180F))
                + rect.centerX();
        quadrant2Y = (float) (radius * Math.sin(135 * Math.PI / 180F))
                + rect.centerY();

        float quadrant3X = 0, quadrant3Y = 0;
        quadrant3X = (float) (radius * Math.cos(225 * Math.PI / 180F))
                + rect.centerX();
        quadrant3Y = (float) (radius * Math.sin(225 * Math.PI / 180F))
                + rect.centerY();

        float quadrant4X = 0, quadrant4Y = 0;
        quadrant4X = (float) (radius * Math.cos(315 * Math.PI / 180F))
                + rect.centerX();
        quadrant4Y = (float) (radius * Math.sin(315 * Math.PI / 180F))
                + rect.centerY();

        RectF rect1 = new RectF(quadrant3X + 5, quadrant3Y + 5, quadrant1X - 5, quadrant2Y - 5);
        p.setColor(Color.TRANSPARENT);
        p.setStyle(Paint.Style.FILL_AND_STROKE);
        canvas.drawRect(rect1, p);

        //draw text inside rectangle2
        int textSizeInPx = (int) Utils.convertDpToPixel(16, getContext());
        drawText(canvas, rect1, mTimeTextColor, mTimeText, textSizeInPx, false);
    }

    private void drawText(Canvas canvas, RectF rect1, String textColor, String text, int textSize, boolean flag) {
        TextPaint textPaint = new TextPaint();

        textPaint.setTextSize(textSize);
        int textX = 0;
        int textY = 0;
        textX = (int) rect1.left;
        textY = (int) (rect1.top + ((rect1.height() / 2) - (textSize / 2)));
        textPaint.setColor(ContextCompat.getColor(mContext, R.color.frankross_green));
        textPaint.setTypeface(Typeface.DEFAULT_BOLD);
        StaticLayout textLayout = new StaticLayout(text, textPaint, (int) (rect1.width()), Layout.Alignment.ALIGN_CENTER, 1.0f, 1.0f, false);
        canvas.save();
        canvas.translate(textX, textY);
        textLayout.draw(canvas);
        canvas.restore();
        mWidth = textLayout.getWidth();
    }
}


