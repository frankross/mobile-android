/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.search;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;

/**
 * Created by gowtham on 5/7/15.
 */

/**
 * This class manages the fragment transactions for Search based on the intents and its data
 */
public class SearchActivity extends BaseActivity {

    private static final String TAG = SearchActivity.class.getSimpleName();

    public static Intent getActivityIntent(Context context) {
        return new Intent(context, SearchActivity.class);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /**
         * Create a search fragment instance with the empty search text
         */
        loadFragment(getFragmentContainerId(), SearchFragment.create(""), TAG, R.anim.push_left_in,
                R.anim.push_left_out, BaseFragment.FragmentTransactionType.ADD);
    }
}
