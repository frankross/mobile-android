/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.cart;

import android.app.Dialog;
import android.text.TextUtils;
import android.view.View;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.common.BaseDialogFragment;
import com.emamifrankross.frankross.ui.common.ICartQuantityNotifier;
import com.emamifrankross.frankross.ui.customviews.NumberPickerWidget;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

/**
 * Created by gauthami on 10/7/15.
 */

/**
 * This class represents the UI for Quantity picker
 */
public class CartQuantityPickerDialogFragment extends BaseDialogFragment implements
        View.OnClickListener, NumberPickerWidget.OnNumberChangedListener {

    public static final String TAG = CartQuantityPickerDialogFragment.class.getSimpleName();

    private RobotoTextView mCartMaxQuantityReached;
    private NumberPickerWidget mCartQuantityPicker;
    private ICartQuantityNotifier mCartQuantityNotifier;

    private int mQuantity = 1;
    private int mMaxOrderableQty = 0;
    private String mStripInfo = "";

    public void create(CartFragment cartFragment, int quantity, int maxQty, String stripInfo) {
        mCartQuantityNotifier = cartFragment;
        mQuantity = quantity;
        mMaxOrderableQty = maxQty;
        mStripInfo = stripInfo;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_cart_quantity_picker_dialog;
    }

    @Override
    public void initViews(Dialog view) {
        RobotoTextView cartQuantityPickerDoneButton = (RobotoTextView) view.findViewById(R.id.cart_quantity_picker_dialog_done_btn);
        mCartQuantityPicker = (NumberPickerWidget) view.findViewById(R.id.cart_quantity_picker_dialog_number_picker);
        RobotoTextView cartQuantityPickerStripInfo = (RobotoTextView) view.findViewById(R.id.cart_quantity_picker_dialog_description_tv);
        mCartMaxQuantityReached = (RobotoTextView) view.findViewById(R.id.max_quantity_txt_tv);

        mCartQuantityPicker.setValue(mQuantity > mMaxOrderableQty ? mMaxOrderableQty : mQuantity);
        mCartQuantityPicker.setMaxValue(mMaxOrderableQty);
        cartQuantityPickerStripInfo.setText(mStripInfo);
        mCartMaxQuantityReached.setVisibility((mQuantity >= mMaxOrderableQty) ? View.VISIBLE : View.GONE);
        cartQuantityPickerStripInfo.setVisibility(TextUtils.isEmpty(mStripInfo) ? View.GONE : View.VISIBLE);

        cartQuantityPickerDoneButton.setOnClickListener(this);
        mCartQuantityPicker.setOnNumberChangedListener(this);

        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.QUANTITY_SELECTION_SCREEN_VISIT_EVENT);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.cart_quantity_picker_dialog_done_btn:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.QUANTITY_SELECTION_DONE_TAP_EVENT);
                mCartQuantityNotifier.onAddToCartClick((int) mCartQuantityPicker.getValue());
                getDialog().dismiss();
                break;
        }
    }

    @Override
    public void onNumberIncremented(int number) {
        mCartMaxQuantityReached.setVisibility(number == mMaxOrderableQty ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onNumberDecremented(int number) {
        mCartMaxQuantityReached.setVisibility(number == mMaxOrderableQty ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }
}
