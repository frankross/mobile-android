/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.sdkmanager;

import android.content.Context;

import com.emamifrankross.frankross.core.network.UrlConstants;
import com.emamifrankross.frankross.utils.Log;
import com.flurry.android.FlurryAgent;

import java.util.Map;

/**
 * This class manages the Analytics session and events by using the singleton instance
 */
public class FrankRossAnalytics {

    private static final String TAG = FrankRossAnalytics.class.getSimpleName();
    private static FrankRossAnalytics mFrankRossTracker;

    private FrankRossAnalytics() {
    }

    public static FrankRossAnalytics getFrankRossTracker() {
        if (mFrankRossTracker == null) {
            mFrankRossTracker = new FrankRossAnalytics();
        }
        return mFrankRossTracker;
    }


    public void init(Context applicationContext) {
        //mContext = applicationContext;
        FlurryManager.init(applicationContext);
    }

    public void startSession(Context context) {
        FlurryAgent.onStartSession(context);
    }

    public void endSession(Context context) {
        FlurryAgent.onEndSession(context);
    }

    public void logEvent(String event) {
        if (!UrlConstants.DEV_MODE) {
            FlurryAgent.logEvent(event);
            Log.d(TAG, "Event : " + event);
        }
    }

    public void logEvent(String event, Map<String, String> eventData) {
        if (!UrlConstants.DEV_MODE) {
            FlurryAgent.logEvent(event, eventData);
            Log.d(TAG, "Event : " + event);
        }
    }

    public void endTimedEvent(String event, Map<String, String> eventData) {
        if (!UrlConstants.DEV_MODE) {
            if (eventData != null) {
                FlurryAgent.endTimedEvent(event, eventData);
            } else {
                FlurryAgent.endTimedEvent(event);
                FlurryAgent.logEvent(event, true);
            }
            Log.d(TAG, "End timed event : " + event);
        }
    }

    public void logTimedEvent(String event, Map<String, String> eventData) {
        if (!UrlConstants.DEV_MODE) {
            if (eventData != null) {
                FlurryAgent.logEvent(event, eventData, true);
            } else {
                FlurryAgent.logEvent(event, true);
            }
            Log.d(TAG, "Start timed event : " + event);
        }
    }
}
