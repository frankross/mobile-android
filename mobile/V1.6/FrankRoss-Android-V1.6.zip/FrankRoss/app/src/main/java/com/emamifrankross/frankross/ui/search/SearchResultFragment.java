/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.search;

import android.os.Handler;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.aloglia.AlgoliaManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.pharmacy.ProductListingFragment;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Utils;

import java.util.Map;

/**
 * Created by gowtham on 3/12/15.
 */

/**
 * This class represents the UI for search result screen with the search result count and a search bar
 */
public class SearchResultFragment extends ProductListingFragment {

    private static final String TAG = SearchResultFragment.class.getSimpleName();
    private static final long ANIMATE_LIN_LAYOUT_DURATION = 500;

    private String mSearchText = "";

    public static SearchResultFragment create(String searchTerm) {
        SearchResultFragment newSearchResultFragment = new SearchResultFragment();
        newSearchResultFragment.setSearchText(searchTerm);

        return newSearchResultFragment;
    }

    private void setSearchText(String searchTerm) {
        mSearchText = searchTerm;
        mListingFlow = ListingFlow.SEARCH_RESULT;
    }

    @Override
    protected void setProductsCount() {
        super.setProductsCount();
        mSearchTerm.setText(mSearchText);
        mSearchProductsLinLyt.setVisibility(View.VISIBLE);
        mSearchCountLinLyt.setVisibility(mProductsCount != 0 ? View.VISIBLE : View.GONE);
    }

    @Override
    protected void logVisitEvent() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_RESULT_SCREEN_VISIT_EVENT);
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_search_result);
    }

    @Override
    public int getToolbarMenuId() {
        return R.menu.menu_search_result;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_cart:
                        Map<String, String> cartClickData = Utils.cartToolbarClickDataForAnalytics(Constants.SEARCH_RESULT_SCREEN_NAME,
                                FrankRossEvents.VIEW_CART_FROM_TOOLBAR_SCREEN_NAME);
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_CART_FROM_TOOLBAR_EVENT, cartClickData);
                        startActivity(CartActivity.getActivityIntent(getActivity().getApplicationContext(),
                                CartActivity.CART_FRAGMENT_ID));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;
                }
                return false;
            }
        };
    }

    @Override
    protected void getAlgoliaProductsWithAppliedFilterInfo(AlgoliaManager.IProductInfoResultNotifier productInfoResultNotifier) {
        AlgoliaManager.getInstance().performGetSearchResultProductsWithAppliedFilterAndSortInfo(
                getActivity().getApplicationContext(), mSearchText, mCurrentSortType, mAppliedFilterInfo,
                ALGOLIA_PRODUCTS_COUNT, mCurrentPageNumber, productInfoResultNotifier);
    }

    @Override
    protected void getAlgoliaProductsWithFilterInfo(AlgoliaManager.IProductInfoWithFilterResultNotifier
                                                            productInfoWithFilterResultNotifier) {
        AlgoliaManager.getInstance().performGetSearchResultProductsWithFilterAndSortInfo(getActivity(), mSearchText,
                ALGOLIA_PRODUCTS_COUNT, mCurrentPageNumber, productInfoWithFilterResultNotifier);
    }

    @Override
    protected void onRecyclerViewFling(boolean isScrolledUp) {
        super.onRecyclerViewFling(isScrolledUp);

        //To animate the Search count Linear Layout
        if (isScrolledUp) {
            animateSlideBottom();
        } else {
            animateSlideUp();
        }
    }

    /**
     * Method that provides up animation to the Linear layout that contains Search result count
     */
    public void animateSlideUp() {
        if (mSearchCountLinLyt.getVisibility() == View.GONE) {
            mSearchCountLinLyt.clearAnimation();
            Animation animation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_up);
            animation.setDuration(ANIMATE_LIN_LAYOUT_DURATION);
            animation.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                    if (mProductsCount != 0)
                        mSearchCountLinLyt.setVisibility(View.VISIBLE);
                }

                @Override
                public void onAnimationEnd(Animation animation) {

                }

                @Override
                public void onAnimationRepeat(Animation animation) {

                }
            });
            mSearchCountLinLyt.setAnimation(animation);
            mSearchCountLinLyt.animate();
            animation.start();
        }
    }

    /**
     * Method that provides bottom animation to the Linear layout that contains Search result count
     */
    public void animateSlideBottom() {
        if (mSearchCountLinLyt.getVisibility() == View.VISIBLE) {
            Animation animation = AnimationUtils.loadAnimation(getActivity(), R.anim.slide_bottom);
            animation.setDuration(ANIMATE_LIN_LAYOUT_DURATION);
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    mSearchCountLinLyt.clearAnimation();
                    mSearchCountLinLyt.setVisibility(View.GONE);
                }
            }, animation.getDuration());
            mSearchCountLinLyt.setAnimation(animation);
            mSearchCountLinLyt.animate();
            animation.start();
        }
    }
}
