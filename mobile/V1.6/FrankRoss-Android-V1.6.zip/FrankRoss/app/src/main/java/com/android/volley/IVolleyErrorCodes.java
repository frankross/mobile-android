package com.android.volley;

public interface IVolleyErrorCodes {

	int VOLLEY_UNKNOWN_ERROR = 101;
	int VOLLEY_TIME_OUT_ERROR = 102;
	int VOLLEY_NO_CONNECTION_ERROR = 103;
	int VOLLEY_NETWORK_ERROR = 104;
	int VOLLEY_PARSE_ERROR = 105;
	int VOLLEY_SERVER_ERROR = 106;
	int getErrorCode();
}
