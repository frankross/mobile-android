
package com.emamifrankross.frankross.ui.customviews;

import android.content.Context;
import android.support.v4.view.ViewPager;
import android.util.AttributeSet;

import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.ui.adapters.IAutoScroll;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Log;

public class AutoScrollViewPager extends ViewPager {

    private int mAdapterSize = 0;

    private boolean mIsAutoScrollRequired = false;

    private IAutoScroll mAutoScroll = new IAutoScroll() {
        @Override
        public void scrollNext() {
            Log.d("LOOP", "inside view pager AutoScroll before set and page number + " + getCurrentItem());
            if (mAdapterSize <= 1) {
                ApiRequestManager.getInstance(getContext()).setLoopingDelay(Constants.AUTO_SCROLL_SECONDARY_DELAY);
                return;
            } else if (mAdapterSize == 2) {
                if (getCurrentItem() == 1)
                    ApiRequestManager.getInstance(getContext()).setLoopingDelay(Constants.AUTO_SCROLL_SECONDARY_DELAY);

            } else {
                if (getCurrentItem() == mAdapterSize - 1)
                    ApiRequestManager.getInstance(getContext()).setLoopingDelay(Constants.AUTO_SCROLL_SECONDARY_DELAY);

            }

            int nextItemPosition = (getCurrentItem() == mAdapterSize - 1) ? 0 : getCurrentItem() + 1;
            Log.d("LOOP", "inside view pager AutoScroll next item position + " + nextItemPosition);
            setCurrentItem(nextItemPosition, true);
        }
    };

    public void setAutoScrollRequired(boolean isAutoScrollRequired) {
        mIsAutoScrollRequired = isAutoScrollRequired;
    }

    public boolean isAutoScrollRequired() {
        return mIsAutoScrollRequired;
    }

    public IAutoScroll getAutoScrollNotifier() {
        return (mIsAutoScrollRequired) ? mAutoScroll : null;
    }

    public void setAdapterSize(int size) {
        mAdapterSize = size;
    }

    public AutoScrollViewPager(Context paramContext) {
        super(paramContext);
        init();
    }

    public AutoScrollViewPager(Context paramContext, AttributeSet paramAttributeSet) {
        super(paramContext, paramAttributeSet);
        init();
    }

    private void init() {
        setCurrentItem(0);
    }
}
