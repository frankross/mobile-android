/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.order;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.account.login.LogInActivity;
import com.emamifrankross.frankross.ui.adapters.CheckOutDeliverySlotAdapter;
import com.emamifrankross.frankross.ui.adapters.PrescriptionFilterAdapter;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.order.returnorder.ReturnPickUpSlotFragment;
import com.emamifrankross.frankross.ui.order.returnorder.ReturnProductsSubmitFragment;
import com.emamifrankross.frankross.ui.prescription.PrescriptionDetailFragment;
import com.emamifrankross.frankross.ui.prescription.PrescriptionFilterFragment;
import com.emamifrankross.frankross.ui.prescription.PrescriptionFragment;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.PaytmUtils;
import com.emamifrankross.frankross.utils.Utils;

import java.util.List;

/**
 * Created by gauthami on 14/7/15.
 */

/**
 * This class manages the fragment transactions for Order History based on the intents and its data
 */
public class OrderHistoryActivity extends BaseActivity implements
        PrescriptionFilterFragment.IPrescriptionFilterSelectNotifier,
        ReturnPickUpSlotFragment.IReturnPickUpSlotNotifier {

    public static final String ORDER_HISTORY_FRAGMENT_ID = "001";
    public static final String PRESCRIPTION_FRAGMENT_ID = "002";
    public static final String ORDER_HISTORY_DETAILS_FRAGMENT_ID = "003";
    public static final String PRESCRIPTION_DETAILS_FRAGMENT_ID = "004";

    private static final String EXTRA_FRAGMENT_ID = "fragment_id";
    private static final String EXTRA_DETAILS_ID = "details_id";

    private String mFragmentId = ORDER_HISTORY_FRAGMENT_ID;
    private long mDetailsId = 0;

    /**
     * Method to launch the Order History and Prescriptions screen
     *
     * @param appContext the application context
     * @param fragmentId the fragment to be launched identified with an id
     * @return the intent associated with the Order History and Prescriptions
     */
    public static Intent getActivityIntent(Context appContext, String fragmentId) {
        Intent intent = new Intent(appContext, OrderHistoryActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);

        return intent;
    }

    /**
     * Method to launch the Order Details and Prescriptions Details
     *
     * @param appContext the application context
     * @param fragmentId the fragment to be launched identified with an id
     * @param id         the prescription id or order id
     * @return the intent associated with the Order Details and Prescriptions Details
     */
    public static Intent getActivityIntent(Context appContext, String fragmentId, long id) {
        Intent intent = new Intent(appContext, OrderHistoryActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);
        intent.putExtra(EXTRA_DETAILS_ID, id);

        return intent;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFragmentId = getIntent().getStringExtra(EXTRA_FRAGMENT_ID);
        mDetailsId = getIntent().getLongExtra(EXTRA_DETAILS_ID, 0);

        if (Utils.isLoggedIn(getApplicationContext())) {
            initFragment(mFragmentId, mDetailsId);
        } else {
            startActivityForResult(LogInActivity.getActivityIntent(getApplicationContext(),
                    false, LogInActivity.LOG_IN_FRAGMENT), Constants.REQUEST_CODE_FOR_LOGIN);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == Constants.REQUEST_CODE_FOR_LOGIN) {
            if (resultCode == RESULT_OK) {
                setResult(RESULT_OK);
                initFragment(mFragmentId, mDetailsId);
            } else {
                finish();
            }
        }
    }

    @Override
    public void onBackPressed() {

        switch (mFragmentId) {
            case ORDER_HISTORY_DETAILS_FRAGMENT_ID:

                mFragmentId = ORDER_HISTORY_FRAGMENT_ID;
                loadFragment(getFragmentContainerId(), OrderHistoryFragment.create(), null,
                        R.anim.push_left_in, R.anim.push_left_out,
                        BaseFragment.FragmentTransactionType.REPLACE);

                break;
            case PRESCRIPTION_DETAILS_FRAGMENT_ID:

                mFragmentId = PRESCRIPTION_FRAGMENT_ID;
                loadFragment(getFragmentContainerId(), PrescriptionFragment.create(), null,
                        R.anim.push_left_in, R.anim.push_left_out,
                        BaseFragment.FragmentTransactionType.REPLACE);

                break;
            default:
                super.onBackPressed();
                break;
        }
    }

    private void initFragment(String fragmentId, long id) {
        if (!TextUtils.isEmpty(fragmentId)) {
            switch (fragmentId) {
                case ORDER_HISTORY_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(),
                            OrderHistoryFragment.create(), null, R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.REPLACE);
                    break;

                case PRESCRIPTION_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(), PrescriptionFragment.create(),
                            PrescriptionFragment.TAG, R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.REPLACE);
                    break;

                case ORDER_HISTORY_DETAILS_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(),
                            OrderHistoryDetailsFragment.create(id, PaytmUtils.getPaymentErrorMessage()),
                            null, R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.REPLACE);
                    break;

                case PRESCRIPTION_DETAILS_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(),
                            PrescriptionDetailFragment.create(id), null, R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.REPLACE);
                    break;
                default:
                    break;

            }
        }
    }

    /**
     * Callback on applying the filter for prescriptions
     *
     * @param selectedDoctorNames  the doctors whose prescription has to be listed
     * @param selectedPatientNames the patients whose prescription has to be listed
     */
    @Override
    public void onFilterApplied(List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> selectedDoctorNames,
                                List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> selectedPatientNames) {

        Fragment fragment = getSupportFragmentManager().findFragmentByTag(PrescriptionFragment.TAG);
        if (fragment != null && fragment instanceof PrescriptionFragment) {
            ((PrescriptionFragment) fragment).onFilterApplied(selectedDoctorNames, selectedPatientNames);
        }
    }

    /**
     * Callback to be invoked on clearing the applied filters
     */
    @Override
    public void onFilterCleared() {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(PrescriptionFragment.TAG);
        if (fragment != null && fragment instanceof PrescriptionFragment) {
            ((PrescriptionFragment) fragment).onFilterCleared();
        }
    }

    /**
     * Callback when pick up slot selected
     *
     * @param pickUpSlot the pick up slot that was selected
     */
    @Override
    public void onPickUpSlotSelect(CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem pickUpSlot) {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(ReturnProductsSubmitFragment.TAG);
        if (fragment != null && fragment instanceof ReturnProductsSubmitFragment) {
            ((ReturnProductsSubmitFragment) fragment).onPickUpSlotSelect(pickUpSlot);
        }
    }
}