/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.account;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;

/**
 * Created by gauthami on 7/7/15.
 */

/**
 * This class represents the UI for Change password for a logged in user
 */
public class ChangePasswordFragment extends ApiRequestBaseFragment implements IToolbar, View.OnClickListener {

    private EditText mCurrentPassword;
    private EditText mNewPassword;
    private EditText mConfirmNewPassword;

    public static ChangePasswordFragment create() {
        return new ChangePasswordFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Since the first editable field gets focused and opens the keyboard by default -To avoid the scenario
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_change_password, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the views
     *
     * @param view the root view
     */
    private void initViews(View view) {
        mCurrentPassword = (EditText) view.findViewById(R.id.change_password_current_pwd_et);
        mNewPassword = (EditText) view.findViewById(R.id.change_password_new_pwd_et);
        mConfirmNewPassword = (EditText) view.findViewById(R.id.change_password_re_enter_pwd_et);
        Button changePasswordSubmit = (Button) view.findViewById(R.id.change_password_submit_btn);

        changePasswordSubmit.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.change_password_submit_btn:
                performUpdatePassword();
                break;
        }
    }

    /**
     * Method requests for updating user password;If success, closes the fragment
     */
    private void performUpdatePassword() {
        String currentPassword = (mCurrentPassword.getText() != null) ? mCurrentPassword.getText().toString() : "";
        String newPassword = (mNewPassword.getText() != null) ? mNewPassword.getText().toString() : "";
        String confirmPassword = (mConfirmNewPassword.getText() != null) ? mConfirmNewPassword.getText().toString() : "";

        if (validateData(currentPassword, newPassword, confirmPassword)) {
            mFragmentInteractionListener.showBlockingProgressBar();
            mApiRequestManager.performUpdateUserPassword(currentPassword, newPassword, new ApiRequestManager.IUpdateUserPasswordResultNotifier() {
                @Override
                public void onUserPasswordUpdated() {
                    mFragmentInteractionListener.hideBlockingProgressBar();

                    showAlert(getString(R.string.password_changed_successfully), new AlertDialogFragment.AlertPositiveActionListener() {
                        @Override
                        public void onPositiveAction() {
                            getActivity().finish();
                        }
                    }, false);

                }
            }, this, this);
        }
    }

    /**
     * @return If false,displays the input error dialog with appropriate message;else true.
     */
    private boolean validateData(String currentPassword, String newPassword, String confirmPassword) {
        if (TextUtils.isEmpty(currentPassword)) {
            showAlert(getString(R.string.please_enter_your_password));
        } else if (TextUtils.isEmpty(newPassword)) {
            showAlert(getString(R.string.please_enter_your_new_password));
        } else if (TextUtils.isEmpty(confirmPassword)) {
            showAlert(getString(R.string.please_enter_your_confirm_password));
        } else if (!newPassword.equals(confirmPassword)) {
            showAlert(getString(R.string.password_do_not_match));
        } else {
            return true;
        }

        return false;
    }

    protected void showAlert(String alertMessage, AlertDialogFragment.AlertPositiveActionListener clickListener, boolean isCancelable) {
        mFragmentInteractionListener.showAlert(null, alertMessage, getString(R.string.ok), null, clickListener, null, isCancelable);
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_set_password);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

}
