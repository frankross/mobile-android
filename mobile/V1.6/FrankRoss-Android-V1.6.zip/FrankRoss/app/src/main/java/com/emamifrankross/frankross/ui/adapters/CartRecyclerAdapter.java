/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.Html;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.Cart;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.CirclePageIndicator;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderDataBinder;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 21/7/15.
 * <p> Adapter class for Cart Section</p>
 * <p>Supports the twelve View Types </p>
 * <p> 1 : CART ITEM INACTIVE VIEW TYPE </p>
 * <p> 2 : CART ITEM VIEW TYPE </p>
 * <p> 3 : CART COUPON CODE VIEW TYPE </p>
 * <p> 4 : CART ITEM BACK IN STOCK VIEW TYPE </p>
 * <p> 5 : CART ITEM UNAVAILABLE VIEW TYPE </p>
 * <p> 6 : CART ORDER SUMMARY VIEW TYPE </p>
 * <p> 7 : CART HEADER VIEW TYPE </p>
 * <p> 8 : CART OFFER VIEW PAGER HEADER VIEW TYPE </p>
 * <p> 9 : CART APPLIED COUPON VIEW TYPE </p>
 * <p> 10 : CART ORDER FAILURE REASON VIEW TYPE </p>
 * <p> 11 : CART ORDER FAILURE REASON HEADER VIEW TYPE </p>
 * <p> 12 : COMMON RECYCLER BORDER ITEM VIEW TYPE </p>
 */
public class CartRecyclerAdapter extends BaseRecyclerAdapter {

    public CartRecyclerAdapter(@NonNull List<BaseRecyclerAdapter.IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<BaseRecyclerAdapter.RecyclerViewDataBinder> getViewDataBinders() {
        List<BaseRecyclerAdapter.RecyclerViewDataBinder> viewHolderTypeList = new ArrayList<>(1);
        viewHolderTypeList.add(new CartInActiveItemViewHolderType());
        viewHolderTypeList.add(new CartItemViewHolderType());
        viewHolderTypeList.add(new CartItemUnavailableViewHolderType());
        viewHolderTypeList.add(new CartItemStockViewHolderType());
        viewHolderTypeList.add(new CartCouponCodeViewHolderType());
        viewHolderTypeList.add(new CartOrderSummaryViewHolderType());
        viewHolderTypeList.add(new OrderFailureReasonsViewDataBinder());
        viewHolderTypeList.add(new RecyclerBorderDataBinder());
        viewHolderTypeList.add(new OrderFailureReasonHeaderViewDataBinder());
        viewHolderTypeList.add(new CartOffersViewPagerDataBinder());
        viewHolderTypeList.add(new CartAppliedCouponDataBinder());

        /** Revised order LIst ItemTypes */
        viewHolderTypeList.add(new RevisedOrderCartItemViewHolderType());

        return viewHolderTypeList;
    }

    /**
     * failure reasons HEADER VIEW TYPE
     */
    public static class OrderFailureReasonHeaderDataItem implements IViewType {

        public String headerTitle;

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_ORDER_FAILURE_REASON_HEADER_VIEW_TYPE;
        }
    }

    private static class OrderFailureReasonHeaderViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mOrderFailureHeaderTitle;

        public OrderFailureReasonHeaderViewHolder(View itemView) {
            super(itemView);
            mOrderFailureHeaderTitle = (RobotoTextView) itemView.findViewById(R.id.non_pharma_key_features_title_tv);
            Context context = mOrderFailureHeaderTitle.getContext();
            mOrderFailureHeaderTitle.setRobotoFaceType(RobotoTextView.InputTypeFace.MEDIUM);
            mOrderFailureHeaderTitle.setTypeface(Typeface.DEFAULT_BOLD);
            mOrderFailureHeaderTitle.setTextColor(ContextCompat.getColor(context, R.color.black_text_color));
        }
    }

    public static class OrderFailureReasonHeaderViewDataBinder implements
            RecyclerViewDataBinder<OrderFailureReasonHeaderViewHolder, OrderFailureReasonHeaderDataItem> {

        @Override
        public OrderFailureReasonHeaderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.non_pharma_key_features_header, parent, false);
            return new OrderFailureReasonHeaderViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(OrderFailureReasonHeaderViewHolder viewHolder,
                                         final OrderFailureReasonHeaderDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mOrderFailureHeaderTitle.setText(data.headerTitle);
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_ORDER_FAILURE_REASON_HEADER_VIEW_TYPE;
        }
    }

    /**
     * CART DIGITIZATION CANCEL REASONS
     */
    public static class OrderFailureReasonDataItem implements IViewType {

        public String cancellationReason;

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_DIGITIZATION_CANCELLATION_REASON_VIEW_TYPE;
        }
    }

    private static class OrderFailureReasonViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mOrderFailureReasonView;
        private LinearLayout mOrderFailureLayout;
        private ImageView mBulletView;


        public OrderFailureReasonViewHolder(View itemView) {
            super(itemView);
            mOrderFailureReasonView = (RobotoTextView) itemView.findViewById(R.id.non_pharma_product_detail_key_feature_tv);
            mOrderFailureLayout = (LinearLayout) itemView.findViewById(R.id.key_feature_data_item_layout);
            mBulletView = (ImageView) itemView.findViewById(R.id.non_pharma_key_features_bullet_iv);
            Context context = mOrderFailureLayout.getContext();
            mOrderFailureLayout.setBackgroundColor(ContextCompat.getColor(context, R.color.background_darker_grey));
            mOrderFailureReasonView.setTextColor(ContextCompat.getColor(context, R.color.cart_shipping_details_text_color));
            mOrderFailureReasonView.setTextSize(14);
            mOrderFailureLayout.setPadding(Utils.convertDpToPixel(context, 16),
                    0, Utils.convertDpToPixel(context, 16), Utils.convertDpToPixel(context, 5));
            mBulletView.setVisibility(View.VISIBLE);
        }
    }

    private static class OrderFailureReasonsViewDataBinder implements
            RecyclerViewDataBinder<OrderFailureReasonViewHolder, OrderFailureReasonDataItem> {

        @Override
        public OrderFailureReasonViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.non_pharma_key_features, parent, false);

            return new OrderFailureReasonViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(OrderFailureReasonViewHolder viewHolder,
                                         final OrderFailureReasonDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mOrderFailureReasonView.setText(Html.fromHtml(data.cancellationReason));
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_DIGITIZATION_CANCELLATION_REASON_VIEW_TYPE;
        }
    }

    /**
     * CART INACTIVE ITEM VIEW TYPE
     */
    public static class CartInActiveDataItem implements IViewType {

        public long variantId;
        public String productName;

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_ITEM_INACTIVE_VIEW_TYPE;
        }
    }

    private static class CartInActiveItemViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mCartProductName;
        private ImageView mCartProductDeleteImage;

        public CartInActiveItemViewHolder(View itemView) {
            super(itemView);
            mCartProductName = (RobotoTextView) itemView.findViewById(R.id.cart_list_item_product_name_tv);
            mCartProductDeleteImage = (ImageView) itemView.findViewById(R.id.cart_list_item_product_delete_iv);
        }
    }

    private static class CartInActiveItemViewHolderType implements
            RecyclerViewDataBinder<CartInActiveItemViewHolder, CartInActiveDataItem> {

        @Override
        public CartInActiveItemViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_list_item_inactive, parent, false);

            return new CartInActiveItemViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(CartInActiveItemViewHolder viewHolder,
                                         final CartInActiveDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mCartProductName.setText(data.productName);
            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
                viewHolder.mCartProductDeleteImage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_ITEM_INACTIVE_VIEW_TYPE;
        }
    }

    /**
     * REVISED ORDER CART ITEM VIEW TYPE
     */
    public static class RevisedOrderCartDataItem extends CartDataItem {
        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_ITEM_REVISED_ORDER_VIEW_TYPE;
        }
    }

    private static class RevisedOrderCartItemViewHolderType implements
            RecyclerViewDataBinder<CartItemViewHolder, RevisedOrderCartDataItem> {

        @Override
        public CartItemViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_list_item, parent, false);

            return new CartItemViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(CartItemViewHolder viewHolder,
                                         final RevisedOrderCartDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mCartProductName.setText(data.productName);
            viewHolder.mCartProductPrice.setText(Utils.addRupeeSymbol(viewHolder.mCartProductPrice.getContext(), "",
                    Utils.getFormattedDouble(data.productPrice)));
            viewHolder.mCartProductQuantity.setText(String.valueOf(data.productQuantity));
            viewHolder.mCartProductStripInfo.setText(data.productStripInfo);
            viewHolder.mCartProductTotalPrice.setText(Utils.addRupeeSymbol(viewHolder.mCartProductTotalPrice.getContext(), "",
                    Utils.getFormattedDouble(data.productTotalPrice)));

            if (data.prescriptionRequired) {
                viewHolder.mCartProductPrescription.setVisibility(View.VISIBLE);
                // viewHolder.mCartProductPrescription.setText(data.productStatus);
                viewHolder.mCartProductPrescription.setText(data.prescriptionMessage);
                viewHolder.mCartProductPrescription.setTextColor(
                        ContextCompat.getColor(viewHolder.mCartProductPrescription.getContext(),
                                data.prescriptionAvailable ? R.color.frankross_green : R.color.prescription_rqrd_txt_color));
            } else {
                viewHolder.mCartProductPrescription.setVisibility(View.GONE);
            }

            viewHolder.mCartProductDeleteImage.setVisibility(View.GONE);

            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_ITEM_REVISED_ORDER_VIEW_TYPE;
        }
    }

    /**
     * CART ITEM VIEW TYPE
     */
    public static class CartDataItem implements IViewType {

        public String innerPackagingQty;
        public String outerPackagingQty;
        public String unitOfSale;
        public String productStatus;
        public String productStripInfo;
        public String productName;
        public String prescriptionMessage;
        public String cashBackMessage;
        public long variantId;
        public double productPrice;
        public double productTotalPrice;
        public int maxOrderableQty;
        public int productQuantity;
        public boolean isActive;
        public boolean isPharma;
        public boolean isCashBack;
        public boolean prescriptionRequired;
        public boolean prescriptionAvailable;
        public boolean isProductAvailable;

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_ITEM_VIEW_TYPE;
        }
    }

    private static class CartItemViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mCartProductName;
        private RobotoTextView mCartProductPrice;
        private RobotoTextView mCartProductQuantity;
        private RobotoTextView mCartProductStripInfo;
        private RobotoTextView mCartProductTotalPrice;
        private RobotoTextView mCartProductPrescription;
        private RobotoTextView mCartProductOfferText;
        private RobotoTextView mCartProductOfferAmount;
        private RobotoTextView mCartProductCashBackMessage;
        private LinearLayout mCartProductCashBackLinLyt;
        private ImageView mCartProductDeleteImage;

        public CartItemViewHolder(View itemView) {
            super(itemView);
            mCartProductName = (RobotoTextView) itemView.findViewById(R.id.cart_list_item_product_name_tv);
            mCartProductPrice = (RobotoTextView) itemView.findViewById(R.id.cart_list_item_product_price_tv);
            mCartProductStripInfo = (RobotoTextView) itemView.findViewById(R.id.cart_list_item_product_strip_info_tv);
            mCartProductTotalPrice = (RobotoTextView) itemView.findViewById(R.id.cart_list_item_product_total_price_tv);
            mCartProductPrescription = (RobotoTextView) itemView.findViewById(R.id.cart_prescription_required_tv);
            mCartProductQuantity = (RobotoTextView) itemView.findViewById(R.id.cart_list_item_product_amount_tv);
            mCartProductDeleteImage = (ImageView) itemView.findViewById(R.id.cart_list_item_product_delete_iv);
            mCartProductOfferText = (RobotoTextView) itemView.findViewById(R.id.cart_list_item_discount_info_tv);
            mCartProductOfferAmount = (RobotoTextView) itemView.findViewById(R.id.cart_list_item_discount_price_tv);
            mCartProductCashBackLinLyt = (LinearLayout) itemView.findViewById(R.id.cart_cashback_message_linLyt);
            mCartProductCashBackMessage = (RobotoTextView) itemView.findViewById(R.id.cart_cashback_message_tv);
        }
    }

    private static class CartItemViewHolderType implements
            RecyclerViewDataBinder<CartItemViewHolder, CartDataItem> {

        @Override
        public CartItemViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_list_item, parent, false);

            return new CartItemViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(CartItemViewHolder viewHolder,
                                         final CartDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mCartProductName.setText(data.productName);
            viewHolder.mCartProductPrice.setText(Utils.addRupeeSymbol(viewHolder.mCartProductPrice.getContext(), "",
                    Utils.getFormattedDouble(data.productPrice)));
            viewHolder.mCartProductQuantity.setText(String.valueOf(data.productQuantity));
            viewHolder.mCartProductStripInfo.setText(data.productStripInfo);
            viewHolder.mCartProductTotalPrice.setText(Utils.addRupeeSymbol(viewHolder.mCartProductTotalPrice.getContext(), "",
                    Utils.getFormattedDouble(data.productTotalPrice)));

            if (data.isCashBack) {
                viewHolder.mCartProductCashBackLinLyt.setVisibility(View.VISIBLE);
                viewHolder.mCartProductCashBackMessage.setText(data.cashBackMessage);
            } else {
                viewHolder.mCartProductCashBackLinLyt.setVisibility(View.GONE);
            }

            if (data.prescriptionRequired) {
                viewHolder.mCartProductPrescription.setVisibility(View.VISIBLE);
                //viewHolder.mCartProductPrescription.setText(data.productStatus);
                viewHolder.mCartProductPrescription.setText(data.prescriptionMessage);
                viewHolder.mCartProductPrescription.setTextColor(
                        ContextCompat.getColor(viewHolder.mCartProductPrescription.getContext(),
                                data.prescriptionAvailable ? R.color.frankross_green : R.color.prescription_rqrd_txt_color));
            } else {
                viewHolder.mCartProductPrescription.setVisibility(View.GONE);
            }

            if (recyclerViewClickListener != null) {
                viewHolder.mCartProductQuantity.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
                viewHolder.mCartProductDeleteImage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_ITEM_VIEW_TYPE;
        }
    }

    /**
     * CART ITEM UNAVAILABLE VIEW TYPE
     */

    public static class CartItemUnavailableDataItem extends CartDataItem implements IViewType {

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_ITEM_UNAVAILABLE_VIEW_TYPE;
        }
    }

    private static class CartItemUnavailableViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mCartProductQuantity;
        private RobotoTextView mCartProductPrice;
        private RobotoTextView mCartProductTotalPrice;
        private RobotoTextView mCartProductStripInfo;
        private RobotoTextView mCartProductPrescription;
        private RobotoTextView mCartProductName;
        private ImageView mCartProductDeleteImage;


        public CartItemUnavailableViewHolder(View itemView) {
            super(itemView);
            mCartProductName = (RobotoTextView) itemView.findViewById(R.id.cart_list_unavailable_item_product_name_tv);
            mCartProductDeleteImage = (ImageView) itemView.findViewById(R.id.cart_list_unavialable_item_product_delete_iv);
            mCartProductStripInfo = (RobotoTextView) itemView.findViewById(R.id.cart_list_item_product_strip_info_tv);
            mCartProductTotalPrice = (RobotoTextView) itemView.findViewById(R.id.cart_list_item_product_total_price_tv);
            mCartProductPrice = (RobotoTextView) itemView.findViewById(R.id.cart_list_item_product_price_tv);
            mCartProductQuantity = (RobotoTextView) itemView.findViewById(R.id.cart_list_item_product_amount_tv);
            mCartProductPrescription = (RobotoTextView) itemView.findViewById(R.id.cart_unavailable_prescription_required_tv);
        }
    }

    private static class CartItemUnavailableViewHolderType implements
            RecyclerViewDataBinder<CartItemUnavailableViewHolder, CartItemUnavailableDataItem> {

        @Override
        public CartItemUnavailableViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_list_item_unavailable, parent, false);

            return new CartItemUnavailableViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(CartItemUnavailableViewHolder viewHolder,
                                         final CartItemUnavailableDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            Context context = viewHolder.mCartProductName.getContext();

            viewHolder.mCartProductPrice.setText(Utils.addRupeeSymbol(context, "",
                    Utils.getFormattedDouble(data.productPrice)));
            viewHolder.mCartProductQuantity.setText(String.valueOf(data.productQuantity));
            viewHolder.mCartProductStripInfo.setText(data.productStripInfo);
            viewHolder.mCartProductTotalPrice.setText(Utils.addRupeeSymbol(context, "",
                    Utils.getFormattedDouble(data.productTotalPrice)));
            viewHolder.mCartProductName.setText(data.productName);

            if (data.prescriptionRequired) {
                viewHolder.mCartProductPrescription.setVisibility(View.VISIBLE);
                //viewHolder.mCartProductPrescription.setText(data.productStatus);
                viewHolder.mCartProductPrescription.setText(data.prescriptionMessage);
                viewHolder.mCartProductPrescription.setTextColor(
                        ContextCompat.getColor(viewHolder.mCartProductPrescription.getContext(),
                                data.prescriptionAvailable ? R.color.frankross_green : R.color.prescription_rqrd_txt_color));
            } else {
                viewHolder.mCartProductPrescription.setVisibility(View.GONE);
            }

            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
                viewHolder.mCartProductDeleteImage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_ITEM_UNAVAILABLE_VIEW_TYPE;
        }
    }

    /**
     * CART ITEM STOCK INFO VIEW TYPE
     */

    public static class CartDataStockItem extends CartDataItem implements IViewType {

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_ITEM_BACK_IN_STOCK_VIEW_TYPE;
        }
    }

    private static class CartItemStockViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mCartProductName;
        private RobotoTextView mCartProductPrice;
        private RobotoTextView mCartProductQuantity;
        private RobotoTextView mCartProductStripInfo;
        private RobotoTextView mCartProductTotalPrice;
        private RobotoTextView mCartProductPrescription;
        private RobotoTextView mCartProductStockInfo;
        private RobotoTextView mCartProductCashBackMessage;
        private LinearLayout mCartProductCashBackLinLyt;
        private ImageView mCartProductDeleteImage;

        public CartItemStockViewHolder(View itemView) {
            super(itemView);
            mCartProductName = (RobotoTextView) itemView.findViewById(R.id.cart_stock_info_list_item_product_name_tv);
            mCartProductPrice = (RobotoTextView) itemView.findViewById(R.id.cart_stock_info_list_item_product_price_tv);
            mCartProductStripInfo = (RobotoTextView) itemView.findViewById(R.id.cart_stock_info_list_item_product_strip_info_tv);
            mCartProductTotalPrice = (RobotoTextView) itemView.findViewById(R.id.cart_stock_info_list_item_product_total_price_tv);
            mCartProductPrescription = (RobotoTextView) itemView.findViewById(R.id.cart_stock_info_prescription_required_tv);
            mCartProductStockInfo = (RobotoTextView) itemView.findViewById(R.id.cart_stock_info_tv);
            mCartProductQuantity = (RobotoTextView) itemView.findViewById(R.id.cart_stock_info_list_item_product_amount_tv);
            mCartProductDeleteImage = (ImageView) itemView.findViewById(R.id.cart_stock_info_list_item_product_delete_iv);
            mCartProductCashBackLinLyt = (LinearLayout) itemView.findViewById(R.id.cart_cashback_message_linLyt);
            mCartProductCashBackMessage = (RobotoTextView) itemView.findViewById(R.id.cart_cashback_message_tv);
        }
    }

    private static class CartItemStockViewHolderType implements
            RecyclerViewDataBinder<CartItemStockViewHolder, CartDataStockItem> {

        @Override
        public CartItemStockViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_stock_info_list_item, parent, false);

            return new CartItemStockViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(CartItemStockViewHolder viewHolder,
                                         final CartDataStockItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            Context context = viewHolder.mCartProductName.getContext();

            viewHolder.mCartProductName.setText(data.productName);
            viewHolder.mCartProductPrice.setText(Utils.addRupeeSymbol(context, "", Utils.getFormattedDouble(data.productPrice)));
            viewHolder.mCartProductQuantity.setText(String.valueOf(data.productQuantity));
            viewHolder.mCartProductStripInfo.setText(data.productStripInfo);
            viewHolder.mCartProductTotalPrice.setText(Utils.addRupeeSymbol(context, "", Utils.getFormattedDouble(data.productTotalPrice)));
            viewHolder.mCartProductStockInfo.setText("Only " + data.maxOrderableQty + " left in stock");

            if (data.isCashBack) {
                viewHolder.mCartProductCashBackLinLyt.setVisibility(View.VISIBLE);
                viewHolder.mCartProductCashBackMessage.setText(data.cashBackMessage);
            } else {
                viewHolder.mCartProductCashBackLinLyt.setVisibility(View.GONE);
            }

            if (data.prescriptionRequired) {
                viewHolder.mCartProductPrescription.setVisibility(View.VISIBLE);
                //viewHolder.mCartProductPrescription.setText(data.productStatus);
                viewHolder.mCartProductPrescription.setText(data.prescriptionMessage);
                viewHolder.mCartProductPrescription.setTextColor(ContextCompat.getColor(context, R.color.prescription_rqrd_txt_color));
            } else {
                viewHolder.mCartProductPrescription.setVisibility(View.GONE);
            }

            if (recyclerViewClickListener != null) {
                viewHolder.mCartProductQuantity.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
                viewHolder.mCartProductDeleteImage.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_ITEM_BACK_IN_STOCK_VIEW_TYPE;
        }
    }

    /**
     * CART COUPON CODE VIEW TYPE
     */

    public static class CartCouponCodeDataItem implements IViewType {

        public String enteredCouponCode = "";
        public String mCouponMessage = "";
        public boolean isApplied = false;
        public boolean isIneligible = false;

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_COUPON_CODE_VIEW_TYPE;
        }
    }

    private static class CartCouponCodeViewHolder extends RecyclerView.ViewHolder {

        private Button mCartCouponCodeBtn;
        private EditText mCartCouponCode;
        private LinearLayout mCartCouponCodeLinLyt;
        private RobotoTextView mCartCouponCodeClearBtn;
        private RobotoTextView mCartAppliedCouponMessage;

        public CartCouponCodeViewHolder(View itemView) {
            super(itemView);
            mCartCouponCodeLinLyt = (LinearLayout) itemView.findViewById(R.id.cart_enter_coupon_code_linLyt);
            mCartCouponCodeBtn = (Button) itemView.findViewById(R.id.cart_enter_coupon_code_apply_btn);
            mCartCouponCode = (EditText) itemView.findViewById(R.id.cart_enter_coupon_code_et);
            mCartCouponCodeClearBtn = (RobotoTextView) itemView.findViewById(R.id.cart_enter_coupon_code_clear_txt_btn);
            mCartCouponCodeLinLyt.setGravity(Gravity.CENTER_VERTICAL);
            mCartAppliedCouponMessage = (RobotoTextView) itemView.findViewById(R.id.cart_coupon_message_tv);
        }
    }

    private static class CartCouponCodeViewHolderType implements
            RecyclerViewDataBinder<CartCouponCodeViewHolder, CartCouponCodeDataItem> {

        @Override
        public CartCouponCodeViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_coupon_code, parent, false);

            return new CartCouponCodeViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final CartCouponCodeViewHolder viewHolder,
                                         final CartCouponCodeDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mCartCouponCode.setText(data.enteredCouponCode);

            if (!TextUtils.isEmpty(viewHolder.mCartCouponCode.getText().toString())) {
                viewHolder.mCartCouponCodeClearBtn.setVisibility(View.VISIBLE);
            } else {
                viewHolder.mCartCouponCodeClearBtn.setVisibility(View.GONE);
            }

            if (data.isApplied) {
                viewHolder.mCartCouponCode.setEnabled(false);
                viewHolder.mCartCouponCodeClearBtn.setVisibility(View.GONE);

                viewHolder.mCartCouponCode.setBackgroundColor(ContextCompat.getColor(viewHolder.mCartCouponCode.getContext(),
                        R.color.cart_coupon_code_applied_background_color));

                viewHolder.mCartCouponCodeBtn.setText(viewHolder.mCartCouponCodeBtn.getContext().
                        getResources().getString(R.string.remove));
                viewHolder.mCartCouponCode.clearFocus();

                viewHolder.mCartAppliedCouponMessage.setVisibility(TextUtils.isEmpty(data.mCouponMessage) ? View.GONE : View.VISIBLE);
                viewHolder.mCartAppliedCouponMessage.setText(data.mCouponMessage);
                if (data.isIneligible) {
                    viewHolder.mCartAppliedCouponMessage.setTextColor(ContextCompat.getColor(viewHolder.mCartAppliedCouponMessage.getContext()
                            , R.color.prescription_reference_expired_txt_color));
                } else {
                    viewHolder.mCartAppliedCouponMessage.setTextColor(ContextCompat.getColor(viewHolder.mCartAppliedCouponMessage.getContext(),
                            R.color.frankross_common_text_color));
                }
            } else if (data.isIneligible) {
                viewHolder.mCartCouponCodeClearBtn.setVisibility(View.GONE);
                viewHolder.mCartCouponCode.setEnabled(false);
                viewHolder.mCartCouponCode.setBackgroundColor(ContextCompat.getColor(viewHolder.mCartCouponCode.getContext(),
                        R.color.cart_coupon_code_expired_txt_color));
                viewHolder.mCartCouponCodeBtn.setText(viewHolder.mCartCouponCodeBtn.getContext().
                        getResources().getString(R.string.remove));
                viewHolder.mCartAppliedCouponMessage.setTextColor(ContextCompat.getColor(viewHolder.mCartAppliedCouponMessage.getContext(),
                        R.color.prescription_reference_expired_txt_color));
                viewHolder.mCartAppliedCouponMessage.setText(data.mCouponMessage);
            } else {
                viewHolder.mCartCouponCode.setEnabled(true);
                viewHolder.mCartCouponCode.setBackgroundColor(ContextCompat.getColor(viewHolder.mCartCouponCode.getContext(), R.color.white_background));
                viewHolder.mCartCouponCodeBtn.setText(viewHolder.mCartCouponCodeBtn.getContext().
                        getResources().getString(R.string.apply));
                viewHolder.mCartAppliedCouponMessage.setVisibility(View.GONE);
            }

            if (recyclerViewClickListener != null) {
                /**
                 * Verifies if the coupon code is valid;If not,shows error dialog
                 * else changes background color to light green
                 */
                viewHolder.mCartCouponCodeBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (data.isIneligible) {
                            viewHolder.mCartCouponCode.setEnabled(true);
                            viewHolder.mCartCouponCode.setBackgroundColor(ContextCompat.getColor(viewHolder.mCartCouponCode.getContext(),
                                    R.color.white_background));
                            viewHolder.mCartCouponCodeBtn.setText(viewHolder.mCartCouponCodeBtn.getContext().
                                    getResources().getString(R.string.apply));
                            viewHolder.mCartCouponCode.getText().clear();
                            viewHolder.mCartAppliedCouponMessage.setVisibility(View.GONE);
                            data.isIneligible = false;
                            data.isApplied = false;
                        } else {
                            recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                        }
                    }
                });

                /**
                 * Clears the text in the editable filed
                 */
                viewHolder.mCartCouponCodeClearBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (!TextUtils.isEmpty(viewHolder.mCartCouponCode.getText().toString())) {
                            viewHolder.mCartCouponCode.getText().clear();
                            viewHolder.mCartCouponCode.setEnabled(true);
                        }
                    }
                });

            }

            /**
             * Focus change listener to set Visibility of clear button and background color
             */
            viewHolder.mCartCouponCode.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (hasFocus) {
                        if (!TextUtils.isEmpty(viewHolder.mCartCouponCode.getText().toString())) {
                            viewHolder.mCartCouponCodeClearBtn.setVisibility(View.VISIBLE);
                        } else {
                            viewHolder.mCartCouponCodeClearBtn.setVisibility(View.GONE);
                        }
                        viewHolder.mCartCouponCodeBtn.setText(viewHolder.mCartCouponCodeBtn.getContext().
                                getResources().getString(R.string.apply));
                        viewHolder.mCartCouponCode.setBackgroundColor(ContextCompat.getColor(viewHolder.mCartCouponCode.getContext(),
                                R.color.white_background));
                    }
                }
            });

            /**
             * Text watcher to set Visibility of clear button and background color
             */
            viewHolder.mCartCouponCode.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {

                }

                @Override
                public void afterTextChanged(Editable s) {
                    if (!TextUtils.isEmpty(s.toString())) {
                        viewHolder.mCartCouponCodeClearBtn.setVisibility(View.VISIBLE);
                        data.enteredCouponCode = viewHolder.mCartCouponCode.getText().toString();
                    } else {
                        viewHolder.mCartCouponCodeClearBtn.setVisibility(View.GONE);
                        data.enteredCouponCode = viewHolder.mCartCouponCode.getText().toString();
                    }

                    viewHolder.mCartCouponCodeBtn.setText(viewHolder.mCartCouponCodeBtn.getContext().
                            getResources().getString(R.string.apply));
                    viewHolder.mCartCouponCode.setBackgroundColor(ContextCompat.getColor(viewHolder.mCartCouponCode.getContext(),
                            R.color.white_background));
                }
            });
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_COUPON_CODE_VIEW_TYPE;
        }
    }

    /**
     * CART ORDER SUMMARY VIEW TYPE
     */

    public static class CartOrderSummaryDataItem implements IViewType {

        public String shippingDescription = "";
        public String cashBackCartSummary = "";
        public double productItemsTotal = 0.00d;
        public double shippingCharges = 0.00d;
        public double orderTotal = 0.00d;
        public double discountTotal = 0.00d;
        public double promotionalDiscountTotal = 0.00d;
        public long orderId = 0;
        public boolean isCashBack = false;
        public boolean isOrderWithoutPrescription = false;

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_ORDER_SUMMARY_VIEW_TYPE;
        }
    }

    private static class CartOrderSummaryViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mCartItems;
        private RobotoTextView mCartShippingCharges;
        private RobotoTextView mCartOrderTotal;
        private RobotoTextView mCartTotalSavings;
        private RobotoTextView mCartShippingDescription;
        private RobotoTextView mCartTotalDiscount;
        private RobotoTextView mCartTotalDiscountAmount;
        private RobotoTextView mCartCashbackSummary;
        private LinearLayout mCartTotalSavingsLinLyt;

        public CartOrderSummaryViewHolder(View itemView) {
            super(itemView);
            mCartItems = (RobotoTextView) itemView.findViewById(R.id.cart_order_summary_items_price_tv);
            mCartShippingCharges = (RobotoTextView) itemView.findViewById(R.id.cart_order_summary_shipping_charges_tv);
            mCartOrderTotal = (RobotoTextView) itemView.findViewById(R.id.cart_order_summary_order_total_tv);
            mCartTotalSavings = (RobotoTextView) itemView.findViewById(R.id.cart_order_summary_shipping_total_savings_tv);
            mCartShippingDescription = (RobotoTextView) itemView.findViewById(R.id.cart_order_summary_shipping_charges_description_tv);
            mCartTotalSavingsLinLyt = (LinearLayout) itemView.findViewById(R.id.cart_total_savings_linLyt);
            mCartTotalDiscount = (RobotoTextView) itemView.findViewById(R.id.cart_order_summary_items_discount_tv);
            mCartTotalDiscountAmount = (RobotoTextView) itemView.findViewById(R.id.cart_order_summary_items_discount_price_tv);
            mCartCashbackSummary = (RobotoTextView) itemView.findViewById(R.id.cart_order_cashback_summary_tv);
        }
    }

    private static class CartOrderSummaryViewHolderType implements
            RecyclerViewDataBinder<CartOrderSummaryViewHolder, CartOrderSummaryDataItem> {

        @Override
        public CartOrderSummaryViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_order_summary, parent, false);

            return new CartOrderSummaryViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(CartOrderSummaryViewHolder viewHolder,
                                         final CartOrderSummaryDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            Context context = viewHolder.mCartItems.getContext();
            viewHolder.mCartItems.setText(Utils.addRupeeSymbol(context, "", Utils.getFormattedDouble(data.productItemsTotal)));
            viewHolder.mCartShippingCharges.setText(Utils.addRupeeSymbol(context, "", Utils.getFormattedDouble(data.shippingCharges)));
            viewHolder.mCartOrderTotal.setText(Utils.addRupeeSymbol(context, "", Utils.getFormattedDouble(data.orderTotal)));
            viewHolder.mCartShippingDescription.setText(data.shippingDescription);
            viewHolder.mCartShippingDescription.setVisibility(TextUtils.isEmpty(data.shippingDescription) ? View.GONE : View.VISIBLE);

            viewHolder.mCartTotalDiscount.setVisibility(data.promotionalDiscountTotal == 0.0d ? View.GONE : View.VISIBLE);
            viewHolder.mCartTotalDiscountAmount.setVisibility(data.promotionalDiscountTotal == 0.0d ? View.GONE : View.VISIBLE);
            viewHolder.mCartTotalDiscount.setText(context.getString(R.string.additional_discount));
            viewHolder.mCartTotalDiscountAmount.setText(Utils.addRupeeSymbol(context, "- ", Utils.getFormattedDouble(data.promotionalDiscountTotal)));

            viewHolder.mCartCashbackSummary.setVisibility((!TextUtils.isEmpty(data.cashBackCartSummary) && data.isCashBack) ? View.VISIBLE : View.GONE);
            viewHolder.mCartCashbackSummary.setText(data.cashBackCartSummary);

            if (data.discountTotal == 0.0d) {
                viewHolder.mCartTotalSavingsLinLyt.setVisibility(View.GONE);
            } else {
                viewHolder.mCartTotalSavingsLinLyt.setVisibility(View.VISIBLE);
                viewHolder.mCartTotalSavings.setText(Utils.addRupeeSymbol(context, "", Utils.getFormattedDouble(data.discountTotal)));
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_ORDER_SUMMARY_VIEW_TYPE;
        }
    }

    /**
     * CART OFFERS VIEW PAGER VIEW TYPE
     */

    public static class CartOffersViewPagerDataItem implements IViewType {

        public List<Cart.CartPromotion> mCartOffersData;

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_OFFERS_VIEW_PAGER_VIEW_TYPE;
        }
    }

    private static class CartOffersViewPagerViewHolder extends RecyclerView.ViewHolder {

        private ViewPager mCartOffersViewPager;
        private CirclePageIndicator mPagerIndicator;

        public CartOffersViewPagerViewHolder(View itemView) {
            super(itemView);
            mCartOffersViewPager = (ViewPager) itemView.findViewById(R.id.cart_offers_pager);
            mCartOffersViewPager.setAdapter(new CartOffersAdapter(new ArrayList<Cart.CartPromotion>()));
            mPagerIndicator = (CirclePageIndicator) itemView.findViewById(R.id.cart_offers_pager_pager_indicator);
            mPagerIndicator.getBackground().setAlpha((int) (0.7F * 255));
            mPagerIndicator.setViewPager(mCartOffersViewPager);
        }
    }

    private static class CartOffersViewPagerDataBinder implements
            RecyclerViewDataBinder<CartOffersViewPagerViewHolder, CartOffersViewPagerDataItem> {

        @Override
        public CartOffersViewPagerViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_offers_view_pager, parent, false);
            return new CartOffersViewPagerViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final CartOffersViewPagerViewHolder viewHolder,
                                         CartOffersViewPagerDataItem data, int position,
                                         RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mCartOffersViewPager.setAdapter(new CartOffersAdapter(data.mCartOffersData));
            viewHolder.mCartOffersViewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
                @Override
                public void onPageSelected(int position) {
                    viewHolder.mPagerIndicator.setCurrentItem(position);
                }
            });
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_OFFERS_VIEW_PAGER_VIEW_TYPE;
        }
    }

    /**
     * CART COUPON CODE APPLIED VIEW TYPE
     */

    public static class CartAppliedCouponsDataItem implements IViewType {

        public ArrayList<String> appliedCouponCodes = new ArrayList<>();

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_APPLIED_COUPON_CODES_VIEW_TYPE;
        }
    }

    private static class CartAppliedCouponViewHolder extends RecyclerView.ViewHolder {

        private final RecyclerView mHorizontalRecyclerView;

        public CartAppliedCouponViewHolder(View itemView, Context context) {
            super(itemView);

            mHorizontalRecyclerView = (RecyclerView) itemView.findViewById(R.id.cart_applied_coupon_code_horizontal_view);
            mHorizontalRecyclerView.setHasFixedSize(false);
            LinearLayoutManager layoutManager
                    = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
            mHorizontalRecyclerView.setLayoutManager(layoutManager);
        }
    }

    private static class CartAppliedCouponDataBinder implements
            RecyclerViewDataBinder<CartAppliedCouponViewHolder, CartAppliedCouponsDataItem> {

        @Override
        public CartAppliedCouponViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_coupon_codes_horizontal_view, parent, false);
            return new CartAppliedCouponViewHolder(view, view.getContext());
        }

        @Override
        public void bindDataToViewHolder(final CartAppliedCouponViewHolder viewHolder,
                                         CartAppliedCouponsDataItem data, int position,
                                         RecyclerItemClickListener recyclerViewClickListener) {

            List<BaseRecyclerAdapter.IViewType> couponCodeDataList = new ArrayList<>();
            CartCouponCodesAdapter cartCouponCodesAdapter = new CartCouponCodesAdapter(couponCodeDataList);
            cartCouponCodesAdapter.setRecyclerItemClickListener(recyclerViewClickListener);

            viewHolder.mHorizontalRecyclerView.setAdapter(cartCouponCodesAdapter);

            for (String appliedCouponCode : data.appliedCouponCodes) {
                CartCouponCodesAdapter.AppliedCouponCodeDataItem item = new CartCouponCodesAdapter.AppliedCouponCodeDataItem();
                item.couponCodeName = appliedCouponCode;
                couponCodeDataList.add(item);
            }
            cartCouponCodesAdapter.notifyDataSetChanged();
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartViewType.CART_APPLIED_COUPON_CODES_VIEW_TYPE;
        }
    }
}
