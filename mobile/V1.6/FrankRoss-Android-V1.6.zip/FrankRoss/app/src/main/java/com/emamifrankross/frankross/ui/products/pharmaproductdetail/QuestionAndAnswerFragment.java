/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.products.pharmaproductdetail;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

/**
 * Created by gauthami on 4/8/15.
 */

/**
 * This class represents the UI for Questions and Answers for a Pharma product
 */
public class QuestionAndAnswerFragment extends ApiRequestBaseFragment implements IToolbar {

    private static final String BUNDLE_QUESTION_KEY = "question";
    private static final String BUNDLE_ANSWER_KEY = "answer";

    private String mQuestion = "";
    private String mAnswer = "";

    public static QuestionAndAnswerFragment create(String question, String answer) {
        QuestionAndAnswerFragment fragment = new QuestionAndAnswerFragment();
        Bundle bundle = new Bundle();
        bundle.putString(BUNDLE_QUESTION_KEY, question);
        bundle.putString(BUNDLE_ANSWER_KEY, answer);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the views
     *
     * @param view the root view
     */
    private void initViews(View view) {
        RobotoTextView pharmaAnswer = (RobotoTextView) view.findViewById(R.id.pharma_question_and_answer_tv);
        pharmaAnswer.setText(Html.fromHtml("<html><body>" + "<p align=\"justify\">" + mAnswer + "</p> " + "</body></html>"));
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_question_and_answer, container, false);
        if (getArguments() != null) {
            mQuestion = getArguments().getString(BUNDLE_QUESTION_KEY);
            mAnswer = getArguments().getString(BUNDLE_ANSWER_KEY);
        }
        return view;
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return mQuestion;
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }
}
