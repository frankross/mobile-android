package com.emamifrankross.frankross.ui.viewmodels;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gauthami on 30/12/15.
 */

/**
 * Horizontal scroll view more data binder
 */
public class HorizontalScrollerViewMoreViewDataBinder implements
        BaseRecyclerAdapter.RecyclerViewDataBinder<HorizontalScrollerViewMoreViewHolder,
                HorizontalScrollerViewMoreDataItem> {

    @Override
    public HorizontalScrollerViewMoreViewHolder getViewHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_top_categories_horizontal_scroll_view_more_list_item,
                parent, false);

        return new HorizontalScrollerViewMoreViewHolder(view);
    }

    @Override
    public void bindDataToViewHolder(HorizontalScrollerViewMoreViewHolder viewHolder,
                                     final HorizontalScrollerViewMoreDataItem data, final int position,
                                     final BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.width = Utils.getDisplayPixels(viewHolder.mCategoryLayout.getContext(), data.viewWidth);
        params.height = Utils.getDisplayPixels(viewHolder.mCategoryLayout.getContext(), data.viewHeight);
        viewHolder.mCategoryLayout.setLayoutParams(params);

        viewHolder.mCategoryIcon.setImageResource(R.mipmap.nextarrow);

        final int sdk = android.os.Build.VERSION.SDK_INT;
        if (sdk < android.os.Build.VERSION_CODES.JELLY_BEAN) {
            viewHolder.mCategoryLayout.setBackgroundDrawable(data.isCategory ?
                    viewHolder.mCategoryIcon.getContext().getResources().getDrawable(R.drawable.category_view_more_image_border)
                    : viewHolder.mCategoryIcon.getContext().getResources().getDrawable(R.drawable.featured_view_more_image_border));
        } else {
            viewHolder.mCategoryLayout.setDividerDrawable(data.isCategory ?
                    viewHolder.mCategoryIcon.getContext().getResources().getDrawable(R.drawable.category_view_more_image_border)
                    : viewHolder.mCategoryIcon.getContext().getResources().getDrawable(R.drawable.featured_view_more_image_border));
        }

        if (recyclerViewClickListener != null) {
            viewHolder.mCategoryLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                }
            });
        }
    }

    @Override
    public int getViewType() {
        return ViewTypes.CommonViewType.HORIZONTAL_SCROLL_LIST_VIEW_MORE_ITEM_VIEW_TYPE;
    }
}
