/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 7/8/15.
 */
public class ApiPrescriptionDescription {

    public static class Response {

        @SerializedName("id")
        private long id = 0;

        @SerializedName("refNo")
        private String refNo = "";

        @SerializedName("date")
        private String date = "";

        @SerializedName("expiryDate")
        private String expiryDate = "";

        @SerializedName("patient")
        private Patient patient;

        @SerializedName("doctor")
        private Doctor doctor;

        @SerializedName("line_items")
        private List<Medicines> medicines = new ArrayList<>();

        @SerializedName("symptoms")
        private String symptoms = "";

        @SerializedName("diagnosis")
        private String diagnosis = "";

        @SerializedName("testsPrescribed")
        private String testsPrescribed = "";

        @SerializedName("notesAndDirections")
        private String notesAndDirections = "";

        @SerializedName("remarks")
        private String remarks = "";

        private List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>();

        public List<BaseRecyclerAdapter.IViewType> getUiDataList() {
            return uiDataList;
        }

        public void setUiDataList(List<BaseRecyclerAdapter.IViewType> dataList) {
            this.uiDataList = dataList;
        }

        public long getId() {
            return id;
        }

        public void setId(long id) {
            this.id = id;
        }

        public String getSymptoms() {
            return symptoms;
        }

        public void setSymptoms(String symptoms) {
            this.symptoms = symptoms;
        }

        public Patient getPatient() {
            return patient;
        }

        public void setPatient(Patient patient) {
            this.patient = patient;
        }

        public String getNotesAndDirections() {
            return notesAndDirections;
        }

        public void setNotesAndDirections(String notesAndDirections) {
            this.notesAndDirections = notesAndDirections;
        }

        public String getTestsPrescribed() {
            return testsPrescribed;
        }

        public void setTestsPrescribed(String testsPrescribed) {
            this.testsPrescribed = testsPrescribed;
        }

        public String getExpiryDate() {
            return expiryDate;
        }

        public void setExpiryDate(String expiryDate) {
            this.expiryDate = expiryDate;
        }

        public String getDiagnosis() {
            return diagnosis;
        }

        public void setDiagnosis(String diagnosis) {
            this.diagnosis = diagnosis;
        }

        public String getRefNo() {
            return refNo;
        }

        public void setRefNo(String refNo) {
            this.refNo = refNo;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public Doctor getDoctor() {
            return doctor;
        }

        public void setDoctor(Doctor doctor) {
            this.doctor = doctor;
        }

        public String getRemarks() {
            return remarks;
        }

        public List<Medicines> getMedicines() {
            return medicines;
        }

        public static class Medicines {

            @SerializedName("medicineName")
            private String medicineName = "";

            @SerializedName("variant_id")
            private long variantId = 0l;

            @SerializedName("quantity")
            private String quantity = "";

            @SerializedName("food_instruction")
            private String foodInstruction = "";

            @SerializedName("duration")
            private String duration = "";

            @SerializedName("time_evening")
            private boolean timeEvening = false;

            @SerializedName("time_morning")
            private boolean timeMorning = false;

            @SerializedName("time_afternoon")
            private boolean timeAfternoon = false;

            @SerializedName("time_night")
            private boolean timeNight = false;

            @SerializedName("frequency")
            private String frequency = "";

            @SerializedName("sos")
            private boolean sos = false;

            @SerializedName("specific_timings")
            private String specificTimings = "";

            public String getMedicineName() {
                return medicineName;
            }

            public long getVariantId() {
                return variantId;
            }

            public String getQuantity() {
                return quantity;
            }

            public String getFoodInstruction() {
                return foodInstruction;
            }

            public String getDuration() {
                return duration;
            }

            public boolean isTimeEvening() {
                return timeEvening;
            }

            public boolean isTimeMorning() {
                return timeMorning;
            }

            public boolean isTimeAfternoon() {
                return timeAfternoon;
            }

            public boolean isTimeNight() {
                return timeNight;
            }

            public String getFrequency() {
                return frequency;
            }

            public boolean isSos() {
                return sos;
            }

            public String getSpecificTimings() {
                return specificTimings;
            }
        }

        public static class Patient {

            @SerializedName("height")
            private String height = "-";

            @SerializedName("weight")
            private String weight = "-";

            @SerializedName("age")
            private String age = "-";

            @SerializedName("name")
            private String name = "-";

            @SerializedName("gender")
            private String gender = "-";

            public String getHeight() {
                return height;
            }

            public void setHeight(String height) {
                this.height = height;
            }

            public String getWeight() {
                return weight;
            }

            public void setWeight(String weight) {
                this.weight = weight;
            }

            public String getAge() {
                return age;
            }

            public void setAge(String age) {
                this.age = age;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getGender() {
                return gender;
            }

            public void setGender(String gender) {
                this.gender = gender;
            }
        }

        public static class Doctor {

            @SerializedName("phone")
            private String phone = "-";

            @SerializedName("facility")
            private String facility = "-";

            @SerializedName("address")
            private String address = "-";

            @SerializedName("speciality")
            private String speciality = "-";

            @SerializedName("name")
            private String name = "-";

            @SerializedName("regNo")
            private String regNo = "-";

            @SerializedName("mobile")
            private String mobile = "-";

            public String getPhone() {
                return phone;
            }

            public void setPhone(String phone) {
                this.phone = phone;
            }

            public String getFacility() {
                return facility;
            }

            public void setFacility(String facility) {
                this.facility = facility;
            }

            public String getAddress() {
                return address;
            }

            public void setAddress(String address) {
                this.address = address;
            }

            public String getSpeciality() {
                return speciality;
            }

            public void setSpeciality(String speciality) {
                this.speciality = speciality;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getRegNo() {
                return regNo;
            }

            public void setRegNo(String regNo) {
                this.regNo = regNo;
            }

            public String getMobile() {
                return mobile;
            }

            public void setMobile(String mobile) {
                this.mobile = mobile;
            }
        }
    }
}
