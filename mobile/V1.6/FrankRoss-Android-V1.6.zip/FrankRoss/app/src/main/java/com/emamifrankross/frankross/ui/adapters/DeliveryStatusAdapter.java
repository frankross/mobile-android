/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.graphics.Paint;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.android.volley.toolbox.NetworkImageView;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.customviews.CircularProgressBarWithText;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.customviews.VolleySingleton;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gauthami on 29/6/15.
 * <p> Adapter class for  Delivery Status Section in Home </p>
 * <p>Supports the Five View Types </p>
 * <p> 1 : DELIVERY STATUS VIEW TYPE</p>
 * <p> 2 : REVISE ORDER VIEW TYPE </p>
 * <p> 3 : BACK IN STOCK VIEW TYPE </p>
 * <p> 4 : ORDER READY VIEW TYPE </p>
 * <p> 5 : DIGITIZATION STATUS VIEW TYPE </p>
 */

public class DeliveryStatusAdapter extends PagerAdapter implements View.OnClickListener {

    private static final int DELIVERY_STATUS_PAGE_COUNT = 5;

    private static final int DELIVERY_STATUS = 0;
    private static final int REVISE_ORDER = 1;
    private static final int BACK_IN_STOCK = 2;
    private static final int ORDER_READY = 3;
    private static final int DIGITIZATION_STATUS = 4;

    @Override
    public int getCount() {
        return DELIVERY_STATUS_PAGE_COUNT;
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        View view = null;
        ViewPager pager = (ViewPager) container;
        int count = pager.getChildCount();

        switch (position) {
            case DELIVERY_STATUS:
                view = LayoutInflater.from(container.getContext()).inflate(R.layout.delivery_status_item, container, false);
                pager.addView(view, count > position ? position : count);
                break;
            case REVISE_ORDER:
                view = LayoutInflater.from(container.getContext()).inflate(R.layout.home_revise_order, container, false);
                initReviseOrderViews(view);
                pager.addView(view, count > position ? position : count);
                break;
            case BACK_IN_STOCK:
                view = LayoutInflater.from(container.getContext()).inflate(R.layout.home_back_in_stock, container, false);
                initBackInStockViews(view);
                pager.addView(view, count > position ? position : count);
                break;
            case ORDER_READY:
                view = LayoutInflater.from(container.getContext()).inflate(R.layout.home_order_ready, container, false);
                initOrderReadyViews(view);
                pager.addView(view, count > position ? position : count);
                break;
            case DIGITIZATION_STATUS:
                view = LayoutInflater.from(container.getContext()).inflate(R.layout.home_digitization_status, container, false);
                initDigitizationStatusViews(view);
                pager.addView(view, count > position ? position : count);
                break;
        }

        return view;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.home_view_revised_order_btn:
                break;
            case R.id.home_view_order_btn:
                break;
        }
    }


    private void initDigitizationStatusViews(View view) {

        RobotoTextView productReady1 = (RobotoTextView) view.findViewById(R.id.home_digitization_status_product1_tv);
        RobotoTextView productReady2 = (RobotoTextView) view.findViewById(R.id.home_digitization_status_product2_tv);
        RobotoTextView moreCount = (RobotoTextView) view.findViewById(R.id.home_digitization_status_product_count_tv);
        CircularProgressBarWithText productImage = (CircularProgressBarWithText) view.findViewById(R.id.home_digitization_status_product_iv);
    }

    private void initOrderReadyViews(View view) {

        RobotoTextView productReady1 = (RobotoTextView) view.findViewById(R.id.home_order_ready_product1_tv);
        RobotoTextView productReady2 = (RobotoTextView) view.findViewById(R.id.home_order_ready_product2_tv);
        RobotoTextView moreCount = (RobotoTextView) view.findViewById(R.id.home_order_ready_more_count_tv);
        NetworkImageView productImage = (NetworkImageView) view.findViewById(R.id.home_order_ready_iv);
        Button viewOrderBtn = (Button) view.findViewById(R.id.home_view_order_btn);

        viewOrderBtn.setOnClickListener(this);
        productImage.setImageUrl("http://im.rediff.com/money/2010/mar/08product2.jpg",
                VolleySingleton.getInstance(productImage.getContext()).getImageLoader());
    }

    private void initBackInStockViews(View view) {

        RobotoTextView productActualAmount = (RobotoTextView) view.findViewById(R.id.home_back_in_stock_actual_amt_tv);
        RobotoTextView productAmount = (RobotoTextView) view.findViewById(R.id.home_back_in_stock_price_tv);
        RobotoTextView productName = (RobotoTextView) view.findViewById(R.id.home_back_in_stock_product_name_tv);
        NetworkImageView productImage = (NetworkImageView) view.findViewById(R.id.home_back_in_stock_iv);

        productImage.setImageUrl("http://im.rediff.com/money/2010/mar/08product2.jpg",
                VolleySingleton.getInstance(productImage.getContext()).getImageLoader());
        productActualAmount.setText(Utils.addRupeeSymbol(productActualAmount.getContext(), "", "300"));
        productActualAmount.setPaintFlags(productActualAmount.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        productAmount.setText(Utils.addRupeeSymbol(productAmount.getContext(), "", "150"));
    }

    private void initReviseOrderViews(View view) {
        Button reviseOrderBtn = (Button) view.findViewById(R.id.home_view_revised_order_btn);
        reviseOrderBtn.setOnClickListener(this);
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
}
