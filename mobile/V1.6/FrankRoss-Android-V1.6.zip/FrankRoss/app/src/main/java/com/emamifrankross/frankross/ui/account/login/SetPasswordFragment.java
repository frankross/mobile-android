/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.account.login;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.NetworkUtils;
import com.emamifrankross.frankross.utils.PreferenceUtils;

/**
 * Created by gauthami on 2/7/15.
 */

/**
 * This class represents the UI for password creation for the particular verified user
 */
public class SetPasswordFragment extends ApiRequestBaseFragment implements View.OnClickListener, IToolbar {

    public static final String PHONE_NUMBER_KEY = "phoneNumber";
    public static final String OTP_KEY = "otp";
    private static final String IS_ALREADY_PLACED = "isAlreadyPlacedOrder";

    private EditText mRegistrationUserPassword;
    private CheckBox mRegistrationTermsAndConditions;
    private LinearLayout mRegistrationTermsAndConditionsLinLyt;
    private RobotoTextView mTitle;
    private RobotoTextView mShowPassword;
    private RobotoTextView mSubTitle;
    private RobotoTextView mClearBtn;

    private String mOtp;
    private String mPhoneNumber;
    private boolean mIsOrderPlaced = false;

    public static SetPasswordFragment create(boolean isPlaced, String phoneNumber, String otp) {
        SetPasswordFragment fragment = new SetPasswordFragment();

        Bundle bundle = new Bundle();
        bundle.putString(OTP_KEY, otp);
        bundle.putString(PHONE_NUMBER_KEY, phoneNumber);
        bundle.putBoolean(IS_ALREADY_PLACED, isPlaced);

        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            mOtp = bundle.getString(OTP_KEY);
            mPhoneNumber = bundle.getString(PHONE_NUMBER_KEY);
            mIsOrderPlaced = getArguments().getBoolean(IS_ALREADY_PLACED);
        }
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_complete_registration, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the views
     *
     * @param view the root view
     */
    private void initViews(View view) {
        Button registerBtn = (Button) view.findViewById(R.id.complete_registration_next_btn);
        mRegistrationUserPassword = (EditText) view.findViewById(R.id.complete_registration_user_password_et);
        mRegistrationTermsAndConditionsLinLyt = (LinearLayout) view.findViewById(R.id.complete_registration_terms_conditions_lin_lyt);
        mRegistrationTermsAndConditions = (CheckBox) view.findViewById(R.id.complete_registration_terms_conditions_checkbox_cb);
        mShowPassword = (RobotoTextView) view.findViewById(R.id.complete_registration_show_password_tv);
        mSubTitle = (RobotoTextView) view.findViewById(R.id.complete_registration_title_tv);
        mTitle = (RobotoTextView) view.findViewById(R.id.complete_registration_glad_to_have_tv);
        mClearBtn = (RobotoTextView) view.findViewById(R.id.complete_registration_clear_txt_btn);
        mRegistrationUserPassword.addTextChangedListener(mPasswordTextChangeListener);

        registerBtn.setOnClickListener(this);
        mShowPassword.setOnClickListener(this);
        mClearBtn.setOnClickListener(this);

        setVisibility();
    }

    /**
     * Text watcher for password that helps in setting the clear button and hide/show password button
     * visibility
     */
    private TextWatcher mPasswordTextChangeListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            setClearButtonVisibility(charSequence);
            mShowPassword.setVisibility((!TextUtils.isEmpty(charSequence.toString())) ? View.VISIBLE : View.GONE);
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    };

    /**
     * Method that sets the visibility of clear button associated with Password field
     *
     * @param charSequence determines the visibility state of clear button
     */
    private void setClearButtonVisibility(CharSequence charSequence) {
        mClearBtn.setVisibility((!TextUtils.isEmpty(charSequence) && charSequence.length() > 0) ? View.VISIBLE : View.INVISIBLE);
    }

    /**
     * Method that initializes the default text and visibility based on the flow
     */
    private void setVisibility() {
        mRegistrationTermsAndConditionsLinLyt.setVisibility(mIsOrderPlaced ? View.VISIBLE : View.GONE);
        mTitle.setVisibility(mIsOrderPlaced ? View.VISIBLE : View.INVISIBLE);
        mSubTitle.setText(mIsOrderPlaced ? getString(R.string.complete_registration_sub_title2) : getString(R.string.complete_registration_sub_title));
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.complete_registration_next_btn:
                if (validateSetPassword()) {
                    performSetPassword();
                }
                break;
            case R.id.complete_registration_show_password_tv:
                //hide/show password acts as a toggle button
                mRegistrationUserPassword.setInputType(mShowPassword.getText().toString().contains(getString(R.string.show_password)) ?
                        InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD : InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                mRegistrationUserPassword.setSelection(mRegistrationUserPassword.getText().length());
                mShowPassword.setText(mShowPassword.getText().toString().contains(getString(R.string.show_password)) ?
                        getString(R.string.hide_password) : getString(R.string.show_password));
                break;

            case R.id.complete_registration_clear_txt_btn:
                mRegistrationUserPassword.getText().clear();
                break;
        }
    }

    /**
     * Method requests for setting up a password;If success, log in the user to the app
     */
    private void performSetPassword() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performSetPasswordRequest(mRegistrationUserPassword.getText().toString(),
                mOtp, mPhoneNumber, new ApiRequestManager.ISetPasswordResultNotifier() {
                    @Override
                    public void onPasswordSet() {
                        performSignIn();
                    }
                }, this, this);
    }

    /**
     * Method requests for Log In;If success, notifies its parent for an action
     */
    private void performSignIn() {
        mApiRequestManager.performLoginRequest(mPhoneNumber, mRegistrationUserPassword.getText().toString(),
                new ApiRequestManager.ILoginResultNotifier() {
                    @Override
                    public void onLoginCompleted(String accessToken) {
                        mFragmentInteractionListener.hideBlockingProgressBar();

                        PreferenceUtils.saveStringIntoSharedPreference(getActivity().getApplicationContext(),
                                PreferenceUtils.PREFERENCE_KEY_ACCESS_TOKEN, accessToken);

                        getActivity().setResult(Activity.RESULT_OK);
                        getActivity().finish();
                    }
                }, this, this);
    }

    /**
     * @return If false,displays the input or network error dialog with appropriate message;else true.
     */
    private boolean validateSetPassword() {
        boolean isValid = false;

        if (getUserPassword().length() < 6) {
            showAlert(getString(R.string.password_must_have_minimum_6_character));
        } else if (!NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
            showAlert(getString(R.string.please_check_your_network_connection));
        } else if (mIsOrderPlaced && !mRegistrationTermsAndConditions.isChecked()) {
            showAlert(getString(R.string.please_agree_to_terms_and_conditions));
        } else {
            isValid = true;
        }

        return isValid;
    }

    /**
     * @return returns user password if not empty or null,else returns empty string
     */
    private String getUserPassword() {
        String userPassword = mRegistrationUserPassword.getText().toString();
        if (TextUtils.isEmpty(userPassword)) return "";
        return userPassword;
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return "";
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

}
