/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.aloglia.datamodel;

import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 27/7/15.
 */
public class AlgoliaProductInfo {

    @SerializedName("mrp")
    private double mrpPrice = 0.0d;

    @SerializedName("sales_price_f")
    private double salesPrice = 0.0d;

    @SerializedName("promotional_price_f")
    private double promotionalPrice = 0.0d;

    @SerializedName("discount_percent_f")
    private float discountPercent = 0.0f;

    @SerializedName("active")
    private boolean isActive = false;

    @SerializedName("available")
    private boolean isAvailable = false;

    @SerializedName("inventory_label")
    private String inventoryLabel = "";

    @SerializedName("max_orderable_quantity")
    private int maxOrderSize = 0;

    @SerializedName("cash_back")
    private boolean isCashBack = false;

    @SerializedName("cash_back_desc")
    private String cashBackMessage = "";

    public AlgoliaProductInfo() {
    }

    public double getMrpPrice() {
        return mrpPrice;
    }

    public double getSalesPrice() {
        return salesPrice;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setIsActive(boolean isActive) {
        this.isActive = isActive;
    }

    public double getPromotionalPrice() {
        return promotionalPrice;
    }

    public float getDiscountPercent() {
        return discountPercent;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public String getInventoryLabel() {
        return inventoryLabel;
    }

    public int getMaxOrderSize() {
        return maxOrderSize;
    }

    public boolean isCashBack() {
        return isCashBack;
    }

    public void setCashBack(boolean cashBack) {
        isCashBack = cashBack;
    }

    public String getCashBackMessage() {
        return cashBackMessage;
    }

    public void setCashBackMessage(String cashBackMessage) {
        this.cashBackMessage = cashBackMessage;
    }
}
