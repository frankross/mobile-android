/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;

/**
 * Created by gowtham on 18/8/15.
 */

/**
 * Common Product data item
 */
public class ProductDataModel implements BaseRecyclerAdapter.IViewType {

    public String productName = "";
    public String productBrandOrManufacturerName = "";
    public String productImageUrl = "";
    public String productIconImageUrl = "";
    public String innerPackagingQty = "";
    public String outerPackagingQty = "";
    public String unitOfSale = "";
    public String cashBackMessage = "";

    public int maxOrderQuantity = 0;
    public int totalProducts = 0;

    public double productSellingPrice = 0.0d;
    public double productActualPrice = 0.0d;

    public long productId;
    public float productDiscountPercent = 0.0f;

    public boolean isPharma = false;
    public boolean isAddToCartVisible = false;
    public boolean isAvailable = false;
    public boolean isCashBack = false;

    @Override
    public int getViewType() {
        return ViewTypes.CommonViewType.PRODUCT_ITEM;
    }
}
