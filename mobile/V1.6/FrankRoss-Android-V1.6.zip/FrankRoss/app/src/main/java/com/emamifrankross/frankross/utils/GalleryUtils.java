/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.utils;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.IOException;

/**
 * Created by gowtham on 6/7/15.
 */
public class GalleryUtils {

    private static final String[] ACCEPTABLE_IMAGE_TYPES = new String[]{"image/jpeg", "image/png", "image/gif"};

    private static final String WHERE_CLAUSE = "(" + MediaStore.Images.Media.MIME_TYPE + " in (?, ?, ?))";

    private static final String WHERE_CLAUSE_WITH_BUCKET_ID = WHERE_CLAUSE + " AND " + MediaStore.Images.Media.BUCKET_ID + " = ?";

    public static void addPhotoToGallery(Context context, String photoPath) {
        Intent mediaScanIntent = new Intent("android.intent.action.MEDIA_SCANNER_SCAN_FILE");
        File f = new File(photoPath);
        Uri contentUri = Uri.fromFile(f);
        mediaScanIntent.setData(contentUri);
        context.sendBroadcast(mediaScanIntent);
    }

    public static GalleryPhotoInfo getGalleryPhotoInfo(ContentResolver cr, Uri imgUri) {
        GalleryPhotoInfo photoInfo = null;
        if (imgUri != null) {
            photoInfo = new GalleryPhotoInfo();
            // For getting images from gallery.
            String[] filePathColumn = {MediaStore.Images.Media.DATA, MediaStore.Images.ImageColumns.ORIENTATION};
            try {
                Cursor cursor = cr.query(imgUri, filePathColumn, null, null, null);
                if (cursor != null) {
                    cursor.moveToFirst();
                    int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                    photoInfo.photoPath = cursor.getString(columnIndex);

                    columnIndex = cursor.getColumnIndex(filePathColumn[1]);
                    photoInfo.rotationDegree = cursor.getInt(columnIndex);

                    cursor.close();
                }
            } catch (CursorIndexOutOfBoundsException cursorIndexOutOfBoundException) {

            }
        }

        return photoInfo;
    }

    public static String whereClause(String bucketId) {
        return bucketId == null ? WHERE_CLAUSE : WHERE_CLAUSE_WITH_BUCKET_ID;
    }

    public static String[] whereClauseArgs(String bucketId) {
        // TODO: Since mBucketId won't change, we should keep the array.
        if (bucketId != null) {
            int count = ACCEPTABLE_IMAGE_TYPES.length;
            String[] result = new String[count + 1];
            System.arraycopy(ACCEPTABLE_IMAGE_TYPES, 0, result, 0, count);
            result[count] = bucketId;
            return result;
        }
        return ACCEPTABLE_IMAGE_TYPES;
    }

    public static boolean hasStorage() {
        return hasStorage(true);
    }

    public static boolean hasStorage(boolean requireWriteAccess) {
        String state = Environment.getExternalStorageState();

        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return !requireWriteAccess || checkFsWritable();
        } else if (!requireWriteAccess && Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            return true;
        }
        return false;
    }

    private static boolean checkFsWritable() {
        // Create a temporary file to see whether a volume is really
        // writeable.
        // It's important not to put it in the root directory which may have
        // a
        // limit on the number of files.
        String directoryName = Environment.getExternalStorageDirectory().toString() + "/DCIM";
        File directory = new File(directoryName);
        if (!directory.isDirectory()) {
            if (!directory.mkdirs()) {
                return false;
            }
        }
        File f = new File(directoryName, ".probe");
        try {
            // Remove stale file if any
            if (f.exists()) {
                f.delete();
            }
            if (!f.createNewFile()) {
                return false;
            }
            f.delete();
            return true;
        } catch (IOException ex) {
            return false;
        }
    }

    private static Cursor query(ContentResolver resolver, Uri uri, String[] projection, String selection,
                                String[] selectionArgs, String sortOrder) {
        try {
            if (resolver == null) {
                return null;
            }
            return resolver.query(uri, projection, selection, selectionArgs, sortOrder);
        } catch (UnsupportedOperationException ex) {
            return null;
        }

    }

    public static boolean isMediaScannerScanning(ContentResolver cr) {
        boolean result = false;
        Cursor cursor = query(cr, MediaStore.getMediaScannerUri(),
                new String[]{MediaStore.MEDIA_SCANNER_VOLUME}, null, null, null);
        if (cursor != null) {
            if (cursor.getCount() == 1) {
                cursor.moveToFirst();
                result = "external".equals(cursor.getString(0));
            }
            cursor.close();
        }

        return result;
    }
}
