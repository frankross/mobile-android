/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;

import java.util.List;

/**
 * Created by gauthami on 31/8/15.
 */
public class ApiOrderCancellationReason {

    public static class Response {

        private List<String> cancellationReasons;

        private List<BaseRecyclerAdapter.IViewType> uiDataList;

        public List<String> getCancellationReasons() {
            return cancellationReasons;
        }

        public void setCancellationReasons(List<String> cancellationReasons) {
            this.cancellationReasons = cancellationReasons;
        }

        public void setUiDataList(List<BaseRecyclerAdapter.IViewType> uiDataList) {
            this.uiDataList = uiDataList;
        }

        public List<BaseRecyclerAdapter.IViewType> getUiDataList() {
            return uiDataList;
        }
    }
}
