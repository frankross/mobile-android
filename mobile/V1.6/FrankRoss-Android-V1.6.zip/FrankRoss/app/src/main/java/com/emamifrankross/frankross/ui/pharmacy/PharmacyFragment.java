/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.pharmacy;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.PharmacyRecyclerAdapter;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.prescription.prescriptionmedicines.PrescriptionMedicineActivity;
import com.emamifrankross.frankross.ui.search.SearchActivity;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by gauthami on 1/7/15.
 */

/**
 * This class represents the UI for Category listing screen
 */
public class PharmacyFragment extends ApiRequestBaseFragment implements IToolbar,
        BaseRecyclerAdapter.RecyclerItemClickListener {

    private static final int REQUEST_CODE_CART = 2222;
    private static final int PRESCRIPTION_MEDICINES_CATEGORY_ID = 810;

    private List<BaseRecyclerAdapter.IViewType> mPharmacyScreenData = new ArrayList<>();
    private PharmacyRecyclerAdapter mPharmacyRecyclerAdapter;

    public static PharmacyFragment create() {
        return new PharmacyFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_categories, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initHomeRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);
        getCategoriesData();
    }

    /**
     * Method to request for categories
     */
    public void getCategoriesData() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetCategoriesRequest(new ApiRequestManager.IGetCategoriesResultNotifier() {

            @Override
            public void onCategoriesFetched(List<BaseRecyclerAdapter.IViewType> categoriesList) {
                mPharmacyScreenData.clear();
                mPharmacyScreenData.addAll(categoriesList);
                mPharmacyRecyclerAdapter.notifyDataSetChanged();
                mFragmentInteractionListener.hideBlockingProgressBar();
            }

        }, this, this);
    }

    private void initHomeRecyclerView(View view) {
        RecyclerView pharmacyRecyclerView = (RecyclerView) view.findViewById(R.id.home_container);
        pharmacyRecyclerView.setHasFixedSize(false);
        pharmacyRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mPharmacyRecyclerAdapter = new PharmacyRecyclerAdapter(mPharmacyScreenData);
        mPharmacyRecyclerAdapter.setRecyclerItemClickListener(this);
        pharmacyRecyclerView.setAdapter(mPharmacyRecyclerAdapter);

        final SwipeRefreshLayout swipeRefreshLayout = (SwipeRefreshLayout) view.findViewById(R.id.swipe_refresh_layout);
        swipeRefreshLayout.setEnabled(true);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getCategoriesData();
                swipeRefreshLayout.setRefreshing(false);
            }
        });

        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.CATEGORIES_SCREEN_VISIT_EVENT);
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {
            case ViewTypes.PharmacyViewTypes.PHARMACY_LIST:
                handlePharmacyListItemClick((PharmacyRecyclerAdapter.PharmacyListItem) object);
                break;
        }
    }

    private void handlePrescriptionMedicineClick() {
        startActivityForResult(PrescriptionMedicineActivity.getActivityIntent(getActivity().getApplicationContext(),
                PrescriptionMedicineActivity.PRESCRIPTION_MEDICINE_FRAGMENT_ID), REQUEST_CODE_CART);
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    private void handlePharmacyListItemClick(PharmacyRecyclerAdapter.PharmacyListItem categoryItem) {
        Map<String, String> categoriesClickData = Utils.categoriesClickDataForAnalytics(categoryItem.mCategory.getName(),
                FrankRossEvents.PHARMACY_CATEGORY_NAME);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PHARMACY_CATEGORIES, categoriesClickData);

        if (categoryItem.mCategory.getName().equals(getString(R.string.shop_by_category_prescription_medicine_category_name))
                || categoryItem.mCategory.getId() == PRESCRIPTION_MEDICINES_CATEGORY_ID) {
            handlePrescriptionMedicineClick();
        } else {
            startActivity(PharmacyActivity.getActivityIntent(getActivity().getApplicationContext(),
                    PharmacyActivity.PHARMACY_SUB_CATEGORY_FRAGMENT_ID, categoryItem.mCategory, 0));
            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        //FrankRossAnalytics.getFrankRossTracker().logTimedEvent(FrankRossEvents.TIME_SPENT_CATEGORY_SCREEN_EVENT, null);

        mApiRequestManager.registerCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        //FrankRossAnalytics.getFrankRossTracker().endTimedEvent(FrankRossEvents.TIME_SPENT_CATEGORY_SCREEN_EVENT, null);
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());

        mApiRequestManager.unregisterCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.menu;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return null;
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_categories);
    }

    @Override
    public int getToolbarMenuId() {
        return R.menu.menu_pharmacy;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_search:
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_FROM_TOOLBAR_EVENT);
                        startActivity(SearchActivity.getActivityIntent(getActivity()));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;

                    case R.id.action_cart:
                        Map<String, String> cartClickData = Utils.cartToolbarClickDataForAnalytics(Constants.CATEGORIES_SCREEN_NAME,
                                FrankRossEvents.VIEW_CART_FROM_TOOLBAR_SCREEN_NAME);
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_CART_FROM_TOOLBAR_EVENT,
                                cartClickData);
                        startActivity(CartActivity.getActivityIntent(getActivity().getApplicationContext(),
                                CartActivity.CART_FRAGMENT_ID));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;
                }
                return false;
            }
        };
    }
}

