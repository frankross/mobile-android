/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.prescription.uploadprescription;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.common.AppRuntimePermissionsManager;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.CameraUtils;
import com.emamifrankross.frankross.utils.GalleryPhotoInfo;
import com.emamifrankross.frankross.utils.GalleryUtils;

/**
 * Created by gowtham on 6/7/15.
 */

/**
 * This class represents the UI for Upload prescription screen
 */
public class UploadPrescriptionFragment extends BaseFragment implements IToolbar, View.OnClickListener {
    public static final String TAG = UploadPrescriptionFragment.class.getSimpleName();

    private static final int REQUEST_CODE_TAKE_PHOTO_FROM_CAMERA = 111;
    private static final int REQUEST_CODE_PICK_PHOTO_FROM_GALLERY = 112;

    private static final String CHECKOUT_UPLOAD_PRESCRIPTION = "isCartUploadPrescription";
    private static final String UPLOAD_PRESCRIPTION_ID = "uploadPrescriptionId";
    private static final String IS_FROM_CART = "isFromCart";

    private Uri mPhotoImageUri;
    private GalleryPhotoInfo mGalleryPhotoInfo;

    private long mPrescriptionId = -1;
    private boolean mIsCheckOut = false;
    private boolean mIsFromCart = false;

    public static UploadPrescriptionFragment create(long prescriptionId, boolean isCheckOut, boolean isFromCart) {
        UploadPrescriptionFragment uploadPrescriptionFragment = new UploadPrescriptionFragment();

        Bundle bundle = new Bundle();
        bundle.putLong(UPLOAD_PRESCRIPTION_ID, prescriptionId);
        bundle.putBoolean(CHECKOUT_UPLOAD_PRESCRIPTION, isCheckOut);
        bundle.putBoolean(IS_FROM_CART, isFromCart);

        uploadPrescriptionFragment.setArguments(bundle);
        return uploadPrescriptionFragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();

        if (bundle != null && bundle.containsKey(UPLOAD_PRESCRIPTION_ID)) {

            mPrescriptionId = bundle.getLong(UPLOAD_PRESCRIPTION_ID);
            mIsCheckOut = bundle.getBoolean(CHECKOUT_UPLOAD_PRESCRIPTION);
            mIsFromCart = bundle.getBoolean(IS_FROM_CART);
        }
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.UPLOAD_PRESCRIPTION_SCREEN_VISIT_EVENT);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_upload_prescription, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    private void initViews(View view) {
        Button clickPhotoButton = (Button) view.findViewById(R.id.upload_prescription_camera_btn);
        Button galleryButton = (Button) view.findViewById(R.id.upload_prescription_gallery_btn);

        RobotoTextView uploadPrescriptionTitle = (RobotoTextView) view.findViewById(R.id.upload_prescription_title_tv);
        RobotoTextView uploadPrescriptionInstruction1 = (RobotoTextView) view.findViewById(R.id.upload_prescription_instruction1_tv);
        RobotoTextView uploadPrescriptionInstruction2 = (RobotoTextView) view.findViewById(R.id.upload_prescription_instruction2_tv);
        RobotoTextView uploadPrescriptionInstruction3 = (RobotoTextView) view.findViewById(R.id.upload_prescription_instruction3_tv);
        RobotoTextView uploadPrescriptionInstruction4 = (RobotoTextView) view.findViewById(R.id.upload_prescription_instruction4_tv);
        RobotoTextView uploadPrescriptionInstruction5 = (RobotoTextView) view.findViewById(R.id.upload_prescription_instruction5_tv);

        if (mIsCheckOut) {
            uploadPrescriptionTitle.setText(getString(R.string.checkout_upload_prescription_title));
            uploadPrescriptionInstruction1.setText(getString(R.string.checkout_upload_prescription_intstruction_text1));
            uploadPrescriptionInstruction2.setText(getString(R.string.checkout_upload_prescription_instruction_text2));
            uploadPrescriptionInstruction3.setText(getString(R.string.checkout_upload_prescription_instruction_text3));
            uploadPrescriptionInstruction4.setText(getString(R.string.checkout_upload_prescription_instruction_text4));
            uploadPrescriptionInstruction5.setText(getString(R.string.checkout_upload_prescription_instruction_text5));

        } else {
            uploadPrescriptionTitle.setText(getString(R.string.upload_prescription_title_text));
            uploadPrescriptionInstruction1.setText(getString(R.string.upload_prescription_intstruction_text1));
            uploadPrescriptionInstruction2.setText(getString(R.string.upload_prescription_instruction_text2));
            uploadPrescriptionInstruction3.setText(getString(R.string.upload_prescription_instruction_text3));
            uploadPrescriptionInstruction4.setText(getString(R.string.upload_prescription_instruction_text4));
            uploadPrescriptionInstruction5.setText(getString(R.string.upload_prescription_instruction_text5));
        }

        clickPhotoButton.setOnClickListener(this);
        galleryButton.setOnClickListener(this);
    }

    @Override
    public void onResume() {
        super.onResume();

        if (mGalleryPhotoInfo != null) {
            mFragmentInteractionListener.loadFragment(getId(),
                    PrescriptionSubmitFragment.create(mGalleryPhotoInfo.photoPath, mGalleryPhotoInfo.rotationDegree,
                            mPrescriptionId, mIsCheckOut, mIsFromCart),
                    PrescriptionSubmitFragment.TAG, 0, 0, FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);

            mGalleryPhotoInfo = null;
        }
    }

    private void launchCamera() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                AppRuntimePermissionsManager.checkPermissionForCamera(getActivity())) {
            try {
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.CLICK_A_PHOTO_EVENT);
                try {
                    Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                    mPhotoImageUri = CameraUtils.getCameraImageFileUri();
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, mPhotoImageUri);
                    startActivityForResult(intent, REQUEST_CODE_TAKE_PHOTO_FROM_CAMERA);
                } catch (ActivityNotFoundException activityNotFoundException) {

                }
            } catch (SecurityException securityException) {

            }
        } else {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                    AppRuntimePermissionsManager.REQUEST_CODE_CAMERA_PERMISSIONS);
        }
    }

    private void launchGallery() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                AppRuntimePermissionsManager.checkPermissionForExternalStorage(getActivity())) {
            try {
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ADD_FROM_GALLERY_EVENT);
                try {
                    Intent intent = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(intent, REQUEST_CODE_PICK_PHOTO_FROM_GALLERY);
                } catch (ActivityNotFoundException activityNotFoundException) {

                }
            } catch (SecurityException securityException) {

            }
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                    AppRuntimePermissionsManager.REQUEST_CODE_GALLERY_PERMISSIONS);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK) {
            switch (requestCode) {
                case REQUEST_CODE_TAKE_PHOTO_FROM_CAMERA:
                    if (mPhotoImageUri != null) {
                        mGalleryPhotoInfo = new GalleryPhotoInfo();
                        mGalleryPhotoInfo.photoPath = mPhotoImageUri.getPath();
                        mGalleryPhotoInfo.rotationDegree = CameraUtils.getCameraImageRotation(mPhotoImageUri);
                        GalleryUtils.addPhotoToGallery(getActivity(), mGalleryPhotoInfo.photoPath);
                    }
                    break;

                case REQUEST_CODE_PICK_PHOTO_FROM_GALLERY:
                    mGalleryPhotoInfo = GalleryUtils.getGalleryPhotoInfo(getActivity().getContentResolver(), data.getData());
                    break;

                default:
                    break;
            }
        }
    }

    public void setPrescriptionId(long prescriptionId) {
        mPrescriptionId = prescriptionId;
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_upload_prescription);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.upload_prescription_camera_btn:
                launchCamera();
                break;

            case R.id.upload_prescription_gallery_btn:
                launchGallery();
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case AppRuntimePermissionsManager.REQUEST_CODE_CAMERA_PERMISSIONS:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    launchCamera();
                }
                break;
            case AppRuntimePermissionsManager.REQUEST_CODE_GALLERY_PERMISSIONS:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    launchGallery();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
