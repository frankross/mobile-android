/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.products.sort;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.ProductSortAdapter;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.SortType;
import com.emamifrankross.frankross.ui.common.ViewTypes;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 13/7/15.
 */

/**
 * This class represents the UI for Products sort screen
 */
public class ProductSortFragment extends BaseFragment implements IToolbar,
        BaseRecyclerAdapter.RecyclerItemClickListener {

    private List<BaseRecyclerAdapter.IViewType> mSortData = new ArrayList<>();
    private ProductSortAdapter mSortAdapter;
    private ISortClickListener mSortClickListener;

    public static ProductSortFragment create(List<BaseRecyclerAdapter.IViewType> sortDataItems) {
        ProductSortFragment fragment = new ProductSortFragment();
        fragment.setSortByListener(sortDataItems);
        return fragment;
    }

    private void setSortByListener(List<BaseRecyclerAdapter.IViewType> sortDataItems) {
        mSortData = sortDataItems;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setProductSortByData();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            mSortClickListener = (ISortClickListener) context;
        } catch (ClassCastException e) {
            throw new ClassCastException(context.toString()
                    + " must implement ISortClickListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_product_sort, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    private void setProductSortByData() {
        mSortAdapter = new ProductSortAdapter(mSortData);
        mSortAdapter.notifyDataSetChanged();
    }

    private void initViews(View view) {
        RecyclerView productSortRecyclerView = (RecyclerView) view.findViewById(R.id.products_sort_recycler_view);
        productSortRecyclerView.setHasFixedSize(false);
        productSortRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mSortAdapter.setRecyclerItemClickListener(this);
        productSortRecyclerView.setAdapter(mSortAdapter);
        Button doneBtn = (Button) view.findViewById(R.id.bottom_bar_done_btn);
        doneBtn.setVisibility(View.GONE);
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        switch (((ProductSortAdapter.IViewType) object).getViewType()) {
            case ViewTypes.SortViewType.SORT_LIST_ITEM:
                handleSortListClick((ProductSortAdapter.SortDataItem) object, position);
                break;
        }
    }

    /**
     * Method defines the action to be performed when sort is applied
     */
    private void handleSortListClick(ProductSortAdapter.SortDataItem object, int position) {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SORT_APPLY_EVENT);

        if (mSortData != null && mSortData.size() > 0) {
            switch (position) {
                case 0:
                    if (mSortData.get(1) instanceof ProductSortAdapter.SortDataItem) {
                        ((ProductSortAdapter.SortDataItem) mSortData.get(1)).isChecked = false;
                    }
                    closeFragment();
                    mSortClickListener.onSortClick(SortType.LOW_TO_HIGH, object.sortHeader);
                    break;

                case 1:
                    if (mSortData.get(0) instanceof ProductSortAdapter.SortDataItem) {
                        ((ProductSortAdapter.SortDataItem) mSortData.get(0)).isChecked = false;
                    }
                    closeFragment();
                    mSortClickListener.onSortClick(SortType.HIGH_TO_LOW, object.sortHeader);
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_sort);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    /**
     * Interface defined to notify the sort apply
     */
    public interface ISortClickListener {
        /**
         * Callback that receives the control on clicking apply sort
         *
         * @param sortType the sort type
         * @param header   the sort header text
         */
        void onSortClick(SortType sortType, String header);
    }
}
