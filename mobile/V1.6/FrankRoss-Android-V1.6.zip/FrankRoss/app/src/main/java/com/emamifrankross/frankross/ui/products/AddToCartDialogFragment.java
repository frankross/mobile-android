/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.products;

import android.app.Activity;
import android.app.Dialog;
import android.text.TextUtils;
import android.view.View;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.common.BaseDialogFragment;
import com.emamifrankross.frankross.ui.common.ICartQuantityNotifier;
import com.emamifrankross.frankross.ui.customviews.NumberPickerWidget;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

/**
 * Created by gauthami on 10/7/15.
 */

/**
 * This class represents the UI for Add to cart dialog
 */
public class AddToCartDialogFragment extends BaseDialogFragment implements View.OnClickListener,
        NumberPickerWidget.OnNumberChangedListener {

    public static final String TAG = AddToCartDialogFragment.class.getSimpleName();

    private RobotoTextView mCartMaxQuantityReached;
    private NumberPickerWidget mNumberPickerWidget;
    private ICartQuantityNotifier mCartQuantityNotifier;

    private String mStripInfo;
    private int mMaxOrderableQty = 0;
    private int mCurrentQty = 0;

    public void create(String stripInfo, int maxOrderQuantity, int currentQuantity) {
        mStripInfo = stripInfo;
        mMaxOrderableQty = maxOrderQuantity;
        mCurrentQty = currentQuantity;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mCartQuantityNotifier = (ICartQuantityNotifier) activity;
        } catch (ClassCastException exception) {
            throw new ClassCastException(activity.toString()
                    + " must implement ICartQuantityNotifier");
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_add_to_cart_dialog;
    }

    @Override
    public void initViews(Dialog view) {
        RobotoTextView addToCartDoneButton = (RobotoTextView) view.findViewById(R.id.add_to_cart_dialog_done_btn);
        RobotoTextView productStripInfo = (RobotoTextView) view.findViewById(R.id.add_to_cart_dialog_description_tv);
        mNumberPickerWidget = (NumberPickerWidget) view.findViewById(R.id.add_to_cart_dialog_number_picker);
        mCartMaxQuantityReached = (RobotoTextView) view.findViewById(R.id.max_quantity_txt_tv);

        mNumberPickerWidget.setOnNumberChangedListener(this);
        mNumberPickerWidget.setMaxValue(mMaxOrderableQty);
        productStripInfo.setVisibility(TextUtils.isEmpty(mStripInfo) ? View.GONE : View.VISIBLE);
        productStripInfo.setText(mStripInfo);
        addToCartDoneButton.setOnClickListener(this);
        mNumberPickerWidget.setValue(mCurrentQty > mMaxOrderableQty ? mMaxOrderableQty : mCurrentQty);
        mCartMaxQuantityReached.setVisibility((mNumberPickerWidget.getValue() >= mMaxOrderableQty) ? View.VISIBLE : View.GONE);

        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.QUANTITY_SELECTION_SCREEN_VISIT_EVENT);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.add_to_cart_dialog_done_btn:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.QUANTITY_SELECTION_DONE_TAP_EVENT);
                mCartQuantityNotifier.onAddToCartClick((int) mNumberPickerWidget.getValue());
                getDialog().dismiss();
                break;
        }
    }

    @Override
    public void onNumberIncremented(int number) {
        mCartMaxQuantityReached.setVisibility(number == mMaxOrderableQty ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onNumberDecremented(int number) {
        mCartMaxQuantityReached.setVisibility(number == mMaxOrderableQty ? View.VISIBLE : View.GONE);
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }
}
