/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

import android.graphics.Paint;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.style.TypefaceSpan;

public class RupeeTypefaceSpan extends TypefaceSpan {
    private final Typeface mRupeeType;
    private final Integer mColor;

    public RupeeTypefaceSpan(String family, Typeface type, Integer color) {
        super(family);
        mRupeeType = type;
        mColor = color;
    }

    @Override
    public void updateDrawState(TextPaint ds) {
        applyCustomTypeFace(ds, mRupeeType, mColor);
    }

    @Override
    public void updateMeasureState(TextPaint paint) {
        applyCustomTypeFace(paint, mRupeeType, mColor);
    }

    private static void applyCustomTypeFace(Paint paint, Typeface tf, Integer color) {
        int oldStyle;
        Typeface old = paint.getTypeface();
        if (old == null) {
            oldStyle = 0;
        } else {
            oldStyle = old.getStyle();
        }

        int fake = oldStyle & ~tf.getStyle();
        if ((fake & Typeface.BOLD) != 0) {
            paint.setFakeBoldText(true);
        }

        if ((fake & Typeface.ITALIC) != 0) {
            paint.setTextSkewX(-0.25f);
        }
        if (color != null) {
            paint.setColor(color);
        }
        paint.setTypeface(tf);
    }
}