/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 16/7/15.
 */
public class ApiUpdateUserPassword {

    public static class Request {
        public String toJsonString() {
            return new Gson().toJson(this);
        }

        public Request(String oldPassword, String newPassword) {
            setUser(new User());
            getUser().setOldPassword(oldPassword);
            getUser().setNewPassword(newPassword);
        }

        @SerializedName("user")
        private User user;

        public User getUser() {
            return user;
        }

        public void setUser(User user) {
            this.user = user;
        }

        public static class User {

            @SerializedName("old_password")
            private String oldPassword;

            @SerializedName("new_password")
            private String newPassword;

            public void setOldPassword(String oldPassword) {
                this.oldPassword = oldPassword;
            }

            public void setNewPassword(String newPassword) {
                this.newPassword = newPassword;
            }
        }
    }

    public static class Response {

    }
}
