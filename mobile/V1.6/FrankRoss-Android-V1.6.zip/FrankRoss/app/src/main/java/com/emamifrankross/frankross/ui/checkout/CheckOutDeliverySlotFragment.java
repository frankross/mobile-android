/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.checkout;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.CheckOutDeliverySlotAdapter;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 23/7/15.
 */

/**
 * This class represents the UI for selected Checkout delivery slot listing
 */
public class CheckOutDeliverySlotFragment extends ApiRequestBaseFragment implements IToolbar,
        BaseRecyclerAdapter.RecyclerItemClickListener {

    private CheckOutDeliverySlotAdapter mDeliverySlotAdapter;
    private List<BaseRecyclerAdapter.IViewType> mDeliverySlotInfoList = new ArrayList<>();
    private ICheckoutDeliverySlotNotifier mSelectAddressNotifier;

    private RobotoTextView mNoSlotsFound;

    /**
     * Interface definition for a callback to be invoked when a delivery slot is selected
     */
    public interface ICheckoutDeliverySlotNotifier {
        /**
         * Called when Change number view is clicked.
         *
         * @param deliverySlot the delivery slot that was selected
         */
        void onDeliverySlotSelect(CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem deliverySlot);
    }

    public static CheckOutDeliverySlotFragment create(List<BaseRecyclerAdapter.IViewType> deliverySlots) {
        CheckOutDeliverySlotFragment fragment = new CheckOutDeliverySlotFragment();
        fragment.setDeliverySlots(deliverySlots);
        return fragment;
    }

    private void setDeliverySlots(List<BaseRecyclerAdapter.IViewType> deliverySlots) {
        mDeliverySlotInfoList.addAll(deliverySlots);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mDeliverySlotAdapter = new CheckOutDeliverySlotAdapter(mDeliverySlotInfoList);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.DELIVERY_SLOT_SCREEN_VISIT_EVENT);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            mSelectAddressNotifier = (ICheckoutDeliverySlotNotifier) getActivity();
        } catch (ClassCastException exception) {
            throw new ClassCastException(context.toString()
                    + " must implement ICheckOutAddressNotifier");
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_checkout_delivery_slot, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initSelectAddressRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);

        if (mDeliverySlotInfoList.size() > 0) {
            mNoSlotsFound.setVisibility(View.GONE);
            mDeliverySlotAdapter.notifyDataSetChanged();
        } else {
            mNoSlotsFound.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Method that initializes the views
     *
     * @param view the root view
     */
    private void initSelectAddressRecyclerView(View view) {
        RecyclerView deliverySlotRecyclerView = (RecyclerView) view.findViewById(R.id.checkout_delivery_slot_container);
        deliverySlotRecyclerView.setHasFixedSize(false);
        deliverySlotRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mDeliverySlotAdapter.setRecyclerItemClickListener(this);
        deliverySlotRecyclerView.setAdapter(mDeliverySlotAdapter);
        mNoSlotsFound = (RobotoTextView) view.findViewById(R.id.checkout_delivery_slots_empty_view_tv);
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_delivery_slot);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;

        switch (((CheckOutDeliverySlotAdapter.IViewType) object).getViewType()) {

            case ViewTypes.CheckOutDeliverySlotViewType.CHECKOUT_DELIVERY_SLOT_TIME_TO_VIEW_TYPE:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.DELIVERY_SLOT_SELECT_EVENT);
                closeFragment();
                mSelectAddressNotifier.onDeliverySlotSelect((CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem) object);
                break;
            default:
                break;
        }
    }
}
