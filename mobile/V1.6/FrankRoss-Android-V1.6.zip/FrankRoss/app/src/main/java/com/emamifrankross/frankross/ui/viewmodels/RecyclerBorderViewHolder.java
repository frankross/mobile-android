/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.support.v7.widget.RecyclerView;
import android.view.View;

/**
 * Created by gowtham on 26/7/15.
 */

/**
 * COMMON RECYCLER BORDER ITEM VIEW HOLDER
 */
public class RecyclerBorderViewHolder extends RecyclerView.ViewHolder {
    public View mBorderView;

    public RecyclerBorderViewHolder(View itemView) {
        super(itemView);
        mBorderView = itemView;
    }
}
