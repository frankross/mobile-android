/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.account.login;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiSocialRegister;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;

/**
 * Created by gauthami on 30/5/16.
 */

/**
 * This class represents the UI for OTP verification & submission for logged-in user
 */
public class AccountOTPFragment extends EnterOTPFragment {

    public static AccountOTPFragment create(boolean isPlaced, boolean isNewUserRegistrationFlow, boolean isOldVerified,
                                            boolean isRegisterListener,
                                            String mailAddress, String phoneNumber,
                                            String newPhoneNumber,
                                            String userPassword,
                                            String userName,
                                            ApiSocialRegister.Request apiSocialRegisterRequest) {
        AccountOTPFragment fragment = new AccountOTPFragment();

        Bundle bundle = new Bundle();
        bundle.putString(MAIL_KEY, mailAddress);
        bundle.putString(MOBILE_KEY, phoneNumber);
        bundle.putString(NEW_MOBILE_KEY, newPhoneNumber);
        bundle.putString(PASSWORD_KEY, userPassword);
        bundle.putString(USER_NAME_KEY, userName);
        bundle.putBoolean(IS_ALREADY_PLACED, isPlaced);
        bundle.putBoolean(IS_REGISTER_LISTENER, isRegisterListener);
        bundle.putBoolean(IS_NEW_USER_REGISTRATION_FLOW, isNewUserRegistrationFlow);
        bundle.putBoolean(IS_OLD_NUMBER_VERIFIED, isOldVerified);

        fragment.setArguments(bundle);
        fragment.setRegisterRequestData(apiSocialRegisterRequest);
        return fragment;
    }

    @Override
    protected void performRegisterOrUnregisterToAutoReadOtp() {
        unregisterOtpAutoReadListener();
        if (!mIsUnRegisterListeners) {
            performReSendOTP(mIsOldNumberVerified ? mUserNewNumber : mOldPhoneNumber);
        }
    }

    @Override
    protected void performOtpVerified(String otp) {
        if (mIsUnRegisterListeners) {
            super.performOtpVerified(otp);
        } else {
            performUpdateUserInfoViaVerifyOTP();
        }
    }

    /**
     * Method requests for Updating user information;If success,
     * otherwise displays the success dialog
     */
    private void performUpdateUserInfoViaVerifyOTP() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performUpdateUserInfoRequest(mUserName, mOldPhoneNumber.equals(mUserNewNumber) ?
                        mOldPhoneNumber : mUserNewNumber,
                new ApiRequestManager.IUpdateUserInfoResultNotifier() {
                    @Override
                    public void onUserInfoUpdated() {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        if (!mOldPhoneNumber.equals(mUserNewNumber)) {
                            mFragmentInteractionListener.loadFragment(getId(), AccountOTPFragment.create(false, false, true, false, "",
                                    mUserNewNumber, mUserNewNumber, null, mUserName, null), null, R.anim.push_left_in, R.anim.fade_out,
                                    FragmentTransactionType.REPLACE);
                        } else {
                            mFragmentInteractionListener.hideBlockingProgressBar();
                            showUpdateProfileAlert();
                        }
                    }
                }, this, this);
    }

    /**
     * Method that pops out the Update profile success dialog also defines the positive action
     */
    private void showUpdateProfileAlert() {
        showAlert(getString(R.string.profile_updated_successfully), new AlertDialogFragment.AlertPositiveActionListener() {
            @Override
            public void onPositiveAction() {
                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
            }
        }, false);
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }
}
