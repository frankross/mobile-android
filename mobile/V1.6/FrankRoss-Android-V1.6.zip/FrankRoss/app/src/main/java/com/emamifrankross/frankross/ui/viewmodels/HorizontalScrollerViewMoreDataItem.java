package com.emamifrankross.frankross.ui.viewmodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;

/**
 * Created by gauthami on 30/12/15.
 */

/**
 * Horizontal scroll view more data item
 */
public class HorizontalScrollerViewMoreDataItem implements BaseRecyclerAdapter.IViewType {

    public int viewHeight = 138;
    public int viewWidth = 44;
    public boolean isCategory = false;

    @Override
    public int getViewType() {
        return ViewTypes.CommonViewType.HORIZONTAL_SCROLL_LIST_VIEW_MORE_ITEM_VIEW_TYPE;
    }
}
