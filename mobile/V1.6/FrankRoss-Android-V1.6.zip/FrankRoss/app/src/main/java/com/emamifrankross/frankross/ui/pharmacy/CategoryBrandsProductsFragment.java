/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.pharmacy;

import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.aloglia.AlgoliaManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.search.SearchActivity;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Utils;

import java.util.Map;

/**
 * Created by gauthami on 11/9/15.
 */

/**
 * This class represents the UI for products screen navigated from Home screen more tab
 */
public class CategoryBrandsProductsFragment extends ProductListingFragment {

    private long mCategoryId = 0;
    private String mBrandName = "";

    public static CategoryBrandsProductsFragment create(long categoryId, String brandName) {
        CategoryBrandsProductsFragment fragment = new CategoryBrandsProductsFragment();
        fragment.setCategoryBrandsData(categoryId, brandName);
        return fragment;
    }

    private void setCategoryBrandsData(long categoryId, String brandName) {
        mBrandName = brandName;
        mCategoryId = categoryId;
        mListingFlow = ListingFlow.CATEGORY_SHOP_BY_BRAND;
    }

    @Override
    public String getToolbarTitleId() {
        return Utils.getCapitalizedSentence(mBrandName);
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_search:
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_FROM_TOOLBAR_EVENT);
                        startActivity(SearchActivity.getActivityIntent(getActivity()));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;

                    case R.id.action_cart:
                        Map<String, String> cartClickData = Utils.cartToolbarClickDataForAnalytics(Constants.PRODUCT_LISTING_SCREEN_NAME,
                                FrankRossEvents.VIEW_CART_FROM_TOOLBAR_SCREEN_NAME);
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_CART_FROM_TOOLBAR_EVENT, cartClickData);
                        startActivity(CartActivity.getActivityIntent(getActivity().getApplicationContext(),
                                CartActivity.CART_FRAGMENT_ID));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;
                }
                return false;
            }
        };
    }

    @Override
    protected void getAlgoliaProductsWithAppliedFilterInfo(AlgoliaManager.IProductInfoResultNotifier productInfoResultNotifier) {
        AlgoliaManager.getInstance().performGetNonPharmaCategoryProductsWithBrandWithAppliedFilterAndSortInfo(
                getActivity().getApplicationContext(), mCurrentSortType, mAppliedFilterInfo
                , mBrandName, mCategoryId, ALGOLIA_PRODUCTS_COUNT, mCurrentPageNumber, productInfoResultNotifier);
    }

    @Override
    protected void getAlgoliaProductsWithFilterInfo(AlgoliaManager.IProductInfoWithFilterResultNotifier productInfoWithFilterResultNotifier) {
        AlgoliaManager.getInstance().performGetNonPharmaCategoryProductsWithBrand(getActivity(), mBrandName, mCategoryId,
                ALGOLIA_PRODUCTS_COUNT, mCurrentPageNumber, productInfoWithFilterResultNotifier);
    }
}
