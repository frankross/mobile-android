/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.home.HomeFragment;
import com.emamifrankross.frankross.ui.pharmacy.PharmaCategoryFragment;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Log;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gowtham on 17/12/15.
 */

/**
 * Common Horizontally scrollable recycler view data binder
 */
public class HorizontalRecyclerViewDataBinder implements BaseRecyclerAdapter.RecyclerViewDataBinder<HorizontalRecyclerViewHolder,
        HorizontalRecyclerViewItem>, BaseRecyclerAdapter.RecyclerItemClickListener {
    private BaseRecyclerAdapter.RecyclerItemClickListener mHorizontalRecyclerViewClickListener;
    private BaseRecyclerAdapter mHorizontalRecyclerViewAdapter;

    @Override
    public HorizontalRecyclerViewHolder getViewHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_horizontal_view, parent, false);

        return new HorizontalRecyclerViewHolder(view, view.getContext());
    }

    @Override
    public void bindDataToViewHolder(HorizontalRecyclerViewHolder viewHolder, HorizontalRecyclerViewItem data,
                                     int position, BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        params.height = Utils.getDisplayPixels(viewHolder.mHorizontalRecyclerView.getContext(), data.viewHeight);
        viewHolder.mHorizontalRecyclerView.setLayoutParams(params);

        if (data.mHorizontalRecyclerViewAdapter != null) {
            data.mHorizontalRecyclerViewAdapter.setRecyclerItemClickListener(this);
            viewHolder.mHorizontalRecyclerView.setAdapter(data.mHorizontalRecyclerViewAdapter);
            mHorizontalRecyclerViewClickListener = recyclerViewClickListener;
            mHorizontalRecyclerViewAdapter = data.mHorizontalRecyclerViewAdapter;
        } else {
            Log.e(Constants.LOG_TAG, "Recycler adapter instance cannot be null");
        }
    }

    @Override
    public int getViewType() {
        return ViewTypes.CommonViewType.VIEW_HORIZONTAL_RECYCLER_ITEM;
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (mHorizontalRecyclerViewClickListener instanceof HomeFragment) {
            mHorizontalRecyclerViewClickListener.onRecyclerItemClick(position, view, object);
        } else if (mHorizontalRecyclerViewClickListener instanceof PharmaCategoryFragment) {
             mHorizontalRecyclerViewClickListener.onRecyclerItemClick(position, view, object);
        }
    }
}
