/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.products.notify;

import android.app.Activity;
import android.app.Dialog;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.BaseDialogFragment;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gauthami on 8/8/16.
 */

/**
 * This class represents the UI for Notify me dialog
 */
public class NotifyMeDialogFragment extends BaseDialogFragment implements View.OnClickListener {

    public static final String TAG = NotifyMeDialogFragment.class.getSimpleName();

    private EditText mMobileNumber;
    private RobotoTextView mClearBtn;
    private INotifyMeToMobileNumberListener mNotifyMeListener;
    /**
     * Text watcher for entered mobile number that helps in setting the clear button visibility
     */
    private TextWatcher mMobileNumberTextChangeListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            setClearButtonVisibility(charSequence);
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    };

    @Override
    public int getLayoutId() {
        return R.layout.fragment_product_notify_me_here_dialog;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mNotifyMeListener = (INotifyMeToMobileNumberListener) activity;
        } catch (ClassCastException exception) {
            throw new ClassCastException(activity.toString()
                    + " must implement INotifyMeToMobileNumberListener");
        }
    }

    @Override
    public void initViews(Dialog view) {
        mMobileNumber = (EditText) view.findViewById(R.id.notify_me_here_mobile_num_et);
        Button doneBtn = (Button) view.findViewById(R.id.notify_me_here_done_btn);
        mClearBtn = (RobotoTextView) view.findViewById(R.id.notify_me_here_clear_txt_btn);

        mMobileNumber.addTextChangedListener(mMobileNumberTextChangeListener);
        doneBtn.setOnClickListener(this);
        mClearBtn.setOnClickListener(this);
    }

    /**
     * Method that sets the visibility of clear button associated with the Mobile number
     *
     * @param charSequence that determines visibility of clear button
     */
    private void setClearButtonVisibility(CharSequence charSequence) {
        mClearBtn.setVisibility((!TextUtils.isEmpty(charSequence) && charSequence.length() > 0) ? View.VISIBLE : View.INVISIBLE);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.notify_me_here_done_btn:
                if (validateMobileNumber()) {
                    mNotifyMeListener.onNotifyMeToMobileNumberSubmit(mMobileNumber.getText().toString());
                    getDialog().dismiss();
                }
                break;
            case R.id.notify_me_here_clear_txt_btn:
                mMobileNumber.getText().clear();
                break;
        }
    }

    /**
     * @return If false,displays the input error dialog with appropriate message;else true.
     */
    private boolean validateMobileNumber() {
        boolean isValid = true;

        if (!(Utils.isValidPhoneNumber(getUserMobileNumber()))) {
            mFragmentInteractionListener.showAlert(getString(R.string.error), getString(R.string.please_enter_a_valid_number),
                    getString(R.string.ok), null, null, null, false);
            isValid = false;
        }
        return isValid;
    }

    /**
     * @return returns user mobile number if not empty or null,else returns empty string
     */
    private String getUserMobileNumber() {
        String userMobileNumber = mMobileNumber.getText().toString();
        if (TextUtils.isEmpty(userMobileNumber)) return "";
        return userMobileNumber;
    }

    /**
     * Interface definition for a callback to be invoked when notify number submitted
     */
    public interface INotifyMeToMobileNumberListener {
        /**
         * Called when notify mobile number is submitted
         *
         * @param mobileNumber The mobile number to which the product back in stock will be notified
         */
        void onNotifyMeToMobileNumberSubmit(String mobileNumber);
    }
}

