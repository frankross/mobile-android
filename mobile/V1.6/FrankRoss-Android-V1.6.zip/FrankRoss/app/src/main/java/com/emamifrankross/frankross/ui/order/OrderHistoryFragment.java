/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.order;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiOrdersList;
import com.emamifrankross.frankross.core.apimodels.RequestCartItem;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.OrderHistoryAdapter;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 14/7/15.
 */

/**
 * This class represents the UI for Order history screen
 */
public class OrderHistoryFragment extends ApiRequestBaseFragment implements IToolbar,
        BaseRecyclerAdapter.RecyclerItemClickListener, BaseRecyclerAdapter.OnPageEndListener {

    private static final int RECORDS_PER_PAGE = 20;
    private List<BaseRecyclerAdapter.IViewType> mOrderHistoryData = new ArrayList<>();
    private OrderHistoryAdapter mOrderHistoryAdapter;
    private RobotoTextView mEmptyView;
    private int mCurrentPage = 1;
    private int mTotalPages = 0;

    public static OrderHistoryFragment create() {
        return new OrderHistoryFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mOrderHistoryAdapter = new OrderHistoryAdapter(mOrderHistoryData);
    }

    /**
     * Method that requests for Order History
     */
    private void performOrderHistoryRequest() {
        mCurrentPage = 1;//reset page number on navigating back to order listing screen
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetOrderListRequest(mCurrentPage, RECORDS_PER_PAGE, new ApiRequestManager.IGetOderListResultNotifier() {
            @Override
            public void onOrderListFetched(List<BaseRecyclerAdapter.IViewType> orderList, ApiOrdersList.PageInfo pageInfo) {
                if (orderList.size() == 0) {
                    if (getView() == null) return;
                    mEmptyView.setVisibility(View.VISIBLE);
                } else {
                    mOrderHistoryData.clear();
                    mOrderHistoryData.addAll(orderList);
                    mOrderHistoryAdapter.notifyDataSetChanged();
                }

                if (pageInfo != null) {
                    mCurrentPage = pageInfo.getCurrentPageNumber();
                    mTotalPages = pageInfo.getTotalPages();
                }
                mFragmentInteractionListener.hideBlockingProgressBar();
                mCurrentPage++;//get next set of orders
            }
        }, this, this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initOrderHistoryRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);
        performOrderHistoryRequest();
    }

    /**
     * Method that initializes the views
     *
     * @param view the view that is associated to Order History
     */
    private void initOrderHistoryRecyclerView(View view) {
        mEmptyView = (RobotoTextView) view.findViewById(R.id.empty_view_tv);
        RecyclerView orderHistoryRecyclerView = (RecyclerView) view.findViewById(R.id.home_container);
        orderHistoryRecyclerView.setHasFixedSize(false);
        orderHistoryRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mOrderHistoryAdapter.setRecyclerItemClickListener(this);
        mOrderHistoryAdapter.setRecyclerOnPageEndListener(this);
        orderHistoryRecyclerView.setAdapter(mOrderHistoryAdapter);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ORDER_HISTORY_VISIT_EVENT);
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {

        if (object == null) return;
        switch (((OrderHistoryAdapter.IViewType) object).getViewType()) {
            case ViewTypes.OrderHistoryViewType.ORDER_HISTORY_VIEW_TYPE:
                OrderHistoryAdapter.OrderHistoryItem orderObject = (OrderHistoryAdapter.OrderHistoryItem) object;
                switch (view.getId()) {
                    case R.id.order_history_re_order_btn:
                        onReorderButtonClick(orderObject);
                        break;
                    default:
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ORDER_TAP_EVENT);
                        mFragmentInteractionListener.loadFragment(getId(),
                                OrderHistoryDetailsFragment.create(orderObject.order.getId(), null), null,
                                R.anim.push_left_in, R.anim.push_left_out,
                                FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                        break;
                }
                break;
        }
    }

    /**
     * Method that handles the Reorder/Revise Order button tap
     *
     * @param orderObject the order object corresponding to the Button tap
     */
    private void onReorderButtonClick(OrderHistoryAdapter.OrderHistoryItem orderObject) {
        if (orderObject.order.getMismatched()) {
            loadRevisedOrderedScreen(orderObject.order.getId(),
                    orderObject.order.getDoctorName(), orderObject.order.getPatientName());
        } else {
            mFragmentInteractionListener.showBlockingProgressBar();
            addReorderedItemsToCart(orderObject.order.getOrderItems(),
                    orderObject.order.getDoctorName(), orderObject.order.getPatientName());
        }
    }

    /**
     * Method that launches the Revised order screen
     *
     * @param orderId     the order ID
     * @param doctorName  the doctor name for the order to be revised
     * @param patientName the patient name for the order to be revised
     */
    private void loadRevisedOrderedScreen(long orderId, String doctorName, String patientName) {
        mFragmentInteractionListener.hideBlockingProgressBar();
        startActivity(CartActivity.getActivityIntentForRevisedOrder(doctorName, patientName, getActivity(), orderId));
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    /**
     * Method to add the products into the cart which are to be reordered
     */
    private void addReorderedItemsToCart(final List<ApiOrdersList.OrderItem> orderItems,
                                         final String doctorName, final String patientName) {
        new AsyncTask<Void, Void, List<RequestCartItem>>() {

            @Override
            protected List<RequestCartItem> doInBackground(Void... params) {
                List<RequestCartItem> requestCartItems = new ArrayList<>(1);
                for (ApiOrdersList.OrderItem orderedItem : orderItems) {
                    if (orderedItem.getVariantId() > 0) {
                        RequestCartItem cartItem = new RequestCartItem();
                        cartItem.setVariantId(orderedItem.getVariantId());

                        int quantity = mApiRequestManager.
                                getCartItemQuantityForReOrder(orderedItem.getVariantId(),
                                        orderedItem.getQuantity());

                        cartItem.setQuantity(quantity);

                        requestCartItems.add(cartItem);
                    }
                }

                return requestCartItems;
            }

            @Override
            protected void onPostExecute(List<RequestCartItem> requestCartItems) {
                super.onPostExecute(requestCartItems);
                performAddToCart(requestCartItems, doctorName, patientName);
            }
        }.execute();
    }

    /**
     * Method requests for Adding multiple products to cart
     *
     * @param requestCartItems the cart items to be added
     */
    private void performAddToCart(List<RequestCartItem> requestCartItems,
                                  final String doctorName, final String patientName) {
        mApiRequestManager.performAddCartRequest(requestCartItems,
                new ApiRequestManager.IAddCartResultNotifier() {

                    @Override
                    public void onProductAdded() {
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.RE_ORDER_FROM_HISTORY_EVENT);
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        startActivity(CartActivity.getActivityIntentForPatientDetails(doctorName, patientName, getActivity()));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                    }

                    @Override
                    public void onProductAddFailed() {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        Toast.makeText(getActivity().getApplicationContext(),
                                getString(R.string.add_to_cart_failure_msg), Toast.LENGTH_SHORT).show();
                    }
                }, this, this);
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        //FrankRossAnalytics.getFrankRossTracker().logTimedEvent(FrankRossEvents.TIME_SPENT_ORDER_HISTORY_EVENT, null);
    }

    @Override
    public void onStop() {
        super.onStop();
        //FrankRossAnalytics.getFrankRossTracker().endTimedEvent(FrankRossEvents.TIME_SPENT_ORDER_HISTORY_EVENT, null);
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_order_history);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    @Override
    public void onPageEnd(int position) {
        performOrderHistoryPaginatedRequest();
    }

    /**
     * Method that requests for Paginated order history
     */
    private void performOrderHistoryPaginatedRequest() {

        if (mCurrentPage != 1 && mCurrentPage <= mTotalPages) {

            mFragmentInteractionListener.showBlockingProgressBar();
            mApiRequestManager.performGetOrderListRequest(mCurrentPage, RECORDS_PER_PAGE, new ApiRequestManager.IGetOderListResultNotifier() {
                @Override
                public void onOrderListFetched(List<BaseRecyclerAdapter.IViewType> orderList, ApiOrdersList.PageInfo pageInfo) {
                    mOrderHistoryData.addAll(orderList);
                    mOrderHistoryAdapter.notifyDataSetChanged();
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    mCurrentPage++;//get next set of orders
                }
            }, this, this);
        } else if (mCurrentPage == 1) {
            performOrderHistoryRequest();
        }
    }
}