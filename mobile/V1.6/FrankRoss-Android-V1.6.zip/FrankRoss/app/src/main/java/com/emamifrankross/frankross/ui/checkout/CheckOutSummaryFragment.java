/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.checkout;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiCart;
import com.emamifrankross.frankross.core.apimodels.ApiCartCheckout;
import com.emamifrankross.frankross.core.apimodels.ApiInitializePayment;
import com.emamifrankross.frankross.core.apimodels.ApiOrder;
import com.emamifrankross.frankross.core.apimodels.ApiOrderCancel;
import com.emamifrankross.frankross.core.apimodels.ApiPaymentFailure;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.core.network.UrlConstants;
import com.emamifrankross.frankross.sdkmanager.FacebookManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.CheckOutSummaryAdapter;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.order.OrderHistoryActivity;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryShippingChargesItem;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryTotalAmountItem;
import com.emamifrankross.frankross.utils.PaytmUtils;
import com.emamifrankross.frankross.utils.Utils;
import com.facebook.FacebookSdk;
import com.paytm.pgsdk.PaytmMerchant;
import com.paytm.pgsdk.PaytmOrder;
import com.paytm.pgsdk.PaytmPGService;
import com.paytm.pgsdk.PaytmPaymentTransactionCallback;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by gauthami on 22/7/15.
 */

/**
 * This class represents the UI for Checkout summary screen
 */
public class CheckOutSummaryFragment extends ApiRequestBaseFragment implements
        BaseRecyclerAdapter.RecyclerItemClickListener, IToolbar, View.OnClickListener, PaytmPaymentTransactionCallback {

    public static final String TAG = CheckOutSummaryFragment.class.getSimpleName();

    private static final String BUNDLE_KEY_ORDER_ID = "orderId";
    private static final String BUNDLE_KEY_ADDRESS_ID = "addressId";
    private static final String BUNDLE_KEY_DELIVERY_SLOT_ID = "deliveryId";
    private static final String BUNDLE_KEY_PRESCRIPTION_ID = "prescriptionId";

    private List<BaseRecyclerAdapter.IViewType> mCheckoutSummaryScreenData = new ArrayList<>();
    private CheckOutSummaryAdapter mCheckoutSummaryRecyclerAdapter;
    private ApiCartCheckout.Request mCartCheckOutRequest = new ApiCartCheckout.Request();

    private Button mConfirmOrderBtn;

    private long mOrderId = -1;
    private long mAddressId = -1;
    private long mDeliverySlotId = -1;
    private long mPrescriptionId = -1;

    //To set the transaction id to payment hash in order complete request
    private String mTransactionId = "";

    //To set the selected payment method id to order complete request
    private String mPaymentMethodId = "";

    //To set the selected payment instrument id to order complete request
    private String mPaymentInstrumentId = "";

    //To identify if the Retry count limit has reached and order has to be placed as cod forcefully
    private boolean mIsDirectCodPlaceOrder = false;

    //To identify if the payment is fully done done by Frank Ross wallet
    private boolean mIsFullyPaidByWallet = false;

    //To identify if the Payment hash has to be set to the order complete request
    private boolean mIsPaymentViaPaytm = false;

    //To set the order total to Paytm service request
    private double mOrderTotal = 0.0d;

    private ApiOrder.Order.PaymentDetails mPaymentDetails = new ApiOrder.Order.PaymentDetails();
    private CheckOutDeliveryAddressFragment.CartFlow mCartFlow = CheckOutDeliveryAddressFragment.CartFlow.CART;

    public enum PaymentCases {
        PAYMENT_FAILED,
        PAYMENT_SUCCESS
    }

    public static CheckOutSummaryFragment create(ApiCartCheckout.Request cartCheckOutRequest,
                                                 long orderId, long addressId, long deliverySlotId,
                                                 long prescriptionId
            , CheckOutDeliveryAddressFragment.CartFlow cartFlow) {
        CheckOutSummaryFragment fragment = new CheckOutSummaryFragment();

        Bundle bundle = new Bundle();
        bundle.putLong(BUNDLE_KEY_ORDER_ID, orderId);
        bundle.putLong(BUNDLE_KEY_ADDRESS_ID, addressId);
        bundle.putLong(BUNDLE_KEY_DELIVERY_SLOT_ID, deliverySlotId);
        bundle.putLong(BUNDLE_KEY_PRESCRIPTION_ID, prescriptionId);

        fragment.setCheckOutRequest(cartCheckOutRequest, cartFlow);
        fragment.setArguments(bundle);
        return fragment;
    }

    private void setCheckOutRequest(ApiCartCheckout.Request cartCheckOutRequest,
                                    CheckOutDeliveryAddressFragment.CartFlow cartFlow) {
        mCartCheckOutRequest = cartCheckOutRequest;
        mCartFlow = cartFlow;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();

        if (bundle != null) {
            mOrderId = bundle.getLong(BUNDLE_KEY_ORDER_ID);
            mAddressId = bundle.getLong(BUNDLE_KEY_ADDRESS_ID);
            mDeliverySlotId = bundle.getLong(BUNDLE_KEY_DELIVERY_SLOT_ID);
            mPrescriptionId = bundle.getLong(BUNDLE_KEY_PRESCRIPTION_ID);
        }

        mCheckoutSummaryRecyclerAdapter = new CheckOutSummaryAdapter(mCheckoutSummaryScreenData);
        performGetCartRequest();
    }

    /**
     * Method requests for refreshing the cart items
     */
    private void performGetCartRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetCartItemsRequest(new ApiRequestManager.ICartResultNotifier() {
            @Override
            public void onCartResult(List<BaseRecyclerAdapter.IViewType> cartDataList) {
                mFragmentInteractionListener.hideBlockingProgressBar();
                getCheckoutSummaryAdapterData();
            }
        }, this, this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        FacebookSdk.sdkInitialize(getActivity().getApplicationContext());
        return inflater.inflate(R.layout.fragment_checkout_summary, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initCheckoutSummaryRecyclerView(view);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the views
     *
     * @param view the root view
     */
    private void initViews(View view) {
        mConfirmOrderBtn = (Button) view.findViewById(R.id.cart_checkout_summary_confirm_order_btn);
        mConfirmOrderBtn.setOnClickListener(this);
    }

    /**
     * Method that initializes the recycler view that is associated with the Summary screen
     *
     * @param view the root view
     */
    private void initCheckoutSummaryRecyclerView(View view) {
        RecyclerView checkoutSummaryRecyclerView = (RecyclerView) view.findViewById(R.id.checkout_summary_recycler_view);
        checkoutSummaryRecyclerView.setHasFixedSize(false);
        checkoutSummaryRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mCheckoutSummaryRecyclerAdapter.setRecyclerItemClickListener(this);
        checkoutSummaryRecyclerView.setAdapter(mCheckoutSummaryRecyclerAdapter);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.CHECKOUT_SUMMARY_VISIT_EVENT);
    }

    /**
     * Method that constructs the Summary screen UI data list
     */
    private void getCheckoutSummaryAdapterData() {
        mFragmentInteractionListener.showBlockingProgressBar();
        ApiRequestManager.ICartSummaryResultNotifier cartSummaryResultNotifier = new ApiRequestManager.ICartSummaryResultNotifier() {
            @Override
            public void onCarSummaryFetched(List<BaseRecyclerAdapter.IViewType> checkSummaryData) {

                mFragmentInteractionListener.hideBlockingProgressBar();
                mCheckoutSummaryScreenData.clear();
                mCheckoutSummaryScreenData.addAll(checkSummaryData);
                mCheckoutSummaryRecyclerAdapter.notifyDataSetChanged();
                setBottomBarText();
                if (mIsDirectCodPlaceOrder) {
                    getSelectedOptionForPayment();
                    getSelectedPayment();
                }
            }
        };

        //There can be two different cases of data : Cart checkout and Revised order checkout
        if (mCartFlow != CheckOutDeliveryAddressFragment.CartFlow.REVISED_ORDER) {
            mApiRequestManager.getCartSummaryItems(cartSummaryResultNotifier);
        } else {
            mApiRequestManager.getRevisedOrderSummaryItems(cartSummaryResultNotifier);
        }
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {
            case ViewTypes.CheckOutSummaryViewType.CHECKOUT_REWARD_POINTS_VIEW_TYPE:
                CheckOutSummaryAdapter.CheckOutRewardPointsItem checkOutRewardPointsItem =
                        (CheckOutSummaryAdapter.CheckOutRewardPointsItem) object;
                setRewardPointsDeductionHeader(checkOutRewardPointsItem.checkBoxState);
                break;
            case ViewTypes.CheckOutSummaryViewType.CHECKOUT_SUMMARY_PAY_USING_RADIO_BUTTON_VIEW_TYPE:
                toggleRadioButtons(position);
                break;
            default:
                break;
        }
    }

    /**
     * To maintain radio button toggle behaviour
     *
     * @param position the radio button index
     */
    private void toggleRadioButtons(int position) {
        int index = 0;
        int paymentMethodsIndex = 0;
        for (BaseRecyclerAdapter.IViewType view : mCheckoutSummaryScreenData) {
            if (view.getViewType() == ViewTypes.CheckOutSummaryViewType.CHECKOUT_SUMMARY_PAY_USING_RADIO_BUTTON_VIEW_TYPE) {
                CheckOutSummaryAdapter.CheckOutSummaryRadioButtonDataItem checkOutSummaryRadioButtonDataItem =
                        (CheckOutSummaryAdapter.CheckOutSummaryRadioButtonDataItem) mCheckoutSummaryScreenData.get(index);
                checkOutSummaryRadioButtonDataItem.isSelected = position == index;
                if (position == index) {
                    if (!TextUtils.isEmpty(checkOutSummaryRadioButtonDataItem.paymentType)) {
                        if (checkOutSummaryRadioButtonDataItem.paymentType.equalsIgnoreCase(getString(R.string.cart_summary_postpay))) {
                            mConfirmOrderBtn.setText(getString(R.string.cart_confirm_order_btn_txt));
                        } else {
                            mConfirmOrderBtn.setText(getString(R.string.cart_confirm_order_continue_to_payment_btn_txt));
                        }
                    }
                }
                checkOutSummaryRadioButtonDataItem.paymentMethods.get(paymentMethodsIndex).
                        setIsChecked(checkOutSummaryRadioButtonDataItem.isSelected);
                mCheckoutSummaryRecyclerAdapter.notifyItemChanged(index);
                paymentMethodsIndex++;
            }
            index++;
        }
    }

    /**
     * Method to decide Reward points header visibility based on check state
     *
     * @param checkBoxState the check box state: checked or unchecked
     */
    private void setRewardPointsDeductionHeader(boolean checkBoxState) {
        for (BaseRecyclerAdapter.IViewType view : mCheckoutSummaryScreenData) {
            if (view.getViewType() == ViewTypes.OrderHistoryViewType.ORDER_HISTORY_PRODUCT_INFO_HEADER) {
                if (view instanceof OrderHistoryShippingChargesItem) {
                    performUpdateWalletRequest(checkBoxState);
                }
            }
        }
    }

    /**
     * Method to request the update wallet with credit/debit option
     */
    private void performUpdateWalletRequest(boolean isChecked) {
        mFragmentInteractionListener.showBlockingProgressBar();
        ApiCart.UpdateWalletRequest updateWalletRequest = new ApiCart.UpdateWalletRequest();
        updateWalletRequest.setDebit(isChecked);

        mApiRequestManager.performUpdateWalletRequest(mCartFlow, mOrderId, updateWalletRequest,
                new ApiRequestManager.IUpdateWalletResultNotifier() {
                    @Override
                    public void onWalletUpdated(List<BaseRecyclerAdapter.IViewType> orderDetailList) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        mCheckoutSummaryScreenData.clear();
                        mCheckoutSummaryScreenData.addAll(orderDetailList);
                        mCheckoutSummaryRecyclerAdapter.notifyDataSetChanged();
                        setBottomBarText();
                    }
                }, this, this);
    }

    /**
     * To update the bottom bar text based on the radio button selected or checkbox check/un-check
     */
    private void setBottomBarText() {
        boolean isPaymentMethods = false;

        for (BaseRecyclerAdapter.IViewType view : mCheckoutSummaryScreenData) {
            if (view.getViewType() == ViewTypes.CheckOutSummaryViewType.CHECKOUT_SUMMARY_PAY_USING_RADIO_BUTTON_VIEW_TYPE) {
                isPaymentMethods = true;
                CheckOutSummaryAdapter.CheckOutSummaryRadioButtonDataItem checkOutSummaryRadioButtonDataItem =
                        (CheckOutSummaryAdapter.CheckOutSummaryRadioButtonDataItem) view;
                if (checkOutSummaryRadioButtonDataItem.isSelected) {
                    if (!TextUtils.isEmpty(checkOutSummaryRadioButtonDataItem.paymentType)) {
                        if (checkOutSummaryRadioButtonDataItem.paymentType.equalsIgnoreCase(getString(R.string.cart_summary_postpay))) {
                            mConfirmOrderBtn.setText(getString(R.string.cart_confirm_order_btn_txt));
                        } else {
                            mConfirmOrderBtn.setText(getString(R.string.cart_confirm_order_continue_to_payment_btn_txt));
                        }
                    }
                }
            }
        }
        if (!isPaymentMethods) {
            mConfirmOrderBtn.setText(getString(R.string.cart_confirm_order_btn_txt));
        }
    }

    /**
     * Method to get the selected radio button
     */
    private void getSelectedOptionForPayment() {
        for (BaseRecyclerAdapter.IViewType view : mCheckoutSummaryScreenData) {
            if (view.getViewType() == ViewTypes.OrderHistoryViewType.ORDER_HISTORY_TOTAL_AMOUNT) {
                OrderHistoryTotalAmountItem dataItem = (OrderHistoryTotalAmountItem) view;
                mOrderTotal = dataItem.totalAmt;
            } else if (view.getViewType() == ViewTypes.CheckOutSummaryViewType.CHECKOUT_SUMMARY_PAY_USING_RADIO_BUTTON_VIEW_TYPE) {
                CheckOutSummaryAdapter.CheckOutSummaryRadioButtonDataItem checkOutSummaryRadioButtonDataItem =
                        (CheckOutSummaryAdapter.CheckOutSummaryRadioButtonDataItem) view;
                if (checkOutSummaryRadioButtonDataItem.isSelected && checkOutSummaryRadioButtonDataItem.paymentMethod != null) {
                    mPaymentMethodId = TextUtils.isEmpty(checkOutSummaryRadioButtonDataItem.paymentMethod.getId()) ?
                            "" : checkOutSummaryRadioButtonDataItem.paymentMethod.getId();
                    mPaymentInstrumentId = (checkOutSummaryRadioButtonDataItem.paymentMethod.getPaymentInstruments().size() == 0) ? "" :
                            checkOutSummaryRadioButtonDataItem.paymentMethod.getPaymentInstruments().get(0).getId();
                    mIsPaymentViaPaytm = checkOutSummaryRadioButtonDataItem.paymentMethod.getPaymentType().
                            equalsIgnoreCase(getString(R.string.payment_method_prepaid));
                }
            } else if (view.getViewType() == ViewTypes.OrderHistoryViewType.ORDER_HISTORY_PRODUCT_INFO_HEADER) {
                OrderHistoryShippingChargesItem shippingChargesItem =
                        (OrderHistoryShippingChargesItem) view;
                mIsFullyPaidByWallet = shippingChargesItem.isFullyPaidByWallet;
                if (mIsFullyPaidByWallet) {
                    mPaymentMethodId = shippingChargesItem.paymentMethod;
                    mPaymentInstrumentId = shippingChargesItem.paymentInstrument;
                    mIsPaymentViaPaytm = false;
                }
            }
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.cart_checkout_summary_confirm_order_btn:
                mFragmentInteractionListener.showBlockingProgressBar();
                getSelectedOptionForPayment();
                Map<String, String> confirmOrderClickData = Utils.confirmOrderClickDataForAnalytics(mIsFullyPaidByWallet,
                        mPaymentMethodId);
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.CONFIRM_ORDER_CLICK_EVENT, confirmOrderClickData);
                mPaymentDetails = new ApiOrder.Order.PaymentDetails();

                if (mCartFlow == CheckOutDeliveryAddressFragment.CartFlow.REVISED_ORDER) {
                    performUpdateOrder(PaymentCases.PAYMENT_SUCCESS);
                } else {
                    getSelectedPayment();
                }
                break;
        }
    }

    /**
     * Method requests for cart check out;If success, orderId will be generated
     * otherwise handles the error by notifying user with appropriate dialog
     */

    private void performCartCheckOut() {
        mFragmentInteractionListener.showBlockingProgressBar();
        FacebookManager.logFacebookInitiatedCheckOutEvent(getActivity()
        );

        mApiRequestManager.performCartCheckOutRequest(mCartCheckOutRequest,
                new ApiRequestManager.ICartCheckoutResultNotifier() {
                    @Override
                    public void onOrderIdCreated(long orderId) {
                        mApiRequestManager.refreshCartCount();
                        if (orderId > 0) {
                            if (mCartFlow == CheckOutDeliveryAddressFragment.CartFlow.REVISED_ORDER) {
                                performUpdateOrder(PaymentCases.PAYMENT_SUCCESS);
                            } else if (mCartFlow == CheckOutDeliveryAddressFragment.CartFlow.CART) {
                                placeOrder();
                            }
                        } else {
                            mFragmentInteractionListener.hideBlockingProgressBar();
                            Toast.makeText(getActivity().getApplicationContext(),
                                    "Unable to checkout the order", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onOrderFailed(boolean isInventoryError, String errorMessage, int errorId) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        if (isInventoryError) {
                            showInventoryErrorDialog(errorMessage);
                        } else if (!TextUtils.isEmpty(errorMessage)) {
                            showAlert(errorMessage);
                        } else {
                            String error = (errorId != 0) ? getResources().getString(errorId) :
                                    getResources().getString(R.string.server_error);
                            showAlert(error);
                        }
                    }
                }, this, this);
    }

    /**
     * Method that differentiates the payment methods based on the Payment method ID
     */
    private void getSelectedPayment() {

        if (mIsFullyPaidByWallet) {
            performCartCheckOut();
        } else {
            switch (mPaymentMethodId) {
                case PaytmUtils.PAYMENT_METHOD_COD:
                    performCartCheckOut();
                    break;
                case PaytmUtils.PAYMENT_METHOD_WALLET:
                    performInitPaymentRequest();
                    break;
                case PaytmUtils.PAYMENT_METHOD_CREDIT_CARD:
                    performInitPaymentRequest();
                    break;
                case PaytmUtils.PAYMENT_METHOD_DEBIT_CARD:
                    performInitPaymentRequest();
                    break;
                case PaytmUtils.PAYMENT_METHOD_NET_BANKING:
                    performInitPaymentRequest();
                    break;
                default:
                    //Assuming this case would never occur : Server has to send at least one payment option
                    performCartCheckOut();
                    break;
            }
        }
    }

    /**
     * Method that requests for initiate payment - Request called ONLY for Prepaid payment methods
     */
    private void performInitPaymentRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        ApiInitializePayment.Request initializePaymentRequest = new ApiInitializePayment.Request();

        initializePaymentRequest.setPaymentMethod(mPaymentMethodId);
        initializePaymentRequest.setPaymentInstrument(mPaymentInstrumentId);
        initializePaymentRequest.setDeliverySlotId(mDeliverySlotId);
        initializePaymentRequest.setDeliveryAddressId(mAddressId);
        initializePaymentRequest.setShippingAddressId(mAddressId);

        String prescriptionId = (mPrescriptionId > 0) ? mPrescriptionId + "" : null;
        initializePaymentRequest.setPrescriptionUploadId(prescriptionId);

        mApiRequestManager.performInitializePaymentRequest(mOrderId, initializePaymentRequest,
                new ApiRequestManager.IInitializePaymentResultNotifier() {
                    @Override
                    public void onPaymentInitializeSuccess(ApiInitializePayment.Response response) {
                        mOrderId = Long.parseLong(response.getOrderId());
                        mTransactionId = response.getTransactionId();
                        initPaytmPGService();
                    }

                    @Override
                    public void onPaymentInitializeFailed(boolean isInventoryError, String errorMessage, int errorId) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        if (isInventoryError) {
                            showInventoryErrorDialog(errorMessage);
                        } else if (!TextUtils.isEmpty(errorMessage)) {
                            showAlert(errorMessage);
                        } else {
                            String error = (errorId != 0) ? getResources().getString(errorId) :
                                    getResources().getString(R.string.server_error);
                            showAlert(error);
                        }
                    }
                }, this, this);
    }

    /**
     * Method that Initializes Paytm Payment Gateway service
     */
    private void initPaytmPGService() {

        PaytmPGService Service = PaytmUtils.getPaytmPGService();
        Map<String, String> paramMap = new HashMap<String, String>();

        paramMap.put(PaytmUtils.PG_REQUEST_TYPE, PaytmUtils.PAYTM_REQUEST_TYPE);
        paramMap.put(PaytmUtils.PG_ORDER_ID_KEY, mTransactionId + "");
        paramMap.put(PaytmUtils.PG_MERCHANT_ID_KEY, PaytmUtils.PAYTM_MERCHANT_ID);
        paramMap.put(PaytmUtils.PG_CUSTOMER_ID_KEY, Utils.getAccessToken(getActivity().getApplicationContext()));
        paramMap.put(PaytmUtils.PG_CHANNEL_ID_KEY, PaytmUtils.PAYTM_CHANNEL_ID);
        paramMap.put(PaytmUtils.PG_INDUSTRY_TYPE_KEY, PaytmUtils.PAYTM_INDUSTRY_TYPE);
        paramMap.put(PaytmUtils.PG_WEBSITE_KEY, PaytmUtils.PAYTM_WEBSITE);
        paramMap.put(PaytmUtils.PG_TAXN_AMOUNT_KEY, mOrderTotal + "");
        paramMap.put(PaytmUtils.PG_THEME_KEY, PaytmUtils.PAYTM_THEME);
        PaytmOrder Order = new PaytmOrder(paramMap);

        /**
         * Initialize Merchant server
         */
        PaytmMerchant Merchant = new PaytmMerchant(
                UrlConstants.PAYTM_CHECKSUM_GENERATION_URL,
                UrlConstants.PAYTM_CHECKSUM_VALIDATION_URL);

        Service.initialize(Order, Merchant, null);

        /**
         * Start service
         */
        Service.startPaymentTransaction(getActivity(), false, true, this);
    }

    /**
     * Method to differentiate the revise order and fresh order flow
     */
    public void performUpdateOrCompleteOrder(PaymentCases paymentCase) {
        if (mCartFlow == CheckOutDeliveryAddressFragment.CartFlow.REVISED_ORDER) {
            performUpdateOrder(paymentCase);
        } else {
            if (paymentCase.equals(PaymentCases.PAYMENT_SUCCESS)) {
                performCartCheckOut();
            } else if (paymentCase.equals(PaymentCases.PAYMENT_FAILED)) {
                performPaymentFailedRequest();
            }
        }
    }

    /**
     * Method to set the Payment details Request data
     *
     * @param response the Paytm SDK response
     */
    public void setPaymentDetailsFromPaytm(Bundle response) {
        mPaymentDetails.setTransactionId(response.getString(PaytmUtils.PAYTM_TRANSACTION_ID_KEY));
        mPaymentDetails.setBankTransactionId(response.getString(PaytmUtils.PAYTM_BANK_TXN_ID_KEY));
        mPaymentDetails.setOrderId(response.getString(PaytmUtils.PAYTM_ORDER_ID));
        mPaymentDetails.setTransactionAmount(response.getString(PaytmUtils.PAYTM_TRANSACTION_AMOUNT));
        mPaymentDetails.setTransactionStatus(response.getString(PaytmUtils.PAYTM_TRANSACTION_STATUS));
        mPaymentDetails.setTransactionType(response.getString(PaytmUtils.PAYTM_TRANSACTION_TYPE));
        mPaymentDetails.setCurrency(response.getString(PaytmUtils.PAYTM_TRANSACTION_CURRENCY));
        mPaymentDetails.setGatewayName(response.getString(PaytmUtils.PAYTM_TRANSACTION_GATEWAY));
        mPaymentDetails.setResponseCode(response.getString(PaytmUtils.PAYTM_RESPONSE_CODE));
        mPaymentDetails.setResponseMessage(response.getString(PaytmUtils.PAYTM_RESPONSE_MESSAGE));
        mPaymentDetails.setBankName(response.getString(PaytmUtils.PAYTM_BANK_NAME));
        mPaymentDetails.setMerchantId(response.getString(PaytmUtils.PAYTM_MERCHANT_ID_KEY));
        mPaymentDetails.setPaymentMode(response.getString(PaytmUtils.PAYTM_PAYMENT_MODE));
        mPaymentDetails.setRefundAmount(response.getString(PaytmUtils.PAYTM_REFUND_AMOUNT));
        mPaymentDetails.setTransactionDate(response.getString(PaytmUtils.PAYTM_TRANSACTION_DATE));
        mPaymentDetails.setIsChecksumValid(response.getString(PaytmUtils.PAYTM_CHECKSUM_VALID));
    }

    /**
     * Method that requests for Payment failure API
     */
    private void performPaymentFailedRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        final ApiPaymentFailure.Request paymentFailureRequest = new ApiPaymentFailure.Request();

        paymentFailureRequest.getRequestPlaceOrder().setPayment_method(mPaymentMethodId);
        paymentFailureRequest.getRequestPlaceOrder().setPayment_instrument(mPaymentInstrumentId);

        if (mIsPaymentViaPaytm)
            paymentFailureRequest.getRequestPlaceOrder().setPaymentDetails(mPaymentDetails);

        mApiRequestManager.performPaymentFailureRequest(mOrderId, paymentFailureRequest,
                new ApiRequestManager.IPaymentFailureResultNotifier() {
                    @Override
                    public void onPaymentFailureResultFetched(ApiCart.Response apiPaymentFailureResponse) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        mApiRequestManager.refreshCartCount();
                        if (apiPaymentFailureResponse.getCart().isPaymentRetryable()) {
                            mFragmentInteractionListener.showAlert(null,
                                    getString(R.string.checkout_payment_failure_alrt_message),
                                    getString(R.string.contine), getString(R.string.cancel),
                                    new AlertDialogFragment.AlertPositiveActionListener() {
                                        @Override
                                        public void onPositiveAction() {
                                            FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PAYMENT_RETRY_CONTINUE_TAP_EVENT);
                                            mIsDirectCodPlaceOrder = true;
                                            performGetCartRequest();
                                        }
                                    }, new AlertDialogFragment.AlertNegativeActionListener() {
                                        @Override
                                        public void onNegativeAction() {
                                            mIsDirectCodPlaceOrder = false;
                                            FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PAYMENT_RETRY_CANCEL_TAP_EVENT);
                                            performCancelOrderRequest();
                                        }
                                    }, false);
                        } else {
                            mIsDirectCodPlaceOrder = false;
                        }
                    }
                }, this, this);
    }

    /**
     * Method requests for placing the order;If success, shows the Check out success screen
     */
    private void placeOrder() {
        if (validatePlaceOrder()) {
            mFragmentInteractionListener.showBlockingProgressBar();
            final ApiOrder.Request orderRequest = new ApiOrder.Request();
            orderRequest.getRequestPlaceOrder().setBilling_address_id(mAddressId);
            orderRequest.getRequestPlaceOrder().setShipping_address_id(mAddressId);

            String prescriptionId = (mPrescriptionId > 0) ? mPrescriptionId + "" : null;
            orderRequest.getRequestPlaceOrder().setPrescriptionUploadId(prescriptionId);

            orderRequest.getRequestPlaceOrder().setDeliverySlotId(mDeliverySlotId);
            orderRequest.getRequestPlaceOrder().setPayment_method(mPaymentMethodId);
            orderRequest.getRequestPlaceOrder().setPayment_instrument(mPaymentInstrumentId);

            if (mIsPaymentViaPaytm)
                orderRequest.getRequestPlaceOrder().setPaymentDetails(mPaymentDetails);

            mApiRequestManager.performOrderPlaceRequest(mOrderId, orderRequest,
                    new ApiRequestManager.IPlaceOrderResultNotifier() {
                        @Override
                        public void onOrderConfirmed() {
                            mFragmentInteractionListener.hideBlockingProgressBar();
                            mApiRequestManager.refreshCartCount();
                            mApiRequestManager.clearCartItemsCount();
                            FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ORDER_PLACEMENT_EVENT);
                            FacebookManager.logFacebookPurchasedEvent(getActivity(), mOrderTotal,
                                    getString(R.string.facebook_events_parameter_currency));
                            loadCheckOutSuccessFragment(false);
                        }
                    }, this, this);
        }
    }

    /**
     * Method requests for updating the order;If success, shows the Check out success screen
     *
     * @param paymentCase the payment case to define the success/failure of transaction
     */
    private void performUpdateOrder(final PaymentCases paymentCase) {
        mFragmentInteractionListener.showBlockingProgressBar();

        ApiOrder.Request updateOrderRequest = new ApiOrder.Request();
        updateOrderRequest.getRequestPlaceOrder().setBilling_address_id(mAddressId);
        updateOrderRequest.getRequestPlaceOrder().setShipping_address_id(mAddressId);

        String prescriptionId = (mPrescriptionId > 0) ? mPrescriptionId + "" : null;
        updateOrderRequest.getRequestPlaceOrder().setPrescriptionUploadId(prescriptionId);

        updateOrderRequest.getRequestPlaceOrder().setDeliverySlotId(mDeliverySlotId);
        updateOrderRequest.getRequestPlaceOrder().setPayment_method(mPaymentMethodId);
        updateOrderRequest.getRequestPlaceOrder().setPayment_instrument(mPaymentInstrumentId);

        if (mIsPaymentViaPaytm)
            updateOrderRequest.getRequestPlaceOrder().setPaymentDetails(mPaymentDetails);

        mApiRequestManager.performReviseOrderPlaceRequest(mOrderId, updateOrderRequest,
                new ApiRequestManager.IReviseOrderResultNotifier() {
                    @Override
                    public void onOrderRevised() {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        switch (paymentCase) {
                            case PAYMENT_SUCCESS:
                                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.UPDATE_ORDER_EVENT);
                                loadCheckOutSuccessFragment(true);
                                break;
                            case PAYMENT_FAILED:
                                loadOrderDetailsFragment();
                                break;
                            default:
                                break;
                        }
                    }
                }, this, this);
    }

    /**
     * Method to load the Check Out success Activity so that back stack will be cleared
     *
     * @param isOrderUpdate for text updates in success screen
     */
    private void loadCheckOutSuccessFragment(boolean isOrderUpdate) {
        startActivity(CheckOutSuccessActivity.getActivityIntent(getActivity(), mOrderId, isOrderUpdate, mPaymentMethodId));
        getActivity().finish();
    }

    /**
     * Method to load the Order details fragment - failure case
     */
    private void loadOrderDetailsFragment() {
        startActivity(OrderHistoryActivity.getActivityIntent(getActivity(),
                OrderHistoryActivity.ORDER_HISTORY_DETAILS_FRAGMENT_ID, mOrderId));
        getActivity().finish();
    }

    /**
     * Method that shows insufficient inventory error dialog thrown by server;Navigates to Cart Revised screen
     *
     * @param errorMessage the error message that has to be displayed in the dialog
     */
    private void showInventoryErrorDialog(String errorMessage) {
        errorMessage = (TextUtils.isEmpty(errorMessage)) ?
                getString(R.string.cart_insufficient_inventory_msg) : errorMessage;
        mFragmentInteractionListener.showAlert("", errorMessage,
                getString(R.string.ok), null, new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                        startActivity(CartActivity.getActivityIntentForRevisedCart(getActivity(),
                                mOrderId, mCartCheckOutRequest.getDoctorName(), mCartCheckOutRequest.getPatientName(),
                                mAddressId, mDeliverySlotId, mPrescriptionId));
                        getActivity().finish();
                    }
                }, null, false);
    }

    /**
     * Method to validate the addressId and slotId
     */
    private boolean validatePlaceOrder() {
        if (mAddressId < 1) {
            Toast.makeText(getActivity(), "Address not chosen", Toast.LENGTH_SHORT).show();
        } else if (mDeliverySlotId < 1) {
            Toast.makeText(getActivity(), "Delivery slot not chosen", Toast.LENGTH_SHORT).show();
        } else {
            return true;
        }

        return false;
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        //FrankRossAnalytics.getFrankRossTracker().logTimedEvent(FrankRossEvents.TIME_SPENT_SUMMARY_SCREEN_EVENT, null);
    }

    @Override
    public void onStop() {
        super.onStop();
        //FrankRossAnalytics.getFrankRossTracker().endTimedEvent(FrankRossEvents.TIME_SPENT_SUMMARY_SCREEN_EVENT, null);
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               /* mIsCheckOutProcessInProgress = false;
                mFragmentInteractionListener.hideBlockingProgressBar();
                closeFragment();*/
                getActivity().onBackPressed();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_check_out_summary);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    @Override
    public void onTransactionSuccess(Bundle inResponse) {
        Log.d(TAG, "Payment Transaction is successful " + inResponse);
        Utils.show_toast(getActivity(), getResources().getString(R.string.payment_gateway_success));
        PaytmUtils.setResponseCode(Integer.parseInt(inResponse.getString(PaytmUtils.PAYTM_RESPONSE_CODE)));
        PaytmUtils.setPaymentMessage(inResponse.getString(PaytmUtils.PAYTM_RESPONSE_MESSAGE));

        setPaymentDetailsFromPaytm(inResponse);
        performUpdateOrCompleteOrder(PaymentCases.PAYMENT_SUCCESS);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PAYTM_TRANSACTION_SUCCESS_EVENT);
    }

    @Override
    public void onTransactionFailure(String inErrorMessage, Bundle inResponse) {
        Log.d(TAG, "Payment Transaction Failed : onTransactionFailure " + inErrorMessage);
        PaytmUtils.setResponseCode(Integer.parseInt(inResponse.getString(PaytmUtils.PAYTM_RESPONSE_CODE)));
        PaytmUtils.setPaymentMessage(inResponse.getString(PaytmUtils.PAYTM_RESPONSE_MESSAGE));

        setPaymentDetailsFromPaytm(inResponse);
        performUpdateOrCompleteOrder(PaymentCases.PAYMENT_FAILED);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PAYTM_TRANSACTION_FAILURE_EVENT);
    }

    @Override
    public void networkNotAvailable() {
        Log.d(TAG, "Payment Transaction Failed : networkNotAvailable ");
        Utils.show_toast(getActivity(), getResources().getString(R.string.no_connection_error));
        PaytmUtils.setPaymentMessage(getResources().getString(R.string.no_connection_error));
        mPaymentDetails.setOrderId(mTransactionId);

        performUpdateOrCompleteOrder(PaymentCases.PAYMENT_FAILED);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PAYTM_TRANSACTION_FAILURE_EVENT);
    }

    @Override
    public void clientAuthenticationFailed(String inErrorMessage) {
        Log.d(TAG, "Payment Transaction Failed : clientAuthenticationFailed " + inErrorMessage);
        PaytmUtils.setPaymentMessage(inErrorMessage);
        mPaymentDetails.setOrderId(mTransactionId);

        performUpdateOrCompleteOrder(PaymentCases.PAYMENT_FAILED);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PAYTM_TRANSACTION_FAILURE_EVENT);
    }

    @Override
    public void someUIErrorOccurred(String inErrorMessage) {
        Log.d(TAG, "Payment Transaction Failed : someUIErrorOccurred " + inErrorMessage);
        PaytmUtils.setPaymentMessage(inErrorMessage);
        mPaymentDetails.setOrderId(mTransactionId);

        performUpdateOrCompleteOrder(PaymentCases.PAYMENT_FAILED);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PAYTM_TRANSACTION_FAILURE_EVENT);
    }

    @Override
    public void onErrorLoadingWebPage(int iniErrorCode, String inErrorMessage, String s1) {
        Log.d(TAG, "Payment Transaction Failed : onErrorLoadingWebPage " + inErrorMessage);
        PaytmUtils.setResponseCode(iniErrorCode);
        PaytmUtils.setPaymentMessage(inErrorMessage);
        mPaymentDetails.setOrderId(mTransactionId);

        performUpdateOrCompleteOrder(PaymentCases.PAYMENT_FAILED);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PAYTM_TRANSACTION_FAILURE_EVENT);
    }

    @Override
    public void onBackPressedCancelTransaction() {
        Log.d(TAG, "Payment Transaction Failed : onBackPressedCancelTransaction ");
        PaytmUtils.setPaymentMessage("Transaction cancelled by customer after landing on Payment Gateway Page.");
        mPaymentDetails.setOrderId(mTransactionId);

        performUpdateOrCompleteOrder(PaymentCases.PAYMENT_FAILED);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PAYTM_TRANSACTION_BACK_PRESS_EVENT);
    }

    /**
     * Method that requests for cancelling a particular order that fails the transaction after Retry count has exceeded
     */
    private void performCancelOrderRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        ApiOrderCancel.Request apiOrderCancel = new ApiOrderCancel.Request();
        apiOrderCancel.setReason(getString(R.string.check_out_transaction_failure_cancel_order_reason));
        apiOrderCancel.setRemarks("");
        mApiRequestManager.performCancelOrderRequest(mOrderId, apiOrderCancel, new ApiRequestManager.ICancelOrderResultNotifier() {
            @Override
            public void onOrderCancelled(String message) {
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ORDER_CANCEL_EVENT);
                mFragmentInteractionListener.hideBlockingProgressBar();
                mApiRequestManager.refreshCartCount();
                mApiRequestManager.clearCartItemsCount();
                loadOrderDetailsFragment();
            }
        }, this, this);
    }

    /**
     * Method to identify if the Checkout through any of the Payment mode is in progress
     *
     * @return true if user can go back;false if checkout is in progress
     */
    public boolean getCanGoBackBoolean() {
        return !(mIsDirectCodPlaceOrder || mFragmentInteractionListener.isProgressBarShowing());
    }
}

