/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gowtham on 29/6/15.
 */
public class AlertDialogFragment extends BaseDialogFragment {

    private static final String TITLE = "title";
    private static final String MESSAGE = "message";
    private static final String POSITIVE_ACTION_BTN_TEXT = "positive";
    private static final String NEGATIVE_ACTION_BTN_TEXT = "negative";

    private LinearLayout mAlertTitleLayout;
    private RobotoTextView mAlertTitle;
    private RobotoTextView mAlertMessage;
    private RobotoTextView mAlertAbovePositiveAction;
    private RobotoTextView mAlertNegativeAction;
    private RobotoTextView mAlertPositiveAction;
    private View mAlertActionBtnVerticalDivider;
    private View mAlertActionBtnHorizontalDivider;

    private AlertPositiveActionListener mAlertPositiveActionListener;
    private AlertNegativeActionListener mAlertNegativeActionListener;

    public interface AlertPositiveActionListener {
        void onPositiveAction();
    }

    public interface AlertNegativeActionListener {
        void onNegativeAction();
    }

    public static AlertDialogFragment create(String title, String message, String positiveBtnText,
                                             String negativeBtnText,
                                             AlertPositiveActionListener alertPositiveActionListener,
                                             AlertNegativeActionListener alertNegativeActionListener) {
        Bundle bundle = new Bundle();
        bundle.putString(TITLE, title);
        bundle.putString(MESSAGE, message);
        bundle.putString(POSITIVE_ACTION_BTN_TEXT, positiveBtnText);
        bundle.putString(NEGATIVE_ACTION_BTN_TEXT, negativeBtnText);

        AlertDialogFragment alertFragment = new AlertDialogFragment();
        alertFragment.setArguments(bundle);

        alertFragment.setPositiveActionListener(alertPositiveActionListener);
        alertFragment.setNegativeActionListener(alertNegativeActionListener);

        return alertFragment;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_alert_dialog;
    }

    @Override
    public void initViews(Dialog view) {
        mAlertTitleLayout = (LinearLayout) view.findViewById(R.id.alert_title_layout);
        mAlertTitle = (RobotoTextView) view.findViewById(R.id.alert_title);
        mAlertMessage = (RobotoTextView) view.findViewById(R.id.alert_message);
        mAlertAbovePositiveAction = (RobotoTextView) view.findViewById(R.id.alert_above_positive_action);
        mAlertNegativeAction = (RobotoTextView) view.findViewById(R.id.alert_negative_action);
        mAlertPositiveAction = (RobotoTextView) view.findViewById(R.id.alert_positive_action);
        mAlertActionBtnVerticalDivider = view.findViewById(R.id.alert_btn_verical_divider);
        mAlertActionBtnHorizontalDivider = view.findViewById(R.id.alert_btn_horizontal_divider);
        setCardViewProperty(view);
        setValues();
    }

    private void setCardViewProperty(Dialog view) {
        CardView cardView = (CardView) view.findViewById(R.id.alert_layout_card);
        if (Utils.isAPILevel21AndAbove()) {
            cardView.setPreventCornerOverlap(false);
        } else {
            cardView.setPreventCornerOverlap(true);
        }

    }

    private void setValues() {
        Bundle dataBundle = getArguments();
        if (dataBundle != null) {
            setTitle(dataBundle.getString(TITLE));
            setMessage(dataBundle.getString(MESSAGE));
            setActions(dataBundle.getString(POSITIVE_ACTION_BTN_TEXT), dataBundle.getString(NEGATIVE_ACTION_BTN_TEXT));
        } else {
            dismiss();
        }

    }

    public void setPositiveActionListener(AlertPositiveActionListener alertActionListener) {
        mAlertPositiveActionListener = alertActionListener;
    }

    public void setNegativeActionListener(AlertNegativeActionListener alertActionListener) {
        mAlertNegativeActionListener = alertActionListener;
    }

    private void setTitle(String title) {
        if (!TextUtils.isEmpty(title)) {
            mAlertTitleLayout.setVisibility(View.VISIBLE);
            mAlertTitle.setText(title);
        }
    }

    private void setMessage(String message) {
        mAlertMessage.setText(message);
    }

    private void setActions(String positiveText, String negativeText) {
        if (!TextUtils.isEmpty(positiveText) && !TextUtils.isEmpty(negativeText)) {
            if (positiveText.length() > 10) {
                mAlertAbovePositiveAction.setVisibility(View.VISIBLE);
                mAlertAbovePositiveAction.setText(positiveText);
                mAlertAbovePositiveAction.setOnClickListener(getPositiveOnclickListener());
                mAlertActionBtnVerticalDivider.setVisibility(View.VISIBLE);
            } else {
                mAlertPositiveAction.setVisibility(View.VISIBLE);
                mAlertPositiveAction.setText(positiveText);
                mAlertPositiveAction.setOnClickListener(getPositiveOnclickListener());
                mAlertActionBtnHorizontalDivider.setVisibility(View.VISIBLE);
            }

            mAlertNegativeAction.setVisibility(View.VISIBLE);
            mAlertNegativeAction.setText(negativeText);
            mAlertNegativeAction.setOnClickListener(getNegativeOnClickListener());

        } else if (!TextUtils.isEmpty(positiveText)) {
            mAlertPositiveAction.setVisibility(View.VISIBLE);
            mAlertPositiveAction.setText(positiveText);
            mAlertPositiveAction.setOnClickListener(getPositiveOnclickListener());
        } else {
            mAlertNegativeAction.setVisibility(View.VISIBLE);
            mAlertNegativeAction.setText(negativeText);
            mAlertNegativeAction.setOnClickListener(getNegativeOnClickListener());
        }
    }

    private View.OnClickListener getNegativeOnClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                if (mAlertNegativeActionListener != null) {
                    mAlertNegativeActionListener.onNegativeAction();
                }
            }
        };
    }

    private View.OnClickListener getPositiveOnclickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dismiss();
                if (mAlertPositiveActionListener != null) {
                    mAlertPositiveActionListener.onPositiveAction();
                }
            }
        };
    }

    @Override
    public void onPause() {
        super.onPause();
        //dismiss();
    }
}
