/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.wallet;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.ApptentiveManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.RewardPointsAdapter;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 15/4/16.
 */

/**
 * This class represents the UI for Frank Ross wallet screen
 */
public class FrankRossWalletFragment extends ApiRequestBaseFragment implements IToolbar {

    private static final int REWARD_POINTS = 111;

    private RobotoTextView mEmptyView;
    private ArrayList<BaseRecyclerAdapter.IViewType> mRewardPointsScreenData = new ArrayList<>();
    private RewardPointsAdapter mRewardPointsRecyclerAdapter;

    public static FrankRossWalletFragment create() {
        return new FrankRossWalletFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mRewardPointsRecyclerAdapter = new RewardPointsAdapter(mRewardPointsScreenData);
        performRewardPointsRequests();
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.FRANK_ROSS_WALLET_VISIT_EVENT);
        ApptentiveManager.registerWalletScreenVisitEvent(getActivity());
    }

    /**
     * Method that requests for the Frank Ross wallet details
     */
    private void performRewardPointsRequests() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetRewardPointsListRequest(new ApiRequestManager.IRewardPointsResultNotifier() {
            @Override
            public void onRewardPointsFetched(List<BaseRecyclerAdapter.IViewType> rewardPointsList) {
                mFragmentInteractionListener.hideBlockingProgressBar();

                if (rewardPointsList != null && !rewardPointsList.isEmpty()) {
                    mRewardPointsScreenData.clear();
                    mRewardPointsScreenData.addAll(rewardPointsList);
                    mRewardPointsRecyclerAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onRewardPointsFailed(String failureMessage) {
                mFragmentInteractionListener.hideBlockingProgressBar();
                mEmptyView.setText(failureMessage);
                mEmptyView.setVisibility(View.VISIBLE);
            }
        }, this, this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_reward_points, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initStoreLocatorRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_CANCELED || resultCode == Activity.RESULT_OK) {
            if (requestCode == REWARD_POINTS) {
                performRewardPointsRequests();
            }
        }
    }

    /**
     * Initialize the view
     *
     * @param view view that is associated with the FR wallet screen
     */
    private void initStoreLocatorRecyclerView(View view) {
        RecyclerView rewardPointsRecyclerView = (RecyclerView) view.findViewById(R.id.reward_points_recycler_view);
        rewardPointsRecyclerView.setHasFixedSize(false);
        rewardPointsRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        rewardPointsRecyclerView.setAdapter(mRewardPointsRecyclerAdapter);

        mEmptyView = (RobotoTextView) view.findViewById(R.id.store_locator_empty_view_tv);
        mEmptyView.setVisibility(View.GONE);
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        mApiRequestManager.registerCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
        mApiRequestManager.unregisterCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_frank_ross_wallet);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }
}
