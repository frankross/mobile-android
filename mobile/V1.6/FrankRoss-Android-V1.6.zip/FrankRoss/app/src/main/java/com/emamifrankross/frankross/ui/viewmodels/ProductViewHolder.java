/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.graphics.Paint;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;

import com.android.volley.toolbox.NetworkImageView;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

/**
 * Created by gowtham on 7/7/15.
 */

/**
 * Common product view holder
 */
public class ProductViewHolder extends RecyclerView.ViewHolder {

    public RobotoTextView mProductActualAmount;
    public RobotoTextView mProductOfferAmount;
    public RobotoTextView mProductDiscount;
    public RobotoTextView mProductName;
    public RobotoTextView mProductBrandOrManufacturerName;
    public RobotoTextView mProductCashbackMessage;
    public RobotoTextView mProductAddToCart;
    public LinearLayout mProductCashbackLinLyt;
    public NetworkImageView mProductImage;

    public ProductViewHolder(View itemView) {
        super(itemView);
        mProductActualAmount = (RobotoTextView) itemView.findViewById(R.id.top_selling_product_price_tv);
        mProductOfferAmount = (RobotoTextView) itemView.findViewById(R.id.top_selling_product_offer_price_tv);
        mProductDiscount = (RobotoTextView) itemView.findViewById(R.id.top_selling_product_offer_tv);
        mProductImage = (NetworkImageView) itemView.findViewById(R.id.top_selling_product_icon_iv);
        mProductName = (RobotoTextView) itemView.findViewById(R.id.top_selling_product_title_tv);
        mProductBrandOrManufacturerName = (RobotoTextView) itemView.findViewById(R.id.top_selling_product_brand_tv);
        mProductAddToCart = (RobotoTextView) itemView.findViewById(R.id.top_selling_product_add_to_cart_tv);

        mProductCashbackLinLyt = (LinearLayout) itemView.findViewById(R.id.top_selling_product_cashback_message_linLyt);
        mProductCashbackMessage = (RobotoTextView) itemView.findViewById(R.id.top_selling_product_cashback_message_tv);

        mProductActualAmount.setPaintFlags(mProductActualAmount.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        mProductImage.setDefaultImageResId(R.drawable.product_logo);
        mProductImage.setErrorImageResId(R.drawable.product_logo);
    }
}