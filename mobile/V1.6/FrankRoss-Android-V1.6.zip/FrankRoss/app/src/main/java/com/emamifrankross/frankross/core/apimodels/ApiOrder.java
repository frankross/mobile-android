/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 11/8/15.
 */
public class ApiOrder {

    public static class Request {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("order")
        private Order requestPlaceOrder = new Order();

        public Order getRequestPlaceOrder() {
            return requestPlaceOrder;
        }
    }

    public static class Order {

        @SerializedName("prescription_upload_id")
        private String prescription_upload_id;

        @SerializedName("shipping_address_id")
        private long shipping_address_id;

        @SerializedName("delivery_slot_id")
        private long delivery_slot_id;

        @SerializedName("payment_method")
        private String payment_method;

        @SerializedName("payment_instrument")
        private String payment_instrument;

        @SerializedName("billing_address_id")
        private long billing_address_id;

        @SerializedName("payment_details")
        private PaymentDetails paymentDetails;

        public String getPrescription_upload_id() {
            return prescription_upload_id;
        }

        public void setPrescriptionUploadId(String prescription_upload_id) {
            this.prescription_upload_id = prescription_upload_id;
        }

        public long getShipping_address_id() {
            return shipping_address_id;
        }

        public void setShipping_address_id(long shipping_address_id) {
            this.shipping_address_id = shipping_address_id;
        }

        public long getDelivery_slot_id() {
            return delivery_slot_id;
        }

        public void setDeliverySlotId(long delivery_slot_id) {
            this.delivery_slot_id = delivery_slot_id;
        }

        public String getPayment_method() {
            return payment_method;
        }

        public void setPayment_method(String payment_method) {
            this.payment_method = payment_method;
        }

        public long getBilling_address_id() {
            return billing_address_id;
        }

        public void setBilling_address_id(long billing_address_id) {
            this.billing_address_id = billing_address_id;
        }

        public String getPayment_instrument() {
            return payment_instrument;
        }

        public void setPayment_instrument(String payment_instrument) {
            this.payment_instrument = payment_instrument;
        }

        public PaymentDetails getPaymentDetails() {
            return paymentDetails;
        }

        public void setPaymentDetails(PaymentDetails paymentDetails) {
            this.paymentDetails = paymentDetails;
        }

        public static class PaymentDetails {

            @SerializedName("TXNID")
            private String transactionId = "";

            @SerializedName("BANKTXNID")
            private String bankTransactionId = "";

            @SerializedName("ORDERID")
            private String orderId = "";

            @SerializedName("TXNAMOUNT")
            private String transactionAmount = "";

            @SerializedName("STATUS")
            private String transactionStatus = "";

            @SerializedName("TXNTYPE")
            private String transactionType = "";

            @SerializedName("CURRENCY")
            private String currency = "";

            @SerializedName("GATEWAYNAME")
            private String gatewayName = "";

            @SerializedName("RESPCODE")
            private String responseCode = "";

            @SerializedName("RESPMSG")
            private String responseMessage = "";

            @SerializedName("BANKNAME")
            private String bankName = "";

            @SerializedName("MID")
            private String merchantId = "";

            @SerializedName("PAYMENTMODE")
            private String paymentMode = "";

            @SerializedName("REFUNDAMT")
            private String refundAmount = "";

            @SerializedName("TXNDATE")
            private String transactionDate = "";

            @SerializedName("IS_CHECKSUM_VALID")
            private String isChecksumValid = "";

            public String getIsChecksumValid() {
                return isChecksumValid;
            }

            public void setIsChecksumValid(String isChecksumValid) {
                this.isChecksumValid = isChecksumValid;
            }

            public String getTransactionDate() {
                return transactionDate;
            }

            public void setTransactionDate(String transactionDate) {
                this.transactionDate = transactionDate;
            }

            public String getRefundAmount() {
                return refundAmount;
            }

            public void setRefundAmount(String refundAmount) {
                this.refundAmount = refundAmount;
            }

            public String getPaymentMode() {
                return paymentMode;
            }

            public void setPaymentMode(String paymentMode) {
                this.paymentMode = paymentMode;
            }

            public String getMerchantId() {
                return merchantId;
            }

            public void setMerchantId(String merchantId) {
                this.merchantId = merchantId;
            }

            public String getBankName() {
                return bankName;
            }

            public void setBankName(String bankName) {
                this.bankName = bankName;
            }

            public String getResponseMessage() {
                return responseMessage;
            }

            public void setResponseMessage(String responseMessage) {
                this.responseMessage = responseMessage;
            }

            public String getResponseCode() {
                return responseCode;
            }

            public void setResponseCode(String responseCode) {
                this.responseCode = responseCode;
            }

            public String getGatewayName() {
                return gatewayName;
            }

            public void setGatewayName(String gatewayName) {
                this.gatewayName = gatewayName;
            }

            public String getCurrency() {
                return currency;
            }

            public void setCurrency(String currency) {
                this.currency = currency;
            }

            public String getTransactionType() {
                return transactionType;
            }

            public void setTransactionType(String transactionType) {
                this.transactionType = transactionType;
            }

            public String getTransactionStatus() {
                return transactionStatus;
            }

            public void setTransactionStatus(String transactionStatus) {
                this.transactionStatus = transactionStatus;
            }

            public String getTransactionAmount() {
                return transactionAmount;
            }

            public void setTransactionAmount(String transactionAmount) {
                this.transactionAmount = transactionAmount;
            }

            public String getOrderId() {
                return orderId;
            }

            public void setOrderId(String orderId) {
                this.orderId = orderId;
            }

            public String getBankTransactionId() {
                return bankTransactionId;
            }

            public void setBankTransactionId(String bankTransactionId) {
                this.bankTransactionId = bankTransactionId;
            }

            public String getTransactionId() {
                return transactionId;
            }

            public void setTransactionId(String transactionId) {
                this.transactionId = transactionId;
            }
        }
    }

    public static class Response {

    }

    public static class ErrorResponse {

    }
}
