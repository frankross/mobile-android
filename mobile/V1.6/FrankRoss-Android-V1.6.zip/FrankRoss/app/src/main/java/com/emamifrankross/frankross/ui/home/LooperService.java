/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.home;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.support.annotation.Nullable;

import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.utils.Log;

/**
 * Created by gowtham on 14/12/15.
 */
public class LooperService extends Service {

    private static final String TAG = LooperService.class.getSimpleName();

    private Handler mLooperHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            if (mLoopNotifier != null && !mIsUnbinded) {
                Log.d(TAG, "message receiver in  = " + LooperService.this);
                mLoopNotifier.onLoop();
            }
        }
    };

    private ILoopNotifier mLoopNotifier;
    private boolean mIsUnbinded = true;

    public interface ILoopNotifier {
        void onLoop();
    }

    public class LooperBinder extends Binder {

        public void startLooping(ILoopNotifier looper) {
            Log.d(TAG, "in looper binder startLooping ");
            mLoopNotifier = looper;
            LooperService.this.startLooping();
        }

        public void onPageChanged() {
            Log.d(TAG, "in looper on page changed ");
            mLooperHandler.removeMessages(1);
            LooperService.this.startLooping();
        }
    }

    private void startLooping() {
        Log.d(TAG, "start looping");
        if (!mIsUnbinded) {
            Log.d(TAG, "thread running with delay = " + ApiRequestManager.getInstance(getApplicationContext()).getLoopingDelay());
            mLooperHandler.sendEmptyMessageDelayed(1, ApiRequestManager.getInstance(getApplicationContext()).getLoopingDelay());
        }
    }

    public Binder mBinder = new LooperBinder();

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate");
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind");
        mIsUnbinded = false;
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        Log.d(TAG, "unBind");
        mIsUnbinded = true;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG, "onDestroy");
    }
}
