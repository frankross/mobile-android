/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */
package com.emamifrankross.frankross.ui.viewmodels;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.HomeBannerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;


/**
 * Created by gowtham on 6/11/15.
 */

/**
 * COMMON VIEW PAGER ITEM WITH CIRCLE INDICATOR DATA BINDER
 */
public class BannerViewDataBinder implements
        BaseRecyclerAdapter.RecyclerViewDataBinder<BannerViewHolder, BannerDataItem> {

    @Override
    public BannerViewHolder getViewHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_top_offers, parent, false);

        return new BannerViewHolder(view);
    }

    @Override
    public void bindDataToViewHolder(final BannerViewHolder viewHolder,
                                     final BannerDataItem data, int position,
                                     BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {
        final HomeBannerAdapter homeBannerAdapter = new HomeBannerAdapter(viewHolder.mTopOffersViewPager.getContext(), false, data);
        homeBannerAdapter.setOnRecyclerItemClickListener(recyclerViewClickListener);
        viewHolder.mTopOffersViewPager.setAdapter(homeBannerAdapter);

        viewHolder.mTopOffersPagerIndicator.getBackground().setAlpha((int) (0.7F * 255));
        viewHolder.mTopOffersPagerIndicator.setViewPager(viewHolder.mTopOffersViewPager);
    }

    @Override
    public int getViewType() {
        return ViewTypes.CommonViewType.TOP_OFFERS_VIEW_PAGER;
    }
}
