/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.gcm;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;

/**
 * Created by gowtham on 30/10/15.
 */
public class EFNotification implements Parcelable {

    private int notificationType;

    private long id;

    private String message;

    private String furl;

    private String imageUrl;

    private String subject;

    private String pageLink;

    private String couponCode;

    private String alertMessage;

    private String apptentiveSubject;

    private boolean isPharma;

    public EFNotification() {
    }

    public EFNotification(Parcel source) {
        notificationType = source.readInt();
        id = source.readLong();
        message = source.readString();
        furl = source.readString();
        imageUrl = source.readString();
        subject = source.readString();
        pageLink = source.readString();
        couponCode = source.readString();
        alertMessage = source.readString();
        apptentiveSubject = source.readString();
        isPharma = source.readByte() != 0;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(notificationType);
        dest.writeLong(id);
        dest.writeString(message);
        dest.writeString(furl);
        dest.writeString(imageUrl);
        dest.writeString(subject);
        dest.writeString(pageLink);
        dest.writeString(couponCode);
        dest.writeString(alertMessage);
        dest.writeString(apptentiveSubject);
        dest.writeByte((byte) (isPharma ? 1 : 0));
    }

    public static final Parcelable.Creator<EFNotification> CREATOR = new Creator<EFNotification>() {
        @Override
        public EFNotification createFromParcel(Parcel source) {
            return new EFNotification(source);
        }

        @Override
        public EFNotification[] newArray(int size) {
            return new EFNotification[0];
        }
    };

    public int getNotificationType() {
        return notificationType;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setNotificationType(int notificationType) {
        this.notificationType = notificationType;
    }

    public String getFurl() {
        return furl;
    }

    public void setFurl(String furl) {
        this.furl = furl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getPageLink() {
        return pageLink;
    }

    public void setPageLink(String pageLink) {
        this.pageLink = pageLink;
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode;
    }

    public void setAlertMessage(String alertMessage) {
        this.alertMessage = alertMessage;
    }

    public String getAlertMessage() {
        return alertMessage;
    }

    public void setApptentiveNotification(String apptentiveSubject) {
        this.apptentiveSubject = apptentiveSubject;
    }

    public boolean getIsApptentiveNotification() {
        return !TextUtils.isEmpty(apptentiveSubject);
    }

    public boolean isPharma() {
        return isPharma;
    }

    public void setIsPharma(boolean pharma) {
        isPharma = pharma;
    }

}
