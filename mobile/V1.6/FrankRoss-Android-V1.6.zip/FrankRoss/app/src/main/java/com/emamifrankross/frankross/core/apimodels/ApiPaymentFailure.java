/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gauthami on 19/5/16.
 */
public class ApiPaymentFailure {

    public static class Request {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("order")
        private Order requestPlaceOrder = new Order();

        public Order getRequestPlaceOrder() {
            return requestPlaceOrder;
        }
    }

    public static class Order {

        @SerializedName("payment_method")
        private String payment_method;

        @SerializedName("payment_instrument")
        private String payment_instrument;

        @SerializedName("payment_details")
        private ApiOrder.Order.PaymentDetails paymentDetails;

        public String getPayment_method() {
            return payment_method;
        }

        public void setPayment_method(String payment_method) {
            this.payment_method = payment_method;
        }

        public String getPayment_instrument() {
            return payment_instrument;
        }

        public void setPayment_instrument(String payment_instrument) {
            this.payment_instrument = payment_instrument;
        }

        public ApiOrder.Order.PaymentDetails getPaymentDetails() {
            return paymentDetails;
        }

        public void setPaymentDetails(ApiOrder.Order.PaymentDetails paymentDetails) {
            this.paymentDetails = paymentDetails;
        }
    }
}
