/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.VolleySingleton;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gowtham on 7/7/15.
 */

/**
 * Common product view data binder
 */
public class ProductViewDataBinder implements
        BaseRecyclerAdapter.RecyclerViewDataBinder<ProductViewHolder, ProductDataModel> {

    @Override
    public ProductViewHolder getViewHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.top_selling_product_list_item,
                parent, false);
        return new ProductViewHolder(view);
    }

    @Override
    public void bindDataToViewHolder(ProductViewHolder viewHolder,
                                     final ProductDataModel data, final int position,
                                     final BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {

        Context context = viewHolder.mProductName.getContext();
        viewHolder.mProductName.setText(data.productName);
        viewHolder.mProductBrandOrManufacturerName.setText(data.productBrandOrManufacturerName);
        Animation fadeInAnimation = AnimationUtils.loadAnimation(viewHolder.
                mProductImage.getContext(), R.anim.fade_in);
        viewHolder.mProductImage.startAnimation(fadeInAnimation);
        viewHolder.mProductImage.setImageUrl(data.productImageUrl, VolleySingleton.
                getInstance(viewHolder.mProductImage.getContext()).getImageLoader());
        viewHolder.mProductOfferAmount.setText(Utils.addRupeeSymbol(viewHolder.mProductOfferAmount.getContext(), "",
                Utils.getFormattedDouble(data.productSellingPrice)));
        viewHolder.mProductAddToCart.setVisibility(data.isAddToCartVisible ? View.VISIBLE : View.GONE);
        viewHolder.mProductAddToCart.setEnabled(data.isAvailable);
        viewHolder.mProductAddToCart.setClickable(data.isAvailable);
        viewHolder.mProductAddToCart.setTextColor(ContextCompat.getColor(context,
                data.isAvailable ? R.color.frankross_common_text_color
                        : R.color.common_header_text_color));

        if (data.isCashBack) {
            viewHolder.mProductCashbackLinLyt.setVisibility(View.VISIBLE);
            viewHolder.mProductCashbackMessage.setText(data.cashBackMessage);
        } else {
            viewHolder.mProductCashbackLinLyt.setVisibility(View.GONE);
        }

        if (data.productDiscountPercent == 0) {
            viewHolder.mProductDiscount.setVisibility(View.GONE);
            viewHolder.mProductActualAmount.setVisibility(View.GONE);
        } else {
            viewHolder.mProductDiscount.setVisibility(View.VISIBLE);
            viewHolder.mProductActualAmount.setVisibility(View.VISIBLE);
            viewHolder.mProductDiscount.setText(Utils.getDiscountFormattedDouble(data.
                    productDiscountPercent) + "% off");
            viewHolder.mProductActualAmount.setText(Utils.addRupeeSymbol(viewHolder.
                            mProductOfferAmount.getContext(), "",
                    Utils.getFormattedDouble(data.productActualPrice)));
        }

        if (recyclerViewClickListener != null) {
            viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                }
            });
            viewHolder.mProductAddToCart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                }
            });
        }
    }

    @Override
    public int getViewType() {
        return ViewTypes.CommonViewType.PRODUCT_ITEM;
    }
}