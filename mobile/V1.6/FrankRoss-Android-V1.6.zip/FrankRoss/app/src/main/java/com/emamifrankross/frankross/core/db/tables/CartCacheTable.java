/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.db.tables;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.emamifrankross.frankross.core.apimodels.RequestCartItem;
import com.emamifrankross.frankross.core.db.DBQuery;
import com.emamifrankross.frankross.core.db.DeleteQuery;
import com.emamifrankross.frankross.core.db.InsertQuery;
import com.emamifrankross.frankross.core.db.RawQuery;
import com.emamifrankross.frankross.core.db.SelectQuery;
import com.emamifrankross.frankross.core.db.UpdateQuery;
import com.emamifrankross.frankross.utils.Log;

import java.text.ParseException;
import java.util.ArrayList;

/**
 * Created by gowtham on 13/8/15.
 * This table stores the algolia products variantId and its quantity which were added to the cart in Offline mode.
 */
public class CartCacheTable extends BaseTable {
    public static final String COLUMN_KEY_VARIANT_ID = "variantId";
    public static final String COLUMN_KEY_QUANTITY = "quantity";
    public static final String TABLE_CART_CACHE = "CartCache";
    // SQl statement for fetching the algolia product quantity for the given variant id.
    public static final String RAW_QUERY_CART_ITEM_QUANTITY = "SELECT " + COLUMN_KEY_QUANTITY + " FROM " +
            TABLE_CART_CACHE + " WHERE " + COLUMN_KEY_VARIANT_ID + "=?";
    public static final byte OPERATION_ID_VARIANT_QUANTITY = 11;
    private static final String TAG = CartCacheTable.class.getSimpleName();
    // SQL Statement for creating the CART CACHE table.
    private static final String CREATE_TABLE_CART_CACHE = "CREATE TABLE IF NOT EXISTS "
            + TABLE_CART_CACHE
            + "("
            + COLUMN_KEY_VARIANT_ID
            + " INTEGER PRIMARY KEY , "
            + COLUMN_KEY_QUANTITY
            + " INTEGER ) ";

    @Override
    public void create(SQLiteDatabase db) {
        super.create(db, CREATE_TABLE_CART_CACHE);
        Log.d(TAG, CREATE_TABLE_CART_CACHE);
    }

    @Override
    public void drop(SQLiteDatabase db) {
        super.drop(db, TABLE_CART_CACHE);
    }

    /**
     * Insert the Algolia products variant id and its quantity added to cart into table
     *
     * @param db
     * @param query insert query to be used for inserting algolia products variant id and quantity
     * @return
     * @throws ClassCastException
     * @throws ParseException
     */
    @Override
    public long insert(SQLiteDatabase db, DBQuery query) throws ClassCastException, ParseException {
        InsertQuery<RequestCartItem> insertQuery = (InsertQuery<RequestCartItem>) query;
        if (db != null) {
            RequestCartItem item = insertQuery.getValues();

            long result = db.replace(TABLE_CART_CACHE, null, getContentValues(item));
            Log.d(TAG, "inserted = " + result);
        }
        return 0;
    }

    @Override
    public <T> T select(SQLiteDatabase db, DBQuery query) throws ClassCastException {
        Cursor cursor = null;
        SelectQuery selectQuery = (SelectQuery) query;

        if (db != null) {
            cursor = super.select(TABLE_CART_CACHE, db, selectQuery);

            if (cursor != null) {
                @SuppressWarnings("unchecked")
                T vlaue = (T) getCartItemsList(cursor);
                cursor.close();
                return vlaue;
            }
        }
        return null;
    }

    @Override
    public int update(SQLiteDatabase db, DBQuery query) throws ClassCastException, ParseException {
        UpdateQuery<RequestCartItem> updateQuery = (UpdateQuery<RequestCartItem>) query;

        if (db != null) {
            RequestCartItem item = updateQuery.getValues();

            return db.update(TABLE_CART_CACHE,
                    getContentValues(item),
                    updateQuery.getWhereClause(), updateQuery.getWhereArgs());
        }
        return 0;
    }

    @Override
    public int delete(SQLiteDatabase db, DBQuery query) throws ClassCastException {
        DeleteQuery deleteQuery = (DeleteQuery) query;

        return db.delete(TABLE_CART_CACHE, deleteQuery.getWhereClause(), deleteQuery.getWhereArgs());
    }

    @Override
    public Object raw(SQLiteDatabase db, DBQuery query) {
        RawQuery rawQuery = (RawQuery) query;
        Cursor cursor = null;
        cursor = db.rawQuery(rawQuery.getSqlStatement(), rawQuery.getSelectionArgs());

        if (cursor != null) {
            if (cursor.moveToFirst()) {
                switch (((RawQuery) query).getRawOperationId()) {
                    case OPERATION_ID_VARIANT_QUANTITY:
                        int quantity = cursor.getInt(cursor.getColumnIndex(COLUMN_KEY_QUANTITY));
                        cursor.close();
                        return quantity;
                    default:
                        cursor.close();
                }
            }
            cursor.close();
        }

        return 0;
    }

    private ContentValues getContentValues(RequestCartItem cart) {
        ContentValues contentValues = new ContentValues();
        if (cart != null) {
            contentValues.put(COLUMN_KEY_VARIANT_ID, cart.getVariantId());
            contentValues.put(COLUMN_KEY_QUANTITY, cart.getQuantity());
        }

        return contentValues;
    }

    private ArrayList<RequestCartItem> getCartItemsList(Cursor cursor) {

        ArrayList<RequestCartItem> cartItems = new ArrayList<>();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                RequestCartItem cartItem = new RequestCartItem();

                cartItem.setVariantId(cursor.getLong(cursor.getColumnIndex(COLUMN_KEY_VARIANT_ID)));
                cartItem.setQuantity(cursor.getInt(cursor.getColumnIndex(COLUMN_KEY_QUANTITY)));


                cartItems.add(cartItem);
            }
        }

        return cartItems;
    }
}
