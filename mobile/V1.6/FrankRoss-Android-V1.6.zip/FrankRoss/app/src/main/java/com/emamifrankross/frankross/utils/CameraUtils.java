/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.utils;

import android.media.ExifInterface;
import android.net.Uri;
import android.os.Environment;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Created by gowtham on 6/7/15.
 */
public class CameraUtils {

    private static final String TAG = "Camera Utils";
    public static final int MEDIA_TYPE_IMAGE = 1111;
    public static final int MEDIA_TYPE_VIDEO = 1112;
    private static final String DEFAULT_ALBUM_NAME = "FrankRoss";

    private static File getOutputMediaFile(String albumName, int type) {

        // External sdcard location
        File mediaStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                albumName);

        // Create the storage directory if it does not exist
        if (!mediaStorageDir.exists()) {
            if (!mediaStorageDir.mkdirs()) {
                Log.d(TAG, "Oops! Failed create " + albumName + " directory");
                return null;
            }
        }

        // Create a media file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        File mediaFile;
        if (type == MEDIA_TYPE_IMAGE) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator + "IMG_" + timeStamp + ".jpg");
        } else if (type == MEDIA_TYPE_VIDEO) {
            mediaFile = new File(mediaStorageDir.getPath() + File.separator + "VID_" + timeStamp + ".mp4");
        } else {
            return null;
        }

        return mediaFile;
    }

    public static Uri getCameraImageFileUri() {
        return getCameraImageFileUri(DEFAULT_ALBUM_NAME);
    }

    public static Uri getCameraImageFileUri(String albumName) {
        File file = getOutputMediaFile(albumName, MEDIA_TYPE_IMAGE);

        return (file != null) ? Uri.fromFile(file) : null;
    }

    public static int getCameraImageRotation(Uri photoPathUri) {
        int degree = 0;
        String photoPath = photoPathUri.getPath();
        ExifInterface ei = null;

        try {
            ei = new ExifInterface(photoPath);
        } catch (IOException e) {
            e.printStackTrace();
        }

        int orientation = ei.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);

        switch (orientation) {
            case ExifInterface.ORIENTATION_ROTATE_90:
                degree = 90;
                break;
            case ExifInterface.ORIENTATION_ROTATE_180:
                degree = 180;
                break;
            case ExifInterface.ORIENTATION_ROTATE_270:
                degree = 270;
                break;
        }

        return degree;
    }
}
