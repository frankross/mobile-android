/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.products.pharmaproductdetail;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.View;
import android.widget.Toast;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiNotifyMe;
import com.emamifrankross.frankross.core.apimodels.ApiPharmaProduct;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.BranchManager;
import com.emamifrankross.frankross.sdkmanager.FacebookManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.PharmaProductDetailAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.products.AddToCartDialogFragment;
import com.emamifrankross.frankross.ui.products.ProductDetailsBaseFragment;
import com.emamifrankross.frankross.ui.products.notify.NotifyMeDialogFragment;
import com.emamifrankross.frankross.ui.products.notify.NotifyMeSuccessDialogFragment;
import com.emamifrankross.frankross.ui.support.SupportActivity;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderItem;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.NetworkUtils;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by gauthami on 9/7/15.
 */

/**
 * This class represents the UI for Pharma product detail screen
 */
public class PharmaProductDetailFragment extends ProductDetailsBaseFragment implements
        BaseRecyclerAdapter.RecyclerItemClickListener {

    private static final String TAG = PharmaProductDetailFragment.class.getSimpleName();
    private static final String BUNDLE_KEY_VARIANT_ID = "bundle_key_variant_id";

    private PharmaProductDetailAdapter mPharmaProductDetailAdapter;
    private List<BaseRecyclerAdapter.IViewType> mPharmaProductDetailData = new ArrayList<>();
    private ApiPharmaProduct mPharmaProductDetail;

    private boolean mIsAvailable = false;
    private boolean mIsNotifyMe = false;
    private long mVariantId;

    public static PharmaProductDetailFragment create(long variantId) {
        PharmaProductDetailFragment fragment = new PharmaProductDetailFragment();
        Bundle bundle = new Bundle();
        bundle.putLong(BUNDLE_KEY_VARIANT_ID, variantId);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null)
            mVariantId = getArguments().getLong(BUNDLE_KEY_VARIANT_ID, 0);
        mPharmaProductDetailAdapter = new PharmaProductDetailAdapter(mPharmaProductDetailData);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PHARMA_PDP_VISIT_EVENT);
        getAdapterData();
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initRecyclerViews(view);
        mToolbarInteractionListener.updateToolbar(this);
        mAddToCartLayout.setVisibility(mPharmaProductDetailData.size() > 0 ? View.VISIBLE : View.GONE);
        setAddToCartBtnState();
    }

    private void initRecyclerViews(View view) {
        RecyclerView recyclerView = (RecyclerView) view.findViewById(R.id.product_detail_recycler_view);
        recyclerView.setHasFixedSize(false);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mPharmaProductDetailAdapter.setRecyclerItemClickListener(this);
        recyclerView.setAdapter(mPharmaProductDetailAdapter);
    }

    /**
     * Method that populates the Pharma product details screen data
     */
    private void getAdapterData() {
        if (NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
            addPharmaProductInfo();
        } else {
            showAlert(getString(R.string.please_check_your_network_connection));
        }
    }

    /**
     * Method that requests for Pharma product info
     */
    private void addPharmaProductInfo() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetPharmaProductDetailsRequest(mVariantId, new ApiRequestManager.IGetPharmaProductDetailResultNotifier() {

            @Override
            public void onPharmaProductDetailFetched(ApiPharmaProduct pharmaProductDetail) {
                mPharmaProductDetail = pharmaProductDetail;
                mIsAvailable = pharmaProductDetail.isAvailable();
                mIsNotifyMe = pharmaProductDetail.isNotifyMe();
                mAddToCartLayout.setVisibility(View.VISIBLE);
                loadBasicInfoTab();
            }
        }, this, this);
    }


    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {
            case ViewTypes.ProductDetailViewType.TAB_HEADER:
                switch (view.getId()) {
                    case R.id.pharma_tab_title_basic_info_tv:
                        if (NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
                            loadBasicInfoTab();
                        } else {
                            showAlert(getString(R.string.please_check_your_network_connection));
                        }
                        break;
                    case R.id.pharma_tab_title_more_info_tv:
                        if (NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
                            loadMoreInfoTab();
                        } else {
                            showAlert(getString(R.string.please_check_your_network_connection));
                        }
                        break;
                    default:
                        break;
                }
                break;
            case ViewTypes.ProductDetailViewType.QUESTION_AND_ANSWER:
                loadQuestionAndAnswerFragment((PharmaProductDetailAdapter.QuestionAnswerViewDataItem) object);
                break;
            case ViewTypes.ProductDetailViewType.MEDICINE_BASIC_INFO:
                PharmaProductDetailAdapter.MedicineBasicInfoDataItem medicineBasicInfoDataItem =
                        (PharmaProductDetailAdapter.MedicineBasicInfoDataItem) object;
                if (medicineBasicInfoDataItem.hasMultipleIngredient) {
                    loadMoreIngredientsFragment(getString(R.string.product_details_active_ingridients),
                            (medicineBasicInfoDataItem.activeIngredients));
                }
                break;
        }
    }

    /**
     * Method loads a screen where detailed answer will be displayed
     */
    private void loadMoreIngredientsFragment(String title, String activeIngredients) {
        mFragmentInteractionListener.loadFragment(getId(),
                QuestionAndAnswerFragment.create(title, activeIngredients),
                null, R.anim.push_left_in, R.anim.fade_out,
                FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    /**
     * Method loads a screen where detailed answer will be displayed
     */
    private void loadQuestionAndAnswerFragment(PharmaProductDetailAdapter.QuestionAnswerViewDataItem object) {
        mFragmentInteractionListener.loadFragment(getId(),
                QuestionAndAnswerFragment.create(object.question, object.answer),
                null, R.anim.push_left_in, R.anim.fade_out,
                FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    /**
     * Method populates the data for Basic Info Tab
     */
    private void loadBasicInfoTab() {
        new AsyncTask<Void, Void, ArrayList<BaseRecyclerAdapter.IViewType>>() {
            @Override
            protected ArrayList<BaseRecyclerAdapter.IViewType> doInBackground(Void... params) {
                ArrayList<BaseRecyclerAdapter.IViewType> pharmaDetailData = new ArrayList<BaseRecyclerAdapter.IViewType>();

                PharmaProductDetailAdapter.ProductDetailsDataItem item = new PharmaProductDetailAdapter.ProductDetailsDataItem();
                item.mPharmaProduct = mPharmaProductDetail;
                pharmaDetailData.add(item);

                PharmaProductDetailAdapter.PharmaProductImageViewPagerDataItem imageUrlsItem =
                        new PharmaProductDetailAdapter.PharmaProductImageViewPagerDataItem();
                imageUrlsItem.mPharmaProductImageList = mPharmaProductDetail.getProductImageUrls();
                pharmaDetailData.add(imageUrlsItem);

                //pharmaDetailData.add(new RecyclerBorderItem(1));
                //pharmaDetailData.add(new PharmaProductDetailAdapter.TabHeaderDataItem());
                pharmaDetailData.add(new RecyclerBorderItem(1));
                PharmaProductDetailAdapter.MedicineBasicInfoDataItem basicInfoDataItem =
                        new PharmaProductDetailAdapter.MedicineBasicInfoDataItem();
                basicInfoDataItem.activeIngredients = mPharmaProductDetail.getBasicInfo().getActiveIngredients();
                basicInfoDataItem.activeIngredient = mPharmaProductDetail.getBasicInfo().getActiveIngredient();
                basicInfoDataItem.productForm = mPharmaProductDetail.getBasicInfo().getForm();
                basicInfoDataItem.routeOfAdmin = mPharmaProductDetail.getBasicInfo().getRouteOfAdmin();
                basicInfoDataItem.hasMultipleIngredient = mPharmaProductDetail.getBasicInfo().isHasMultipleActiveIngredient();
                pharmaDetailData.add(basicInfoDataItem);

                /*PharmaProductDetailAdapter.QuestionAnswerViewDataItem questionAnswerViewDataItem =
                new PharmaProductDetailAdapter.QuestionAnswerViewDataItem();
                questionAnswerViewDataItem.question = getString(R.string.pharma_quest_why_prescribe);
                questionAnswerViewDataItem.answer = mPharmaProductDetail.getBasicInfo().getWhyPrescribe();
                pharmaDetailData.add(questionAnswerViewDataItem);

                questionAnswerViewDataItem = new PharmaProductDetailAdapter.QuestionAnswerViewDataItem();
                questionAnswerViewDataItem.question = getString(R.string.pharma_quest_how_it_should_be_taken);
                questionAnswerViewDataItem.answer = mPharmaProductDetail.getBasicInfo().getHowItShouldBeTaken();
                pharmaDetailData.add(questionAnswerViewDataItem);

                questionAnswerViewDataItem = new PharmaProductDetailAdapter.QuestionAnswerViewDataItem();
                questionAnswerViewDataItem.question = getString(R.string.pharma_quest_recommended);
                questionAnswerViewDataItem.answer = mPharmaProductDetail.getBasicInfo().getRecommendedDosage();
                pharmaDetailData.add(questionAnswerViewDataItem);*/

                return pharmaDetailData;
            }

            @Override
            protected void onPostExecute(ArrayList<BaseRecyclerAdapter.IViewType> pharmaDetailData) {
                if (getActivity() != null && getView() != null) {
                    mPharmaProductDetailData.clear();
                    mPharmaProductDetailData.addAll(pharmaDetailData);
                    mPharmaProductDetailAdapter.notifyDataSetChanged();
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    setAddToCartBtnState();
                }
            }
        }.execute();
    }

    /**
     * Method populates the data for More Info Tab
     */
    private void loadMoreInfoTab() {
        new AsyncTask<Void, Void, ArrayList<BaseRecyclerAdapter.IViewType>>() {
            @Override
            protected ArrayList<BaseRecyclerAdapter.IViewType> doInBackground(Void... params) {
                ArrayList<BaseRecyclerAdapter.IViewType> pharmaDetailData = new ArrayList<BaseRecyclerAdapter.IViewType>();

                PharmaProductDetailAdapter.ProductDetailsDataItem item = new PharmaProductDetailAdapter.ProductDetailsDataItem();
                item.mPharmaProduct = mPharmaProductDetail;
                pharmaDetailData.add(item);

                PharmaProductDetailAdapter.PharmaProductImageViewPagerDataItem imageUrlsItem =
                        new PharmaProductDetailAdapter.PharmaProductImageViewPagerDataItem();
                imageUrlsItem.mPharmaProductImageList = mPharmaProductDetail.getProductImageUrls();
                pharmaDetailData.add(imageUrlsItem);

                pharmaDetailData.add(new RecyclerBorderItem(1));
                pharmaDetailData.add(new PharmaProductDetailAdapter.TabHeaderDataItem());
                pharmaDetailData.add(new RecyclerBorderItem(1));

                PharmaProductDetailAdapter.QuestionAnswerViewDataItem questionAnswerViewDataItem =
                        new PharmaProductDetailAdapter.QuestionAnswerViewDataItem();
                questionAnswerViewDataItem.question = getString(R.string.pharma_quest_when_not_to_be_taken);
                questionAnswerViewDataItem.answer = mPharmaProductDetail.getBasicInfo().getWhyPrescribe();
                pharmaDetailData.add(questionAnswerViewDataItem);

                questionAnswerViewDataItem = new PharmaProductDetailAdapter.QuestionAnswerViewDataItem();
                questionAnswerViewDataItem.question = getString(R.string.pharma_quest_precautions);
                questionAnswerViewDataItem.answer = mPharmaProductDetail.getBasicInfo().getHowItShouldBeTaken();
                pharmaDetailData.add(questionAnswerViewDataItem);

                questionAnswerViewDataItem = new PharmaProductDetailAdapter.QuestionAnswerViewDataItem();
                questionAnswerViewDataItem.question = getString(R.string.pharma_quest_side_effects);
                questionAnswerViewDataItem.answer = mPharmaProductDetail.getBasicInfo().getRecommendedDosage();
                pharmaDetailData.add(questionAnswerViewDataItem);

                questionAnswerViewDataItem = new PharmaProductDetailAdapter.QuestionAnswerViewDataItem();
                questionAnswerViewDataItem.question = getString(R.string.pharma_quest_other_precautions);
                questionAnswerViewDataItem.answer = mPharmaProductDetail.getBasicInfo().getRecommendedDosage();
                pharmaDetailData.add(questionAnswerViewDataItem);

                return pharmaDetailData;
            }

            @Override
            protected void onPostExecute(ArrayList<BaseRecyclerAdapter.IViewType> pharmaDetailData) {
                if (getActivity() != null && getView() != null) {
                    mPharmaProductDetailData.clear();
                    mPharmaProductDetailData.addAll(pharmaDetailData);
                    mPharmaProductDetailAdapter.notifyDataSetChanged();
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    setAddToCartBtnState();
                }
            }
        }.execute();
    }

    @Override
    protected void onNotifyMeClicked() {
        super.onNotifyMeClicked();
        if (TextUtils.isEmpty(Utils.getUserID(getActivity().getApplicationContext()))) {
            showNotifyMeViaMobileNumberDialog();
        } else {
            performNotifyMeSignedInUserRequest();
        }
    }

    /**
     * Method that receives the callback from parent activity on notify me to the entered mobile number Done tap
     *
     * @param mobileNumber the mobile number to which the product related notification/sms will be sent
     */
    public void performNotifyMeNonSignedInUserRequest(String mobileNumber) {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performNotifyMeNonSignedInUserRequest(mVariantId, mobileNumber,
                new ApiRequestManager.INotifyMeNonSignedInUserResultNotifier() {
                    @Override
                    public void onNotifyMeNonSignedInUserRequestResultFetched(
                            ApiNotifyMe.Response apiNotifyMeNonSignedInUser) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.NOTIFY_ME_CONFIRM_TAP_EVENT);
                        showNotifyMeSuccessDialog();
                    }

                    @Override
                    public void onNotifyMeNonSignedInUserError(String errorMessage) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        showAlert(errorMessage);
                    }
                }, this, this);
    }

    /**
     * Method that requests for signed in users notify me
     */
    private void performNotifyMeSignedInUserRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performNotifyMeSignedInUserRequest(mVariantId,
                new ApiRequestManager.INotifyMeSignedInUserResultNotifier() {
                    @Override
                    public void onNotifyMeSignedInUserRequestResultFetched(
                            ApiNotifyMe.Response apiNotifyMeSignedInUser) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.NOTIFY_ME_CONFIRM_TAP_EVENT);
                        showNotifyMeSuccessDialog();
                    }

                    @Override
                    public void onNotifyMeSignedInUserError(String errorMessage) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        showAlert(errorMessage);
                    }
                }, this, this);
    }

    /**
     * Method that displays the Notify me dialog when product is inactive
     */
    private void showNotifyMeViaMobileNumberDialog() {
        try {
            NotifyMeDialogFragment notifyMeDialogFragment = new NotifyMeDialogFragment();
            notifyMeDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
        } catch (IllegalStateException illegalStateException) {
            //Not to instantiate a fragment onSavedInstance
        }
    }

    /**
     * Method that displays the Notify me success dialog
     */
    private void showNotifyMeSuccessDialog() {
        try {
            NotifyMeSuccessDialogFragment notifyMeSuccessDialogFragment = new NotifyMeSuccessDialogFragment();
            notifyMeSuccessDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
        } catch (IllegalStateException illegalStateException) {
            //Not to instantiate a fragment onSavedInstance
        }
    }

    /**
     * Method to update the text color and enabling based on the availability of the product
     */
    private void setAddToCartBtnState() {
        if (mIsAvailable) {
            mAddToCart.setEnabled(true);
            mAddToCart.setTextColor(ContextCompat.getColor(getActivity(), R.color.white_background));
            mAddToCart.setText(getResources().getString(R.string.product_detail_add_to_cart_button_title));
        } else if (mIsNotifyMe) {
            mAddToCart.setEnabled(true);
            mAddToCart.setTextColor(ContextCompat.getColor(getActivity(), R.color.white_background));
            mAddToCart.setText(getResources().getString(R.string.product_detail_notify_me_button_title));
        }
    }

    /**
     * Method that requests for adding a product to the cart;If success, displays the success msg
     */
    public void performAddToCartRequest(int cartQuantity) {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performAddCartRequest(mVariantId, cartQuantity, new ApiRequestManager.IAddCartResultNotifier() {
            @Override
            public void onProductAdded() {
                FacebookManager.logFacebookAddToCartEvent(getActivity(), mPharmaProductDetail.getProductName(),
                        mVariantId + "", getString(R.string.facebook_events_parameter_currency));
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ADD_TO_CART_FROM_PDP);
                mFragmentInteractionListener.hideBlockingProgressBar();
                Toast.makeText(getActivity().getApplicationContext(),
                        getString(R.string.add_to_cart_success_msg), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onProductAddFailed() {
                mFragmentInteractionListener.hideBlockingProgressBar();
                Toast.makeText(getActivity().getApplicationContext(),
                        getString(R.string.add_to_cart_failure_msg), Toast.LENGTH_SHORT).show();
            }
        }, this, this);
    }

    @Override
    public void onAddToCartClicked() {
        super.onAddToCartClicked();

        if (NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
            if (mPharmaProductDetail != null) {
                mApiRequestManager.getCartItemQuantity(mPharmaProductDetail.getId(), new ApiRequestManager.IGetCartItemQuantityListener() {
                    @Override
                    public void cartItemQuantity(int quantity) {
                        if (quantity == 0) {
                            quantity = 1;
                        }

                        AddToCartDialogFragment addToCartDialogFragment = new AddToCartDialogFragment();
                        addToCartDialogFragment.create(Utils.getStripInfo(mPharmaProductDetail.getInnerPackageQuantity(),
                                mPharmaProductDetail.getOuterPackageQuantity(), ""),
                                mPharmaProductDetail.getMaxOrderableQuantity(), quantity);
                        addToCartDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
                    }
                });
            }
        } else {
            showAlert(getString(R.string.please_check_your_network_connection));
        }
    }

    @Override
    public void onSupportClicked() {
        super.onSupportClicked();
        startActivity(SupportActivity.getActivityIntent(getActivity().getApplicationContext()));
    }

    @Override
    protected void onCartClicked() {
        Map<String, String> cartClickData = Utils.cartToolbarClickDataForAnalytics(Constants.PHARMA_PDP_SCREEN_NAME,
                FrankRossEvents.VIEW_CART_FROM_TOOLBAR_SCREEN_NAME);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_CART_FROM_TOOLBAR_EVENT, cartClickData);
        super.onCartClicked();
    }

    @Override
    protected void onProductDetailShareClicked() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PDP_SHARING_TAP_EVENT);
        if (NetworkUtils.isNetworkConnected(getActivity())) {

            String pdpShareSubject = mApiRequestManager.getSettingsResponse().getPdpShareSubject();
            String pdpShareText = mApiRequestManager.getSettingsResponse().getPdpShareText();

            String title = "";
            String description = "";
            String imageUrl = "";

            if (mPharmaProductDetail != null) {
                title = mPharmaProductDetail.getProductName();
                description = mPharmaProductDetail.getProductDescription();

                if (!mPharmaProductDetail.getProductImageUrls().isEmpty()) {
                    imageUrl = mPharmaProductDetail.getProductImageUrls().get(0);
                    imageUrl = imageUrl.replaceFirst("/normal/", "/small/");
                }
            }

            if (pdpShareSubject.contains(getResources().getString(R.string.settings_product_name_placeholder)))
                pdpShareSubject = pdpShareSubject.replaceAll(getResources().getString(R.string.settings_product_name_placeholder),
                        mPharmaProductDetail.getProductName());
            if (pdpShareText.contains(getResources().getString(R.string.settings_product_name_placeholder)))
                pdpShareText = pdpShareText.replaceAll(getResources().getString(R.string.settings_product_name_placeholder),
                        mPharmaProductDetail.getProductName());
            if (pdpShareText.contains(getString(R.string.settings_link_name_placeholder)))
                pdpShareText = pdpShareText.replaceAll(getResources().getString(R.string.settings_link_name_placeholder), "");

            BranchManager.showBranchShareSheetForPdp(getActivity(),
                    pdpShareSubject,
                    pdpShareText,
                    mVariantId, getString(R.string.pharma_product_share_using_branch), title, description, imageUrl);
        } else {
            showAlert(getString(R.string.no_connection_error));
        }
        super.onProductDetailShareClicked();
    }
}
