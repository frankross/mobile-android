/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.app.Activity;
import android.content.Context;
import android.graphics.Paint;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.android.volley.toolbox.NetworkImageView;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiPharmaProduct;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.CirclePageIndicator;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderDataBinder;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 14/7/15.
 * <p> Adapter class for Pharma Product Detail Section</p>
 * <p>Supports the Five View Types </p>
 * <p> 1 : PRODUCT DETAILS VIEW TYPE </p>
 * <p> 2 : TOP OFFERS VIEW PAGER VIEW TYPE  </p>
 * <p> 3 : TAB HEADER VIEW TYPE </p>
 * <p> 4 : TAB BASIC INFO VIEW TYPE </p>
 * <p> 5 : TAB MORE INFO VIEW TYPE </p>
 */
public class PharmaProductDetailAdapter extends BaseRecyclerAdapter {

    public PharmaProductDetailAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewDataBinderList = new ArrayList<>(1);
        viewDataBinderList.add(new ProductDetailsViewDataBinder());
        viewDataBinderList.add(new PharmaProductImageViewPagerViewDataBinder());
        viewDataBinderList.add(new TabHeaderViewDataBinder());
        viewDataBinderList.add(new MedicineBasicInfoViewDataBinder());
        viewDataBinderList.add(new QuestionAnswerViewDataBinder());
        viewDataBinderList.add(new RecyclerBorderDataBinder());

        return viewDataBinderList;
    }

    /**
     * PRODUCT DETAILS VIEW TYPE
     */
    public static class ProductDetailsDataItem implements IViewType {

        public ApiPharmaProduct mPharmaProduct;

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.PRODUCT_DETAILS;
        }
    }

    private static class ProductDetailsViewHolder extends RecyclerView.ViewHolder {

        private final RobotoTextView mPharmacyProductName;
        private final RobotoTextView mPharmacyProductCompanyName;
        private final RobotoTextView mPharmacyProductStripInfo;
        private final RobotoTextView mPharmacyProductOfferPrice;
        private final RobotoTextView mPharmacyProductActualPrice;
        private final RobotoTextView mPharmacyProductDiscount;
        private final RobotoTextView mPharmacyProductAvailability;
        private final RobotoTextView mPharmacyProductPrescriptionRequired;
        private final RobotoTextView mPharmacyProductCashBackMessage;
        private final LinearLayout mPharmacyProductCashBackLinLyt;
        private final NetworkImageView mPharmaIconImage;

        public ProductDetailsViewHolder(View itemView) {
            super(itemView);

            mPharmacyProductName = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_name_tv);
            mPharmacyProductCompanyName = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_medicine_company_tv);
            mPharmacyProductStripInfo = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_strip_info_tv);
            mPharmacyProductOfferPrice = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_offer_price_tv);
            mPharmacyProductActualPrice = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_actual_price_tv);
            mPharmacyProductDiscount = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_discount_tv);
            mPharmacyProductAvailability = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_availabilty_txt_tv);
            mPharmacyProductPrescriptionRequired = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_prescription_required_txt_tv);
            mPharmaIconImage = (NetworkImageView) itemView.findViewById(R.id.product_info_medicine_icon);

            mPharmacyProductCashBackLinLyt = (LinearLayout) itemView.findViewById(R.id.pharmacy_product_detail_cashback_message_linLyt);
            mPharmacyProductCashBackMessage = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_detail_cashback_message_tv);

            mPharmacyProductActualPrice.setPaintFlags(mPharmacyProductActualPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }
    }

    private static class ProductDetailsViewDataBinder implements
            RecyclerViewDataBinder<ProductDetailsViewHolder, ProductDetailsDataItem> {

        @Override
        public ProductDetailsViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pharmacy_product_info, parent, false);

            return new ProductDetailsViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(ProductDetailsViewHolder viewHolder,
                                         final ProductDetailsDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mPharmacyProductName.setText(data.mPharmaProduct.getProductName());
            viewHolder.mPharmacyProductCompanyName.setText(data.mPharmaProduct.getManufacturerName());
            viewHolder.mPharmacyProductStripInfo.setText(data.mPharmaProduct.getOuterPackageQuantity() +
                    " of " + data.mPharmaProduct.getInnerPackageQuantity());
            viewHolder.mPharmacyProductAvailability.setText(data.mPharmaProduct.getProductInventoryLabel());
            viewHolder.mPharmacyProductPrescriptionRequired.setVisibility((data.mPharmaProduct.isPrescriptionRequired()
                    ? View.VISIBLE : View.INVISIBLE));

            if (data.mPharmaProduct.isCashBack()) {
                viewHolder.mPharmacyProductCashBackLinLyt.setVisibility(View.VISIBLE);
                viewHolder.mPharmacyProductCashBackMessage.setText(data.mPharmaProduct.getProductCashBackMessage());
            } else {
                viewHolder.mPharmacyProductCashBackLinLyt.setVisibility(View.GONE);
            }

            if (data.mPharmaProduct.getDiscount() > 0) {
                viewHolder.mPharmacyProductDiscount.setVisibility(View.VISIBLE);
                viewHolder.mPharmacyProductActualPrice.setVisibility(View.VISIBLE);
                viewHolder.mPharmacyProductDiscount.setText(Utils.getDiscountFormattedDouble(data.mPharmaProduct.getDiscount()) + "% off");
                viewHolder.mPharmacyProductActualPrice.setText(Utils.addRupeeSymbol(viewHolder.mPharmacyProductActualPrice.getContext(), "",
                        Utils.getFormattedDouble(data.mPharmaProduct.getMrpPrice())));
                viewHolder.mPharmacyProductOfferPrice.setText(Utils.addRupeeSymbol(viewHolder.mPharmacyProductOfferPrice.getContext(), "",
                        Utils.getFormattedDouble(data.mPharmaProduct.getPromotionalPrice())));
            } else {
                viewHolder.mPharmacyProductDiscount.setVisibility(View.GONE);
                viewHolder.mPharmacyProductActualPrice.setVisibility(View.GONE);
                viewHolder.mPharmacyProductOfferPrice.setText(Utils.addRupeeSymbol(viewHolder.mPharmacyProductOfferPrice.getContext(), "",
                        Utils.getFormattedDouble(data.mPharmaProduct.getSellingPrice())));
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.PRODUCT_DETAILS;
        }
    }

    /**
     * TOP OFFERS VIEW PAGER VIEW TYPE
     */

    public static class PharmaProductImageViewPagerDataItem implements IViewType {
        public List<String> mPharmaProductImageList;

        @Override
        public int getViewType() {
            return ViewTypes.CommonViewType.TOP_OFFERS_VIEW_PAGER;
        }
    }

    private static class PharmaProductImageViewPagerViewHolder extends RecyclerView.ViewHolder {
        private ViewPager mPharmaProductImageViewPager;
        private CirclePageIndicator mPharmaProductImagePagerIndicator;

        public PharmaProductImageViewPagerViewHolder(View itemView) {
            super(itemView);
            mPharmaProductImageViewPager = (ViewPager) itemView.findViewById(R.id.home_top_offers_pager);
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (int) (0.35 * Utils.getDisplayHeight((Activity) mPharmaProductImageViewPager.getContext())));
            mPharmaProductImageViewPager.setLayoutParams(layoutParams);
            mPharmaProductImagePagerIndicator = (CirclePageIndicator) itemView.findViewById(R.id.top_offers_pager_indicator);
        }
    }

    private static class PharmaProductImageViewPagerViewDataBinder implements
            RecyclerViewDataBinder<PharmaProductImageViewPagerViewHolder, PharmaProductImageViewPagerDataItem> {

        @Override
        public PharmaProductImageViewPagerViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_top_offers, parent, false);

            return new PharmaProductImageViewPagerViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final PharmaProductImageViewPagerViewHolder viewHolder,
                                         PharmaProductImageViewPagerDataItem data, int position,
                                         RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mPharmaProductImageViewPager.setAdapter(new TopOffersAdapter(data.mPharmaProductImageList));
            if (data.mPharmaProductImageList.size() > 1) {
                viewHolder.mPharmaProductImagePagerIndicator.getBackground().setAlpha((int) (0.7F * 255));
                viewHolder.mPharmaProductImagePagerIndicator.setViewPager(viewHolder.mPharmaProductImageViewPager);

            }
            viewHolder.mPharmaProductImageViewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
                @Override
                public void onPageSelected(int position) {
                    viewHolder.mPharmaProductImagePagerIndicator.setCurrentItem(position);
                }
            });
        }

        @Override
        public int getViewType() {
            return ViewTypes.CommonViewType.TOP_OFFERS_VIEW_PAGER;
        }
    }

    /**
     * TAB HEADER VIEW TYPE
     */
    public static class TabHeaderDataItem implements IViewType {

        public String tabHeaderBasicInfo;
        public String tabHeaderMoreInfo;
        public boolean isBasicInfoClicked = true;

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.TAB_HEADER;
        }
    }

    private static class TabHeaderViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mTabHeaderBasicInfo;
        private RobotoTextView mTabHeaderMoreInfo;

        public TabHeaderViewHolder(View itemView) {
            super(itemView);
            mTabHeaderBasicInfo = (RobotoTextView) itemView.findViewById(R.id.pharma_tab_title_basic_info_tv);
            mTabHeaderMoreInfo = (RobotoTextView) itemView.findViewById(R.id.pharma_tab_title_more_info_tv);
        }
    }

    private static class TabHeaderViewDataBinder implements
            RecyclerViewDataBinder<TabHeaderViewHolder, TabHeaderDataItem> {

        @Override
        public TabHeaderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pharma_product_detail_tab_header, parent, false);

            return new TabHeaderViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final TabHeaderViewHolder viewHolder,
                                         final TabHeaderDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            final Context context = viewHolder.mTabHeaderBasicInfo.getContext();
            if (recyclerViewClickListener != null) {
                viewHolder.mTabHeaderBasicInfo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        viewHolder.mTabHeaderBasicInfo.setTextColor(
                                ContextCompat.getColor(context, data.isBasicInfoClicked ? R.color.common_sub_header_text_color :
                                        R.color.common_header_text_color));
                        viewHolder.mTabHeaderMoreInfo.setTextColor(ContextCompat.getColor(
                                context, !data.isBasicInfoClicked ? R.color.common_sub_header_text_color :
                                        R.color.common_header_text_color));
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
                viewHolder.mTabHeaderMoreInfo.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        viewHolder.mTabHeaderMoreInfo.setTextColor(
                                ContextCompat.getColor(context, data.isBasicInfoClicked ? R.color.common_sub_header_text_color :
                                        R.color.common_header_text_color));
                        viewHolder.mTabHeaderBasicInfo.setTextColor(ContextCompat.getColor(
                                context, !data.isBasicInfoClicked ? R.color.common_sub_header_text_color :
                                        R.color.common_header_text_color));
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.TAB_HEADER;
        }
    }

    public static class MedicineBasicInfoDataItem implements IViewType {

        public String activeIngredients;
        public String activeIngredient;
        public String productForm;
        public String routeOfAdmin;
        public boolean hasMultipleIngredient = false;

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.MEDICINE_BASIC_INFO;
        }
    }

    private static class MedicineBasicInfoViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mActiveIngredients;
        private RobotoTextView mProductForm;
        private RobotoTextView mRouteOfAdmin;
        private LinearLayout mShowActiveIngredientsLinLyt;
        private ImageView mShowActiveIngredients;

        public MedicineBasicInfoViewHolder(View view) {
            super(view);

            mActiveIngredients = (RobotoTextView) view.findViewById(R.id.pharmacy_attributes_active_ingredients_tv);
            mProductForm = (RobotoTextView) view.findViewById(R.id.pharmacy_attributes_form_tv);
            mRouteOfAdmin = (RobotoTextView) view.findViewById(R.id.pharmacy_attributes_route_of_admin_tv);
            mShowActiveIngredients = (ImageView) view.findViewById(R.id.pharmacy_attributes_active_ingredients_iv);
            mShowActiveIngredientsLinLyt = (LinearLayout) view.findViewById(R.id.pharmacy_attributes_active_ingredients_linLyt);
        }
    }

    private static class MedicineBasicInfoViewDataBinder implements
            RecyclerViewDataBinder<MedicineBasicInfoViewHolder, MedicineBasicInfoDataItem> {

        @Override
        public MedicineBasicInfoViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pharma_product_details_basic_info, parent, false);

            return new MedicineBasicInfoViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(MedicineBasicInfoViewHolder viewHolder, final MedicineBasicInfoDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mActiveIngredients.setText(data.activeIngredient);
            viewHolder.mProductForm.setText(data.productForm);
            viewHolder.mRouteOfAdmin.setText(data.routeOfAdmin);

            setAnimation(viewHolder.itemView);

            viewHolder.mShowActiveIngredients.setVisibility(data.hasMultipleIngredient ? View.VISIBLE : View.GONE);

            if (recyclerViewClickListener != null) {
                viewHolder.mShowActiveIngredientsLinLyt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.MEDICINE_BASIC_INFO;
        }
    }

    private static void setAnimation(View itemView) {
        Animation a = AnimationUtils.loadAnimation(itemView.getContext(), R.anim.fade_in);
        a.reset();
        itemView.clearAnimation();
        itemView.startAnimation(a);
    }

    public static class QuestionAnswerViewDataItem implements IViewType {

        public String question;
        public String answer;

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.QUESTION_AND_ANSWER;
        }
    }

    private static class QuestionAnswerViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mMedicineRelatedQuestion;
        private RobotoTextView mMedicineRelatedAnswer;

        public QuestionAnswerViewHolder(View view) {
            super(view);

            mMedicineRelatedQuestion = (RobotoTextView) view.findViewById(R.id.pharmacy_basic_info_medicine_name_tv);
            mMedicineRelatedAnswer = (RobotoTextView) view.findViewById(R.id.pharmacy_basic_info_medicine_company_tv);
        }
    }

    public static class QuestionAnswerViewDataBinder implements
            RecyclerViewDataBinder<QuestionAnswerViewHolder, QuestionAnswerViewDataItem> {

        @Override
        public QuestionAnswerViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pharma_product_details_more_info, parent, false);

            return new QuestionAnswerViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(QuestionAnswerViewHolder viewHolder,
                                         final QuestionAnswerViewDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mMedicineRelatedQuestion.setText(data.question);
            viewHolder.mMedicineRelatedAnswer.setText(data.answer);

            setAnimation(viewHolder.itemView);
            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.QUESTION_AND_ANSWER;
        }
    }
}
