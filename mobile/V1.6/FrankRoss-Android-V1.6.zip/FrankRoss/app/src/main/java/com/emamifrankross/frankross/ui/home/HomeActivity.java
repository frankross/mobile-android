/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.home;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.widget.Toast;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiNewTag;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.core.network.IApiRequestCancel;
import com.emamifrankross.frankross.core.network.UrlConstants;
import com.emamifrankross.frankross.gcm.EFNotification;
import com.emamifrankross.frankross.gcm.NotificationTypes;
import com.emamifrankross.frankross.gcm.RegistrationIntentService;
import com.emamifrankross.frankross.sdkmanager.ApptentiveManager;
import com.emamifrankross.frankross.sdkmanager.BranchManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.account.AccountFragment;
import com.emamifrankross.frankross.ui.account.login.LogInActivity;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;
import com.emamifrankross.frankross.ui.common.AlertError;
import com.emamifrankross.frankross.ui.common.AppFlow;
import com.emamifrankross.frankross.ui.common.BaseDrawerActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IErrorHandler;
import com.emamifrankross.frankross.ui.common.WebViewActivity;
import com.emamifrankross.frankross.ui.order.OrderHistoryActivity;
import com.emamifrankross.frankross.ui.pharmacy.PharmacyActivity;
import com.emamifrankross.frankross.ui.pharmacy.PharmacyFragment;
import com.emamifrankross.frankross.ui.pharmacy.ProductListingActivity;
import com.emamifrankross.frankross.ui.products.ProductDetailActivity;
import com.emamifrankross.frankross.ui.referral.ReferFriendActivity;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Log;
import com.emamifrankross.frankross.utils.PreferenceUtils;
import com.emamifrankross.frankross.utils.Utils;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import io.branch.referral.Branch;
import io.branch.referral.BranchError;

/**
 * Created by gowtham on 25/6/15.
 */

/**
 * This class manages the fragment transactions for Home based on the intents and its data
 */
public class HomeActivity extends BaseDrawerActivity implements IErrorHandler, IApiRequestCancel,
        StagingUrlFragment.IOnUrlSelectListener, NotificationTypes {

    public static final String ACCOUNT_FRAGMENT_TAG = "001";
    public static final String HOME_FRAGMENT_TAG = "002";
    private static final String TAG = HomeActivity.class.getSimpleName();
    private static final String EXTRA_NOTIFICATION_DATA = "Notification_data";
    private static final String PHARMACY_FRAGMENT_TAG = "003";

    private static final String EXTRA_FRAGMENT_TAG = "fragment_tag";
    private static final String EXTRA_IS_FROM_CART = "back_to_home";
    private static final int DEEPLINK_WEB_PAGE_URL_INDEX = 13;
    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private ApiRequestManager mApiRequestManager;
    private AppFlow mAppFlow = AppFlow.MAIN_FLOW;
    private String mFragmentTag = HOME_FRAGMENT_TAG;
    private String mProductType = "";
    private String mVariantId = "";

    public static Intent getActivityIntent(Context context, String fragmentTag) {
        Intent homeActivityIntent = new Intent(context, HomeActivity.class);
        // homeActivityIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        homeActivityIntent.putExtra(EXTRA_FRAGMENT_TAG, fragmentTag);

        return homeActivityIntent;
    }

    public static Intent getActivityIntentBackToHome(Context context, String fragmentTag, boolean isFromBackToHome) {
        Intent homeActivityIntent = new Intent(context, HomeActivity.class);
        homeActivityIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        homeActivityIntent.putExtra(EXTRA_FRAGMENT_TAG, fragmentTag);
        homeActivityIntent.putExtra(EXTRA_IS_FROM_CART, isFromBackToHome);

        return homeActivityIntent;
    }

    public static Intent getActivityIntentForNotification(Context context, String fragmentTag,
                                                          EFNotification efNotification) {
        Intent homeActivityIntent = new Intent(context, HomeActivity.class);
        // homeActivityIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        homeActivityIntent.putExtra(EXTRA_FRAGMENT_TAG, fragmentTag);
        homeActivityIntent.putExtra(EXTRA_NOTIFICATION_DATA, efNotification);

        return homeActivityIntent;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mApiRequestManager = ApiRequestManager.getInstance(getApplicationContext());
        mApiRequestManager.registerRequest(this);

        Bundle extras = getIntent().getExtras();
        boolean isFromCart = false;
        if (extras != null) {
            isFromCart = extras.getBoolean(EXTRA_IS_FROM_CART);
        }

        if (isFromCart) {
            getIntentValuesAndLoadFragments(getIntent());
        } else {
          /*  if (UrlConstants.DEV_MODE) {
                loadFragment(getFragmentContainerId(), StagingUrlFragment.create(),
                        TAG, R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.ADD);
            } else {*/
            getIntentValuesAndLoadFragments(getIntent());
        }
        registerForGcm();
        //}
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.setIntent(intent);
        if (intent.hasExtra(EXTRA_NOTIFICATION_DATA) || intent.getData() != null)
            getIntentValuesAndLoadFragments(intent);
    }

    private void getIntentValuesAndLoadFragments(Intent intent) {
        if (intent != null) {
            if (intent.hasExtra(EXTRA_FRAGMENT_TAG))
                mFragmentTag = intent.getStringExtra(EXTRA_FRAGMENT_TAG);

            if (intent.hasExtra(EXTRA_NOTIFICATION_DATA)) {
                mAppFlow = AppFlow.NOTIFICATION_FLOW;
                handleNotificationFlow((EFNotification) intent.getParcelableExtra(EXTRA_NOTIFICATION_DATA));
                return;
            } else if (intent.getData() != null) {
                mAppFlow = AppFlow.APP_LINKING_FLOW;
                handleAppLinkingFlow(intent.getData());
                return;
            }
        }

        handleMainFlowWithApiStatus();
    }

    private void handleMainFlowWithApiStatus() {
        showBlockingProgressBar();
        checkForApiStatus();
    }

    /**
     * Method to handle the Deep linking flows in the app
     *
     * @param data the deep link data
     */
    private void handleAppLinkingFlow(Uri data) {
        long variantID;
        if (data != null) {
            String path = data.getPath();
            String query = data.getEncodedQuery();
            String[] screenIds = path.split("/");

            if (screenIds.length > 1 &&
                    (screenIds[1].equalsIgnoreCase(Constants.DEEP_LINKING_ORDER_DETAILS_SCREEN)
                            || screenIds[1].equalsIgnoreCase(Constants.DEEP_LINKING_PRESCRIPTION_DETAILS_SCREEN)
                            || screenIds[1].equalsIgnoreCase(Constants.DEEP_LINKING_CART)
                            || screenIds[1].equalsIgnoreCase(Constants.DEEP_LINKING_NPDP)
                            || screenIds[1].equalsIgnoreCase(Constants.DEEP_LINKING_PPDP)
                            || screenIds[1].equalsIgnoreCase(Constants.DEEP_LINKING_HEALTH_ARTICLES)))

                switch (screenIds[1]) {
                    case Constants.DEEP_LINKING_ORDER_DETAILS_SCREEN:
                        long orderId = Long.parseLong(screenIds[2]);
                        Log.d(TAG, "App Linking Order id = " + orderId);
                        loadOrderDetailsActivity(orderId);
                        return;

                    case Constants.DEEP_LINKING_PRESCRIPTION_DETAILS_SCREEN:
                        long prescriptionId = Long.parseLong(screenIds[2]);
                        Log.d(TAG, "App Linking Prescription id = " + prescriptionId);
                        loadPrescriptionDetailsActivity(prescriptionId);
                        return;

                    case Constants.DEEP_LINKING_CART:
                        loadCartActivity();
                        return;

                    case Constants.DEEP_LINKING_PPDP:
                        variantID = Long.parseLong(screenIds[2]);
                        Log.d(TAG, "App Linking Variant id = " + variantID + " is Pharma = " + true);
                        handleProductItemClick(true, variantID);
                        return;

                    case Constants.DEEP_LINKING_NPDP:
                        variantID = Long.parseLong(screenIds[2]);
                        Log.d(TAG, "App Linking Variant id = " + variantID + " is Pharma = " + false);
                        handleProductItemClick(false, variantID);
                        return;

                    case Constants.DEEP_LINKING_HEALTH_ARTICLES:
                        String healthArticlesWebUrl = query;
                        if (healthArticlesWebUrl.contains("web_page_url="))
                            healthArticlesWebUrl = query.substring(DEEPLINK_WEB_PAGE_URL_INDEX, query.length());
                        Log.d(TAG, "App Linking Health articles = " + healthArticlesWebUrl);
                        loadPromotionalDetail(healthArticlesWebUrl, getString(R.string.drawer_menu_health_articles));
                        return;

                    default:
                        return;
                }
        }

        handleMainFlowWithApiStatus();
    }

    /**
     * Method to handle the notifications and its flows
     *
     * @param notification the notification object
     */
    private void handleNotificationFlow(EFNotification notification) {
        if (notification != null) {

            FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PUSH_NOTIFICATION_TAP_EVENT);

            if (notification.getIsApptentiveNotification() && !ApptentiveManager.isApptentiveNotificationHandled(HomeActivity.this)) {
                ApptentiveManager.showApptentiveMessageCenter(HomeActivity.this);
            }

            switch (notification.getNotificationType()) {
                case DIGITISATION_FAILURE:
                    //Type 1
                    loadPrescriptionDetailsActivity(notification.getId());
                    return;

                case CART_PREPARED:
                    //Type 2
                    loadCartActivity();
                    return;

                case ORDER_REVISION:
                case ORDER_STATUS_UPDATE:
                    //Type 3 & 4
                    loadOrderDetailsActivity(notification.getId());
                    return;

                case CATEGORY:
                    //Type 11
                    loadCategoryActivity(notification.getId(), "");
                    return;

                case PROMOTION_PRODUCT_LISTING:
                    //Type 12
                    loadProductListingFragment(notification.getId());
                    return;

                case HOME_COPY_CODE:
                    //Type 13 - alert
                    loadHomeFragmentFromNotificationFlow(notification.getCouponCode());
                    return;

                case CATEGORY_COPY_CODE:
                    //Type 14 - alert
                    loadCategoryActivity(notification.getId(), notification.getCouponCode());
                    return;

                case HTML_PAGE:
                    //Type 15
                    loadPromotionalDetail(notification.getPageLink(), getString(R.string.category_promotion_details));
                    return;

                case REFER_A_FRIEND:
                    //Type 16
                    loadReferFriendActivity();
                    return;

                case PRODUCT_DETAIL:
                    //Type 17
                    loadProductDetailActivity(notification.getId(), notification.isPharma());
                    return;

                case HEALTH_ARTICLES:
                    //Type 18
                    loadPromotionalDetail(notification.getPageLink(), getString(R.string.drawer_menu_health_articles));
                    return;

                case GENERAL_PROMOTION_SPECIFIC_USER:
                case GENERAL_PROMOTION_ALL_USER:
                case HOME:
                default:
                    //Type 5,6 & 10
                    handleMainFlowWithApiStatus();
                    break;
            }
        } else {
            handleMainFlowWithApiStatus();
        }
    }

    /**
     * Method launches Product Detail Activity
     */
    private void loadProductDetailActivity(long variantId, boolean isPharma) {
        if (variantId != 0) {
            startActivityForResult(ProductDetailActivity.getActivityIntent(HomeActivity.this,
                    isPharma ? ProductDetailActivity.PHARMA_PRODUCT_DETAIL_FRAGMENT_ID :
                            ProductDetailActivity.NON_PHARMA_PRODUCT_DETAIL_FRAGMENT_ID,
                    variantId), Constants.REQUEST_CODE_BRANCH_DEEPLINKING);
            overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    /**
     * Method loads the Refer a Friend screen if the user is already logged in
     */
    private void loadReferFriendActivity() {
        performNewTagFeaturesListRequest();
        continueMainFlow();
        int installedAppVersion = Integer.parseInt(UrlConstants.API_VERSION.replaceAll("\\D+", ""));
        if (installedAppVersion > 5) {
            if (Utils.isLoggedIn(getApplicationContext())) {
                startActivity(ReferFriendActivity.getActivityIntent(getApplicationContext(), ReferFriendActivity.INVITE_FRIENDS_FRAGMENT));
                overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
            } else {
                startActivityForResult(LogInActivity.getActivityIntent(getApplicationContext(), false,
                        LogInActivity.LOG_IN_FRAGMENT), Constants.REQUEST_CODE_INVITE_FRIENDS);
                overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
            }
        } else {
            handleMainFlowWithApiStatus();
        }
    }

    /**
     * Method loads the PDP based on the flag isPharma
     */
    private void handleProductItemClick(boolean isPharma, long variantID) {
        //FacebookManager.logFacebookDifferedDeepLinking(HomeActivity.this);
        continueMainFlow();
        startActivity(ProductDetailActivity.getActivityIntent(getApplicationContext(),
                (isPharma) ? ProductDetailActivity.PHARMA_PRODUCT_DETAIL_FRAGMENT_ID
                        : ProductDetailActivity.NON_PHARMA_PRODUCT_DETAIL_FRAGMENT_ID,
                variantID));
        overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    /**
     * Method to load the specific link in app's web view
     *
     * @param pageLink     the web url associated with the offer
     * @param toolbarTitle the web page title
     */
    private void loadPromotionalDetail(String pageLink, String toolbarTitle) {
        if (!TextUtils.isEmpty(pageLink)) {
            startActivityForResult(WebViewActivity.getActivityIntentForWebViewFragment(getApplicationContext(),
                    WebViewActivity.WEB_VIEW_FRAGMENT_ID, pageLink, toolbarTitle),
                    Constants.REQUEST_CODE_WEB_VIEW);
            overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    /**
     * Method to load the Home screen in notification flow
     *
     * @param couponCode the coupon code associated with the offer
     */
    private void loadHomeFragmentFromNotificationFlow(String couponCode) {
        if (!TextUtils.isEmpty(couponCode)) {
            Utils.copyToClipboard(couponCode, this);
            Toast.makeText(this, "Coupon code " + couponCode + " is copied to clipboard",
                    Toast.LENGTH_LONG).show();
            loadFragment(getFragmentContainerId(), HomeFragment.create(), TAG,
                    R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.REPLACE);
        }
    }

    /**
     * Method mto load the Product Listing screen
     *
     * @param promotionId the promotion id associated with the offer
     */
    private void loadProductListingFragment(long promotionId) {
        if (promotionId != 0) {
            startActivityForResult(ProductListingActivity.getActivityIntentForHomePromotionalProducts(getApplicationContext(),
                    ProductListingActivity.PROMOTIONAL_PRODUCTS_FRAGMENT_ID, promotionId), Constants.REQUEST_CODE_PRODUCT_LISTING);
            overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    /**
     * Method to load the category page
     *
     * @param categoryId the category id
     * @param couponCode the coupon code associated with the offer
     */
    private void loadCategoryActivity(long categoryId, String couponCode) {
        if (!TextUtils.isEmpty(couponCode)) {
            Utils.copyToClipboard(couponCode, this);
            Toast.makeText(this, "Coupon code " + couponCode + " is copied to clipboard",
                    Toast.LENGTH_SHORT).show();
        }
        if (categoryId != 0) {
            startActivity(PharmacyActivity.getActivityIntent(getApplicationContext(),
                    PharmacyActivity.PHARMACY_SUB_CATEGORY_FRAGMENT_ID, null, categoryId));
            overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
            loadFragment(getFragmentContainerId(), PharmacyFragment.create(), TAG,
                    R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.REPLACE);
        }
    }

    /**
     * Method to load the prescription detail page
     *
     * @param prescriptionId the prescription id
     */
    private void loadPrescriptionDetailsActivity(long prescriptionId) {
        startActivityForResult(
                OrderHistoryActivity.getActivityIntent(getApplicationContext(),
                        OrderHistoryActivity.PRESCRIPTION_DETAILS_FRAGMENT_ID, prescriptionId), Constants.REQUEST_CODE_PRESCRIPTION_DETAIL);
        overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    /**
     * Method to load Cart screen
     */
    private void loadCartActivity() {
        startActivityForResult(CartActivity.getActivityIntent(getApplicationContext(),
                CartActivity.CART_FRAGMENT_ID), Constants.REQUEST_CODE_CART);
    }

    /**
     * Method to load the Order details screen
     *
     * @param orderId the order id
     */
    private void loadOrderDetailsActivity(long orderId) {
        startActivityForResult(OrderHistoryActivity.getActivityIntent(getApplicationContext(),
                OrderHistoryActivity.ORDER_HISTORY_DETAILS_FRAGMENT_ID, orderId), Constants.REQUEST_CODE_ORDER_HISTORY);
        overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    /**
     * Method to register for gcm android push notifications
     */
    private void registerForGcm() {
        if (checkPlayServices()
                && !PreferenceUtils.getBooleanFromSharedPreference(
                getApplicationContext(), PreferenceUtils.PREFERENCE_KEY_GCM_TOKEN_SENT_TO_SERVER)) {
            // Start IntentService to register this application with GCM.
            Intent intent = new Intent(this, RegistrationIntentService.class);
            startService(intent);
        }
    }

    /**
     * Method to request for New tag features
     */
    private void performNewTagFeaturesListRequest() {
        final IApiRequestCancel apiRequestCancel = new IApiRequestCancel() {
            @Override
            public String getRequestTag() {
                return "Features";
            }
        };
        mApiRequestManager.registerRequest(apiRequestCancel);

        List<String> menuList = new ArrayList<>(1);
        Collections.addAll(menuList, getResources().getStringArray(R.array.drawer_mappings_category));
        Collections.addAll(menuList, getResources().getStringArray(R.array.drawer_mappings_sub_categories));

        ApiNewTag.Request apiNewTagRequest = new ApiNewTag.Request();
        apiNewTagRequest.setFeatures(menuList);

        mApiRequestManager.performNewFeaturesListRequest(apiNewTagRequest, new ApiRequestManager.INewFeaturesResultNotifier() {
            @Override
            public void onNewFeatureListFetched(ApiNewTag.Response apiNewTag) {
                mApiRequestManager.setNewFeaturesResponse(apiNewTag);
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, new IErrorHandler() {
            @Override
            public <T> void handleError(AlertError<T> alertError, int statusCode) {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }

            @Override
            public void handleCommonError(int errorResourceId) {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, apiRequestCancel);
    }

    /**
     * Check the device to make sure it has the Google Play Services APK. If
     * it doesn't, display a dialog that allows users to download the APK from
     * the Google Play Store or enable it in the device's system settings.
     */
    private boolean checkPlayServices() {
        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
        int resultCode = apiAvailability.isGooglePlayServicesAvailable(this);
        if (resultCode != ConnectionResult.SUCCESS) {
            if (apiAvailability.isUserResolvableError(resultCode)) {
                apiAvailability.getErrorDialog(this, resultCode, PLAY_SERVICES_RESOLUTION_REQUEST)
                        .show();
            } else {
                android.util.Log.d(TAG, "This device is not supported.");
                finish();
            }
            return false;
        }
        return true;
    }

    @Override
    public void onStart() {
        super.onStart();
        mApiRequestManager.registerRequest(this);
        FrankRossAnalytics.getFrankRossTracker().startSession(this);
        initBranchSession(HomeActivity.this);
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(this);
        mApiRequestManager.unregisterRequest(this);
    }

    /**
     * Method to initialize the branch session
     *
     * @param context the application context
     */
    private void initBranchSession(final Context context) {
        BranchManager.getBranchInstance(context).initSession(new Branch.BranchReferralInitListener() {
            @Override
            public void onInitFinished(JSONObject referringParams, BranchError error) {

                //Deep linking flow for Product detail - irrespective of Branch user ID
                try {
                    if (error == null && referringParams.has(BranchManager.BRANCH_PDP_SHARE_LINK_CLICKED) &&
                            Boolean.parseBoolean(String.valueOf(referringParams.get(BranchManager.BRANCH_PDP_SHARE_LINK_CLICKED))) &&
                            referringParams.has(BranchManager.BRANCH_PDP_SHARE_VARIANT_ID) &&
                            referringParams.has(BranchManager.BRANCH_PDP_SHARE_SCREEN_NAME)) {

                        mVariantId = referringParams.optString(BranchManager.BRANCH_PDP_SHARE_VARIANT_ID, "");
                        mProductType = referringParams.optString(BranchManager.BRANCH_PDP_SHARE_SCREEN_NAME, "");
                        if (!TextUtils.isEmpty(mVariantId) && !TextUtils.isEmpty(mProductType)) {
                            if (!Utils.isLocationSaved(getApplicationContext())) {
                                loadFragment(getFragmentContainerId(), LocationChooserFragment.createBranchDeepLinkedInstance(
                                        Long.parseLong(mVariantId), mProductType),
                                        TAG, R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.REPLACE);
                            } else {
                                handleProductDetailLaunch();
                            }
                        }
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (error == null &&
                        !BranchManager.getBranchInstance(HomeActivity.this).isUserIdentified()) {

                    Log.d(BranchManager.TAG, "No errors!!Checking for Refer data");
                    checkForReferData(referringParams);

                } else if (error != null) {
                    Log.d(TAG, error.toString());
                }
            }
        }, ((Activity) context).getIntent().getData(), (Activity) context);
    }

    private void handleProductDetailLaunch() {
        startActivityForResult(ProductDetailActivity.getActivityIntent(HomeActivity.this,
                mProductType.equals(getResources().getString(R.string.pharma_product_share_using_branch)) ?
                        ProductDetailActivity.PHARMA_PRODUCT_DETAIL_FRAGMENT_ID :
                        ProductDetailActivity.NON_PHARMA_PRODUCT_DETAIL_FRAGMENT_ID,
                Long.parseLong(mVariantId)), Constants.REQUEST_CODE_BRANCH_DEEPLINKING);
        overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    /**
     * Method that validates the Branch SDK response format and accordingly communicates to Manager class
     *
     * @param referringParams the branch SDK response
     */
    private void checkForReferData(JSONObject referringParams) {
        if (referringParams.has(BranchManager.BRANCH_REFERRAL_DATA_KEY)) {
            //Navigate one level deeper to get the fields under data key
            JSONObject jsonDataObject = null;
            try {
                jsonDataObject = referringParams.getJSONObject(BranchManager.BRANCH_REFERRAL_DATA_KEY);
                if (BranchManager.validateJsonForReferSuccessSession(jsonDataObject)) {
                    Log.d(BranchManager.TAG, "Has Refer data and successful referral");
                    FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.REFER_FRIEND_SUCCESS_EVENT);
                    showBranchReferralDialog(getString(R.string.invite_friends_referral_success_dialog_message));
                    Utils.saveBooleanIsWelcomeDialogShown(HomeActivity.this);
                } else if (BranchManager.validateJsonForReferFailureSession(jsonDataObject)) {
                    Log.d(BranchManager.TAG, "Has Refer data and failed referral");
                    if (!Utils.getBooleansFailureDialogShown(HomeActivity.this)) {
                        showBranchReferralDialog(getString(R.string.invite_friends_referral_failure_dialog_message));
                        Utils.saveBooleansFailureDialogShown(HomeActivity.this);
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else if (BranchManager.validateJsonForReferSuccessSession(referringParams)) {
            Log.d(BranchManager.TAG, "No Refer data, but successful referral");
            FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.REFER_FRIEND_SUCCESS_EVENT);
            showBranchReferralDialog(getString(R.string.invite_friends_referral_success_dialog_message));
            Utils.saveBooleanIsWelcomeDialogShown(HomeActivity.this);
        } else if (BranchManager.validateJsonForReferFailureSession(referringParams)) {
            Log.d(BranchManager.TAG, "No Refer data, but failed referral");
            if (!Utils.getBooleansFailureDialogShown(HomeActivity.this)) {
                showBranchReferralDialog(getString(R.string.invite_friends_referral_failure_dialog_message));
                Utils.saveBooleansFailureDialogShown(HomeActivity.this);
            }
        }
    }

    /**
     * Method that requests for API health status
     */
    private void checkForApiStatus() {
        mApiRequestManager.performApiStatusRequest(new ApiRequestManager.IApiStatusResultNotifier() {
            @Override
            public void onApiDeprecated() {
                hideBlockingProgressBar();
                showAlert(getString(R.string.upgrade), getString(R.string.upgrade_frankross_application_now_or_later),
                        getString(R.string.upgrade_now), getString(R.string.later), new AlertDialogFragment.AlertPositiveActionListener() {
                            @Override
                            public void onPositiveAction() {
                                //IntentUtils.launchPlayStoreToUpdate(HomeActivity.this);
                                launchPlayStore();
                                finish();
                            }
                        }, new AlertDialogFragment.AlertNegativeActionListener() {
                            @Override
                            public void onNegativeAction() {
                                continueMainFlow();
                            }
                        }, false);
            }

            @Override
            public void onApiDiscontinued() {
                hideBlockingProgressBar();
                showAlert(getString(R.string.upgrade), getString(R.string.upgrade_frankross_application_now),
                        getString(R.string.upgrade_now), null, new AlertDialogFragment.AlertPositiveActionListener() {
                            @Override
                            public void onPositiveAction() {
                                launchPlayStore();
                            }
                        }, null, false);
            }

            @Override
            public void onApiLive() {
                hideBlockingProgressBar();

                continueMainFlow();
            }

        }, this, this);
    }

    /**
     * Method to launch play store for upgrade of the app
     */
    private void launchPlayStore() {
        final String appPackageName = getPackageName(); // getPackageName() from Context or Activity object
        try {
            Log.v(TAG, "activity found" + appPackageName);
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Constants.APP_PLAY_STORE_URL + appPackageName)));
        } catch (android.content.ActivityNotFoundException activityNotFoundException) {
            Log.v(TAG, "activity not found");
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(Constants.APP_PLAY_STORE_URL_WEB + appPackageName)));
        }
    }

    /**
     * Method to handle the home screen flows
     */
    private void continueMainFlow() {
        if (!Utils.isLocationSaved(getApplicationContext())) {
            loadFragment(getFragmentContainerId(),
                    TextUtils.isEmpty(mVariantId) ?
                            LocationChooserFragment.create(getApplicationContext(), null) :
                            LocationChooserFragment.createBranchDeepLinkedInstance(Long.parseLong(mVariantId), mProductType),
                    TAG, R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.REPLACE);
        } else {
            updateCartCount(ApiRequestManager.getInstance(getApplicationContext()).getCartItemsCountInString(), false);
            initFragment();
        }
    }

    /**
     * Method to handle the Home screen fragments
     */
    private void initFragment() {
        if (!TextUtils.isEmpty(mFragmentTag)) {
            switch (mFragmentTag) {
                case HOME_FRAGMENT_TAG:
                    loadFragment(getFragmentContainerId(), HomeFragment.create(), TAG,
                            R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.REPLACE);
                    break;

                case ACCOUNT_FRAGMENT_TAG:
                    loadFragment(getFragmentContainerId(), AccountFragment.create(), TAG,
                            R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.REPLACE);
                    break;

                case PHARMACY_FRAGMENT_TAG:
                    loadFragment(getFragmentContainerId(), PharmacyFragment.create(), TAG,
                            R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.REPLACE);
                    break;

                default:
                    loadFragment(getFragmentContainerId(), HomeFragment.create(), TAG,
                            R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.REPLACE);
                    break;
            }
        } else {
            loadFragment(getFragmentContainerId(), HomeFragment.create(), TAG,
                    R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.REPLACE);
        }
    }

    /**
     * Method to show alert with OK button(No title)
     *
     * @param alertMessage the message to be shown in the alert
     */
    private void showBranchReferralDialog(String alertMessage) {
        showAlert(null, alertMessage, getString(R.string.ok), null, new AlertDialogFragment.AlertPositiveActionListener() {
            @Override
            public void onPositiveAction() {

            }
        }, null, true);
    }

    @Override
    public String getRequestTag() {
        return HomeActivity.class.getName();
    }

    @Override
    public <T> void handleError(AlertError<T> alertError, int statusCode) {
        hideBlockingProgressBar();

        if (alertError == null) return;
        showAlert(alertError.getErrorTitle(), alertError.getErrorMessage(),
                alertError.getPositiveButtonText(), alertError.getNegativeButtonText(), new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                        finish();
                    }
                }, new AlertDialogFragment.AlertNegativeActionListener() {
                    @Override
                    public void onNegativeAction() {
                        onErrorNegativeAction();
                    }
                }, true);
    }

    @Override
    public void handleCommonError(int errorResourceId) {
        hideBlockingProgressBar();
        String errorMessage = getString(errorResourceId);

        showAlert(null, errorMessage,
                "OK", null, new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                        onErrorAlertAction();
                    }
                }, null, true);

    }

    protected void onErrorNegativeAction() {

    }

    protected void onErrorAlertAction() {

    }

    @Override
    public void onStagingUrlSelect() {
        getIntentValuesAndLoadFragments(getIntent());

        registerForGcm();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.d(TAG, "ON Activity Result");

        switch (requestCode) {
            case Constants.REQUEST_CODE_ORDER_HISTORY:
            case Constants.REQUEST_CODE_PRESCRIPTION_DETAIL:
            case Constants.REQUEST_CODE_CART:
            case Constants.REQUEST_CODE_WEB_VIEW:
            case Constants.REQUEST_CODE_CATEGORY:
            case Constants.REQUEST_CODE_PRODUCT_LISTING:
                handleMainFlowWithApiStatus();
                break;
            case Constants.REQUEST_CODE_INVITE_FRIENDS:
                if (Utils.isLoggedIn(getApplicationContext())) {
                    startActivity(ReferFriendActivity.getActivityIntent(getApplicationContext(), ReferFriendActivity.INVITE_FRIENDS_FRAGMENT));
                    overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                } else {
                    handleMainFlowWithApiStatus();
                }
                break;
            case Constants.REQUEST_CODE_SUB_CATEGORY:
                mFragmentTag = PHARMACY_FRAGMENT_TAG;
                initFragment();
                break;
            case Constants.REQUEST_CODE_BRANCH_DEEPLINKING:
                Fragment fragment = getSupportFragmentManager().findFragmentByTag(TAG);
                if (fragment != null && !(fragment instanceof HomeFragment)) {
                    mFragmentTag = HOME_FRAGMENT_TAG;
                    initFragment();
                }
                break;
        }
    }
}
