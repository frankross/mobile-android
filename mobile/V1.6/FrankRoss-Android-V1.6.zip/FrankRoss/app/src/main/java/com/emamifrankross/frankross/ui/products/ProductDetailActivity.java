/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.products;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.widget.DrawerLayout;
import android.text.TextUtils;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.VariantSelectionAdapter;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.ICartQuantityNotifier;
import com.emamifrankross.frankross.ui.common.IDrawerSlideController;
import com.emamifrankross.frankross.ui.products.nonpharmaproductdetail.NonPharmaProductDetailFragment;
import com.emamifrankross.frankross.ui.products.nonpharmaproductdetail.VariantsDialogFragment;
import com.emamifrankross.frankross.ui.products.notify.NotifyMeDialogFragment;
import com.emamifrankross.frankross.ui.products.pharmaproductdetail.PharmaProductDetailFragment;

/**
 * Created by gauthami on 9/7/15.
 */

/**
 * This class manages the fragment transactions for Pharma & Non pharma product detail based on the intents and its data
 */
public class ProductDetailActivity extends BaseActivity implements ICartQuantityNotifier,
        IDrawerSlideController, VariantsDialogFragment.IVariantSelectNotifier,
        NotifyMeDialogFragment.INotifyMeToMobileNumberListener {

    public static final String PHARMA_PRODUCT_DETAIL_FRAGMENT_ID = "001";
    public static final String NON_PHARMA_PRODUCT_DETAIL_FRAGMENT_ID = "002";

    private static final String EXTRA_FRAGMENT_ID = "fragment_id";
    private static final String EXTRA_VARIANT_ID = "variant_id";

    public static Intent getActivityIntent(Context appContext, String fragmentId, long variantId) {
        Intent intent = new Intent(appContext, ProductDetailActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);
        intent.putExtra(EXTRA_VARIANT_ID, variantId);

        return intent;
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.setIntent(intent);
        //Hide fragment : Bug fix- previous fragment being shown onNewIntent
        BaseFragment fragment = (BaseFragment) getSupportFragmentManager().findFragmentById(getFragmentContainerId());
        if (fragment != null) {
            if (fragment instanceof PharmaProductDetailFragment) {
                PharmaProductDetailFragment pharmaProductDetailFragment = (PharmaProductDetailFragment)
                        getSupportFragmentManager().findFragmentById(getFragmentContainerId());
                hideFragment(pharmaProductDetailFragment);
            } else if (fragment instanceof NonPharmaProductDetailFragment) {
                NonPharmaProductDetailFragment nonPharmaProductDetailFragment = (NonPharmaProductDetailFragment)
                        getSupportFragmentManager().findFragmentById(getFragmentContainerId());
                hideFragment(nonPharmaProductDetailFragment);
            }
        }
        //Bug fix : Since this activity is declared as singleTask in manifest
        String fragmentId = getIntent().getStringExtra(EXTRA_FRAGMENT_ID);
        long variantId = getIntent().getLongExtra(EXTRA_VARIANT_ID, 0);
        initFragment(fragmentId, variantId);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String fragmentId = getIntent().getStringExtra(EXTRA_FRAGMENT_ID);
        long variantId = getIntent().getLongExtra(EXTRA_VARIANT_ID, 0);
        initFragment(fragmentId, variantId);
    }

    private void initFragment(String fragmentId, long variantId) {
        if (!TextUtils.isEmpty(fragmentId)) {
            switch (fragmentId) {
                case PHARMA_PRODUCT_DETAIL_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(),
                            PharmaProductDetailFragment.create(variantId),
                            null, R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.ADD);
                    break;
                case NON_PHARMA_PRODUCT_DETAIL_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(),
                            NonPharmaProductDetailFragment.create(variantId),
                            null, R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.ADD);
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    public void onAddToCartClick(int cartQuantity) {
        BaseFragment fragment = (BaseFragment) getSupportFragmentManager().findFragmentById(getFragmentContainerId());
        if (fragment != null) {
            if (fragment instanceof PharmaProductDetailFragment) {
                PharmaProductDetailFragment pharmaProductDetailFragment = (PharmaProductDetailFragment)
                        getSupportFragmentManager().findFragmentById(getFragmentContainerId());
                pharmaProductDetailFragment.performAddToCartRequest(cartQuantity);
            } else if (fragment instanceof NonPharmaProductDetailFragment) {
                NonPharmaProductDetailFragment nonPharmaProductDetailFragment = (NonPharmaProductDetailFragment)
                        getSupportFragmentManager().findFragmentById(getFragmentContainerId());
                nonPharmaProductDetailFragment.performAddToCartRequest(cartQuantity);
            }
        }
    }

    @Override
    public void lockDrawer() {
        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
    }

    @Override
    public void unlockDrawer() {
        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
    }

    @Override
    public void onVariantSelect(VariantSelectionAdapter.VariantSelectionItem variantDataItem, boolean isPrimaryVariant) {
        BaseFragment fragment = (BaseFragment) getSupportFragmentManager().findFragmentById(getFragmentContainerId());
        if (fragment != null) {
            if (fragment instanceof NonPharmaProductDetailFragment) {
                NonPharmaProductDetailFragment nonPharmaProductDetailFragment = (NonPharmaProductDetailFragment)
                        getSupportFragmentManager().findFragmentById(getFragmentContainerId());
                nonPharmaProductDetailFragment.onVariantSelected(variantDataItem, isPrimaryVariant);
            }
        }
    }

    @Override
    public void onDialogDismiss(boolean isPrimaryVariant) {
        BaseFragment fragment = (BaseFragment) getSupportFragmentManager().findFragmentById(getFragmentContainerId());
        if (fragment != null) {
            if (fragment instanceof NonPharmaProductDetailFragment) {
                NonPharmaProductDetailFragment nonPharmaProductDetailFragment = (NonPharmaProductDetailFragment)
                        getSupportFragmentManager().findFragmentById(getFragmentContainerId());
                nonPharmaProductDetailFragment.onVariantDialogDismissed(isPrimaryVariant);
            }
        }
    }

    /**
     * Callback to request notify through mobile number
     *
     * @param mobileNumber The mobile number to which the product back in stock will be notified
     */
    @Override
    public void onNotifyMeToMobileNumberSubmit(String mobileNumber) {
        BaseFragment fragment = (BaseFragment) getSupportFragmentManager().findFragmentById(getFragmentContainerId());
        if (fragment != null) {
            if (fragment instanceof NonPharmaProductDetailFragment) {
                NonPharmaProductDetailFragment nonPharmaProductDetailFragment = (NonPharmaProductDetailFragment)
                        getSupportFragmentManager().findFragmentById(getFragmentContainerId());
                nonPharmaProductDetailFragment.performNotifyMeNonSignedInUserRequest(mobileNumber);
            } else if (fragment instanceof PharmaProductDetailFragment) {
                PharmaProductDetailFragment pharmaProductDetailFragment = (PharmaProductDetailFragment)
                        getSupportFragmentManager().findFragmentById(getFragmentContainerId());
                pharmaProductDetailFragment.performNotifyMeNonSignedInUserRequest(mobileNumber);
            }
        }
    }
}