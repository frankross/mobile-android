/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.prescription.prescriptionmedicines;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;

/**
 * Created by gauthami on 8/7/15.
 */

/**
 * This class manages the fragment transactions for Prescription Medicines based on the intents and its data
 */
public class PrescriptionMedicineActivity extends BaseActivity {

    public static final String PRESCRIPTION_MEDICINE_FRAGMENT_ID = "001";

    private static final String EXTRA_FRAGMENT_ID = "fragment_id";

    public static Intent getActivityIntent(Context appContext, String fragmentId) {
        Intent intent = new Intent(appContext, PrescriptionMedicineActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);
        return intent;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String fragmentId = getIntent().getStringExtra(EXTRA_FRAGMENT_ID);
        initFragment(fragmentId);
    }

    private void initFragment(String fragmentId) {
        if (!TextUtils.isEmpty(fragmentId)) {
            switch (fragmentId) {
                case PRESCRIPTION_MEDICINE_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(), PrescriptionMedicineFragment.create(), null,
                            R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.ADD);
                    break;
                default:
                    break;

            }
        }
    }
}