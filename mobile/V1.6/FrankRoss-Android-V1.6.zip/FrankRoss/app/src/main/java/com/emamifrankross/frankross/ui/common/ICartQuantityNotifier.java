/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

/**
 * Created by gauthami on 5/8/15.
 */

/**
 * Interface to communicate on Adding a product to the cart using the picker
 */
public interface ICartQuantityNotifier {
    /**
     * Callback to be invoked on Adding a product to the cart using the picker
     *
     * @param cartQuantity the quantity of the product to be added
     */
    void onAddToCartClick(int cartQuantity);
}
