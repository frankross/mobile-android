/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Log;

/**
 * Created by gowtham on 17/12/15.
 */

/**
 * COMMON VIEW PAGER ITEM BINDER
 */
public class ViewPagerViewDataBinder implements BaseRecyclerAdapter.RecyclerViewDataBinder<ViewPagerViewHolder, ViewPagerDataItem> {

    @Override
    public ViewPagerViewHolder getViewHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.view_pager_layout, parent, false);

        return new ViewPagerViewHolder(view);
    }

    @Override
    public void bindDataToViewHolder(ViewPagerViewHolder viewHolder, ViewPagerDataItem data,
                                     int position, BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {
        if (data.viewPagerAdapter != null) {
            viewHolder.mViewPager.setAdapter(data.viewPagerAdapter);
        } else {
            Log.e(Constants.LOG_TAG, "Pager adapter instance can not be null");
        }

        viewHolder.mPagerIndicator.getBackground().setAlpha((int) (0.7F * 255));
        viewHolder.mPagerIndicator.setViewPager(viewHolder.mViewPager);
    }

    @Override
    public int getViewType() {
        return ViewTypes.CommonViewType.VIEW_PAGER_ITEM;
    }
}
