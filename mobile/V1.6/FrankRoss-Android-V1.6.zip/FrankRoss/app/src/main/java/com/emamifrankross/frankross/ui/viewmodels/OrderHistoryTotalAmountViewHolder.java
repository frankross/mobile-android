/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.support.v7.widget.RecyclerView;
import android.util.TypedValue;
import android.view.View;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

/**
 * Created by gauthami on 22/7/15.
 */

/**
 * Order History total amount item view holder
 */
public class OrderHistoryTotalAmountViewHolder extends RecyclerView.ViewHolder {

    public RobotoTextView mTotalAmtTitle;
    public RobotoTextView mTotalAmt;

    public OrderHistoryTotalAmountViewHolder(View view) {
        super(view);

        mTotalAmt = (RobotoTextView) view.findViewById(R.id.order_history_shipping_amount_tv);
        mTotalAmt.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);

        mTotalAmtTitle = (RobotoTextView) view.findViewById(R.id.order_history_shipping_title_tv);
        mTotalAmtTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
    }
}