/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.db.tables;

import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import com.emamifrankross.frankross.core.db.IDataBaseOperation;
import com.emamifrankross.frankross.core.db.DeleteQuery;
import com.emamifrankross.frankross.core.db.SelectQuery;

/**
 * Base class for Data base Tables.
 * <p/>
 * Which handles the table creation, deletion and getting data from tables.
 */
public abstract class BaseTable implements IDataBaseOperation {

    /**
     * This method creates the database table by executing the provided sql statement.
     *
     * @param db           Sqlite data base reference for executing sql statements
     * @param sqlStatement statement to be defined in subclasses to create the table.
     * @throws SQLException
     */
    public void create(SQLiteDatabase db, String sqlStatement) throws SQLException {
        db.execSQL(sqlStatement);
    }

    /**
     * This method delete the database table for the provided table name
     *
     * @param db        Sqlite data base reference for executing sql statements
     * @param tableName name of the table to be deleted.
     * @throws SQLException
     */
    protected void drop(SQLiteDatabase db, String tableName) throws SQLException {
        String deletionStatement = "DROP TABLE IF EXISTS " + tableName + ";";
        db.execSQL(deletionStatement);
    }

    /**
     * This method fetches the required data from database table for the provided select query
     *
     * @param db        Sqlite data base reference for executing sql statements
     * @param tableName name of the table to be deleted.
     * @param query     select query to fetch the required data base data from the given table name.
     * @throws SQLException
     */
    protected Cursor select(String tableName, SQLiteDatabase db, SelectQuery query) {
        Cursor cursor = null;

        if (db != null && query != null) {
            cursor = db.query(tableName, query.getColumns(), query.getWhereClause(),
                    query.getWhereArgs(), query.getGroupBy(), query.getHaving(),
                    query.getOrderBy(), query.getLimit());
        }
        return cursor;
    }


    /**
     * This method delete the data from database table for the provided delete query.
     * @param tableName name of the table
     * @param db  Sqlite data base reference for executing sql statements
     * @param query delete query
     * @return the number of rows affected, 0 otherwise.
     */
    protected int delete(String tableName, SQLiteDatabase db, DeleteQuery query) {

        int result = 0;

        if (db != null && query != null) {
            result = db.delete(tableName, query.getWhereClause(), query.getWhereArgs());
            //Log.d("TEST" , "tableName = " + tableName + " deleted result = " + result);
//			db.close();
        }
        return result;
    }

}
