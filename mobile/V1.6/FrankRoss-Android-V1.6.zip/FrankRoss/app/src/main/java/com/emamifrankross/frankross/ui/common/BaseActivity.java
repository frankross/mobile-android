/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */
package com.emamifrankross.frankross.ui.common;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.NavigationDrawerAdapter;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 24/6/15.
 */
public abstract class BaseActivity extends FragmentActivity
        implements IFragmentInteractionListener, IToolbarInteractionListener,
        ApiRequestManager.ICartCountChangeNotifier, ApiRequestManager.INotificationsCountChangeNotifier {

    private static final String TAG = BaseActivity.class.getSimpleName();
    private boolean mIsPaused = false;

    protected Toolbar mToolbar;
    protected DrawerLayout mDrawerLayout;
    private LinearLayout mBlockingProgressBar;

    private View.OnTouchListener mProgressbarTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            return true;
        }
    };

    private RobotoTextView mCartBadgeCount;
    private RobotoTextView mNotificationBadgeCount;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_base_drawer);

        initViews();
        initToolbar();
    }

    private void initViews() {
        mDrawerLayout = ((DrawerLayout) findViewById(R.id.base_drawer_layout));
        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);

        RecyclerView recyclerView = ((RecyclerView) findViewById(R.id.drawer_recycler));
        recyclerView.setAdapter(new NavigationDrawerAdapter(new ArrayList<BaseRecyclerAdapter.IViewType>(1)));
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));

        mBlockingProgressBar = (LinearLayout) findViewById(R.id.progressbar_layout);
    }

    protected int getFragmentContainerId() {
        return R.id.fragment_container;
    }

    private void initToolbar() {
        mToolbar = (Toolbar) findViewById(R.id.frankross_toolbar);
        mToolbar.setVisibility(View.VISIBLE);

       /* if (Utils.hasKitKat()) {
            mToolbar.setPadding(0, getStatusBarHeight(), 0, 0);
        }*/

        if (!Utils.hasLOLLYPOP()) {
            findViewById(R.id.toolbar_shadow_view).setVisibility(View.VISIBLE);
        }
    }

    // A method to find height of the status bar
    protected int getStatusBarHeight() {
        int result = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0) {
            result = getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }

    @Override
    public void updateToolbar(IToolbar toolbar) {
        if (mToolbar != null)
            mToolbar.getMenu().clear();
        setToolbarValues(toolbar.getToolbarNavigationIconId(), toolbar.getToolbarTitleId(),
                toolbar.getToolbarMenuId(), toolbar.getToolbarMenuItemClickListener());
        setToolbarListeners(toolbar.getNavigationClickListener(), toolbar.getToolbarMenuItemClickListener());
    }

    protected void setToolbarValues(int navigationIconId, String titleId, int menuId,
                                    final Toolbar.OnMenuItemClickListener toolbarMenuItemClickListener) {
        if (navigationIconId != 0) {
            mToolbar.setNavigationIcon(navigationIconId);
        } else {
            mToolbar.setNavigationIcon(new ColorDrawable(Color.TRANSPARENT));
        }

        mToolbar.setTitle(titleId);
        mToolbar.setTitleTextColor(Color.WHITE);
        if (menuId != 0) {
            mToolbar.inflateMenu(menuId);
            final Menu menu = mToolbar.getMenu();
            final MenuItem cartItem = menu.findItem(R.id.action_cart);

            if (cartItem != null && cartItem.getActionView() != null) {
                View view = cartItem.getActionView();

                view.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        toolbarMenuItemClickListener.onMenuItemClick(cartItem);
                    }
                });

                if (view.findViewById(R.id.cart_count) != null) {
                    mCartBadgeCount = (RobotoTextView) view.findViewById(R.id.cart_count);
                    updateCartCount(ApiRequestManager.getInstance(getApplicationContext()).getCartItemsCountInString(), false);
                }
            }

            final MenuItem notificationsItem = menu.findItem(R.id.action_notifications);

            if (notificationsItem != null && notificationsItem.getActionView() != null) {
                View view = notificationsItem.getActionView();

                view.setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {
                        toolbarMenuItemClickListener.onMenuItemClick(notificationsItem);
                    }
                });

                if (view.findViewById(R.id.notification_count) != null) {
                    mNotificationBadgeCount = (RobotoTextView) view.findViewById(R.id.notification_count);
                    updateNotificationsCount(ApiRequestManager.getInstance(getApplicationContext()).getNotificationsCountInString());
                }
            }
        } else {
            mToolbar.getMenu().clear();
        }
    }

    protected void setToolbarListeners(View.OnClickListener navigationClickListener, Toolbar.OnMenuItemClickListener toolbarMenuItemClickListener) {
        if (navigationClickListener != null)
            mToolbar.setNavigationOnClickListener(navigationClickListener);
        if (toolbarMenuItemClickListener != null)
            mToolbar.setOnMenuItemClickListener(toolbarMenuItemClickListener);
    }


    @Override
    public void loadFragment(int fragmentContainerId, BaseFragment fragment, @Nullable String tag,
                             int enterAnimId, int exitAnimId,
                             BaseFragment.FragmentTransactionType fragmentTransactionType) {

        performFragmentTransaction(fragmentContainerId, fragment, tag,
                (enterAnimId == 0) ? 0 : enterAnimId,
                (exitAnimId == 0) ? 0 : exitAnimId,
                fragmentTransactionType);
    }

    @Override
    public void loadDialogFragment(DialogFragment fragment, @Nullable String tag) {
        fragment.show(getSupportFragmentManager(), tag);
    }

    @Override
    public void showBlockingProgressBar() {
        if (mBlockingProgressBar != null) {
            mBlockingProgressBar.setOnTouchListener(mProgressbarTouchListener);
            mBlockingProgressBar.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void hideBlockingProgressBar() {
        if (mBlockingProgressBar != null) {
            mBlockingProgressBar.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean isProgressBarShowing() {
        boolean visibility = false;
        if (mBlockingProgressBar != null) {
            visibility = mBlockingProgressBar.getVisibility() == View.VISIBLE;
        }
        return visibility;
    }

    @Override
    public void showAlert(String title, String message, String positiveBtnText,
                          String negativeBtnText,
                          AlertDialogFragment.AlertPositiveActionListener alertPositiveActionListener,
                          AlertDialogFragment.AlertNegativeActionListener alertNegativeActionListener,
                          boolean isCancelable) {
        if (mIsPaused) return;
        AlertDialogFragment alertDialogFragment = AlertDialogFragment.create(title, message,
                positiveBtnText, negativeBtnText,
                alertPositiveActionListener, alertNegativeActionListener);
        alertDialogFragment.setCancelable(isCancelable);
        alertDialogFragment.show(getSupportFragmentManager(), "dialog");
    }

    @Override
    protected void onStart() {
        super.onStart();
        updateCartCount(ApiRequestManager.getInstance(getApplicationContext()).getCartItemsCountInString(), false);
        //need to update notification count here
    }

    @Override
    protected void onResume() {
        super.onResume();
        mIsPaused = false;
    }

    @Override
    protected void onPause() {
        super.onPause();
        mIsPaused = true;
    }

    private void performFragmentTransaction(int fragmentContainerId,
                                            Fragment fragment, String tag,
                                            int enterAnimId, int exitAnimId,
                                            BaseFragment.FragmentTransactionType fragmentTransactionType) {
        switch (fragmentTransactionType) {
            case ADD:
                addFragment(fragmentContainerId, fragment, tag, enterAnimId, exitAnimId);
                break;
            case REPLACE:
                replaceFragment(fragmentContainerId, fragment, tag, enterAnimId, exitAnimId);
                break;
            case ADD_TO_BACK_STACK_AND_REPLACE:
                addToBackStackAndReplace(fragmentContainerId, fragment, tag, enterAnimId, exitAnimId);
                break;
            case POP_BACK_STACK_AND_REPLACE:
                popBackStackAndReplace(fragmentContainerId, fragment, tag, enterAnimId, exitAnimId);
                break;
            case CLEAR_BACK_STACK_AND_REPLACE:
                clearBackStackAndReplace(fragmentContainerId, fragment, tag, enterAnimId, exitAnimId);
                break;

            case ClEAR_ALL_AND_REPLACE:
                clearAllFragmentAndReplace(fragmentContainerId, fragment, tag, enterAnimId, exitAnimId);
                break;
            default:
                replaceFragment(fragmentContainerId, fragment, tag, enterAnimId, exitAnimId);
        }

    }

    protected void addFragment(int fragmentContainerId, Fragment fragment, String tag, int enterAnimId, int exitAnimId) {
        try {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(enterAnimId, exitAnimId)
                    .add(fragmentContainerId, fragment, tag)
                    .commit();
        } catch (IllegalStateException illegalStateException) {

            if (!isFinishing()) {
                getSupportFragmentManager().beginTransaction()
                        .setCustomAnimations(enterAnimId, exitAnimId)
                        .add(fragmentContainerId, fragment, tag)
                        .commitAllowingStateLoss();
            }
        }
    }

    private void replaceFragment(int fragmentContainerId, Fragment fragment, @Nullable String tag,
                                 int enterAnimId, int exitAnimId) {
        try {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(enterAnimId, exitAnimId)
                    .replace(fragmentContainerId, fragment, tag).commit();
        } catch (IllegalStateException illegalStateException) {

            if (!isFinishing()) {
                getSupportFragmentManager().beginTransaction()
                        .setCustomAnimations(enterAnimId, exitAnimId)
                        .replace(fragmentContainerId, fragment, tag).commitAllowingStateLoss();
            }
        }
    }

    private void popBackStackAndReplace(int fragmentContainerId, Fragment fragment,
                                        @Nullable String tag, int enterAnimId, int exitAnimId) {
        getSupportFragmentManager().popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);

        try {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(enterAnimId, exitAnimId)
                    .replace(fragmentContainerId, fragment, tag).commit();
        } catch (IllegalStateException illegalStateException) {

            if (!isFinishing()) {
                getSupportFragmentManager().beginTransaction()
                        .setCustomAnimations(enterAnimId, exitAnimId)
                        .replace(fragmentContainerId, fragment, tag).commitAllowingStateLoss();
            }
        }
    }

    private void addToBackStackAndReplace(int fragmentContainerId, Fragment fragment,
                                          @Nullable String tag, int enterAnimId, int exitAnimId) {
        try {
            getSupportFragmentManager().beginTransaction()
                    .addToBackStack(null)
                    .setCustomAnimations(enterAnimId, 0, 0, exitAnimId)
                    .replace(fragmentContainerId, fragment, tag)
                    .commit();
        } catch (IllegalStateException illegalStateException) {

            if (!isFinishing()) {
                getSupportFragmentManager().beginTransaction()
                        .addToBackStack(null)
                        .setCustomAnimations(enterAnimId, 0, 0, exitAnimId)
                        .replace(fragmentContainerId, fragment, tag)
                        .commitAllowingStateLoss();
            }
        }
    }

    private void clearBackStackAndReplace(int fragmentContainerId, Fragment fragment,
                                          @Nullable String tag, int enterAnimId, int exitAnimId) {
        clearBackStack(FragmentManager.POP_BACK_STACK_INCLUSIVE);
        try {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(enterAnimId, exitAnimId)
                    .replace(fragmentContainerId, fragment, tag).commit();
        } catch (IllegalStateException illegalStateException) {

            if (!isFinishing()) {
                getSupportFragmentManager().beginTransaction()
                        .setCustomAnimations(enterAnimId, exitAnimId)
                        .replace(fragmentContainerId, fragment, tag).commitAllowingStateLoss();
            }
        }
    }

    private void clearAllFragmentAndReplace(int fragmentContainerId, Fragment fragment, String tag, int enterAnimId, int exitAnimId) {
        clearAllFragments(fragmentContainerId);
        try {
            getSupportFragmentManager().beginTransaction()
                    .setCustomAnimations(enterAnimId, exitAnimId)
                    .replace(fragmentContainerId, fragment, tag).commit();
        } catch (IllegalStateException illegalStateException) {

            if (!isFinishing()) {
                getSupportFragmentManager().beginTransaction()
                        .setCustomAnimations(enterAnimId, exitAnimId)
                        .replace(fragmentContainerId, fragment, tag).commitAllowingStateLoss();
            }
        }
    }

    private void clearBackStack(int flag) {
        FragmentManager fm = getSupportFragmentManager();

        if (fm.getBackStackEntryCount() > 0) {
            FragmentManager.BackStackEntry first = fm.getBackStackEntryAt(0);
            fm.popBackStack(first.getId(), flag);
            fm.executePendingTransactions();
        }
    }

    @Override
    public void hideFragment(BaseFragment fragment) {
        //Hide fragment : to fix the issue previous fragment being shown onNewIntent
        try {
            getSupportFragmentManager().beginTransaction()
                    .hide(fragment).commit();
        } catch (IllegalStateException illegalStateException) {

            if (!isFinishing()) {
                getSupportFragmentManager().beginTransaction()
                        .hide(fragment).commitAllowingStateLoss();
            }
        }
    }

    private void clearAllFragments(int fragmentContainerId) {
        FragmentManager fm = getSupportFragmentManager();
        List<Fragment> fragmentList = fm.getFragments();

        if (fragmentList == null) return;

        for (Fragment frag : fragmentList) {
            try {
                fm.beginTransaction().remove(frag).commit();
            } catch (IllegalStateException illegalStateException) {

                if (!isFinishing()) {
                    fm.beginTransaction().remove(frag).commitAllowingStateLoss();
                }
            }
        }
        fm.executePendingTransactions();
    }

    protected void hide_keyboard() {
        InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = this.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(this);
        }
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    @Override
    public void onCartCountChanged(int cartCount) {

        updateCartCount((cartCount == 0) ? "" : "" + cartCount, true);
    }

    @Override
    public void onNotificationCountChanged(int notificationCount) {

        updateNotificationsCount((notificationCount == 0) ? "" : "" + notificationCount);
    }

    public void updateCartCount(String cartCount, boolean isCartCountUpdate) {
        if (mCartBadgeCount != null) {

            if (isCartCountUpdate) {
                animateCartCount(cartCount);
            } else {
                mCartBadgeCount.setText((cartCount));
                mCartBadgeCount.invalidate();
            }
        }
    }

    public void updateNotificationsCount(String notificationsCount) {
        if (mNotificationBadgeCount != null) {
            if (notificationsCount.equals("")) {
                mNotificationBadgeCount.setVisibility(View.GONE);
            } else {
                mNotificationBadgeCount.setVisibility(View.VISIBLE);
                mNotificationBadgeCount.setText((notificationsCount));
                mNotificationBadgeCount.invalidate();
            }
        }
    }

    protected void animateCartCount(final String cartCount) {
        ObjectAnimator animation = ObjectAnimator.ofFloat(mCartBadgeCount, "rotationY", 0.0f, 360f);
        animation.setDuration(2000);
        animation.addListener(new Animator.AnimatorListener() {
            @Override
            public void onAnimationStart(Animator animation) {
                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        // Do after 0.5s = 500ms
                        mCartBadgeCount.setText((cartCount));
                        mCartBadgeCount.invalidate();
                    }
                }, 500);
            }

            @Override
            public void onAnimationEnd(Animator animation) {

            }

            @Override
            public void onAnimationCancel(Animator animation) {

            }

            @Override
            public void onAnimationRepeat(Animator animation) {

            }
        });
        animation.setInterpolator(new AccelerateDecelerateInterpolator());
        animation.start();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        hideBlockingProgressBar();
    }
}
