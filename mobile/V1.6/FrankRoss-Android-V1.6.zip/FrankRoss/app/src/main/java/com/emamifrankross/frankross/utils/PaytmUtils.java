/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.utils;

import android.text.TextUtils;

import com.emamifrankross.frankross.core.network.UrlConstants;
import com.paytm.pgsdk.PaytmPGService;

/**
 * Created by gauthami on 19/4/16.
 */
public class PaytmUtils {

    /**
     * Method that checks the application environment when returning the Paytm SDK instance
     *
     * @return the Paytm Payment Gateway SDK instance (Staging/Production)
     */
    public static PaytmPGService getPaytmPGService() {
        return (UrlConstants.DEV_MODE) ? PaytmPGService.getStagingService() :
                PaytmPGService.getProductionService();
    }

    /**
     * REQUEST CREDENTIALS
     */
    public static final String PAYTM_MERCHANT_ID = UrlConstants.DEV_MODE ? "EMAMIF27433313344162" : "frankr25616696649223";
    public static final String PAYTM_WEBSITE = UrlConstants.DEV_MODE ? "EmamifrankWAP" : "Emamiwap";
    public static final String PAYTM_CHANNEL_ID = "WAP";
    public static final String PAYTM_INDUSTRY_TYPE = UrlConstants.DEV_MODE ? "Retail" : "Retail92";
    public static final String PAYTM_THEME = "merchant";
    public static final String PAYTM_REQUEST_TYPE = "DEFAULT";
    public static final String PAYTM_MERCHANT_KEY = UrlConstants.DEV_MODE ? "Gt_2f05QRK9%9UTI" : "eDe6HNePAwX2CW9f";
    public static final String PAYTM_PROMO_ID = "PAYTMEMAM";

    /**
     * REQUEST KEYS
     */
    public static final String PG_REQUEST_TYPE = "REQUEST_TYPE";
    public static final String PG_MERCHANT_ID_KEY = "MID";
    public static final String PG_ORDER_ID_KEY = "ORDER_ID";
    public static final String PG_CUSTOMER_ID_KEY = "CUST_ID";
    public static final String PG_CHANNEL_ID_KEY = "CHANNEL_ID";
    public static final String PG_INDUSTRY_TYPE_KEY = "INDUSTRY_TYPE_ID";
    public static final String PG_WEBSITE_KEY = "WEBSITE";
    public static final String PG_TAXN_AMOUNT_KEY = "TXN_AMOUNT";
    public static final String PG_THEME_KEY = "THEME";
    public static final String PG_PROMO_CODE_KEY = "PROMO_CAMP_ID";
    public static final String PG_EMAIL_ID_KEY = "EMAIL";
    public static final String PG_MOBILE_NUMBER_KEY = "MOBILE_NO";

    /**
     * RESPONSE KEYS
     */
    public static final String PAYTM_TRANSACTION_ID_KEY = "TXNID";
    public static final String PAYTM_BANK_TXN_ID_KEY = "BANKTXNID";
    public static final String PAYTM_ORDER_ID = "ORDERID";
    public static final String PAYTM_TRANSACTION_AMOUNT = "TXNAMOUNT";
    public static final String PAYTM_TRANSACTION_STATUS = "STATUS";
    public static final String PAYTM_TRANSACTION_TYPE = "TXNTYPE";
    public static final String PAYTM_TRANSACTION_CURRENCY = "CURRENCY";
    public static final String PAYTM_TRANSACTION_GATEWAY = "GATEWAYNAME";
    public static final String PAYTM_RESPONSE_CODE = "RESPCODE";
    public static final String PAYTM_RESPONSE_MESSAGE = "RESPMSG";
    public static final String PAYTM_BANK_NAME = "BANKNAME";
    public static final String PAYTM_MERCHANT_ID_KEY = "MID";
    public static final String PAYTM_PAYMENT_MODE = "PAYMENTMODE";
    public static final String PAYTM_REFUND_AMOUNT = "REFUNDAMT";
    public static final String PAYTM_TRANSACTION_DATE = "TXNDATE";
    public static final String PAYTM_CHECKSUM_VALID = "IS_CHECKSUM_VALID";

    /**
     * Payment methods
     */
    public static final String PAYMENT_METHOD_COD = "cod";
    public static final String PAYMENT_METHOD_WALLET = "wallet";
    public static final String PAYMENT_METHOD_CREDIT_CARD = "credit_card";
    public static final String PAYMENT_METHOD_DEBIT_CARD = "debit_card";
    public static final String PAYMENT_METHOD_NET_BANKING = "net_banking";

    /**
     * PAYTM response codes
     */
    private static final int PAYTM_ERROR_CODE_CANCEL_TRANSACTION = 141;
    private static final int PAYTM_ERROR_CODE_TECHNICAL_ERROR = 227;
    private static final int PAYTM_ERROR_CODE_PAGE_CLOSE_AFTER_LOGIN = 810;
    private static final int PAYTM_ERROR_CODE_SUFFICIENT_WALLET_BALANCE_TRANSACTION_CANCEL = 8102;
    private static final int PAYTM_ERROR_CODE_INSUFFICIENT_WALLET_BALANCE_TRANSACTION_CANCEL = 8103;
    private static final int PAYTM_ERROR_CODE_TRANSACTION_SUCCESS = 1;
    private static final int PAYTM_ERROR_CODE_EMPTY = 0;

    private static int mPaytmResponseCode = 0;
    private static String mPaytmMessage;

    public static void setResponseCode(int responseCode) {
        mPaytmResponseCode = responseCode;
    }

    public static void setPaymentMessage(String message) {
        mPaytmMessage = message;
    }

    /**
     * Method that customizes the error messages based on the Paytm SDK response codes
     *
     * @return the paytm payment transaction status message
     */
    public static String getPaymentErrorMessage() {

        StringBuilder paymentMessageBuilder = new StringBuilder();

        if (mPaytmResponseCode == PAYTM_ERROR_CODE_EMPTY && !TextUtils.isEmpty(mPaytmMessage)) {
            //If code is 0 and message is not empty
            paymentMessageBuilder.append(mPaytmMessage);
        } else if (mPaytmResponseCode != PAYTM_ERROR_CODE_EMPTY && TextUtils.isEmpty(mPaytmMessage)) {
            //If code is not 0 and Message is empty
            String paytmMessage;
            switch (mPaytmResponseCode) {
                case PAYTM_ERROR_CODE_TRANSACTION_SUCCESS:
                    paytmMessage = "Transaction Successful";
                    break;
                case PAYTM_ERROR_CODE_CANCEL_TRANSACTION:
                    paytmMessage = "Oops, you have cancelled the transaction";
                    break;
                case PAYTM_ERROR_CODE_TECHNICAL_ERROR:
                    paytmMessage = "Payment Failed due to a technical error. Please try after some time.";
                    break;
                case PAYTM_ERROR_CODE_PAGE_CLOSE_AFTER_LOGIN:
                case PAYTM_ERROR_CODE_SUFFICIENT_WALLET_BALANCE_TRANSACTION_CANCEL:
                case PAYTM_ERROR_CODE_INSUFFICIENT_WALLET_BALANCE_TRANSACTION_CANCEL:
                    paytmMessage = "Oops, you have cancelled the transaction";
                    break;
                default:
                    paytmMessage = "Transaction Failed";
                    break;
            }
            paymentMessageBuilder.append(paytmMessage);
        } else if (mPaytmResponseCode != PAYTM_ERROR_CODE_EMPTY && !TextUtils.isEmpty(mPaytmMessage)) {
            //If code is not 0 and message not empty
            String paytmMessage;
            switch (mPaytmResponseCode) {
                case PAYTM_ERROR_CODE_CANCEL_TRANSACTION:
                    paytmMessage = "Oops, you have cancelled the transaction";
                    break;
                case PAYTM_ERROR_CODE_TECHNICAL_ERROR:
                    paytmMessage = "Payment Failed due to a technical error. Please try after some time.";
                    break;
                case PAYTM_ERROR_CODE_PAGE_CLOSE_AFTER_LOGIN:
                case PAYTM_ERROR_CODE_SUFFICIENT_WALLET_BALANCE_TRANSACTION_CANCEL:
                case PAYTM_ERROR_CODE_INSUFFICIENT_WALLET_BALANCE_TRANSACTION_CANCEL:
                    paytmMessage = "Oops, you have cancelled the transaction";
                    break;
                default:
                    paytmMessage = mPaytmMessage;
                    break;
            }
            paymentMessageBuilder.append(paytmMessage);
        } else if (mPaytmResponseCode == PAYTM_ERROR_CODE_EMPTY && TextUtils.isEmpty(mPaytmMessage)) {
            //If code and message both are not empty/0
            paymentMessageBuilder.append("Transaction Failed");
        }
        return paymentMessageBuilder.toString();
    }
}
