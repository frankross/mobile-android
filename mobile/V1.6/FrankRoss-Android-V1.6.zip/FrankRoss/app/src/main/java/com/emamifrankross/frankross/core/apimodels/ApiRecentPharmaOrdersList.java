/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 18/8/15.
 */
public class ApiRecentPharmaOrdersList {

    public static class Response {

        private List<BaseRecyclerAdapter.IViewType> mUiDataList = new ArrayList<>(1);

        @SerializedName("recent_pharma_items")
        private List<RecentPharmaProduct> recentPharmaProducts;

        public List<RecentPharmaProduct> getRecentPharmaProducts() {
            return recentPharmaProducts;
        }

        public void setRecentPharmaProducts(List<RecentPharmaProduct> recentPharmaProducts) {
            this.recentPharmaProducts = recentPharmaProducts;
        }

        public List<BaseRecyclerAdapter.IViewType> getUiDataList() {
            return mUiDataList;
        }

        public void setUiDataList(List<BaseRecyclerAdapter.IViewType> uiDataList) {
            this.mUiDataList = uiDataList;
        }
    }
}
