/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.android.volley.toolbox.NetworkImageView;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiCategories;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.customviews.VolleySingleton;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 30/6/15.
 * <p/>
 * <p> Adapter class for Pharmacy Section</p>
 * <p>Supports the Two View Types </p>
 * <p> 1 : PHARMACY LIST ITEM VIEW TYPE </p>
 */
public class PharmacyRecyclerAdapter extends BaseRecyclerAdapter {

    public PharmacyRecyclerAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        ArrayList<RecyclerViewDataBinder> viewHolderTypes = new ArrayList<>(1);
        viewHolderTypes.add(new PharmacyListHolderType());
        return viewHolderTypes;
    }

    /**
     * PHARMACY LIST VIEW TYPE
     */

    public static class PharmacyListItem implements IViewType {

        public ApiCategories.Category mCategory;

        @Override
        public int getViewType() {
            return ViewTypes.PharmacyViewTypes.PHARMACY_LIST;
        }
    }

    private static class PharmacyListHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mPharmacyListItemTitle;
        private NetworkImageView mPharmacyListTitleIcon;

        public PharmacyListHolder(View view) {
            super(view);

            mPharmacyListItemTitle = (RobotoTextView) view.findViewById(R.id.pharmacy_category_title_tv);
            mPharmacyListTitleIcon = (NetworkImageView) view.findViewById(R.id.pharmacy_category_icon_iv);
            Animation fadeInAnimation = AnimationUtils.loadAnimation(mPharmacyListTitleIcon.getContext(), R.anim.fade_in);
            mPharmacyListTitleIcon.startAnimation(fadeInAnimation);
            mPharmacyListTitleIcon.setDefaultImageResId(R.drawable.product_logo);
        }
    }

    private class PharmacyListHolderType implements RecyclerViewDataBinder<PharmacyListHolder,
            PharmacyListItem> {
        @Override
        public PharmacyListHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pharmacy_list_item, parent, false);

            return new PharmacyListHolder(view);
        }

        @Override
        public void bindDataToViewHolder(PharmacyListHolder viewHolder, final PharmacyListItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mPharmacyListTitleIcon.setImageUrl(data.mCategory.getCategoryImageUrl(),
                    VolleySingleton.getInstance(viewHolder.mPharmacyListTitleIcon.getContext()).getImageLoader());
            viewHolder.mPharmacyListItemTitle.setText(Utils.getCapitalizedSentence(data.mCategory.getName()));

            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }

        }

        @Override
        public int getViewType() {
            return ViewTypes.PharmacyViewTypes.PHARMACY_LIST;
        }
    }

}
