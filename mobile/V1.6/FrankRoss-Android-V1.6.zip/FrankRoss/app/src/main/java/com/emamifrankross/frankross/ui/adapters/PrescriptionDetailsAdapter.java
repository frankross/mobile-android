/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiPrescriptionDescription;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 16/7/15.
 * <p> Adapter class for Prescription Details Section</p>
 * <p>Supports the Five View Types </p>
 * <p> 1 : DOSAGE HEADER HEADER VIEW TYPE </p>
 * <p> 2 : PRESCRIPTION INFO HEADER VIEW TYPE </p>
 * <p> 3 : PRESCRIPTION INFO VIEW TYPE </p>
 * <p> 4 : DOSAGE SCHEDULE HEADER VIEW TYPE </p>
 * <p> 5 : PRESCRIPTION NOTES VIEW TYPE </p>
 */
public class PrescriptionDetailsAdapter extends BaseRecyclerAdapter {

    public PrescriptionDetailsAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewDataBinderList = new ArrayList<>(1);
        viewDataBinderList.add(new PrescriptionInfoViewDataBinder());
        viewDataBinderList.add(new PrescriptionNotesViewDataBinder());
        viewDataBinderList.add(new PrescriptionDosageViewDataBinder());
        viewDataBinderList.add(new PrescriptionRemarksViewDataBinder());
        viewDataBinderList.add(new PrescriptionDeleteViewDataBinder());
        return viewDataBinderList;
    }

    /**
     * PRESCRIPTION INFO VIEW TYPE
     */
    public static class PrescriptionInfoDataItem implements IViewType {

        public String prescriptionDate = "NA";
        public String prescriptionExpiryDate = "NA";
        public String prescriptionReferenceNumber = "NA";

        public ApiPrescriptionDescription.Response.Patient patient;
        public ApiPrescriptionDescription.Response.Doctor doctor;
        public long presNumber = 0;

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_INFO;
        }
    }

    private static class PrescriptionInfoViewHolder extends RecyclerView.ViewHolder {

        public LinearLayout mPrescriptionPatientView;
        public LinearLayout mPrescriptionDoctorView;

        public ImageView mDoctorMoreIcon;
        public ImageView mPatientMoreIcon;

        public RobotoTextView mPrescriptionDate;
        public RobotoTextView mPatientName;
        public RobotoTextView mDoctorName;
        public RobotoTextView mPrescriptionReferenceNumber;
        public RobotoTextView mPrescriptionRefNo;

        public RobotoTextView mPatientAge;
        public RobotoTextView mPatientGender;
        public RobotoTextView mPatientHeight;
        public RobotoTextView mPatientWeight;
        public RobotoTextView mDoctorRegNumber;
        public RobotoTextView mDoctorPhoneNumber;
        public RobotoTextView mDoctorSpeciality;
        public RobotoTextView mDoctorMobile;
        public RobotoTextView mDoctorFacility;
        public RobotoTextView mDoctorAddress;

        public PrescriptionInfoViewHolder(View itemView) {
            super(itemView);

            mPrescriptionDate = (RobotoTextView) itemView.findViewById(R.id.prescription_date_tv);
            mPatientName = (RobotoTextView) itemView.findViewById(R.id.prescriptions_patient_name_tv);
            mDoctorName = (RobotoTextView) itemView.findViewById(R.id.prescriptions_doctor_name_tv);
            mPrescriptionPatientView = (LinearLayout) itemView.findViewById(R.id.prescription_patient_view);
            mPrescriptionDoctorView = (LinearLayout) itemView.findViewById(R.id.prescription_doctor_view);
            mDoctorMoreIcon = (ImageView) itemView.findViewById(R.id.prescription_doctor_more_iv);
            mPatientMoreIcon = (ImageView) itemView.findViewById(R.id.prescription_patient_more_iv);
            mPrescriptionReferenceNumber = (RobotoTextView) itemView.findViewById(R.id.prescription_reference_number_tv);
            mPrescriptionRefNo = (RobotoTextView) itemView.findViewById(R.id.prescription_ref_no_tv);
            mPrescriptionReferenceNumber.setTextColor(ContextCompat.getColor(mPrescriptionReferenceNumber.getContext(), R.color.black_text_color));
            ((RobotoTextView) itemView.findViewById(R.id.prescription_reference_title_tv)).
                    setTextColor(ContextCompat.getColor(mPrescriptionReferenceNumber.getContext(), R.color.black_text_color));

            mPatientAge = (RobotoTextView) itemView.findViewById(R.id.patient_age);
            mPatientGender = (RobotoTextView) itemView.findViewById(R.id.patient_gender);
            mPatientHeight = (RobotoTextView) itemView.findViewById(R.id.patient_height);
            mPatientWeight = (RobotoTextView) itemView.findViewById(R.id.patient_weight);

            mDoctorRegNumber = (RobotoTextView) itemView.findViewById(R.id.doctor_reg_number_tv);
            mDoctorPhoneNumber = (RobotoTextView) itemView.findViewById(R.id.doctor_phone_number_tv);
            mDoctorSpeciality = (RobotoTextView) itemView.findViewById(R.id.doctor_speciality_tv);
            mDoctorMobile = (RobotoTextView) itemView.findViewById(R.id.doctor_mobile_number_tv);
            mDoctorFacility = (RobotoTextView) itemView.findViewById(R.id.doctor_facility_tv);
            mDoctorAddress = (RobotoTextView) itemView.findViewById(R.id.doctor_address_tv);
        }
    }

    private class PrescriptionInfoViewDataBinder implements
            RecyclerViewDataBinder<PrescriptionInfoViewHolder, PrescriptionInfoDataItem> {

        @Override
        public PrescriptionInfoViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.prescription_details_info_item, parent, false);

            return new PrescriptionInfoViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final PrescriptionInfoViewHolder viewHolder,
                                         final PrescriptionInfoDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mPrescriptionReferenceNumber.setText(TextUtils.isEmpty(String.valueOf(data.presNumber)) ?
                    "Not available" : String.valueOf(data.presNumber));
            viewHolder.mPrescriptionDate.setText(TextUtils.isEmpty(data.prescriptionDate) ? "" : data.prescriptionDate);
            viewHolder.mPrescriptionRefNo.setText(TextUtils.isEmpty(data.prescriptionReferenceNumber) ? "NA" :
                    data.prescriptionReferenceNumber);

            viewHolder.mPatientName.setText(TextUtils.isEmpty(data.patient.getName()) ? " - " : data.patient.getName());
            viewHolder.mPatientAge.setText(TextUtils.isEmpty(data.patient.getAge()) ? " - " : data.patient.getAge());
            viewHolder.mPatientWeight.setText(TextUtils.isEmpty(data.patient.getWeight()) ? " - " : data.patient.getWeight());
            viewHolder.mPatientHeight.setText(TextUtils.isEmpty(data.patient.getHeight()) ? " - " : data.patient.getHeight());
            viewHolder.mPatientGender.setText(TextUtils.isEmpty(data.patient.getGender()) ? " - " : data.patient.getGender());

            viewHolder.mDoctorName.setText(TextUtils.isEmpty(data.doctor.getName()) ? " - " : Utils.getDoctorPrefixedName(data.doctor.getName()));
            viewHolder.mDoctorAddress.setText(TextUtils.isEmpty(data.doctor.getAddress()) ? " - " : data.doctor.getAddress());
            viewHolder.mDoctorSpeciality.setText(TextUtils.isEmpty(data.doctor.getSpeciality()) ? " - " : data.doctor.getSpeciality());
            viewHolder.mDoctorRegNumber.setText(TextUtils.isEmpty(data.doctor.getRegNo()) ? " - " : data.doctor.getRegNo());
            viewHolder.mDoctorMobile.setText(TextUtils.isEmpty(data.doctor.getMobile()) ? " - " : data.doctor.getMobile());
            viewHolder.mDoctorPhoneNumber.setText(TextUtils.isEmpty(data.doctor.getPhone()) ? " - " : data.doctor.getPhone());
            viewHolder.mDoctorFacility.setText(TextUtils.isEmpty(data.doctor.getFacility()) ? " - " : data.doctor.getFacility());

            if (recyclerViewClickListener != null) {
                viewHolder.mDoctorMoreIcon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int visibilityState = viewHolder.mPrescriptionDoctorView.getVisibility();
                        if (visibilityState != View.VISIBLE) {

                            viewHolder.mPrescriptionDoctorView.setVisibility(View.VISIBLE);
                            final int widthSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
                            final int heightSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
                            viewHolder.mPrescriptionDoctorView.measure(widthSpec, heightSpec);
                            ValueAnimator mAnimator = slideAnimator(0, viewHolder.mPrescriptionDoctorView.getMeasuredHeight(),
                                    viewHolder.mPrescriptionDoctorView);
                            mAnimator.start();
                            viewHolder.mDoctorMoreIcon.setRotation(180);

                        } else {
                            viewHolder.mDoctorMoreIcon.setRotation(0);
                            int finalHeight = viewHolder.mPrescriptionDoctorView.getHeight();
                            ValueAnimator mAnimator = slideAnimator(finalHeight, 0, viewHolder.mPrescriptionDoctorView);
                            mAnimator.addListener(new Animator.AnimatorListener() {
                                @Override
                                public void onAnimationStart(Animator animation) {

                                }

                                @Override
                                public void onAnimationEnd(Animator animator) {
                                    viewHolder.mPrescriptionDoctorView.setVisibility(View.GONE);
                                }

                                @Override
                                public void onAnimationCancel(Animator animation) {

                                }

                                @Override
                                public void onAnimationRepeat(Animator animation) {

                                }
                            });
                            mAnimator.start();
                        }
                    }
                });

                viewHolder.mPatientMoreIcon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int visibilityState = viewHolder.mPrescriptionPatientView.getVisibility();
                        if (visibilityState != View.VISIBLE) {

                            viewHolder.mPrescriptionPatientView.setVisibility(View.VISIBLE);
                            final int widthSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
                            final int heightSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
                            viewHolder.mPrescriptionPatientView.measure(widthSpec, heightSpec);
                            ValueAnimator mAnimator = slideAnimator(0, viewHolder.mPrescriptionPatientView.getMeasuredHeight(),
                                    viewHolder.mPrescriptionPatientView);
                            mAnimator.start();
                            viewHolder.mPatientMoreIcon.setRotation(180);

                        } else {
                            viewHolder.mPatientMoreIcon.setRotation(0);
                            int finalHeight = viewHolder.mPrescriptionPatientView.getHeight();
                            ValueAnimator mAnimator = slideAnimator(finalHeight, 0, viewHolder.mPrescriptionPatientView);
                            mAnimator.addListener(new Animator.AnimatorListener() {
                                @Override
                                public void onAnimationStart(Animator animation) {

                                }

                                @Override
                                public void onAnimationEnd(Animator animator) {
                                    viewHolder.mPrescriptionPatientView.setVisibility(View.GONE);
                                }

                                @Override
                                public void onAnimationCancel(Animator animation) {

                                }

                                @Override
                                public void onAnimationRepeat(Animator animation) {

                                }
                            });
                            mAnimator.start();
                        }
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_INFO;
        }
    }

    private ValueAnimator slideAnimator(int start, int end, final LinearLayout view) {

        ValueAnimator animator = ValueAnimator.ofInt(start, end);

        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                int value = (Integer) valueAnimator.getAnimatedValue();
                ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                layoutParams.height = value;
                view.setLayoutParams(layoutParams);
            }
        });
        return animator;
    }

    /**
     * DOSAGE SCHEDULE INFO VIEW TYPE
     */

    public static class PrescriptionDosageDataItem implements IViewType {

        public String prescriptionMedicineTimings = "NA";
        public String prescriptionMedicineDays = "NA";
        public String prescriptionMedicineQuantity = "NA";
        public String prescriptionMedicineName = "NA";
        public String presMedicineQuantity = "";

        public long presMedicineVariantId = 0;
        public int prescMedicineListSize = 0;

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_DOSAGE_INFO;
        }
    }

    private static class PrescriptionDosageViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mPrescriptionMedicineTimings;
        private RobotoTextView mPrescriptionMedicineDays;
        private RobotoTextView mPrescriptionMedicineQuantity;
        private RobotoTextView mPrescriptionMedicineName;

        public PrescriptionDosageViewHolder(View itemView) {
            super(itemView);
            mPrescriptionMedicineName = (RobotoTextView) itemView.findViewById(R.id.prescription_detail_medicine_name_tv);
            mPrescriptionMedicineQuantity = (RobotoTextView) itemView.findViewById(R.id.prescription_details_medicine_quantity_tv);
            mPrescriptionMedicineDays = (RobotoTextView) itemView.findViewById(R.id.prescription_details_medicine_days_count_tv);
            mPrescriptionMedicineTimings = (RobotoTextView) itemView.findViewById(R.id.prescription_details_medicine_status_tv);
        }
    }

    private static class PrescriptionDosageViewDataBinder implements
            RecyclerViewDataBinder<PrescriptionDosageViewHolder, PrescriptionDosageDataItem> {

        @Override
        public PrescriptionDosageViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.prescription_detail_dosage_info, parent, false);
            return new PrescriptionDosageViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(PrescriptionDosageViewHolder viewHolder,
                                         final PrescriptionDosageDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mPrescriptionMedicineName.setText(data.prescriptionMedicineName);
            viewHolder.mPrescriptionMedicineQuantity.setText(data.prescriptionMedicineQuantity);
            viewHolder.mPrescriptionMedicineTimings.setText(data.prescriptionMedicineTimings);
            viewHolder.mPrescriptionMedicineDays.setText(data.prescriptionMedicineDays);

            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_DOSAGE_INFO;
        }
    }

    /**
     * PRESCRIPTION NOTES VIEW TYPE
     */

    public static class PrescriptionNotesDataItem implements IViewType {

        public String notesHeader;
        public String noteDescription;

        @Override
        public int getViewType() {
            return ViewTypes.SortViewType.SORT_LIST_ITEM;
        }
    }

    private static class PrescriptionNotesViewHolder extends RecyclerView.ViewHolder {

        private ImageView mNotesIndicator;
        private RobotoTextView mNoteHeaderText;

        public PrescriptionNotesViewHolder(View itemView, Context context) {
            super(itemView);
            mNotesIndicator = (ImageView) itemView.findViewById(R.id.sort_indicator_iv);
            mNoteHeaderText = (RobotoTextView) itemView.findViewById(R.id.sort_by_text_tv);

            mNoteHeaderText.setTextSize(17);
            mNotesIndicator.setImageDrawable(ContextCompat.getDrawable(context, R.mipmap.nextarrow));
        }
    }

    private static class PrescriptionNotesViewDataBinder implements
            RecyclerViewDataBinder<PrescriptionNotesViewHolder, PrescriptionNotesDataItem> {

        @Override
        public PrescriptionNotesViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sort_products_list_item, parent, false);

            return new PrescriptionNotesViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(final PrescriptionNotesViewHolder viewHolder,
                                         final PrescriptionNotesDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mNoteHeaderText.setText(data.notesHeader);

            if (recyclerViewClickListener != null) {
                viewHolder.mNoteHeaderText.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.SortViewType.SORT_LIST_ITEM;
        }
    }

    /**
     * PRESCRIPTION REMARKS VIEW TYPE
     */

    public static class PrescriptionRemarksDataItem implements IViewType {

        public String remarks = "";

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_REMARKS;
        }
    }

    private static class PrescriptionRemarksViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mRemarks;

        public PrescriptionRemarksViewHolder(View itemView) {
            super(itemView);
            mRemarks = (RobotoTextView) itemView.findViewById(R.id.prescription_details_remarks_tv);
        }
    }

    private static class PrescriptionRemarksViewDataBinder implements
            RecyclerViewDataBinder<PrescriptionRemarksViewHolder, PrescriptionRemarksDataItem> {

        @Override
        public PrescriptionRemarksViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.prescription_details_remarks, parent, false);

            return new PrescriptionRemarksViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final PrescriptionRemarksViewHolder viewHolder,
                                         final PrescriptionRemarksDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mRemarks.setText(data.remarks);
        }

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_REMARKS;
        }
    }

    /**
     * PRESCRIPTION REMARKS VIEW TYPE
     */

    public static class PrescriptionDeleteDataItem implements IViewType {

        public String title = "Delete this prescription";

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_DELETE_PRESC;
        }
    }

    private static class PrescriptionDeleteViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mDeletePresc;

        public PrescriptionDeleteViewHolder(View itemView) {
            super(itemView);
            mDeletePresc = (RobotoTextView) itemView.findViewById(R.id.top_selling_products_list_header_tv);
        }
    }

    private static class PrescriptionDeleteViewDataBinder implements
            RecyclerViewDataBinder<PrescriptionDeleteViewHolder, PrescriptionDeleteDataItem> {

        @Override
        public PrescriptionDeleteViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.top_selling_products_list_header, parent, false);

            return new PrescriptionDeleteViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final PrescriptionDeleteViewHolder viewHolder,
                                         final PrescriptionDeleteDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mDeletePresc.setText(data.title);
        }

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_DELETE_PRESC;
        }
    }
}


