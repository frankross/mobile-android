/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class PreferenceUtils {

    protected static final String TAG = PreferenceUtils.class.getName();

    private static final String PREFERENCE_NAME = "frankross";

    public static final String PREFERENCE_KEY_ACCESS_TOKEN = "accessToken";
    public static final String PREFERENCE_KEY_GCM_TOKEN = "gcmToken";
    public static final String PREFERENCE_KEY_GCM_TOKEN_SENT_TO_SERVER = "sentTokenToServer";

    public static final String PREFERENCE_KEY_LOCATION_NAME = "LocationName";
    public static final String PREFERENCE_KEY_LOCATION_ID = "LocationId";
    public static final String PREFERENCE_USER_NAME = "UserName";
    public static final String PREFERENCE_USER_MOBILE_NUMBER = "UserMobileNumber";
    public static final String PREFERENCE_USER_ID = "UserID";
    public static final String PREFERENCE_IS_REGISTERED = "isRegistered";
    public static final String PREFERENCE_IS_FAILURE_DIALOG_SHOWN = "isFailureDialogShown";
    public static final String PREFERENCE_IS_WELCOME_DIALOG_SHOWN = "isWelcomeDialogShown";
    public static final String PREFERENCE_SPINNER_ITEM_POSITION = "SpinnerItemPosition";

    public static final String PREFERENCE_KEY_REFERRAL_CODE = "referralCode";

    public static final String PREFERENCE_KEY_PRIVACY_URL = "privacyUrl";
    public static final String PREFERENCE_KEY_API_STAGING_URL = "staging_url";
    public static final String PREFERENCE_KEY_ALGOLIA_SUFFIX = "algolia_suffix";


    public static String getStringFromSharedPreference(Context context,
                                                       String key) {
        String value = null;
        SharedPreferences sharedpreferences = context.getSharedPreferences(
                PREFERENCE_NAME, Context.MODE_PRIVATE);

        if (sharedpreferences.contains(key)) {
            value = sharedpreferences.getString(key, null);
        }

        return value;
    }

    public static void saveStringIntoSharedPreference(Context context,
                                                      String key, String value) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(
                PREFERENCE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor prefEditor = sharedpreferences.edit();
        prefEditor.putString(key, value);
        prefEditor.apply();
    }

    public static int getIntegerFromSharedPreference(Context context, String key) {
        int value = 0;
        SharedPreferences sharedpreferences = context.getSharedPreferences(
                PREFERENCE_NAME, Context.MODE_PRIVATE);
        if (sharedpreferences.contains(key)) {
            value = sharedpreferences.getInt(key, -1);
        }

        return value;
    }

    public static void saveIntegerIntoSharedPreference(Context context,
                                                       String key, int value) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(
                PREFERENCE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor prefEditor = sharedpreferences.edit();
        prefEditor.putInt(key, value);

        prefEditor.apply();
    }

    public static float getFloatFromSharedPreference(Context context, String key) {
        float value = 0.0f;
        SharedPreferences sharedpreferences = context.getSharedPreferences(
                PREFERENCE_NAME, Context.MODE_PRIVATE);
        if (sharedpreferences.contains(key)) {
            value = sharedpreferences.getFloat(key, -0.0f);
        }

        return value;
    }

    public static void saveFloatIntoSharedPreference(Context context,
                                                     String key, float value) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(
                PREFERENCE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor prefEditor = sharedpreferences.edit();
        prefEditor.putFloat(key, value);

        prefEditor.apply();
    }

    public static void saveBooleanIntoSharedPreference(Context context,
                                                       String key, boolean value) {
        SharedPreferences sharedpreferences = context.getSharedPreferences(
                PREFERENCE_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor prefEditor = sharedpreferences.edit();
        prefEditor.putBoolean(key, value);

        prefEditor.apply();
    }


    public static boolean getBooleanFromSharedPreference(Context context, String key) {
        boolean value = false;
        SharedPreferences sharedpreferences = context.getSharedPreferences(
                PREFERENCE_NAME, Context.MODE_PRIVATE);
        if (sharedpreferences.contains(key)) {
            value = sharedpreferences.getBoolean(key, false);
        }

        return value;
    }

}
