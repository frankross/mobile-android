/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gauthami on 22/7/15.
 */

/**
 * Order history product header item view holder
 */
public class OrderHistoryProductInfoHeaderViewHolder extends RecyclerView.ViewHolder {

    public LinearLayout mOrderHistoryProductInfoLinLyt;
    public RobotoTextView mPriceHeader;

    public OrderHistoryProductInfoHeaderViewHolder(View view, Context context) {
        super(view);

        mOrderHistoryProductInfoLinLyt = (LinearLayout) view.findViewById(R.id.order_history_header_layout);
        mPriceHeader = (RobotoTextView) view.findViewById(R.id.order_history_product_info_price_tv);
        mPriceHeader.setText(Utils.addRupeeSymbolWithoutSpace(context, "Price (", ")"));
        mOrderHistoryProductInfoLinLyt.setPadding(context.getResources().getDimensionPixelOffset(R.dimen.header_left_padding),
                context.getResources().getDimensionPixelOffset(R.dimen.order_history_product_header_top_margin),
                context.getResources().getDimensionPixelOffset(R.dimen.header_right_padding),
                context.getResources().getDimensionPixelOffset(R.dimen.order_history_product_header_bottom_margin));
    }
}