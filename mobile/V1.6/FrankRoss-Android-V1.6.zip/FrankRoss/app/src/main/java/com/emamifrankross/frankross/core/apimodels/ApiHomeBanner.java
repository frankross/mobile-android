/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 24/8/15.
 */
public class ApiHomeBanner {

    public static class Response {

        private List<List<Banner>> mUiDataList = new ArrayList<>();

        @SerializedName("home_banners")
        private List<Banner> homeBannerList;

        @SerializedName("home_store_banners")
        private List<Banner> homeStoreList;

        public List<Banner> getHomeBannerList() {
            return homeBannerList;
        }

        public List<List<Banner>> getUiDataList() {
            return mUiDataList;
        }

        public void setUiDataList(List<List<Banner>> mUiDataList) {
            this.mUiDataList = mUiDataList;
        }

        public List<Banner> getHomeStoreList() {
            return homeStoreList;
        }
    }

    public static class Banner {

        @SerializedName("url")
        private String url = "";

        @SerializedName("id")
        private long id = 0;

        @SerializedName("promotion_id")
        private long promotionId = 0;

        @SerializedName("type")
        private String type = "";

        @SerializedName("html_page")
        private String webUrl = "";

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }

        public String getWebUrl() {
            return webUrl;
        }

        public void setWebUrl(String webUrl) {
            this.webUrl = webUrl;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public long getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public long getPromotionId() {
            return promotionId;
        }

        public void setPromotionId(long promotionId) {
            this.promotionId = promotionId;
        }
    }
}
