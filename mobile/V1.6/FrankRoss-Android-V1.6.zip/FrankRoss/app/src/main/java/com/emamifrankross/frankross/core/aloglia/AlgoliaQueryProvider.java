/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.aloglia;

import android.text.TextUtils;

import com.algolia.search.saas.Query;
import com.emamifrankross.frankross.core.aloglia.datamodel.AlgoliaProductsFilterInfo;
import com.emamifrankross.frankross.ui.common.FilterSelectionStats;
import com.emamifrankross.frankross.ui.common.Stats;
import com.emamifrankross.frankross.utils.Log;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by gowtham on 23/7/15.
 * This call is responsible for creating Algolia Queries required for this application.
 * Based on provided information like city, index, facet attributes numerical filters, facets filters etc..
 * Note : Please add methods below for newly required queries.
 */
public class AlgoliaQueryProvider {

    private static final String TAG = AlgoliaQueryProvider.class.getSimpleName();

    private static List<String> getAttributesListForSearch() {
        ArrayList list = new ArrayList(3);
        list.add("id");
        list.add("name");
        list.add("brand_name");
        list.add("manufacturer");
        list.add("icon_image_url");
        list.add("category_details");
        list.add("generic_keywords1");

        return list;
    }

    /**
     * Creates and returns the Algolia Query for getting the home screen products.
     *
     * @param cityKey      city key for filter the products only for this city id.
     * @param itemsPerPage number of products to be fetched per page.
     * @param pageNumber   Page number for products
     * @return Algolia Query.
     */
    public static Query getFeaturedProductQuery(String cityKey, int itemsPerPage, int pageNumber,
                                                boolean isFilterRequired) {
        Query searchQuery = new Query();
        searchQuery.setNumericFilters("cities_mapping." + cityKey + ".active=1");
        searchQuery.setFacetFilters("featured:true");
        if (isFilterRequired)
            searchQuery.setFacets(Arrays.asList("*"));
        searchQuery.setHitsPerPage(itemsPerPage);
        searchQuery.setPage(pageNumber);

        return searchQuery;
    }

    /**
     * Creates and returns the Algolia Query for getting search suggestions.
     *
     * @param cityKey      city key for filter the products only for this city id.
     * @param itemsPerPage number of products to be fetched per page.
     * @param searchTerm   search string used for filter the products
     * @return Algolia Query.
     */
    public static Query getSearchSuggestionsQuery(String searchTerm, String cityKey, int itemsPerPage) {
        Query searchQuery = new Query(searchTerm);
        searchQuery.setNumericFilters("cities_mapping." + cityKey + ".active=1");
        searchQuery.setHitsPerPage(itemsPerPage);
        searchQuery.setPage(0);
        searchQuery.setAttributesToRetrieve(getAttributesListForSearch());

        return searchQuery;
    }

    /**
     * Creates and returns the Algolia Query for getting search products.
     *
     * @param cityKey      city key for filter the products only for this city id.
     * @param itemsPerPage number of products to be fetched per page.
     * @param searchTerm   search string used for filter the products
     * @return Algolia Query.
     */
    public static Query getSearchResultsQuery(String searchTerm, String cityKey, int itemsPerPage, int pageNumber) {
        Query searchQuery = new Query(searchTerm);
        String filter = "cities_mapping." + cityKey + ".active=1";

        searchQuery.setNumericFilters(filter);
        searchQuery.setHitsPerPage(itemsPerPage);
        searchQuery.setFacets(Arrays.asList("*"));
        searchQuery.setPage(pageNumber);
        // searchQuery.setAttributesToRetrieve(getAttributesListForSearch());

        return searchQuery;
    }

    /**
     * Creates and returns the Algolia Query for getting promotional products
     *
     * @param cityKey      city key for filter the products only for this city id.
     * @param itemsPerPage number of products to be fetched per page.
     * @param promotionId  id used for filter the products
     * @return Algolia Query.
     */
    public static Query getPromotionsProductQuery(long categoryId, long promotionId, String cityKey, int itemsPerPage,
                                                  int pageNumber, boolean isFilterRequired) {
        Query searchQuery = new Query();
        String filter = "cities_mapping." + cityKey + ".active=1," +
                "( category_details.base_category.id=" + categoryId
                + ",category_details.primary_category.id=" + categoryId
                + ",category_details.secondary_category.id=" + categoryId
                + ")"
                + ", cities_mapping." + cityKey + ".promotion_id=" + promotionId;

        searchQuery.setNumericFilters(filter);
        if (isFilterRequired)
            searchQuery.setFacets(Arrays.asList("*"));
        searchQuery.setHitsPerPage(itemsPerPage);
        searchQuery.setPage(pageNumber);

        return searchQuery;
    }

    /**
     * Creates and returns the Algolia Query for getting category products
     *
     * @param cityKey      city key for filter the products only for this city id.
     * @param itemsPerPage number of products to be fetched per page.
     * @param categoryId   id used for filter the products based on category.
     * @return Algolia Query.
     */
    public static Query getCategoryProductQuery(boolean isFeatured, long categoryId, String cityKey, int itemsPerPage,
                                                int pageNumber, boolean isFilterRequired) {
        Query searchQuery = new Query();
        String filter = "cities_mapping." + cityKey + ".active=1," +
                "( category_details.base_category.id=" + categoryId
                + ",category_details.primary_category.id=" + categoryId
                + ",category_details.secondary_category.id=" + categoryId
                + ")";

        searchQuery.setNumericFilters(filter);

        if (isFeatured)
            searchQuery.setFacetFilters("featured:true");

        if (isFilterRequired)
            searchQuery.setFacets(Arrays.asList("*"));
        searchQuery.setHitsPerPage(itemsPerPage);
        searchQuery.setPage(pageNumber);

        return searchQuery;
    }

    public static Query getSearchResultsQueryWithAppliedFilterAndSortInfo(String searchTerm, String cityFilterKey,
                                                                          int itemsPerPage, int pageNumber,
                                                                          AlgoliaProductsFilterInfo appliedFilterInfo) {
        Query searchQuery = new Query(searchTerm);
        return getProductQueryWithAppliedFilterAndSortInfo(searchQuery, false, -1, -1, cityFilterKey, itemsPerPage, pageNumber, appliedFilterInfo);
    }

    public static Query getCategoryProductWithBrandQueryWithAppliedFilterAndSortInfo(String brandName, long categoryId,
                                                                                     String cityKey, int itemsPerPage, int pageNumber,
                                                                                     AlgoliaProductsFilterInfo appliedFilterInfo) {
        Query searchQuery = getProductQueryWithAppliedFilterAndSortInfo(new Query(), false, -1, categoryId, cityKey, itemsPerPage, pageNumber, appliedFilterInfo);

        String facetFilter = searchQuery.getFacetFilters();
        StringBuilder brandFaceBuilder = new StringBuilder();

        brandFaceBuilder.append(facetFilter);
        if (!TextUtils.isEmpty(facetFilter)) {
            brandFaceBuilder.append(",");
        }
        brandFaceBuilder.append("(brand_name:")
                .append(brandName)
                .append(")");
        searchQuery.setFacetFilters(brandFaceBuilder.toString());
        return searchQuery;
    }

    public static Query getCategoryProductWithPromotionQueryWithAppliedFilterAndSortInfo(long promotionId, long categoryId,
                                                                                         String cityKey, int itemsPerPage,
                                                                                         int pageNumber,
                                                                                         AlgoliaProductsFilterInfo appliedFilterInfo) {
        Query searchQuery = new Query();
        return getProductQueryWithAppliedFilterAndSortInfo(searchQuery, false, promotionId, categoryId, cityKey, itemsPerPage, pageNumber, appliedFilterInfo);
    }

    public static Query getProductQueryWithAppliedFilterAndSortInfo(
            boolean isFeatured, long categoryId, String cityKey, int itemsPerPage, int pageNumber,
            AlgoliaProductsFilterInfo appliedFilterInfo) {
        Query searchQuery = new Query();
        return getProductQueryWithAppliedFilterAndSortInfo(searchQuery, isFeatured, -1, categoryId, cityKey, itemsPerPage, pageNumber, appliedFilterInfo);
    }

    /**
     * Creates and returns the Algolia Query for getting category products with applied Filter and Sort Info
     *
     * @param isFeatured   the flag that indicates the featured products
     * @param categoryId   id used for filter the products based on category.
     * @param cityKey      city key for filter the products only for this city id.
     * @param itemsPerPage number of products to be fetched per page.
     * @return Algolia Query.
     */
    public static Query getProductQueryWithAppliedFilterAndSortInfo(Query searchQuery,
                                                                    boolean isFeatured,
                                                                    long promotionalId,
                                                                    long categoryId,
                                                                    String cityKey,
                                                                    int itemsPerPage,
                                                                    int pageNumber,
                                                                    AlgoliaProductsFilterInfo appliedFilterInfo) {
        StringBuilder numericFilterBuilder = new StringBuilder();
        numericFilterBuilder.append("cities_mapping.").append(cityKey).append(".active=1");

        if (categoryId != -1) {
            numericFilterBuilder.append(", ")
                    .append("(")
                    .append("category_details.base_category.id=").append(categoryId)
                    .append(",category_details.primary_category.id=").append(categoryId)
                    .append(",category_details.secondary_category.id=").append(categoryId)
                    .append(")");
        }

        if (promotionalId != -1) {
            numericFilterBuilder.append(", cities_mapping.").append(cityKey);
            numericFilterBuilder.append(".promotions.promotion_id=").append(promotionalId);
        }

        StringBuilder facetBuilder = new StringBuilder();

        if (isFeatured)
            facetBuilder.append("featured:true");

        if (appliedFilterInfo != null) {

            String categoryFacetFilter = getCategoryNameFacetFilterString(appliedFilterInfo.getCategoryStatList());
            if (!TextUtils.isEmpty(categoryFacetFilter)) {
                facetBuilder.append((!TextUtils.isEmpty(facetBuilder.toString())) ? "," : "")
                        .append(categoryFacetFilter);
            }

            String brandFacetFilter = getBrandFacetFilterString(appliedFilterInfo.getBrandStatList());
            if (!TextUtils.isEmpty(brandFacetFilter)) {
                facetBuilder.append((!TextUtils.isEmpty(facetBuilder.toString())) ? "," : "")
                        .append(brandFacetFilter);
            }

            String salesPriceNumericFilter = getSalesPriceStatsNumericFilterString(appliedFilterInfo.getSalesPriceStats(), cityKey);
            if (!TextUtils.isEmpty(salesPriceNumericFilter)) {
                numericFilterBuilder.append((!TextUtils.isEmpty(numericFilterBuilder.toString())) ? "," : "")
                        .append(salesPriceNumericFilter);
            }

            String discountPriceNumericFilter = getDiscountPriceStatsNumericFilterString(appliedFilterInfo.getDiscountStats(), cityKey);
            if (!TextUtils.isEmpty(discountPriceNumericFilter)) {
                numericFilterBuilder.append((!TextUtils.isEmpty(numericFilterBuilder.toString())) ? "," : "")
                        .append(discountPriceNumericFilter);
            }
        }

        Log.d(TAG, "Numeric Filter " + numericFilterBuilder.toString());
        Log.d(TAG, "Facet Filter " + facetBuilder.toString());
        searchQuery.setNumericFilters(numericFilterBuilder.toString());
        searchQuery.setFacetFilters(facetBuilder.toString());
        searchQuery.setHitsPerPage(itemsPerPage);
        searchQuery.setPage(pageNumber);

        return searchQuery;
    }

    private static String getDiscountPriceStatsNumericFilterString(Stats discountStats, String cityKey) {
        String numericFilter = "";
        if (discountStats != null
                && !(discountStats.getMin() == discountStats.getSelectedMin()
                && discountStats.getMax() == discountStats.getSelectedMax())) {
            numericFilter = "cities_mapping." + cityKey + ".discount_percent_f:"
                    + discountStats.getSelectedMin() + " to "
                    + discountStats.getSelectedMax();
        }

        return numericFilter;
    }

    private static String getSalesPriceStatsNumericFilterString(Stats salesPriceStats, String cityKey) {
        String numericFilter = "";
        if (salesPriceStats != null
                && !(salesPriceStats.getMin() == salesPriceStats.getSelectedMin()
                && salesPriceStats.getMax() == salesPriceStats.getSelectedMax())) {

            numericFilter = "cities_mapping." + cityKey + ".promotional_price_f:"//".sales_price_f:"
                    + salesPriceStats.getSelectedMin() + " to "
                    + salesPriceStats.getSelectedMax();

        }
        return numericFilter;
    }

    private static String getBrandFacetFilterString(List<FilterSelectionStats> brandStatList) {

        if (brandStatList != null && brandStatList.size() > 0) {
            StringBuilder brandFilter = new StringBuilder();
            boolean isFilterExist = false;
            brandFilter.append("(");
            for (FilterSelectionStats brandStat : brandStatList) {
                if (brandStat.isSelected()) {
                    isFilterExist = true;
                    brandFilter.append("brand_name:").append(brandStat.getHeader()).append(",");
                }
            }

            if (isFilterExist) {
                String brandNameFilter = brandFilter.toString();
                brandNameFilter = brandNameFilter.substring(0, brandNameFilter.length() - 1);
                brandNameFilter = brandNameFilter + ")";

                return brandNameFilter;
            }
        }

        return "";
    }

    private static String getCategoryNameFacetFilterString(List<FilterSelectionStats> categoryStatList) {
        if (categoryStatList != null && categoryStatList.size() > 0) {
            StringBuilder categoryFilter = new StringBuilder();

            boolean isCategoryFilterExist = false;
            categoryFilter.append("(");
            for (FilterSelectionStats categoryStat : categoryStatList) {
                if (categoryStat.isSelected()) {
                    isCategoryFilterExist = true;
                    categoryFilter.append("category_details.primary_category.name:").append(categoryStat.getHeader()).append(",");
                }
            }

            if (isCategoryFilterExist) {
                String categoryNameFilter = categoryFilter.toString();
                categoryNameFilter = categoryNameFilter.substring(0, categoryNameFilter.length() - 1);
                categoryNameFilter = categoryNameFilter + ")";

                return categoryNameFilter;
            }
        }

        return "";
    }

    /**
     * Creates and returns the Algolia Query for getting category products with applied brand
     *
     * @param brandName    the brand name to apply the filter on products
     * @param categoryId   id used for filter the products based on category.
     * @param cityKey      city key for filter the products only for this city id.
     * @param itemsPerPage number of products to be fetched per page.
     * @return Algolia Query.
     */
    public static Query getCategoryProductWithBrandQuery(String brandName, long categoryId, String cityKey, int itemsPerPage,
                                                         int pageNumber, boolean isFilterRequired) {
        Query searchQuery = new Query();
        String filter = "cities_mapping." + cityKey + ".active=1," +
                "( category_details.base_category.id=" + categoryId
                + ",category_details.primary_category.id=" + categoryId
                + ",category_details.secondary_category.id=" + categoryId
                + ")";

        searchQuery.setFacetFilters("(brand_name:" + brandName + ")");

        searchQuery.setNumericFilters(filter);
        if (isFilterRequired)
            searchQuery.setFacets(Arrays.asList("*"));
        searchQuery.setHitsPerPage(itemsPerPage);
        searchQuery.setPage(pageNumber);

        return searchQuery;
    }

    /**
     * Creates and returns the Algolia Query for getting category products with applied promotion ID
     *
     * @param promotionId  the promotional id based on which the products are to be fetched
     * @param categoryId   id used for filter the products based on category.
     * @param cityKey      city key for filter the products only for this city id.
     * @param itemsPerPage number of products to be fetched per page.
     * @return Algolia Query.
     */
    public static Query getCategoryProductWithPromotionQuery(long promotionId, long categoryId, String cityKey, int itemsPerPage,
                                                             int pageNumber, boolean isFilterRequired) {
        Query searchQuery = new Query();
        StringBuilder filterBuilder = new StringBuilder();
        String filter = "cities_mapping." + cityKey + ".active=1";
        filterBuilder.append(filter);

        //Home screen category Id will be -1
        if (categoryId != -1) {
            filterBuilder.append(",(category_details.base_category.id=")
                    .append(categoryId).append(",category_details.primary_category.id=")
                    .append(categoryId).append(",category_details.secondary_category.id=")
                    .append(categoryId).append(")");
        }

        if (promotionId != -1) {
            filterBuilder.append(", cities_mapping.").append(cityKey);
            filterBuilder.append(".promotions.promotion_id=").append(promotionId);
        }

        searchQuery.setNumericFilters(filterBuilder.toString());
        if (isFilterRequired)
            searchQuery.setFacets(Arrays.asList("*"));
        searchQuery.setHitsPerPage(itemsPerPage);
        searchQuery.setPage(pageNumber);

        return searchQuery;
    }
}
