/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.content.Context;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.util.TypedValue;
import android.view.View;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

/**
 * Created by gauthami on 22/7/15.
 */

/**
 * Order history product info item view holder
 */
public class OrderHistoryProductInfoViewHolder extends RecyclerView.ViewHolder {

    public RobotoTextView mProductName;
    public RobotoTextView mProductQuantity;
    public RobotoTextView mProductPrice;

    public LinearLayout mOrderHistoryProductInfoLinLyt;

    public OrderHistoryProductInfoViewHolder(View view, Context context) {
        super(view);

        mOrderHistoryProductInfoLinLyt = (LinearLayout) view.findViewById(R.id.order_history_header_layout);
        mOrderHistoryProductInfoLinLyt.setPadding(context.getResources().getDimensionPixelOffset(R.dimen.header_left_padding),
                context.getResources().getDimensionPixelOffset(R.dimen.order_history_header_layout_top_bottom_padding),
                context.getResources().getDimensionPixelOffset(R.dimen.header_right_padding),
                context.getResources().getDimensionPixelOffset(R.dimen.order_history_header_layout_top_bottom_padding));

        mProductName = (RobotoTextView) view.findViewById(R.id.order_history_product_info_product_tv);
        mProductName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        mProductName.setTextColor(ContextCompat.getColor(context, R.color.common_sub_header_text_color));

        mProductQuantity = (RobotoTextView) view.findViewById(R.id.order_history_product_info_quantity_tv);
        mProductQuantity.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        mProductQuantity.setTextColor(ContextCompat.getColor(context, R.color.common_sub_header_text_color));

        mProductPrice = (RobotoTextView) view.findViewById(R.id.order_history_product_info_price_tv);
        mProductPrice.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        mProductPrice.setTextColor(ContextCompat.getColor(context, R.color.common_sub_header_text_color));

        (itemView.findViewById(R.id.order_history_below_vertical_saparator)).setVisibility(View.GONE);
        (itemView.findViewById(R.id.order_history_above_vertical_separator)).setVisibility(View.GONE);
    }
}
