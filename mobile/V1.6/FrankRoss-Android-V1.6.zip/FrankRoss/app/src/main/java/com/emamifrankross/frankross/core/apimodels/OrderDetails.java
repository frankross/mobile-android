/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.utils.Utils;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 7/8/15.
 */
public class OrderDetails {

    @SerializedName("id")
    private long id = 0;

    @SerializedName("total")
    private double total = 0.00d;

    @SerializedName("state")
    private String state = "";

    @SerializedName("state_display_name")
    private String stateDisplayName = "";

    @SerializedName("state_bucket")
    private String stateBucket = "";

    @SerializedName("reorder_reminder")
    private boolean reorderReminder;

    @SerializedName("reorder_reminder_details")
    private ReorderReminderDetails reorderReminderDetails;

    @SerializedName("is_cancellable")
    private boolean isCancellable;

    @SerializedName("is_returnable")
    private boolean isReturnable;

    @SerializedName("is_reorderable")
    private boolean isReorderable;

    @SerializedName("is_mismatched")
    private boolean isMismatched;

    @SerializedName("shipping_total")
    private double shippingTotal = 0.00d;

    @SerializedName("city")
    private String city = "";

    @SerializedName("currency")
    private String currency = "";

    @SerializedName("discount_total")
    private double discountTotal = 0.00d;

    @SerializedName("promotion_discount_total")
    private double promotionalDiscountTotal = 0.00d;

    @SerializedName("line_items_total")
    private double lineItemsTotal = 0.00d;

    @SerializedName("payment_method")
    private String paymentMethod = "";

    @SerializedName("confirmed_on")
    private String confirmedOnDate = "";

    @SerializedName("deliverd_on")
    private String deliveredOnDate = "";

    @SerializedName("doctor_names")
    private String doctorName = "";

    @SerializedName("patient_name")
    private String patientName = "";

    @SerializedName("shipping_address")
    private Address shippingAddress = new Address();

    @SerializedName("billing_address")
    private Address billingAddress = new Address();

    @SerializedName("delivery_remarks")
    private String deliveryRemarks = "";

    @SerializedName("shipping_description")
    private String shippingDescription = "";

    @SerializedName("order_without_prescription")
    private boolean isOrderWithoutPrescription = false;

    @SerializedName("apply_wallet")
    private boolean applyWallet = false;

    @SerializedName("wallet_amount")
    private double walletAmount = 0.0d;

    @SerializedName("payment_status")
    private String paymentStatus = "";

    @SerializedName("delivery_slot")
    private DeliverySlot deliverySlot;

    @SerializedName("line_items")
    private List<OrderProductItem> orderProductItems;

    @SerializedName("payment_methods")
    private List<PaymentMethods> paymentMethods;

    @SerializedName("prescription_details")
    private List<FailedPrescriptionDetails> mFailedPrescriptionDetails = new ArrayList<>();

    @SerializedName("payments")
    private List<Payments> payments = new ArrayList<>(1);

    @SerializedName("fully_paid_by_wallet")
    private boolean fullyPaidByWallet = false;

    @SerializedName("cash_back_desc")
    private String cashBackSummary = "";

    @SerializedName("cash_back")
    private boolean isCashBack = false;

    public List<OrderProductItem> getOrderProductItems() {
        return orderProductItems;
    }

    public void setOrderProductItems(List<OrderProductItem> orderProductItems) {
        this.orderProductItems = orderProductItems;
    }

    public long getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public double getShippingTotal() {
        return shippingTotal;
    }

    public void setShippingTotal(double shippingTotal) {
        this.shippingTotal = shippingTotal;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public double getDiscountTotal() {
        return discountTotal;
    }

    public void setDiscountTotal(double discountTotal) {
        this.discountTotal = discountTotal;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public String getConfirmedOnDate() {
        return confirmedOnDate;
    }

    public void setConfirmedOnDate(String confirmedOnDate) {
        this.confirmedOnDate = confirmedOnDate;
    }

    public String getDeliveredOnDate() {
        return deliveredOnDate;
    }

    public void setDeliveredOnDate(String deliveredOnDate) {
        this.deliveredOnDate = deliveredOnDate;
    }

    public Address getShippingAddress() {
        return shippingAddress;
    }

    public void setShippingAddress(Address shippingAddress) {
        this.shippingAddress = shippingAddress;
    }

    public Address getBillingAddress() {
        return billingAddress;
    }

    public void setBillingAddress(Address billingAddress) {
        this.billingAddress = billingAddress;
    }

    public String getDeliveryRemarks() {
        return deliveryRemarks;
    }

    public void setDeliveryRemarks(String deliveryRemarks) {
        this.deliveryRemarks = deliveryRemarks;
    }

    public DeliverySlot getDeliverySlot() {
        return deliverySlot;
    }

    public void setDeliverySlot(DeliverySlot deliverySlot) {
        this.deliverySlot = deliverySlot;
    }

    public String getStateDisplayName() {
        return stateDisplayName;
    }

    public String getStateBucket() {
        return stateBucket;
    }

    public boolean isReorderReminder() {
        return reorderReminder;
    }

    public ReorderReminderDetails getReorderReminderDetails() {
        return reorderReminderDetails;
    }

    public boolean isCancellable() {
        return isCancellable;
    }

    public boolean isReturnable() {
        return isReturnable;
    }

    public boolean isReorderable() {
        return isReorderable;
    }

    public boolean isMismatched() {
        return isMismatched;
    }

    public double getLineItemsTotal() {
        return lineItemsTotal;
    }

    public String getShippingDescription() {
        return shippingDescription;
    }

    public String getDoctorName() {
        return doctorName;
    }

    public void setDoctorName(String doctorName) {
        this.doctorName = doctorName;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public List<FailedPrescriptionDetails> getFailedPrescriptionDetails() {
        return mFailedPrescriptionDetails;
    }

    public double getPromotionalDiscountTotal() {
        return promotionalDiscountTotal;
    }

    public void setPromotionalDiscountTotal(double promotionalDiscountTotal) {
        this.promotionalDiscountTotal = promotionalDiscountTotal;
    }

    public boolean isOrderWithoutPrescription() {
        return isOrderWithoutPrescription;
    }

    public void setIsOrderWithoutPrescription(boolean isOrderWithoutPrescription) {
        this.isOrderWithoutPrescription = isOrderWithoutPrescription;
    }

    public boolean isApplyWallet() {
        return applyWallet;
    }

    public void setApplyWallet(boolean applyWallet) {
        this.applyWallet = applyWallet;
    }

    public double getWalletAmount() {
        return walletAmount;
    }

    public void setWalletAmount(double walletAmount) {
        this.walletAmount = walletAmount;
    }

    public List<PaymentMethods> getPaymentMethods() {
        return paymentMethods;
    }

    public void setPaymentMethods(List<PaymentMethods> paymentMethods) {
        this.paymentMethods = paymentMethods;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public List<Payments> getPayments() {
        return payments;
    }

    public void setPayments(List<Payments> payments) {
        this.payments = payments;
    }

    public boolean isFullyPaidByWallet() {
        return fullyPaidByWallet;
    }

    public void setFullyPaidByWallet(boolean fullyPaidByWallet) {
        this.fullyPaidByWallet = fullyPaidByWallet;
    }

    public boolean isCashBack() {
        return isCashBack;
    }

    public String getCashBackSummary() {
        return cashBackSummary;
    }

    public static class OrderProductItem {
        @SerializedName("total")
        private String total = "";

        @SerializedName("variant_name")
        private String variantName = "";

        @SerializedName("promotional_price")
        private String promotionalPrice = "";

        @SerializedName("mrp")
        private String mrp = "";

        @SerializedName("variant_id")
        private long variantId = 0;

        @SerializedName("quantity")
        private int quantity = 0;

        @SerializedName("discount_amount")
        private String discountAmount = "";

        @SerializedName("discount_percent")
        private String discountPercent = "";

        @SerializedName("sales_price")
        private String salesPrice = "";

        @SerializedName("inner_package_quantity")
        private String innerPackageQuantity;

        @SerializedName("outer_package_quantity")
        private String outerPackageQuantity;

        @SerializedName("prescription_required")
        private boolean prescriptionRequired;

        @SerializedName("prescription_available")
        private boolean prescriptionAvailable;

        @SerializedName("prescription_message")
        private String prescriptionMessage;

        @SerializedName("unit_of_sale")
        private String unitOfSale;

        @SerializedName("max_orderable_quantity")
        private int maxOrderableQuantity = 0;

        @SerializedName("cash_back_desc")
        private String cashBackSummary = "";

        @SerializedName("active")
        private boolean isActive = false;

        @SerializedName("pharma")
        private boolean isPharma = false;

        @SerializedName("cash_back")
        private boolean isCashBack = false;

        public String getVariantName() {
            return variantName;
        }

        public void setVariantName(String variantName) {
            this.variantName = variantName;
        }

        public long getVariantId() {
            return variantId;
        }

        public void setVariantId(int variantId) {
            this.variantId = variantId;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        public double getDiscountAmount() {
            return Utils.getDoubleValue(discountAmount);
        }

        public double getDiscountPercent() {
            return Utils.getDoubleValue(discountPercent);
        }

        public double getSalesPrice() {
            return Utils.getDoubleValue(salesPrice);
        }

        public double getMrp() {
            return Utils.getDoubleValue(mrp);
        }

        public double getPromotionalPrice() {
            return Utils.getDoubleValue(promotionalPrice);
        }

        public double getTotal() {
            return Utils.getDoubleValue(total);
        }

        public String getInnerPackageQuantity() {
            return innerPackageQuantity;
        }

        public String getOuterPackageQuantity() {
            return outerPackageQuantity;
        }

        public boolean isPrescriptionRequired() {
            return prescriptionRequired;
        }

        public boolean isPrescriptionAvailable() {
            return prescriptionAvailable;
        }

        public String getUnitOfSale() {
            return unitOfSale;
        }

        public int getMaxOrderableQuantity() {
            return maxOrderableQuantity;
        }

        public boolean isActive() {
            return isActive;
        }

        public boolean isPharma() {
            return isPharma;
        }

        public String getPrescriptionMessage() {
            return prescriptionMessage;
        }

        public void setPrescriptionMessage(String prescriptionMessage) {
            this.prescriptionMessage = prescriptionMessage;
        }

        public String getCashBackSummary() {
            return cashBackSummary;
        }

        public boolean isCashBack() {
            return isCashBack;
        }
    }

    public static class FailedPrescriptionDetails {

        @SerializedName("id")
        private long id;

        @SerializedName("escalation_reason")
        private String escalationReason = "";

        @SerializedName("image_url")
        private String failedImageUrl = "";

        public String getEscalationReason() {
            return escalationReason;
        }
    }


    public static class Payments {

        @SerializedName("payment_method")
        private String payment_method;

        @SerializedName("payment_instrument")
        private String payment_instrument;

        @SerializedName("amount")
        private String amount;

        @SerializedName("status")
        private String status;

        public String getPayment_method() {
            return payment_method;
        }

        public void setPayment_method(String payment_method) {
            this.payment_method = payment_method;
        }

        public String getPayment_instrument() {
            return payment_instrument;
        }

        public void setPayment_instrument(String payment_instrument) {
            this.payment_instrument = payment_instrument;
        }

        public String getAmount() {
            return amount;
        }

        public void setAmount(String amount) {
            this.amount = amount;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }
    }
}
