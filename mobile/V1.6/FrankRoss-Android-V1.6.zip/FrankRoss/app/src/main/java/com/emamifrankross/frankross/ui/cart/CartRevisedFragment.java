/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.cart;

import android.os.Bundle;
import android.support.annotation.Nullable;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.checkout.CheckOutDeliveryAddressFragment;
import com.emamifrankross.frankross.ui.common.BaseFragment;

/**
 * Created by gauthami on 11/9/15.
 */

/**
 * This class represents the UI for Revised cart
 */
public class CartRevisedFragment extends CartFragment {

    private static final String TAG = CartRevisedFragment.class.getSimpleName();

    private static final String BUNDLE_KEY_ORDER_ID = "orderId";
    private static final String BUNDLE_KEY_ADDRESS_ID = "addressId";
    private static final String BUNDLE_KEY_DELIVERY_SLOT_ID = "deliveryId";
    private static final String BUNDLE_KEY_PRESCRIPTION_ID = "prescriptionId";
    private static final String BUNDLE_KEY_DOCTOR_NAME = "doctorName";
    private static final String BUNDLE_KEY_PATIENT_NAME = "patientName";

    private long mAddressId = -1;
    private long mDeliverySlotId = -1;
    private long mPrescriptionId = -1;
    private long mOrderId = -1;

    private String mPatientName = "";
    private String mDoctorName = "";

    public static CartRevisedFragment create(long orderId, String doctorName, String patientName,
                                             long addressId,
                                             long deliverySlotId,
                                             long prescriptionId) {
        CartRevisedFragment fragment = new CartRevisedFragment();

        Bundle bundle = new Bundle();
        bundle.putLong(BUNDLE_KEY_ORDER_ID, orderId);
        bundle.putLong(BUNDLE_KEY_ADDRESS_ID, addressId);
        bundle.putLong(BUNDLE_KEY_DELIVERY_SLOT_ID, deliverySlotId);
        bundle.putLong(BUNDLE_KEY_PRESCRIPTION_ID, prescriptionId);
        bundle.putString(BUNDLE_KEY_DOCTOR_NAME, doctorName);
        bundle.putString(BUNDLE_KEY_PATIENT_NAME, patientName);

        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle bundle = getArguments();
        if (bundle != null) {
            mAddressId = bundle.getLong(BUNDLE_KEY_ADDRESS_ID);
            mDeliverySlotId = bundle.getLong(BUNDLE_KEY_DELIVERY_SLOT_ID);
            mPrescriptionId = bundle.getLong(BUNDLE_KEY_PRESCRIPTION_ID);
            mOrderId = bundle.getLong(BUNDLE_KEY_ORDER_ID);

            mDoctorName = bundle.getString(BUNDLE_KEY_DOCTOR_NAME);
            mPatientName = bundle.getString(BUNDLE_KEY_PATIENT_NAME);
        }
    }

    /**
     * Method validates insufficient inventory on Place Order click and performs the specified actions
     */
    @Override
    public void performPlaceOrder() {
        if (mIsInsufficientInventory) {
            mFragmentInteractionListener.showAlert(getString(R.string.cart_insufficient_inventory_title), getString(R.string.cart_insufficient_inventory_msg),
                    getString(R.string.ok), null, null, null, false);
        } else {
            mFragmentInteractionListener.loadFragment(getId(), CheckOutDeliveryAddressFragment.create(mDoctorName, mPatientName, mOrderId,
                            mAddressId, mDeliverySlotId, mPrescriptionId, CheckOutDeliveryAddressFragment.CartFlow.REVISED_CART),
                    CheckOutDeliveryAddressFragment.TAG, R.anim.push_left_in, R.anim.fade_out,
                    BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
        }
    }
}
