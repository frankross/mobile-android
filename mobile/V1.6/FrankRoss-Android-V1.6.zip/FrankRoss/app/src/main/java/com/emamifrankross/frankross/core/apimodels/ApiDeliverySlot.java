/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by gowtham on 4/8/15.
 */
public class ApiDeliverySlot {

    public static class Response {

        @SerializedName("delivery_slots")
        private List<DeliverySlot> deliverySlots;

        private List<BaseRecyclerAdapter.IViewType> uiDataList;

        public List<DeliverySlot> getDeliverySlots() {
            return deliverySlots;
        }

        public void setDeliverySlots(List<DeliverySlot> deliverySlots) {
            this.deliverySlots = deliverySlots;
        }

        public void setUiDataList(List<BaseRecyclerAdapter.IViewType> uiDataList) {
            this.uiDataList = uiDataList;
        }

        public List<BaseRecyclerAdapter.IViewType> getUiDataList() {
            return uiDataList;
        }
    }
}
