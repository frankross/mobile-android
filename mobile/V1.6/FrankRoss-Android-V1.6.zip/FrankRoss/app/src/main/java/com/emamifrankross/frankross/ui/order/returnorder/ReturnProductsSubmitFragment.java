package com.emamifrankross.frankross.ui.order.returnorder;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiReturnReasons;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.CheckOutDeliverySlotAdapter;
import com.emamifrankross.frankross.ui.adapters.ReturnProductsAdapter;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.viewmodels.CommonRecyclerHeaderItem;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderItem;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 29/7/16.
 */

/**
 * This class represents the UI for Return order submit screen
 */
public class ReturnProductsSubmitFragment extends ApiRequestBaseFragment implements IToolbar,
        BaseRecyclerAdapter.RecyclerItemClickListener, View.OnClickListener {

    public static final String TAG = ReturnProductsSubmitFragment.class.getName();

    private List<BaseRecyclerAdapter.IViewType> mReturnProductsSubmitData = new ArrayList<>();
    private ReturnProductsAdapter mReturnProductsSubmitAdapter;
    private List<BaseRecyclerAdapter.IViewType> mPickUpSlots = new ArrayList<>(1);
    private CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem mSelectedDeliverySlot;

    private long mPickUpSlotId = -1;
    private String mReturnComment = "";
    private String mReturnReason = "";

    public static ReturnProductsSubmitFragment create() {
        ReturnProductsSubmitFragment fragment = new ReturnProductsSubmitFragment();
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mReturnProductsSubmitAdapter = new ReturnProductsAdapter(mReturnProductsSubmitData);
        Utils.clearSpinnerSelectedItemPosition(getActivity());
        performReturnReasonsRequest();
    }

    /**
     * Method that requests for Return products reasons
     */
    private void performReturnReasonsRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        //on success
        //To be added
        //performDeliverySlotListRequest(16);
    }

    private void getMappedUiDataForReturnProductsSubmit() {
        mFragmentInteractionListener.showBlockingProgressBar();

        new AsyncTask<Void, Void, ArrayList<BaseRecyclerAdapter.IViewType>>() {
            @Override
            protected ArrayList<BaseRecyclerAdapter.IViewType> doInBackground(Void... params) {

                ArrayList<BaseRecyclerAdapter.IViewType> returnProductsSubmitScreenData = new ArrayList<BaseRecyclerAdapter.IViewType>();

                if (getActivity() != null && isAdded()) {

                    CommonRecyclerHeaderItem commonRecyclerHeaderItem =
                            new CommonRecyclerHeaderItem(getResources().
                                    getString(R.string.return_products_reason_comment_header_title));
                    returnProductsSubmitScreenData.add(commonRecyclerHeaderItem);
                    returnProductsSubmitScreenData.add(new RecyclerBorderItem(1));


                    List<ApiReturnReasons> objects = new ArrayList<>();

                    ApiReturnReasons apiReturnReasons = new ApiReturnReasons();
                    apiReturnReasons.setReturnReason("Order created by mistake");
                    apiReturnReasons.setSelected(false);
                    objects.add(apiReturnReasons);

                    apiReturnReasons = new ApiReturnReasons();
                    apiReturnReasons.setReturnReason("Change my mind");
                    objects.add(apiReturnReasons);

                    apiReturnReasons = new ApiReturnReasons();
                    apiReturnReasons.setReturnReason("Items did not arrive on time");
                    apiReturnReasons.setSelected(false);
                    objects.add(apiReturnReasons);

                    apiReturnReasons = new ApiReturnReasons();
                    apiReturnReasons.setReturnReason("Item price too high");
                    apiReturnReasons.setSelected(false);
                    objects.add(apiReturnReasons);

                    apiReturnReasons = new ApiReturnReasons();
                    apiReturnReasons.setReturnReason("Shipping Charge too high");
                    apiReturnReasons.setSelected(false);
                    objects.add(apiReturnReasons);

                    apiReturnReasons = new ApiReturnReasons();
                    apiReturnReasons.setReturnReason("Incorrect Shipping address");
                    apiReturnReasons.setSelected(false);
                    objects.add(apiReturnReasons);

                    apiReturnReasons = new ApiReturnReasons();
                    apiReturnReasons.setReturnReason(getString(R.string.return_product_select_reason_hint));
                    apiReturnReasons.setSelected(false);
                    objects.add(apiReturnReasons);

                    returnProductsSubmitScreenData.add(new ReturnProductsAdapter.ReturnProductsReasonCommentDataItem(objects));
                    returnProductsSubmitScreenData.add(new RecyclerBorderItem(1));

                    RecyclerBorderItem recyclerBorderItem = new RecyclerBorderItem(100);
                    recyclerBorderItem.borderBackground = R.color.background_darker_grey;
                    returnProductsSubmitScreenData.add(recyclerBorderItem);

                    returnProductsSubmitScreenData.add(new RecyclerBorderItem(1));

                    /**
                     * Checks if there are any delivery slot selected by user
                     */
                    if (mPickUpSlots != null) {
                        for (BaseRecyclerAdapter.IViewType viewType : mPickUpSlots) {
                            if (viewType instanceof CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem) {
                                CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem dataItem =
                                        (CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem) viewType;
                                if (mPickUpSlotId == dataItem.deliverySlotId) {
                                    dataItem.isChecked = true;
                                    mSelectedDeliverySlot = dataItem;
                                } else {
                                    dataItem.isChecked = false;
                                }
                            }
                        }
                    }

                    ReturnProductsAdapter.ReturnProductsPickUpSlotDataItem returnPickUpSlotDataItem =
                            new ReturnProductsAdapter.ReturnProductsPickUpSlotDataItem();
                    if (mSelectedDeliverySlot != null) {
                        //selected delivery slot
                        returnPickUpSlotDataItem.deliverySlotHeader = mSelectedDeliverySlot.deliverySlotHeader;
                        returnPickUpSlotDataItem.deliverySlotTime = mSelectedDeliverySlot.deliverySlotTime;
                    } else {
                        //no delivery slot selected
                        returnPickUpSlotDataItem.deliverySlotHeader = "";
                        returnPickUpSlotDataItem.deliverySlotTime = "";
                    }
                    returnProductsSubmitScreenData.add(returnPickUpSlotDataItem);

                }

                return returnProductsSubmitScreenData;
            }

            @Override
            protected void onPostExecute(ArrayList<BaseRecyclerAdapter.IViewType> checkOutScreenData) {
                super.onPostExecute(checkOutScreenData);
                mReturnProductsSubmitData.clear();
                mReturnProductsSubmitData.addAll(checkOutScreenData);
                mFragmentInteractionListener.hideBlockingProgressBar();
                if (getActivity() != null && getView() != null && isAdded()) {
                    mReturnProductsSubmitAdapter.notifyDataSetChanged();
                }
            }
        }.execute();
    }

    /**
     * Method to navigate to Select delivery slot screen
     */
    private void loadDeliverySlotFragment() {
        mFragmentInteractionListener.loadFragment(getId(), ReturnPickUpSlotFragment.create(mPickUpSlots),
                null, R.anim.push_left_in, R.anim.push_left_out,
                FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    /**
     * Method that receives the callback from parent activity on the Pickup slot selection
     *
     * @param pickUpSlot the pickup slot data object associated to the clicked pickup slot
     */
    public void onPickUpSlotSelect(CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem pickUpSlot) {
        mPickUpSlotId = pickUpSlot.deliverySlotId;
        getMappedUiDataForReturnProductsSubmit();
    }

    /**
     * Method that requests for Return products request
     */
    private void performReturnProductsSubmitRequest() {
        //mFragmentInteractionListener.showBlockingProgressBar();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_order_history_details, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initReturnProductsSubmitRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the views associated to return products views
     *
     * @param view the root view
     */
    private void initReturnProductsSubmitRecyclerView(View view) {
        RecyclerView returnProductsSubmitRecyclerView = (RecyclerView) view.
                findViewById(R.id.order_details_recycler_view);
        returnProductsSubmitRecyclerView.setHasFixedSize(false);
        returnProductsSubmitRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mReturnProductsSubmitAdapter.setRecyclerItemClickListener(this);
        returnProductsSubmitRecyclerView.setAdapter(mReturnProductsSubmitAdapter);

        Button submitBtn = (Button) view.findViewById(R.id.order_details_bottom_btn);
        submitBtn.setText(getString(R.string.submit));
        submitBtn.setOnClickListener(this);
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    @Override
    public String getToolbarTitleId() {
        return getResources().getString(R.string.return_products_title);
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {

        if (object == null) return;
        switch (((ReturnProductsAdapter.IViewType) object).getViewType()) {
            case ViewTypes.ReturnManagementViewType.RETURN_PICK_UP_SLOT_VIEW_TYPE:
                loadDeliverySlotFragment();
                break;
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.order_details_bottom_btn:
                getReturnProductDetailsFromUiList();
                if (TextUtils.isEmpty(mReturnReason) || mReturnReason.equals(getString(R.string.return_product_select_reason_hint))) {
                    showAlert(getResources().getString(R.string.return_products_error_select_reason));
                } else if (mSelectedDeliverySlot == null) {
                    showAlert(getResources().getString(R.string.return_products_error_pickup_slot));
                } else {
                    performReturnProductsSubmitRequest();
                }
                break;
        }
    }

    /**
     * Method that iterates through the UI data list to get the return reason & comment
     */
    private void getReturnProductDetailsFromUiList() {
        for (BaseRecyclerAdapter.IViewType view : mReturnProductsSubmitData) {
            if (view.getViewType() == ViewTypes.ReturnManagementViewType.RETURN_REASON_COMMENT_VIEW_TYPE) {
                ReturnProductsAdapter.ReturnProductsReasonCommentDataItem returnProductsReasonCommentDataItem =
                        (ReturnProductsAdapter.ReturnProductsReasonCommentDataItem) view;
                mReturnComment = returnProductsReasonCommentDataItem.returnSelectedComment;
                mReturnReason = returnProductsReasonCommentDataItem.returnSelectedReason;
            }
        }
    }
}
