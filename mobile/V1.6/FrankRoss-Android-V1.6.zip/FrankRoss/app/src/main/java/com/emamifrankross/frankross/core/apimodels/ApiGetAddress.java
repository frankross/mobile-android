/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.AccountAdapter;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 16/7/15.
 */
public class ApiGetAddress {

    public static class Response {

        @SerializedName("addresses")
        private List<Address> addressList = new ArrayList<>(1);

        private List<AccountAdapter.AccountAddressItem> uiData = new ArrayList<>(1);

        public List<Address> getAddressList() {
            return addressList;
        }

        public List<AccountAdapter.AccountAddressItem> getUiData() {
            return uiData;
        }

        public void setUiData(List<AccountAdapter.AccountAddressItem> uiData) {
            this.uiData = uiData;
        }
    }

}
