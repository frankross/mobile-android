/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.support;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.core.network.IApiRequestCancel;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.account.login.LogInActivity;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;
import com.emamifrankross.frankross.ui.common.AlertError;
import com.emamifrankross.frankross.ui.common.AppRuntimePermissionsManager;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.IErrorHandler;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.viewmodels.UserInformation;
import com.emamifrankross.frankross.utils.IntentUtils;
import com.emamifrankross.frankross.utils.Utils;
import com.livechatinc.inappchat.ChatWindowFragment;

/**
 * Created by gauthami on 5/11/15.
 */

/**
 * This class represents the UI for Support screen using Live Chat SDK
 */
public class SupportActivity extends BaseActivity implements IToolbar,
        View.OnClickListener, IApiRequestCancel, IErrorHandler {

    private static final int REQUEST_CODE_SUPPORT = 111;
    /**
     * LIVE CHAT SDK constants
     */
    private static final String LIVE_CHAT_TEST_LICENCE_NUMBER = "6699861";//Used only for test builds
    private static final String LIVE_CHAT_LICENCE_NUMBER = "6451451";//Live licence number
    private static final String LIVE_CHAT_GROUP_ID = "0";
    private static final String LIVE_CHAT_FRAGMENT_ID = "chat_fragment";

    private LinearLayout mCallButton;

    private String mCustomerCareNumber;
    private ApiRequestManager mApiRequestManager;
    private boolean isFromHome = false;

    public static Intent getActivityIntent(Context applicationContext) {
        return new Intent(applicationContext, SupportActivity.class);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mApiRequestManager = ApiRequestManager.getInstance(getApplicationContext());
        mApiRequestManager.registerRequest(this);
        initViews();

        if (Utils.isLoggedIn(getApplicationContext())) {
            getSupportNumbers();
            getUserDetails();
        } else {
            startActivityForResult(LogInActivity.getActivityIntent(getApplicationContext(), false,
                    LogInActivity.LOG_IN_FRAGMENT), REQUEST_CODE_SUPPORT);
            overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    /**
     * Method that requests for user details
     */
    private void getUserDetails() {
        showBlockingProgressBar();

        mApiRequestManager.performUserInfoRequest(new ApiRequestManager.IGetUserInfoResultNotifier() {
            @Override
            public void onUserInfoFetched(UserInformation userInfo) {
                if (userInfo != null && !isFinishing()) {
                    loadSupport(userInfo);
                }
            }
        }, this, this);
    }

    /**
     * Method that loads the Live chat SDK fragment into the activity
     *
     * @param userInfo the user details that fetched freshly from the User API
     */
    private void loadSupport(UserInformation userInfo) {
        if (userInfo != null) {
            /*
            SDK does not encode/decode the space.
             To avoid the issue with SDK all empty spaces in visitor name and mail ID will be replaced with dot(.)
             */
            String visitorName = ".";
            String visitorMailId = ".";

            if (!TextUtils.isEmpty(userInfo.userName)) {
                visitorName = userInfo.userName.replaceAll(" ", ".");
            }

            if (!TextUtils.isEmpty(userInfo.userMailId)) {
                visitorMailId = userInfo.userMailId;
            }

            hideBlockingProgressBar();
            getFragmentManager()
                    .beginTransaction()
                    .replace(getFragmentContainerId(), ChatWindowFragment.
                            newInstance(LIVE_CHAT_LICENCE_NUMBER,
                                    LIVE_CHAT_GROUP_ID,
                                    visitorName,
                                    visitorMailId), LIVE_CHAT_FRAGMENT_ID)
                    .addToBackStack(LIVE_CHAT_FRAGMENT_ID)
                    .commit();
        }
    }

    /**
     * Method that requests for Support Call center number
     */
    private void getSupportNumbers() {
        mApiRequestManager.performCustomerCareNumberRequest(
                new ApiRequestManager.ICustomerCareNumberResultNotifier() {
                    @Override
                    public void onCustomerCareNumberFetched(String customerCareNumber) {
                        if (!TextUtils.isEmpty(customerCareNumber)) {
                            mCustomerCareNumber = customerCareNumber;
                            if (mCallButton != null)
                                mCallButton.setVisibility(View.VISIBLE);
                        } else {
                            if (mCallButton != null)
                                mCallButton.setVisibility(View.GONE);
                        }
                    }
                }, this, this);
    }

    private void initViews() {
        mCallButton = (LinearLayout) findViewById(R.id.footer_layout);

        findViewById(R.id.support_call_btn).setOnClickListener(this);
        updateToolbar(this);

        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SUPPORT_SCREEN_VISIT_EVENT);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.support_call_btn:
                showPopUp();
                break;
        }
    }

    /**
     * Method that displays a pop up to confirm the Call center call action
     */
    private void showPopUp() {
        showAlert(null, mCustomerCareNumber,
                getString(R.string.call), getString(R.string.cancel),
                new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                        call();
                    }
                }, new AlertDialogFragment.AlertNegativeActionListener() {
                    @Override
                    public void onNegativeAction() {
                    }
                }, true);
    }

    /**
     * Method that performs the Telephonic call action
     * using standard Call intent
     */
    private void call() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                AppRuntimePermissionsManager.checkPermissionForCall(SupportActivity.this)) {
            try {
                if (TextUtils.isEmpty(mCustomerCareNumber)) return;
                mCustomerCareNumber = mCustomerCareNumber.trim();
                startActivity(IntentUtils.getCallIntent(mCustomerCareNumber));
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SUPPORT_CALL_EVENT);
            } catch (SecurityException securityException) {

            }
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                this.requestPermissions(new String[]{Manifest.permission.CALL_PHONE},
                        AppRuntimePermissionsManager.REQUEST_CODE_CALL_PERMISSIONS);
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        mApiRequestManager.registerRequest(this);
        FrankRossAnalytics.getFrankRossTracker().startSession(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(this);
        mApiRequestManager.unregisterRequest(this);
    }

    @Override
    public <T> void handleError(AlertError<T> alertError, int statusCode) {
        hideBlockingProgressBar();

        if (alertError == null) return;
        showAlert(alertError.getErrorTitle(), alertError.getErrorMessage(),
                alertError.getPositiveButtonText(), alertError.getNegativeButtonText(),
                new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                        onErrorPositiveAction();
                    }
                }, new AlertDialogFragment.AlertNegativeActionListener() {
                    @Override
                    public void onNegativeAction() {
                        onErrorNegativeAction();
                    }
                }, true);
    }

    private void onErrorNegativeAction() {

    }

    private void onErrorPositiveAction() {

    }

    @Override
    public void handleCommonError(int errorResourceId) {
        hideBlockingProgressBar();
        String errorMessage = getString(errorResourceId);

        showAlert(null, errorMessage,
                "OK", null, new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                        onErrorAlertAction();
                    }
                }, null, true);

    }

    private void onErrorAlertAction() {

    }

    @Override
    public String getRequestTag() {
        return this.toString();
    }

    @Override
    public int getToolbarNavigationIconId() {
        return (isFromHome) ? R.mipmap.menu : R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return (isFromHome) ? null : new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_support);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_SUPPORT) {
            if (Utils.isLoggedIn(getApplicationContext())) {
                getSupportNumbers();
                getUserDetails();
            } else {
                finish();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case AppRuntimePermissionsManager.REQUEST_CODE_CALL_PERMISSIONS:
                if (grantResults != null && grantResults.length > 0 &&
                        grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    call();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
