/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.gcm;

import android.app.IntentService;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.support.v4.content.LocalBroadcastManager;
import android.text.TextUtils;

import com.emamifrankross.frankross.FrankRossApplication;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.core.network.IApiRequestCancel;
import com.emamifrankross.frankross.sdkmanager.ApptentiveManager;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Log;
import com.emamifrankross.frankross.utils.PreferenceUtils;
import com.google.android.gms.gcm.GcmPubSub;
import com.google.android.gms.gcm.GoogleCloudMessaging;
import com.google.android.gms.iid.InstanceID;

import java.io.IOException;

public class RegistrationIntentService extends IntentService {

    private static final String TAG = RegistrationIntentService.class.getSimpleName();
    private static final String[] TOPICS = {"global"};

    public RegistrationIntentService() {
        super(TAG);
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);

        try {
            // [START register_for_gcm]
            // Initially this call goes out to the network to retrieve the token, subsequent calls
            // are local.
            // [START get_token]
            InstanceID instanceID = InstanceID.getInstance(this);
            String token = instanceID.getToken(getString(R.string.gcm_push_notification_sender_id),
                    GoogleCloudMessaging.INSTANCE_ID_SCOPE, null);
            // [END get_token]
            Log.d(TAG, "GCM Registration Token: " + token);

            if (!TextUtils.isEmpty(token)) {

                ApptentiveManager.registerApptentivePushNotification(token);

                sendRegistrationToServer(token);
                // sharedPreferences.edit().putString(Constants.GCM_TOKEN, token).apply();

                // Subscribe to topic channels
                subscribeTopics(token);
            }

            // [END register_for_gcm]
        } catch (Exception e) {

        }
        // Notify UI that registration has completed, so the progress indicator can be hidden.
        Intent registrationComplete = new Intent(Constants.REGISTRATION_COMPLETE);
        LocalBroadcastManager.getInstance(this).sendBroadcast(registrationComplete);
    }


    private void sendRegistrationToServer(String token) {
        final ApiRequestManager apiRequestManager = ApiRequestManager.getInstance(getApplicationContext());
        final IApiRequestCancel apiRequestCancel = new IApiRequestCancel() {
            @Override
            public String getRequestTag() {
                return "DeviceRegistration";
            }
        };

        apiRequestManager.registerRequest(apiRequestCancel);
        apiRequestManager.performDeviceRegistration(new ApiRequestManager.IDeviceRegisterResultNotifier() {
            @Override
            public void onDeviceRegistered(String gcmToken) {
                PreferenceUtils.saveBooleanIntoSharedPreference(
                        FrankRossApplication.getFrankrossApplicationContext(), PreferenceUtils.PREFERENCE_KEY_GCM_TOKEN_SENT_TO_SERVER, true);
                PreferenceUtils.saveStringIntoSharedPreference(getApplicationContext(), PreferenceUtils.PREFERENCE_KEY_GCM_TOKEN, gcmToken);
                apiRequestManager.unregisterRequest(apiRequestCancel);
            }

            @Override
            public void onDeviceRegistrationFailed() {
                apiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, token, apiRequestCancel);

    }

    /**
     * Subscribe to any GCM topics of interest, as defined by the TOPICS constant.
     *
     * @param token GCM token
     * @throws IOException if unable to reach the GCM PubSub service
     */
    // [START subscribe_topics]
    private void subscribeTopics(String token) throws IOException {
        GcmPubSub pubSub = GcmPubSub.getInstance(this);
        for (String topic : TOPICS) {
            pubSub.subscribe(token, "/topics/" + topic, null);
        }
    }

}
