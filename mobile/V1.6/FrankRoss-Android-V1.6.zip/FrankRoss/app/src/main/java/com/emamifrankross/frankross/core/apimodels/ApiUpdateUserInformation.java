/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 16/7/15.
 */
public class ApiUpdateUserInformation {

    public static class Request {

        public Request(String userName, String userPhoneNumber) {
            setUser(new User());
            getUser().setName(userName);
            getUser().setPrimaryPhone(userPhoneNumber);
        }

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("user")
        private User user;

        public User getUser() {
            return user;
        }

        public void setUser(User user) {
            this.user = user;
        }

        public static class User {

            @SerializedName("name")
            private String name;

            @SerializedName("primary_phone")
            private String primaryPhone;

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getPrimaryPhone() {
                return primaryPhone;
            }

            public void setPrimaryPhone(String primaryPhone) {
                this.primaryPhone = primaryPhone;
            }
        }
    }

    public static class Response {

    }
}
