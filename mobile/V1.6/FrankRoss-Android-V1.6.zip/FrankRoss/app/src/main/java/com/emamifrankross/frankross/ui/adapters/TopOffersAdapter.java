/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.customviews.VolleySingleton;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 30/6/15.
 * <p> Adapter class for PDP view pager Section</p>
 * <p>Supports the One View Types </p>
 * <p> 1 : PDP IMAGE VIEW TYPE </p>
 */
public class TopOffersAdapter extends PagerAdapter {

    private List<String> mOfferImages = new ArrayList<>();

    public TopOffersAdapter(List<String> topOffersPagerDataList) {
        if (topOffersPagerDataList != null) {
            this.mOfferImages = topOffersPagerDataList;
        }
    }

    @Override
    public int getCount() {
        if (mOfferImages.size() < 1) {
            return 1;
        }
        return mOfferImages.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {

        ViewPager pager = (ViewPager) container;
        int count = pager.getChildCount();
        View view = LayoutInflater.from(container.getContext()).inflate(R.layout.pdp_image, container, false);
        initViews(view, position);
        pager.addView(view, count > position ? position : count);
        return view;
    }

    private void initViews(View view, int position) {
        NetworkImageView networkImageView = (NetworkImageView) view.findViewById(R.id.pdp_network_imageview);
        Animation fadeInAnimation = AnimationUtils.loadAnimation(view.getContext(), R.anim.fade_in);
        view.startAnimation(fadeInAnimation);
        networkImageView.setDefaultImageResId(R.drawable.pdp_placeholder);
        networkImageView.setErrorImageResId(R.drawable.pdp_placeholder);

        if (mOfferImages.size() > 0) {
            ImageLoader imageLoader = VolleySingleton.getInstance(view.getContext().getApplicationContext()).getImageLoader();
            networkImageView.setImageUrl(mOfferImages.get(position), imageLoader);
        }
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
}