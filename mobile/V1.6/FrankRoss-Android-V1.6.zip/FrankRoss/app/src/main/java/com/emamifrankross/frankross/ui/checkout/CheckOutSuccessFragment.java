/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.checkout;

import android.content.ActivityNotFoundException;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiOrderReminder;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.ApptentiveManager;
import com.emamifrankross.frankross.sdkmanager.BranchManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.home.HomeActivity;
import com.emamifrankross.frankross.ui.order.RemindOrderDialogFragment;
import com.emamifrankross.frankross.utils.IntentUtils;
import com.emamifrankross.frankross.utils.NetworkUtils;

/**
 * Created by gauthami on 21/7/15.
 */

/**
 * This class represents the UI for Checkout success screen
 */
public class CheckOutSuccessFragment extends ApiRequestBaseFragment implements IToolbar, View.OnClickListener,
        IRemindOrderDoneClickNotifier {

    private static final String TAG = CheckOutSuccessFragment.class.getSimpleName();
    private static final String CHECK_OUT_ORDER_ID = "order_id";
    private static final String IS_ORDER_UPDATE = "isOrderUpdate";
    private static final String PAYMENT_METHOD = "payment_method";

    private long mOrderId = 0;
    private boolean mIsOrderUpdate = false;
    private String mPaymentMethod = "";

    public static CheckOutSuccessFragment create(long orderId, boolean isOrderUpdate, String paymentMethod) {
        CheckOutSuccessFragment fragment = new CheckOutSuccessFragment();
        Bundle bundle = new Bundle();
        bundle.putLong(CHECK_OUT_ORDER_ID, orderId);
        bundle.putBoolean(IS_ORDER_UPDATE, isOrderUpdate);
        bundle.putString(PAYMENT_METHOD, paymentMethod);
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFragmentInteractionListener.hideBlockingProgressBar();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        if (getArguments() != null) {
            mOrderId = getArguments().getLong(CHECK_OUT_ORDER_ID);
            mIsOrderUpdate = getArguments().getBoolean(IS_ORDER_UPDATE);
            mPaymentMethod = getArguments().getString(PAYMENT_METHOD);
        }

        return inflater.inflate(R.layout.fragment_cart_success, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    private void initViews(View view) {
        Button checkOutSuccessRoOrderReminder = (Button) view.findViewById(R.id.cart_success_re_order_reminder_btn);
        Button backToHomeBtn = (Button) view.findViewById(R.id.cart_success_back_to_home_btn);
        RobotoTextView checkOutSuccess = (RobotoTextView) view.findViewById(R.id.cart_success_sub_title_tv);

        ImageView shareUsingFacebook = (ImageView) view.findViewById(R.id.social_share_facebook_iv);
        ImageView shareUsingWhatsapp = (ImageView) view.findViewById(R.id.social_share_whatsapp_iv);
        ImageView shareUsingTwitter = (ImageView) view.findViewById(R.id.social_share_twitter_iv);
        ImageView shareUsingGplus = (ImageView) view.findViewById(R.id.social_share_google_plus_iv);
        RobotoTextView shareUsingMore = (RobotoTextView) view.findViewById(R.id.social_share_more_iv);

        checkOutSuccess.setText((mIsOrderUpdate) ? getString(R.string.revised_order_success_sub_title)
                : getString(R.string.cart_success_sub_title));

        if (!TextUtils.isEmpty(mPaymentMethod) && !mIsOrderUpdate) {
            ApptentiveManager.registerOrderConfirmEvent(getActivity(), mPaymentMethod);
        }

        checkOutSuccessRoOrderReminder.setOnClickListener(this);
        backToHomeBtn.setOnClickListener(this);
        shareUsingFacebook.setOnClickListener(this);
        shareUsingWhatsapp.setOnClickListener(this);
        shareUsingTwitter.setOnClickListener(this);
        shareUsingGplus.setOnClickListener(this);
        shareUsingMore.setOnClickListener(this);
    }

    /**
     * Method that requests for setting reminder for reorder;If success,shows success message in the dialog
     */
    @Override
    public void onRemindOrderDoneClick(ApiOrderReminder.Request apiOrderReminderRequest) {
        mApiRequestManager.performReOrderReminderListRequest(mOrderId, apiOrderReminderRequest, new ApiRequestManager.IReOrderReminderResultNotifier() {
            @Override
            public void onReminderSet() {
                mFragmentInteractionListener.showAlert(getString(R.string.remind_order_success_title),
                        getString(R.string.remind_order_succes_msg), getString(R.string.ok), null, null, null, true);
            }
        }, this, this);
    }

    /**
     * Method that gets the callback on not setting the reminder for reorder
     */
    @Override
    public void onRemindOrderCancel() {
    }

    @Override
    public int getToolbarNavigationIconId() {
        return 0;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return "";
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                return false;
            }
        };
    }

    @Override
    public void onClick(View view) {
        String shareExtensionPackageName = null;
        switch (view.getId()) {
            case R.id.cart_success_back_to_home_btn:
                startActivity(HomeActivity.getActivityIntentBackToHome(getActivity(), HomeActivity.HOME_FRAGMENT_TAG, true));
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                break;
            case R.id.cart_success_re_order_reminder_btn:
                RemindOrderDialogFragment remindOrderDialogFragment = RemindOrderDialogFragment.create(this);
                remindOrderDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
                break;
            case R.id.social_share_facebook_iv:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ORDER_SHARING_FB_TAP_EVENT);
                shareExtensionPackageName = getResources().getString(R.string.social_share_facebook_package_name);
                break;
            case R.id.social_share_google_plus_iv:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ORDER_SHARING_GPLUS_TAP_EVENT);
                shareExtensionPackageName = getResources().getString(R.string.social_share_gplus_package_name);
                break;
            case R.id.social_share_twitter_iv:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ORDER_SHARING_TWITTER_TAP_EVENT);
                shareExtensionPackageName = getResources().getString(R.string.social_share_twitter_package_name);
                break;
            case R.id.social_share_whatsapp_iv:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ORDER_SHARING_WHATSAPP_TAP_EVENT);
                shareExtensionPackageName = getResources().getString(R.string.social_share_whatsapp_package_name);
                break;
            case R.id.social_share_more_iv:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ORDER_SHARING_MORE_TAP_EVENT);
                shareExtensionPackageName = getResources().getString(R.string.checkout_success_more_extensions);
                break;
        }

        if (!TextUtils.isEmpty(shareExtensionPackageName)) {

            if (NetworkUtils.isNetworkConnected(getActivity())) {

                String appShareSubject = mApiRequestManager.getSettingsResponse().getAppShareSubject();
                String appShareText = mApiRequestManager.getSettingsResponse().getAppShareText();
                String appShareLinkTitle = mApiRequestManager.getSettingsResponse().getAppShareLinkTitle();
                String appShareLinkDescription = mApiRequestManager.getSettingsResponse().getAppShareLinkDescription();
                String appShareLinkImageUrl = mApiRequestManager.getSettingsResponse().getAppShareLinkImageUrl();

                if (shareExtensionPackageName.equals(getResources().getString(R.string.checkout_success_more_extensions))) {

                    if (appShareText.contains(getResources().getString(R.string.settings_link_placeholder)))
                        appShareText = appShareText.replaceAll(getResources().getString(R.string.settings_link_placeholder), "");
                    BranchManager.showBranchShareSheetForAppSharing(getActivity(), appShareSubject, appShareText,
                            appShareLinkTitle, appShareLinkDescription, appShareLinkImageUrl);

                } else if (shareExtensionPackageName != null) {

                    String shareAppName = "";
                    if (shareExtensionPackageName.equals(getResources().getString(R.string.social_share_facebook_package_name))) {
                        shareAppName = getResources().getString(R.string.branch_social_share_facebook_channel);
                    } else if (shareExtensionPackageName.equals(getResources().getString(R.string.social_share_gplus_package_name))) {
                        shareAppName = getResources().getString(R.string.branch_social_share_gplus_channel);
                    } else if (shareExtensionPackageName.equals(getResources().getString(R.string.social_share_twitter_package_name))) {
                        shareAppName = getResources().getString(R.string.branch_social_share_twitter_channel);
                    } else if (shareExtensionPackageName.equals(getResources().getString(R.string.social_share_whatsapp_package_name))) {
                        shareAppName = getResources().getString(R.string.branch_social_share_whatsapp_channel);
                    }

                    try {

                        if (appShareText.contains(getResources().getString(R.string.settings_link_placeholder))) {
                            String appShareBranchLink = BranchManager.getAppSharableLink(getActivity(), shareAppName,
                                    appShareLinkTitle, appShareLinkDescription, appShareLinkImageUrl);
                            if (appShareBranchLink != null)
                                appShareText = appShareText.replaceAll(getResources().getString(R.string.settings_link_placeholder),
                                        appShareBranchLink);
                        }
                        getActivity().startActivity(IntentUtils.getOrderSuccessScreenSocialSharableIntent(shareExtensionPackageName,
                                appShareSubject,
                                appShareText));

                    } catch (ActivityNotFoundException activityNotFoundException) {
                        showAlert(shareAppName + " " + getString(R.string.cart_success_share_app_not_found_message));
                    }
                }
            } else {
                showAlert(getString(R.string.no_connection_error));
            }
        }
    }
}

