package com.emamifrankross.frankross.ui.common;

/**
 * Created by gowtham on 27/10/15.
 */
public enum AppFlow {
    NOTIFICATION_FLOW,
    MAIN_FLOW,
    APP_LINKING_FLOW
}
