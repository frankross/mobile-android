/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.account.login;

import android.app.Activity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;

import com.emamifrankross.frankross.FrankRossApplication;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiRegister;
import com.emamifrankross.frankross.core.apimodels.ApiSocialLogin;
import com.emamifrankross.frankross.core.apimodels.ApiSocialRegister;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.core.network.IApiRequestCancel;
import com.emamifrankross.frankross.sdkmanager.FacebookManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;
import com.emamifrankross.frankross.ui.common.AlertError;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IErrorHandler;
import com.emamifrankross.frankross.utils.NetworkUtils;
import com.emamifrankross.frankross.utils.PreferenceUtils;
import com.emamifrankross.frankross.utils.Utils;

import java.util.List;

/**
 * Created by gauthami on 12/5/16.
 */

/**
 * This class represents the UI for Social user registration screen
 */
public class SocialUserRegistrationFragment extends RegistrationFragment {

    public static SocialUserRegistrationFragment create(String provider, String accessToken, String userId, String userName,
                                                        String emailId) {
        SocialUserRegistrationFragment fragment = new SocialUserRegistrationFragment();
        Bundle bundle = new Bundle();
        bundle.putString(EXTRA_USER_NAME, userName);
        bundle.putString(EXTRA_USER_MAIL_ID, emailId);
        bundle.putString(EXTRA_PROVIDER, provider);
        bundle.putString(EXTRA_USER_ACCESS_TOKEN, accessToken);
        bundle.putString(EXTRA_USER_ID, userId);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    protected void initVisibilityAndDataOfViews() {
        mRegistrationUserPasswordLinLyt.setVisibility(View.GONE);

        if (!TextUtils.isEmpty(mUserName)) {
            mRegistrationUserName.setText(mUserName);
            mRegistrationUserName.setEnabled(false);
            mRegistrationUserNameClearBtn.setVisibility(View.INVISIBLE);
        }

        if (!TextUtils.isEmpty(mUserMailId)) {
            mRegistrationUserMailId.setText(mUserMailId);
            mRegistrationUserMailId.setEnabled(false);
            mRegistrationUserMailIdClearBtn.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    protected void performRegistration() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.NEXT_FROM_REGISTER_SCREEN_EVENT);
        hide_keyboard(getActivity(), mRegistrationUserName);

        if (validateRegistration()) {
            mFragmentInteractionListener.showBlockingProgressBar();

            final ApiSocialRegister.Request apiSocialRegisterRequest = new ApiSocialRegister.Request();
            ApiSocialRegister.Request.User apiSocialRegisterUser = new ApiSocialRegister.Request.User();
            apiSocialRegisterUser.setSocial_login_provider(mProvider);
            apiSocialRegisterUser.setSocial_login_uid(mUserId);
            apiSocialRegisterUser.setSocial_auth_token(mUserAccessToken);
            apiSocialRegisterUser.setEmail(getUserMailId());
            apiSocialRegisterUser.setName(getUserName());
            apiSocialRegisterUser.setPrimary_phone(getUserMobileNumber());
            apiSocialRegisterRequest.setUser(apiSocialRegisterUser);

            mApiRequestManager.performSocialRegisterRequest(apiSocialRegisterRequest, new ApiRequestManager.IRegisterResultNotifier() {
                @Override
                public void onRegisterCompleted(ApiRegister.Response apiRegisterResponse) {
                    FrankRossAnalytics.getFrankRossTracker().logEvent(mProvider.equalsIgnoreCase(getString(R.string.log_in_facebook)) ?
                            FrankRossEvents.SOCIAL_REGISTRATION_FACEBOOK_SUCCESS_EVENT
                            : FrankRossEvents.SOCIAL_REGISTRATION_GOOGLE_SUCCESS_EVENT);
                    FacebookManager.logFacebookRegisterEvent(getActivity(), mProvider);
                    Utils.saveBooleanIsRegistered(getActivity().getApplicationContext());

                    mFragmentInteractionListener.hideBlockingProgressBar();
                    if (!apiRegisterResponse.isOtpVerified()) {
                        mFragmentInteractionListener.loadFragment(getId(), EnterOTPFragment.create(true, true, getUserMailId(),
                                getUserMobileNumber(), "", apiSocialRegisterRequest), null, R.anim.push_left_in, R.anim.fade_out,
                                BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                    }
                }

                @Override
                public void onRegisterError(ApiRegister.Response errorResponse) {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                   /* if (!TextUtils.isEmpty(errorResponse.getMessage()) && errorResponse.isOtpVerified()) {
                        showSignInDialog(errorResponse.getMessage());
                    } else*/
                    if (!TextUtils.isEmpty(errorResponse.getMessage())) {
                        showAlert(errorResponse.getMessage());
                    } else {
                        showAlert(getString(R.string.no_connection_error));
                    }
                }
            }, this, this);
        }
    }

    @Override
    protected void showSignInDialog(String message) {
        mFragmentInteractionListener.showAlert(null,
                message, getString(R.string.log_in_btn_text), getString(R.string.cancel),
                new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                        performSocialSignIn();
                    }
                }, new AlertDialogFragment.AlertNegativeActionListener() {
                    @Override
                    public void onNegativeAction() {

                    }
                }, true);
    }

    /**
     * Method requests for Social Log In;If success, updates the cart count
     */
    private void performSocialSignIn() {
        if (isAdded() && getActivity() != null) {
            hide_keyboard(getActivity(), mRegistrationUserMailId);
            mFragmentInteractionListener.showBlockingProgressBar();

            ApiSocialLogin.Request socialLoginRequest = new ApiSocialLogin.Request();
            ApiSocialLogin.User socialLogInUser = new ApiSocialLogin.User();
            socialLogInUser.setSocial_auth_token(mUserAccessToken);
            socialLogInUser.setSocial_login_uid(mUserId);
            socialLogInUser.setSocial_login_provider(mProvider);
            socialLogInUser.setToken(PreferenceUtils.getStringFromSharedPreference(
                    FrankRossApplication.getFrankrossApplicationContext(), PreferenceUtils.PREFERENCE_KEY_GCM_TOKEN));
            socialLoginRequest.setUser(socialLogInUser);

            mApiRequestManager.performSocialLoginRequest(socialLoginRequest, new ApiRequestManager.ISocialLoginResultNotifier() {
                @Override
                public void onSocialLoginSuccess(String accessToken) {
                    FrankRossAnalytics.getFrankRossTracker().logEvent(mProvider.equalsIgnoreCase(getString(R.string.log_in_facebook)) ?
                            FrankRossEvents.SOCIAL_SIGNIN_FACEBOOK_SUCCESS_EVENT
                            : FrankRossEvents.SOCIAL_SIGNIN_GOOGLE_SUCCESS_EVENT);
                    getCartItems();
                }

                @Override
                public void onSocialNewUserLoginError(String message) {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                }

                @Override
                public void onSocialNewUserOtpError(String phoneNumber) {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    ApiSocialRegister.Request apiSocialRegisterRequest = new ApiSocialRegister.Request();
                    ApiSocialRegister.Request.User apiSocialRegisterUser = new ApiSocialRegister.Request.User();
                    apiSocialRegisterUser.setSocial_login_provider(mProvider);
                    apiSocialRegisterUser.setSocial_login_uid(mUserId);
                    apiSocialRegisterUser.setSocial_auth_token(mUserAccessToken);
                    apiSocialRegisterUser.setEmail(getUserMailId());
                    apiSocialRegisterUser.setName(getUserName());
                    apiSocialRegisterUser.setPrimary_phone(getUserMobileNumber());
                    apiSocialRegisterRequest.setUser(apiSocialRegisterUser);
                    mFragmentInteractionListener.loadFragment(getId(), EnterOTPFragment.create(false, false, getUserMailId(),
                            phoneNumber, null, apiSocialRegisterRequest), null, R.anim.push_left_in, R.anim.fade_out,
                            BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                }

                @Override
                public void onSocialLoginError(String message) {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    showAlert(message);
                }
            }, this, this);
        }
    }

    /**
     * Method requests for the updated cart count
     */
    private void getCartItems() {
        final IApiRequestCancel apiRequestCancel = new IApiRequestCancel() {
            @Override
            public String getRequestTag() {
                return "Cart";
            }
        };
        mApiRequestManager.registerRequest(apiRequestCancel);
        mApiRequestManager.performGetCartItemsRequest(new ApiRequestManager.ICartItemDeleteResultNotifier() {
            @Override
            public void onCartItemDeleted() {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }

            @Override
            public void onCartResult(List<BaseRecyclerAdapter.IViewType> cartDataList) {
                mFragmentInteractionListener.hideBlockingProgressBar();

                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, new IErrorHandler() {
            @Override
            public <T> void handleError(AlertError<T> alertError, int statusCode) {
                mFragmentInteractionListener.hideBlockingProgressBar();

                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }

            @Override
            public void handleCommonError(int errorResourceId) {
                mFragmentInteractionListener.hideBlockingProgressBar();

                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, apiRequestCancel);
    }

    /**
     * @return If false,displays the input or network error dialog with appropriate message;else true.
     */
    protected boolean validateRegistration() {
        boolean isValid = false;

        if (TextUtils.isEmpty(getUserName())) {
            showAlert(getString(R.string.please_enter_your_name));
        } else if (TextUtils.isEmpty(getUserMailId())) {
            showAlert(getString(R.string.please_enter_your_email));
        } else if (!Utils.isValidEmail(getUserMailId())) {
            showAlert(getString(R.string.please_enter_a_valid_email));
        } else if (TextUtils.isEmpty(getUserMobileNumber())) {
            showAlert(getString(R.string.please_enter_your_number));
        } else if (!Utils.isValidPhoneNumber(getUserMobileNumber())) {
            showAlert(getString(R.string.please_enter_a_valid_number));
        } else if (!mRegistrationTermsAndConditions.isChecked()) {
            showAlert(getString(R.string.please_agree_to_terms_and_conditions));
        } else if (!NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
            showAlert(getString(R.string.please_check_your_network_connection));
        } else {
            isValid = true;
        }

        return isValid;
    }
}
