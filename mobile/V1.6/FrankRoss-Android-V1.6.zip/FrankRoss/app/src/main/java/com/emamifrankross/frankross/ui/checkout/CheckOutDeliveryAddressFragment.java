/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.checkout;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.Address;
import com.emamifrankross.frankross.core.apimodels.ApiCartCheckout;
import com.emamifrankross.frankross.core.apimodels.ApiFulfillmentCenter;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.account.AccountActivity;
import com.emamifrankross.frankross.ui.adapters.AccountAdapter;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.CartDeliveryAddressAdapter;
import com.emamifrankross.frankross.ui.adapters.CheckOutDeliverySlotAdapter;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.utils.PreferenceUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 22/7/15.
 */

/**
 * This class represents the UI for selected Checkout delivery address and slot
 */
public class CheckOutDeliveryAddressFragment extends ApiRequestBaseFragment implements
        BaseRecyclerAdapter.RecyclerItemClickListener, IToolbar,
        View.OnClickListener {

    public static final String TAG = CheckOutDeliveryAddressFragment.class.getName();

    public static final int REQUEST_CODE_ADD_ADDRESS = 113;

    private static final String BUNDLE_KEY_ORDER_ID = "orderId";
    private static final String BUNDLE_KEY_ADDRESS_ID = "addressId";
    private static final String BUNDLE_KEY_DELIVERY_SLOT_ID = "deliveryId";
    private static final String BUNDLE_KEY_PRESCRIPTION_ID = "prescriptionId";
    private static final String BUNDLE_KEY_DOCTOR_NAME = "doctorName";
    private static final String BUNDLE_KEY_PATIENT_NAME = "patientName";

    private AccountAdapter.AccountAddressItem mSelectedAddress;
    private CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem mSelectedDeliverySlot;
    private CartDeliveryAddressAdapter.CheckOutDoctorPatientInfoDataItem mCheckOutDoctorPatientInfoDataItem =
            new CartDeliveryAddressAdapter.CheckOutDoctorPatientInfoDataItem();

    private CartDeliveryAddressAdapter mCheckOutRecyclerAdapter;
    private List<BaseRecyclerAdapter.IViewType> mCheckOutScreenData = new ArrayList<>();
    private List<BaseRecyclerAdapter.IViewType> mDeliverySlots = new ArrayList<>(1);
    private List<AccountAdapter.AccountAddressItem> mAddressUiList = new ArrayList<>(1);
    private List<Address> mAddressList = new ArrayList<>();

    private Button mProceedBtn;

    private long mOrderId = -1;
    private long mAddressId = -1;
    private long mPrescriptionId = -1;
    private long mDeliverySlotId = -1;

    private String mPatientDetailsFlag = "";
    private String mPatientName = "";
    private String mDoctorName = "";

    public enum CartFlow {
        CART,
        REVISED_CART,
        REVISED_ORDER,
    }

    private CartFlow mCartFlow = CartFlow.CART;

    public static CheckOutDeliveryAddressFragment create(String doctorName, String patientName,
                                                         long orderId, long addressId, long slotId,
                                                         long prescriptionId, CartFlow cartFlow) {
        CheckOutDeliveryAddressFragment fragment = new CheckOutDeliveryAddressFragment();

        Bundle bundle = new Bundle();
        bundle.putLong(BUNDLE_KEY_ORDER_ID, orderId);
        bundle.putLong(BUNDLE_KEY_ADDRESS_ID, addressId);
        bundle.putLong(BUNDLE_KEY_DELIVERY_SLOT_ID, slotId);
        bundle.putLong(BUNDLE_KEY_PRESCRIPTION_ID, prescriptionId);

        bundle.putString(BUNDLE_KEY_DOCTOR_NAME, doctorName);
        bundle.putString(BUNDLE_KEY_PATIENT_NAME, patientName);

        fragment.setCartFlow(cartFlow);
        fragment.setArguments(bundle);
        return fragment;
    }

    public void setCartFlow(CartFlow cartFlow) {
        mCartFlow = cartFlow;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();

        if (bundle != null) {
            mOrderId = bundle.getLong(BUNDLE_KEY_ORDER_ID);
            mAddressId = bundle.getLong(BUNDLE_KEY_ADDRESS_ID);
            mDeliverySlotId = bundle.getLong(BUNDLE_KEY_DELIVERY_SLOT_ID);
            mPrescriptionId = bundle.getLong(BUNDLE_KEY_PRESCRIPTION_ID);

            mDoctorName = bundle.getString(BUNDLE_KEY_DOCTOR_NAME);
            mPatientName = bundle.getString(BUNDLE_KEY_PATIENT_NAME);
        }

        mCheckOutRecyclerAdapter = new CartDeliveryAddressAdapter(mCheckOutScreenData);

        if (mCartFlow != CartFlow.REVISED_ORDER) {
            getCheckoutPatientData();
        } else {
            getAddress();
        }
    }

    /**
     * Method to auto fill the patient name and doctor name in mandatory case,
     * auto fill the patient name in optional case
     */
    private void setPatientDetailsData() {
        if (TextUtils.isEmpty(mDoctorName) && TextUtils.isEmpty(mPatientName)) {

            if (!TextUtils.isEmpty(mPatientDetailsFlag)) {

                if (mPatientDetailsFlag.equalsIgnoreCase(getString(R.string.cart_checkout_optional))) {
                    mCheckOutDoctorPatientInfoDataItem.isOptional = true;

                    if (TextUtils.isEmpty(mCheckOutDoctorPatientInfoDataItem.patientName) ||
                            TextUtils.isEmpty(mCheckOutDoctorPatientInfoDataItem.doctorName)) {
                        mCheckOutDoctorPatientInfoDataItem.patientName = "";
                        mCheckOutDoctorPatientInfoDataItem.doctorName = "";
                    }
                } else if (mPatientDetailsFlag.equalsIgnoreCase(getString(R.string.cart_checkout_mandatory))) {

                    mCheckOutDoctorPatientInfoDataItem.isOptional = false;
                    mCheckOutDoctorPatientInfoDataItem.doctorName = "";
                    mCheckOutDoctorPatientInfoDataItem.patientName = TextUtils.isEmpty(
                            PreferenceUtils.getStringFromSharedPreference(getActivity(), PreferenceUtils.PREFERENCE_USER_NAME)) ? ""
                            : PreferenceUtils.getStringFromSharedPreference(getActivity(), PreferenceUtils.PREFERENCE_USER_NAME);
                }
            }
        } else {
            if (mPatientDetailsFlag.equalsIgnoreCase(getString(R.string.cart_checkout_mandatory))) {
                mCheckOutDoctorPatientInfoDataItem.isOptional = false;
                mCheckOutDoctorPatientInfoDataItem.doctorName = TextUtils.isEmpty(mDoctorName) ? "" : mDoctorName;
                mCheckOutDoctorPatientInfoDataItem.patientName = TextUtils.isEmpty(mPatientName) ? "" : mPatientName;
            } else {
                mCheckOutDoctorPatientInfoDataItem.isOptional = true;
                mCheckOutDoctorPatientInfoDataItem.doctorName = "";
                mCheckOutDoctorPatientInfoDataItem.patientName = "";
            }
        }

        getAddress();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_checkout_delivery_address, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initCheckOutRecyclerView(view);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method to initialize the views
     *
     * @param view the root view
     */
    private void initViews(View view) {
        mProceedBtn = (Button) view.findViewById(R.id.checkout_delivery_address_proceed_btn);
        mProceedBtn.setOnClickListener(this);
    }

    /**
     * Method to initialize the Checkout delivery address screen recycler view
     *
     * @param view the root view
     */
    private void initCheckOutRecyclerView(View view) {
        RecyclerView checkOutDeliveryAddRecyclerView = (RecyclerView) view.
                findViewById(R.id.checkout_delivery_address_recycler_view);
        checkOutDeliveryAddRecyclerView.setHasFixedSize(false);
        checkOutDeliveryAddRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mCheckOutRecyclerAdapter.setRecyclerItemClickListener(this);
        checkOutDeliveryAddRecyclerView.setAdapter(mCheckOutRecyclerAdapter);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.CHECKOUT_DELIVERY_ADDRESS_VISIT_EVENT);
    }

    /**
     * Method requests for user addresses
     */
    private void getAddress() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetAddressRequest(new ApiRequestManager.IGetAddressResultNotifier() {

            @Override
            public void onAddressFetched(List<AccountAdapter.AccountAddressItem> addressList, List<Address> list) {
                onAddressListFetched(addressList, list);
            }
        }, this, this);
    }

    /**
     * Method requests for cached patient details flag;It can be optional,mandatory or not_required
     */
    private void getCheckoutPatientData() {
        mFragmentInteractionListener.showBlockingProgressBar();
        ApiRequestManager.ICartCheckOutPatientDetailsResultNotifier cartSummaryResultNotifier =
                new ApiRequestManager.ICartCheckOutPatientDetailsResultNotifier() {
                    @Override
                    public void onCheckOutResultFetched(String isMandatory) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        mPatientDetailsFlag = isMandatory;

                        setPatientDetailsData();
                    }
                };

        mApiRequestManager.getCheckOutAddressData(cartSummaryResultNotifier);
    }

    /**
     * Method that receives the callback on selecting the address
     *
     * @param address the address object associated to the selected address from address list
     */
    public void onAddressSelect(AccountAdapter.AccountAddressItem address) {
        mFragmentInteractionListener.showBlockingProgressBar();

        mSelectedAddress = address;
        mAddressId = mSelectedAddress.addressId;
        mDeliverySlotId = -1;
        mSelectedDeliverySlot = null;
        mDeliverySlots.clear();
        //getDeliverySlotList(mSelectedAddress.areaId);
        getFulfillmentCenter(mSelectedAddress.areaId);
        mCheckOutDoctorPatientInfoDataItem.isDeliverySlotSelected = false;
    }

    /**
     * Method that receives the callback when the address list is fetched
     *
     * @param addressList the UI list of address objects
     * @param list        the List of addresses from server mapped to address model
     */
    private void onAddressListFetched(List<AccountAdapter.AccountAddressItem> addressList, List<Address> list) {
        mAddressUiList.clear();
        mAddressList.clear();

        if (addressList != null && addressList.size() > 0) {
            mAddressUiList.addAll(addressList);
            mAddressList.addAll(list);

            getSelectedAddress();
        } else {
            mSelectedAddress = null;
            mAddressId = -1;
            mDeliverySlotId = -1;
            mSelectedDeliverySlot = null;
            getCheckOutAdapterData(false);
        }
    }

    /**
     * Method that receives the callback when the address list is refreshed
     *
     * @param addressList the UI list of address objects
     * @param list        the List of addresses from server mapped to address model
     */
    public void onAddressListRefreshed(List<AccountAdapter.AccountAddressItem> addressList, List<Address> list) {
        mFragmentInteractionListener.showBlockingProgressBar();
        onAddressListFetched(addressList, list);
    }

    /**
     * Method gets the selected address which also fetches the area id to get the delivery slots
     */
    private void getSelectedAddress() {
        new AsyncTask<Void, Void, AccountAdapter.AccountAddressItem>() {
            @Override
            protected AccountAdapter.AccountAddressItem doInBackground(Void... params) {
                if (mAddressUiList.size() == 0) {
                    return null;
                } else {
                    int defaultIndex = 0, matchingIndex = -1;
                    int index = 0;

                    for (AccountAdapter.AccountAddressItem address : mAddressUiList) {
                        if (address.isDefaultAddress) defaultIndex = index;
                        if (mAddressId == address.addressId) matchingIndex = index;

                        index++;
                    }

                    if (matchingIndex != -1) {
                        return mAddressUiList.get(matchingIndex);
                    } else {
                        return mAddressUiList.get(defaultIndex);
                    }
                }
            }

            @Override
            protected void onPostExecute(AccountAdapter.AccountAddressItem selectedAddress) {
                super.onPostExecute(selectedAddress);

                if (selectedAddress != null) {
                    mSelectedAddress = selectedAddress;
                    mAddressId = selectedAddress.addressId;

                    //getDeliverySlotList(selectedAddress.areaId);
                    getFulfillmentCenter(selectedAddress.areaId);
                } else {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                }
            }
        }.execute();
    }

    /**
     * Method requests for delivery slots of particular area
     *
     * @param areaId              the area id of the selected address
     * @param fulFillmentCenterId the fulfillment center id from omni channel
     */
    private void getDeliverySlotList(int areaId, int fulFillmentCenterId) {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetDeliverySlotRequest(areaId, mPrescriptionId, fulFillmentCenterId,
                new ApiRequestManager.IGetDeliverySlotsResultNotifier() {
                    @Override
                    public void onDeliverySlotsFetched(List<BaseRecyclerAdapter.IViewType> deliverySlots) {
                        if (deliverySlots != null && deliverySlots.size() > 0) {
                            mDeliverySlots = deliverySlots;
                        } else {
                            showAlert("There are no slots available for delivery");
                        }
                        getCheckOutAdapterData(false);

                        mFragmentInteractionListener.hideBlockingProgressBar();
                    }
                }, this, this);
    }

    /**
     * Method requests for fulfillment center
     *
     * @param areaId the area id of the selected address
     */
    private void getFulfillmentCenter(final int areaId) {
        mFragmentInteractionListener.showBlockingProgressBar();
        ApiFulfillmentCenter.Request fulFillmentCenterRequest = new ApiFulfillmentCenter.Request();
        fulFillmentCenterRequest.setAreaId(areaId);
        fulFillmentCenterRequest.setBillingAddressId(mAddressId);
        fulFillmentCenterRequest.setShippingAddressI(mAddressId);

        mApiRequestManager.performGetFulfillmentCenterRequest(fulFillmentCenterRequest,
                new ApiRequestManager.IGetFulfillmentCenterResultNotifier() {

                    @Override
                    public void onFulfillmentCenterFetched(int fulfillmentCenterId) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        getDeliverySlotList(areaId, fulfillmentCenterId);
                    }
                }, this, this);
    }

    /**
     * Method that receives the callback from parent activity on the Delivery slot selection
     *
     * @param deliverySlot the delivery slot data object associated to the clicked delivery slot
     */
    public void onDeliverySlotSelect(CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem deliverySlot) {
        mDeliverySlotId = deliverySlot.deliverySlotId;
        getCheckOutAdapterData(true);
        show_Keyboard(getActivity().getApplicationContext(), mProceedBtn);
    }

    /**
     * Method that populates the Check out Delivery address screen data
     *
     * @param isDeliverySlot true if delivery slot selected
     */
    private void getCheckOutAdapterData(final boolean isDeliverySlot) {
        mFragmentInteractionListener.showBlockingProgressBar();
        new AsyncTask<Void, Void, ArrayList<BaseRecyclerAdapter.IViewType>>() {
            @Override
            protected ArrayList<BaseRecyclerAdapter.IViewType> doInBackground(Void... params) {
                ArrayList<BaseRecyclerAdapter.IViewType> checkOutScreenData = new ArrayList<BaseRecyclerAdapter.IViewType>();

                /**
                 * Adds Delivery address data item to recycler view UI list
                 */
                CartDeliveryAddressAdapter.CheckOutDeliverToItem addressItem = new CartDeliveryAddressAdapter.CheckOutDeliverToItem();
                if (mSelectedAddress == null) {
                    //no selected address
                    addressItem.mobileNumber = getString(R.string.cart_check_out_choose_delivery_address);
                    addressItem.userName = "";
                    addressItem.fullAddress = "";
                    addressItem.changeBtnTxt = getString(R.string.add);
                    checkOutScreenData.add(addressItem);
                } else {
                    //selected address
                    addressItem.userName = mSelectedAddress.userName;
                    addressItem.fullAddress = mSelectedAddress.fullAddress;
                    addressItem.mobileNumber = mSelectedAddress.mobileNumber;
                    addressItem.changeBtnTxt = getString(R.string.change);
                    checkOutScreenData.add(addressItem);
                }

                /**
                 * Checks if there are any delivery slot selected by user
                 */
                if (mDeliverySlots != null) {
                    for (BaseRecyclerAdapter.IViewType viewType : mDeliverySlots) {
                        if (viewType instanceof CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem) {
                            CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem dataItem =
                                    (CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem) viewType;
                            if (mDeliverySlotId == dataItem.deliverySlotId) {
                                dataItem.isChecked = true;
                                mSelectedDeliverySlot = dataItem;
                            } else {
                                dataItem.isChecked = false;
                            }
                        }
                    }
                }

                /**
                 * Adds Delivery slot data item to recycler view UI list
                 */
                CartDeliveryAddressAdapter.CheckOutDeliverySlotDataItem deliverySlotItem =
                        new CartDeliveryAddressAdapter.CheckOutDeliverySlotDataItem();
                if (mSelectedDeliverySlot != null) {
                    //selected delivery slot
                    deliverySlotItem.deliverySlotHeader = mSelectedDeliverySlot.deliverySlotHeader;
                    deliverySlotItem.deliverySlotTime = mSelectedDeliverySlot.deliverySlotTime;
                } else {
                    //no delivery slot selected
                    deliverySlotItem.deliverySlotHeader = "";
                    deliverySlotItem.deliverySlotTime = "";
                }

                checkOutScreenData.add(deliverySlotItem);

                /**
                 * Adds Patient information data item to recycler view UI list
                 */
                mCheckOutDoctorPatientInfoDataItem.isDeliverySlotSelected = isDeliverySlot;
                mCheckOutDoctorPatientInfoDataItem.isRevisedOrder = mCartFlow == CartFlow.REVISED_ORDER;

                if (!TextUtils.isEmpty(mPatientDetailsFlag)) {

                    if (mPatientDetailsFlag.equalsIgnoreCase(getString(R.string.cart_checkout_optional))) {
                        if (!TextUtils.isEmpty(mCheckOutDoctorPatientInfoDataItem.patientName) ||
                                !TextUtils.isEmpty(mCheckOutDoctorPatientInfoDataItem.doctorName)) {
                            //if optional then don't expand;default value is false
                            mCheckOutDoctorPatientInfoDataItem.isExpand = true;
                        }
                        checkOutScreenData.add(mCheckOutDoctorPatientInfoDataItem);
                    } else if (mPatientDetailsFlag.equalsIgnoreCase(getString(R.string.cart_checkout_mandatory))) {
                        checkOutScreenData.add(mCheckOutDoctorPatientInfoDataItem);
                    }
                }

                return checkOutScreenData;
            }

            @Override
            protected void onPostExecute(ArrayList<BaseRecyclerAdapter.IViewType> checkOutScreenData) {
                super.onPostExecute(checkOutScreenData);
                mCheckOutScreenData.clear();
                mCheckOutScreenData.addAll(checkOutScreenData);
                mFragmentInteractionListener.hideBlockingProgressBar();

                if (getActivity() != null && getView() != null) {
                    mCheckOutRecyclerAdapter.notifyDataSetChanged();
                }
            }
        }.execute();
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;

        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {

            case ViewTypes.CheckOutDeliveryAddressViewType.CHECKOUT_DELIVERY_SLOT_VIEW_TYPE:
                loadDeliverySlotFragment();
                break;
            case ViewTypes.CheckOutDeliveryAddressViewType.CHECKOUT_DELIVER_TO_VIEW_TYPE:
                switch (view.getId()) {
                    case R.id.check_out_deliver_to_change_tv:
                        if (mAddressList.size() > 0) {
                            loadSelectAddressFragment();
                        } else {
                            loadAddAddressFragment();
                        }
                        break;
                }
                break;
        }
    }

    /**
     * Method to navigate to Add delivery address screen
     */
    private void loadAddAddressFragment() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ADD_NEW_DELIVERY_ADDRESS_EVENT);
        startActivityForResult(AccountActivity.getActivityIntentForAddAddress(getActivity().getApplicationContext()),
                REQUEST_CODE_ADD_ADDRESS);
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    /**
     * Method to navigate to Select delivery address screen
     */
    private void loadSelectAddressFragment() {
        mFragmentInteractionListener.loadFragment(getId(), CheckOutSelectAddressFragment.create(mAddressUiList, mAddressList),
                null, R.anim.push_left_in, R.anim.push_left_out,
                BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    /**
     * Method to navigate to Select delivery slot screen
     * If no delivery address selected then shows alert dialog to choose the delivery address
     */
    private void loadDeliverySlotFragment() {
        if (mSelectedAddress == null) {
            showAlert(getString(R.string.please_select_the_delivery_to));
        } else {
            mFragmentInteractionListener.loadFragment(getId(), CheckOutDeliverySlotFragment.create(mDeliverySlots),
                    null, R.anim.push_left_in, R.anim.push_left_out,
                    BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.checkout_delivery_address_proceed_btn:
                loadCheckOutSummaryFragment();
                break;
        }
    }

    /**
     * Method shows the alert dialog if the mandatory fields are not filled or selected
     */
    private void loadCheckOutSummaryFragment() {
        ApiCartCheckout.Request cartCheckOutRequest = null;

        if (mSelectedAddress == null) {

            showAlert(getString(R.string.please_select_the_delivery_to));

        } else if (mSelectedDeliverySlot == null) {

            showAlert(getString(R.string.please_select_the_delivery_slot));

        } else if (mCartFlow == CartFlow.REVISED_ORDER) {

            hide_keyboard(getActivity(), mProceedBtn);
            cartCheckOutRequest = new ApiCartCheckout.Request();
            cartCheckOutRequest.setDoctorName(mDoctorName);
            cartCheckOutRequest.setPatientName(mPatientName);

            mFragmentInteractionListener.loadFragment(getId(), CheckOutSummaryFragment.create(cartCheckOutRequest,
                    mOrderId, mAddressId, mSelectedDeliverySlot.deliverySlotId, mPrescriptionId, mCartFlow),
                    null, R.anim.push_left_in, R.anim.push_left_out,
                    BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);

        } else if (!mCheckOutDoctorPatientInfoDataItem.isOptional &&
                (TextUtils.isEmpty(mCheckOutDoctorPatientInfoDataItem.doctorName) ||
                        TextUtils.isEmpty(mCheckOutDoctorPatientInfoDataItem.patientName))) {

            if (TextUtils.isEmpty(mCheckOutDoctorPatientInfoDataItem.patientName)) {
                showAlert(getString(R.string.cart_checkout_patient_name_mandatory));
            } else if (TextUtils.isEmpty(mCheckOutDoctorPatientInfoDataItem.doctorName)) {
                showAlert(getString(R.string.cart_checkout_doctor_name_mandatory));
            }

        } else {

            hide_keyboard(getActivity(), mProceedBtn);
            cartCheckOutRequest = new ApiCartCheckout.Request();
            cartCheckOutRequest.setDoctorName(TextUtils.isEmpty(mCheckOutDoctorPatientInfoDataItem.doctorName) ? "" :
                    mCheckOutDoctorPatientInfoDataItem.doctorName);
            cartCheckOutRequest.setPatientName(TextUtils.isEmpty(mCheckOutDoctorPatientInfoDataItem.patientName) ? "" :
                    mCheckOutDoctorPatientInfoDataItem.patientName);

            mFragmentInteractionListener.loadFragment(getId(), CheckOutSummaryFragment.create(cartCheckOutRequest,
                    mOrderId, mAddressId, mSelectedDeliverySlot.deliverySlotId, mPrescriptionId, mCartFlow),
                    null, R.anim.push_left_in, R.anim.push_left_out,
                    BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);

        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == getActivity().RESULT_OK) {
            if (requestCode == REQUEST_CODE_ADD_ADDRESS) {
                /*Refresh the selected address after adding a new address*/
                mFragmentInteractionListener.showBlockingProgressBar();
                getAddress();
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        //FrankRossAnalytics.getFrankRossTracker().logTimedEvent(FrankRossEvents.TIME_SPENT_DELIVERY_ADDRESS_SCREEN_EVENT, null);
    }

    @Override
    public void onStop() {
        super.onStop();
        //FrankRossAnalytics.getFrankRossTracker().endTimedEvent(FrankRossEvents.TIME_SPENT_DELIVERY_ADDRESS_SCREEN_EVENT, null);
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_delivery_address);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }
}


