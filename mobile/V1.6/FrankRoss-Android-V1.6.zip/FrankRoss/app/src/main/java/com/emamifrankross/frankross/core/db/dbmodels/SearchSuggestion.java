/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.db.dbmodels;

/**
 * Created by gowtham on 13/8/15.
 */
public class SearchSuggestion {

    private long variantId;

    private String variantName;

    private long categoryId;

    private String categoryName;

    private String brandOrManufacturerName;

    private String genericKeyword;

    private String productIconUrl;

    private boolean isPharma;

    public long getVariantId() {
        return variantId;
    }

    public void setVariantId(long variantId) {
        this.variantId = variantId;
    }

    public String getVariantName() {
        return variantName;
    }

    public void setVariantName(String variantName) {
        this.variantName = variantName;
    }

    public long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(long categoryId) {
        this.categoryId = categoryId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getBrandOrManufacturerName() {
        return brandOrManufacturerName;
    }

    public void setBrandOrManufacturerName(String brandOrManufacturerName) {
        this.brandOrManufacturerName = brandOrManufacturerName;
    }

    public String getGenericKeyword() {
        return genericKeyword;
    }

    public void setGenericKeyword(String genericKeyword) {
        this.genericKeyword = genericKeyword;
    }

    public boolean isPharma() {
        return isPharma;
    }

    public void setIsPharma(boolean isPharma) {
        this.isPharma = isPharma;
    }

    public String getProductIconUrl() {
        return productIconUrl;
    }

    public void setProductIconUrl(String productIconUrl) {
        this.productIconUrl = productIconUrl;
    }
}
