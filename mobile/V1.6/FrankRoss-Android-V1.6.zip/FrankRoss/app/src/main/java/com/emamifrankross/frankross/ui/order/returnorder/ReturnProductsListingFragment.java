/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.order.returnorder;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.ReturnProductsAdapter;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.faq.FAQFragment;
import com.emamifrankross.frankross.ui.viewmodels.CommonRecyclerHeaderItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 29/7/16.
 */

/**
 * This class represents the UI for Return order products listing screen
 */
public class ReturnProductsListingFragment extends ApiRequestBaseFragment implements IToolbar,
        BaseRecyclerAdapter.RecyclerItemClickListener, View.OnClickListener {

    private List<BaseRecyclerAdapter.IViewType> mReturnProductsListingData = new ArrayList<>();
    private ReturnProductsAdapter mReturnProductsListingAdapter;

    public static ReturnProductsListingFragment create() {
        ReturnProductsListingFragment fragment = new ReturnProductsListingFragment();
        fragment.setReturnProductsListingData();
        return fragment;
    }

    private void setReturnProductsListingData() {

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getProductListingMappedUiData();
        mReturnProductsListingAdapter = new ReturnProductsAdapter(mReturnProductsListingData);
    }

    private void getProductListingMappedUiData() {
        if (getActivity() != null && isAdded()) {
            List<BaseRecyclerAdapter.IViewType> returnProductsListingData = new ArrayList<>();
            CommonRecyclerHeaderItem commonRecyclerHeaderItem =
                    new CommonRecyclerHeaderItem(getActivity().getResources().getString(R.string.return_products_listing_header));
            returnProductsListingData.add(commonRecyclerHeaderItem);

            ReturnProductsAdapter.NonReturnableProductsItemDataModel nonReturnableProductsItemDataModel =
                    new ReturnProductsAdapter.NonReturnableProductsItemDataModel();
            nonReturnableProductsItemDataModel.productId = 1131;
            nonReturnableProductsItemDataModel.productName = "Test product 1 and this is just for test";
            nonReturnableProductsItemDataModel.productImageUrl = "http://emami-staging-2.s3.amazonaws.com/variant_images/files/000/009/483/normal/FR-19919.png?1454910916";
            nonReturnableProductsItemDataModel.returnErrorMessage = "Non returnable product";
            returnProductsListingData.add(nonReturnableProductsItemDataModel);

            ReturnProductsAdapter.ReturnableProductsItemDataModel orderedProductInfo =
                    new ReturnProductsAdapter.ReturnableProductsItemDataModel();
            orderedProductInfo.productId = 1111;
            orderedProductInfo.productName = "Test product 2 and this is just for test";
            orderedProductInfo.productImageUrl = "http://emami-staging-2.s3.amazonaws.com/variant_images/files/000/003/115/normal/BC_272.png?1440401212";
            orderedProductInfo.orderQuantity = 3;
            returnProductsListingData.add(orderedProductInfo);

            mReturnProductsListingData.addAll(returnProductsListingData);
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_order_history_details, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initReturnProductsListingRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the views associated to return products views
     *
     * @param view the root view
     */
    private void initReturnProductsListingRecyclerView(View view) {
        RecyclerView returnProductsRecyclerView = (RecyclerView) view.
                findViewById(R.id.order_details_recycler_view);
        returnProductsRecyclerView.setHasFixedSize(false);
        returnProductsRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mReturnProductsListingAdapter.setRecyclerItemClickListener(this);
        returnProductsRecyclerView.setAdapter(mReturnProductsListingAdapter);

        Button proceedBtn = (Button) view.findViewById(R.id.order_details_bottom_btn);
        proceedBtn.setText(getResources().getString(R.string.return_products_listing_proceed));
        proceedBtn.setOnClickListener(this);
    }

    /**
     * Method that handles the click of 'Return policy' menu there by launching the FAQ screen
     * for return management
     *
     * @param faqTopicID the return policy/return management faq id
     */
    private void loadReturnPolicyFAQFragment(long faqTopicID) {
        if (faqTopicID != 0) {
            mFragmentInteractionListener.loadFragment(getId(),
                    FAQFragment.create(getString(R.string.return_products_menu_return_policy), faqTopicID), null,
                    R.anim.push_left_in, R.anim.push_left_out,
                    FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
        }
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public int getToolbarMenuId() {
        return R.menu.menu_return_order_policy;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_return_policy:
                        loadReturnPolicyFAQFragment(4);
                        return true;
                }
                return false;
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getResources().getString(R.string.return_products_title);
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.order_details_bottom_btn:
                mFragmentInteractionListener.loadFragment(getId(),
                        ReturnProductsSubmitFragment.create(), ReturnProductsSubmitFragment.TAG,
                        R.anim.push_left_in, R.anim.push_left_out,
                        FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                break;
        }
    }
}
