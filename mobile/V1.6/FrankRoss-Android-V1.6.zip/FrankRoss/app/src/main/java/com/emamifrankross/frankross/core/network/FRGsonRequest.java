/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.network;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.HttpHeaderParser;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.utils.Log;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Type;
import java.util.Map;

/**
 * class for all network Gson requests.
 *
 * @param <T> The type of parsed response this request expects for 200 status code.
 * @param <U> The type of parsed response this request expects for other status code.
 */
public class FRGsonRequest<T, U> extends Request<T> {

    /**
     * Default character set used is "utf-8"
     */
    private static final String PROTOCOL_CHARSET_DEFAULT = "UTF-8";
    /**
     * Content-Type for "application/json"
     */
    private static final String PROTOCOL_CONTENT_TYPE_JSON = String.format(
            "application/json; charset=%s", PROTOCOL_CHARSET_DEFAULT);
    /**
     * Content-Type for "application/x-www-form-urlencoded"
     */
    private static final String PROTOCOL_CONTENT_TYPE_APPLICATION_URL_ENCODED = String
            .format("application/x-www-form-urlencoded; charset=%s",
                    PROTOCOL_CHARSET_DEFAULT);
    /**
     * EmailRequest time out 5s
     */
    private static final int FRANK_ROSS_REQUEST_TIMEOUT_MS = 20 * 1000;
    private final Gson gson = new Gson();
    public SuccessResponseListener<T> mSuccessResponseListener;
    private IAPIRequestCancelHandler mAPIRequestCancelHandler;
    private int mErrorStatusCode;
    private Map<String, String> mResponseHeaders;
    private IAPIRequest mFrankRossRequest;
    private Class<T> mSuccessModeClazz;
    private Class<U> mErrorModelClazz;
    private Type mSuccessModelType;
    private Type mErrorModelType;
    private ErrorResponseListener<U> mErrorResponseListener;
    private U errorResult;
    private String mRequestTag;
    public FRGsonRequest(IAPIRequest walletRequest, Type successModelType, Type errorModelType,
                         SuccessResponseListener<T> successResponseListener,
                         ErrorResponseListener<U> errorResponseListener,
                         String requestTag) {
        this(walletRequest, successResponseListener, errorResponseListener, requestTag);

        mSuccessModelType = successModelType;
        mErrorModelType = errorModelType;
    }
    public FRGsonRequest(IAPIRequest walletRequest, Class<T> successModeClazz, Class<U> errorModelClazz,
                         SuccessResponseListener<T> successResponseListener,
                         ErrorResponseListener<U> errorResponseListener,
                         String requestTag) {
        this(walletRequest, successResponseListener, errorResponseListener, requestTag);

        mSuccessModeClazz = successModeClazz;
        mErrorModelClazz = errorModelClazz;
    }
    public FRGsonRequest(IAPIRequest walletRequest, SuccessResponseListener<T> successResponseListener,
                         ErrorResponseListener<U> errorResponseListener, String requestTag) {
        super(getVolleyMethodType(walletRequest.getRequestMethodType()), walletRequest.getRequestUrl(), new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                //Ignore.
            }
        });

        mFrankRossRequest = walletRequest;
        mSuccessResponseListener = successResponseListener;
        mErrorResponseListener = errorResponseListener;
        mRequestTag = requestTag;
        setTag(requestTag);
        setRetryPolicy(new DefaultRetryPolicy(FRANK_ROSS_REQUEST_TIMEOUT_MS,
                DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));
    }

    private static int getVolleyMethodType(MethodType methodType) {
        if (methodType.equals(MethodType.GET)) return Method.GET;
        else if (methodType.equals(MethodType.POST)) return Method.POST;
        else if (methodType.equals(MethodType.DEL)) return Method.DELETE;
        else if (methodType.equals(MethodType.PUT)) return Method.PUT;
        else return Method.GET;
    }

    @Override
    public Map<String, String> getHeaders() throws AuthFailureError {
        return mFrankRossRequest.getRequestHeaders() != null ? mFrankRossRequest.getRequestHeaders() : super.getHeaders();
    }

    @Override
    public byte[] getBody() throws AuthFailureError {
        try {
            return mFrankRossRequest.getRequestBody() == null ? null : mFrankRossRequest.getRequestBody()
                    .getBytes(PROTOCOL_CHARSET_DEFAULT);
        } catch (UnsupportedEncodingException uee) {
            VolleyLog
                    .wtf("Unsupported Encoding while trying to get the bytes of %s using %s",
                            mFrankRossRequest.getRequestBody(), PROTOCOL_CHARSET_DEFAULT);
            return null;
        }
    }

    @Override
    public String getBodyContentType() {

        switch (mFrankRossRequest.getContentType()) {
            case JSON:
                return PROTOCOL_CONTENT_TYPE_JSON;
            case APPLICATION_FORM_URL_ENCODED:
                return PROTOCOL_CONTENT_TYPE_APPLICATION_URL_ENCODED;
            default:
                return super.getBodyContentType();
        }
    }

    @Override
    final protected Response<T> parseNetworkResponse(NetworkResponse response) {
        try {
            T result = null;
            String json = new String(response.data, HttpHeaderParser.parseCharset(response.headers));
            mResponseHeaders = response.headers;
            Log.v("HTTP", String.format("Response\t[%s]\t%s", mFrankRossRequest.getRequestUrl(), getPrettyPrintedJson(json)));
            //Log.d("OBFUS", String.format("Response\t[%s]\t%s", mFrankRossRequest.getRequestUrl(), getPrettyPrintedJson(json)));

            if (mSuccessModeClazz == null && mSuccessModelType == null) {
                result = parseSuccessResponse(json);
            } else if (mSuccessModeClazz != null) {
                result = gson.fromJson(json, mSuccessModeClazz);
            } else {
                result = gson.fromJson(json, mSuccessModelType);
            }

            result = postProcess(result);
            //Log.d("OBFUS", "After Post process");
            return Response.success(result, HttpHeaderParser.parseCacheHeaders(response));
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            return Response.error(new ParseError(e));
        } catch (JsonSyntaxException e) {
            e.printStackTrace();
            return Response.error(new ParseError(e));
        }
    }

    protected T parseSuccessResponse(String json) {
        return (T) new Object();
    }

    protected T postProcess(T response) {
        return response;
    }

    @Override
    final protected VolleyError parseNetworkError(VolleyError volleyError) {
        if (volleyError.networkResponse != null) {
            try {

                String json = new String(volleyError.networkResponse.data, HttpHeaderParser.parseCharset(volleyError.networkResponse.headers));
                Log.v("HTTP", String.format("Response\t[%s]\t%s", mFrankRossRequest.getRequestUrl(), getPrettyPrintedJson(json)));
                // Log.d("OBFUS", String.format("Response\t[%s]\t%s", mFrankRossRequest.getRequestUrl(), getPrettyPrintedJson(json)));

                if (mSuccessModeClazz == null && mSuccessModelType == null) {
                    errorResult = parseErrorResponse(json);
                } else if (mErrorModelClazz != null) {
                    errorResult = gson.fromJson(json, mErrorModelClazz);
                } else {
                    errorResult = gson.fromJson(json, mErrorModelType);
                }

                mErrorStatusCode = volleyError.networkResponse.statusCode;
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                return new ParseError(e);
            } catch (JsonSyntaxException e) {
                e.printStackTrace();
                return new ParseError(e);
            }
        }

        return super.parseNetworkError(volleyError);
    }

    protected U parseErrorResponse(String json) {
        return (U) new Object();
    }

    @Override
    protected void deliverResponse(T response) {
        if (mSuccessResponseListener != null && (mAPIRequestCancelHandler == null || mAPIRequestCancelHandler.isRequestCancelled(getRequestTag()))) {
            mSuccessResponseListener.onResponse(response, mResponseHeaders);
        }
    }

    @Override
    public void deliverError(VolleyError error) {
        //Log.d("OBFUS", "deliverError");
        if (mErrorResponseListener != null && (mAPIRequestCancelHandler == null || mAPIRequestCancelHandler.isRequestCancelled(getRequestTag()))) {
            if (errorResult != null) {
                mErrorResponseListener.onErrorResponse(errorResult, mErrorStatusCode);
            } else if ((error instanceof NetworkError)
                    || (error instanceof NoConnectionError)) {
                mErrorResponseListener.onError(R.string.no_connection_error);
            } else if (error instanceof ServerError) {
                mErrorResponseListener.onError(R.string.server_error);
            } else if (error instanceof ParseError) {
                //Log.d("OBFUS", "deliverError parse error");
                mErrorResponseListener.onError(R.string.unknown_error);
            } else if (error instanceof TimeoutError) {
                mErrorResponseListener.onError(R.string.time_out_error);
            } else if (error instanceof AuthFailureError) {
                // Log.d("OBFUS", "deliverError AuthFailureError");
                mErrorResponseListener.onError(R.string.unknown_error);
            } else {
                //Log.d("OBFUS", "deliverError else part");
                mErrorResponseListener.onError(R.string.unknown_error);
            }
        }
    }

    private String getPrettyPrintedJson(String unformattedString) {
        String prettyJsonString = unformattedString;
        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            JsonParser jp = new JsonParser();
            JsonElement je = jp.parse(unformattedString);
            prettyJsonString = gson.toJson(je);

        } catch (JsonSyntaxException ex) {
            prettyJsonString = unformattedString;
        }
        return prettyJsonString;
    }

    /**
     * Method to set the request cancel handler.
     *
     * @param requestCancelHandler the cancel request handler
     */
    public void setAPIRequestCancelHandler(IAPIRequestCancelHandler requestCancelHandler) {
        mAPIRequestCancelHandler = requestCancelHandler;
    }

    private String getRequestTag() {
        if (getTag() != null) return (String) getTag();

        return "";
    }

    public enum ContentType {
        JSON, APPLICATION_FORM_URL_ENCODED
    }

    public enum MethodType {
        PUT, POST, GET, DEL
    }

    /**
     * Interface for Gson EmailRequest
     */
    public interface IAPIRequest {

        MethodType getRequestMethodType();

        String getRequestUrl();

        Map<String, String> getRequestHeaders();

        String getRequestBody();

        ContentType getContentType();

    }

    /**
     * Callback interface for delivering parsed success responses.
     * T : Success response model.
     * U : Error response model.
     */
    public interface SuccessResponseListener<T> {
        void onResponse(T response, Map<String, String> responseHeaders);
    }

    /**
     * Callback interface for delivering parsed error responses.
     * U : Error response model.
     */
    public interface ErrorResponseListener<U> {

        void onErrorResponse(U errorResponse, int statusCode);

        void onError(int messageId);
    }

    /**
     * Interface to identify whether the activity or fragment destroyed. It will help in delivering the response back to Fragment.
     * <p> API EmailRequest manager class had implemented this interface. You can set this interface to this EmailRequest using method</p>
     */
    public interface IAPIRequestCancelHandler {
        boolean isRequestCancelled(String requestTag);
    }

}
