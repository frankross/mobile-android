/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 29/7/15.
 */
public class ApiResendOtp {

    public static class Request {

        public String toJsonString() {
            return new Gson().toJson(this);
        }
    }

    public static class EmailRequest extends Request {

        public EmailRequest(String email) {
            this.email = email;
        }

        @SerializedName("email")
        private String email;

        public String getEmail() {
            return email;
        }
    }


    public static class NumberRequest extends Request {

        public NumberRequest(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }

        @SerializedName("phone_number")
        private String phoneNumber;

        public String getPhoneNumber() {
            return phoneNumber;
        }
    }

    public static class Response {

        @SerializedName("message")
        private String successMessage = "Otp Sent";

        public String getSuccessMessage() {
            return successMessage;
        }

        public void setSuccessMessage(String successMessage) {
            this.successMessage = successMessage;
        }
    }
}
