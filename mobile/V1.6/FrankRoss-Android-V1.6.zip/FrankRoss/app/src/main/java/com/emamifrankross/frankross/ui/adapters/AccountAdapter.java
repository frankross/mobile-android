/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.viewmodels.CommonRecyclerHeaderViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.UserInformation;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 3/7/15.
 * <p/>
 * <p> Adapter class for Account Section</p>
 * <p>Supports the Five View Types </p>
 * <p> 1 : ACCOUNT_VIEW_TYPE_USER_INFO </p>
 * <p> 2 : ACCOUNT_VIEW_TYPE_ORDER_INFO  </p>
 * <p> 3 : ACCOUNT_VIEW_TYPE_HEADER </p>
 * <p> 4 : ACCOUNT_VIEW_TYPE_ADDRESS </p>
 * <p> 5 : ACCOUNT_VIEW_TYPE_FOOTER </p>
 */
public class AccountAdapter extends BaseRecyclerAdapter {

    public AccountAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        ArrayList<RecyclerViewDataBinder> viewHolderTypes = new ArrayList<>(1);
        viewHolderTypes.add(new AccountUserInfoViewHolderType());
        viewHolderTypes.add(new CommonRecyclerHeaderViewDataBinder());
        viewHolderTypes.add(new AccountAddressViewHolderType());
        viewHolderTypes.add(new RecyclerBorderDataBinder());
        viewHolderTypes.add(new AccountAddressFooterViewHolderType());

        return viewHolderTypes;
    }

    /**
     * ACCOUNT VIEW TYPE USER INFO
     */

    public static class AccountUserInfoViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mUserName;
        private RobotoTextView mUserMailId;
        private RobotoTextView mUserMobileNumber;
        private ImageView mEditProfile;
        private LinearLayout mEmailIdLinearLayout;

        public AccountUserInfoViewHolder(View view) {
            super(view);
            mEditProfile = (ImageView) itemView.findViewById(R.id.account_edit_icon_iv);
            mUserName = (RobotoTextView) view.findViewById(R.id.account_user_name_tv);
            mUserMailId = (RobotoTextView) view.findViewById(R.id.account_user_mail_id_tv);
            mUserMobileNumber = (RobotoTextView) view.findViewById(R.id.account_user_mobile_number_tv);
            mEmailIdLinearLayout = (LinearLayout) view.findViewById(R.id.account_user_info_mailid_linlay);
        }
    }

    private class AccountUserInfoViewHolderType implements RecyclerViewDataBinder<AccountUserInfoViewHolder,
            UserInformation> {
        @Override
        public AccountUserInfoViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.account_user_info, parent, false);

            return new AccountUserInfoViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(AccountUserInfoViewHolder viewHolder, final UserInformation data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mUserName.setText(Utils.getCapitalizedWords(data.userName));

            if (TextUtils.isEmpty(data.userMailId)) {
                viewHolder.mEmailIdLinearLayout.setVisibility(View.GONE);
            } else {
                viewHolder.mEmailIdLinearLayout.setVisibility(View.VISIBLE);
                viewHolder.mUserMailId.setText(data.userMailId);
            }

            viewHolder.mUserMobileNumber.setText(Utils.getFormattedMobileNumber(data.userMobileNumber));
            if (recyclerViewClickListener != null) {
                viewHolder.mEditProfile.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        recyclerViewClickListener.onRecyclerItemClick(position, view, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.AccountViewType.ACCOUNT_VIEW_TYPE_USER_INFO;
        }
    }

    /**
     * ACCOUNT VIEW TYPE ADDRESS
     */

    public static class AccountAddressItem implements IViewType {

        public String addressCategory;
        public String userName;
        public String fullAddress;
        public String mobileNumber;
        public long addressId;
        public int areaId;
        public boolean isActive;
        public boolean isDefaultAddress;

        @Override
        public int getViewType() {
            return ViewTypes.AccountViewType.ACCOUNT_VIEW_TYPE_ADDRESS;
        }
    }

    public static class AccountAddressViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mAddressCategory;
        private RobotoTextView mDefaultAddress;
        private RobotoTextView mUserName;
        private RobotoTextView mFullAddress;
        private RobotoTextView mMobileNumber;
        private ImageView mOverflow;
        private CardView mCardView;

        public AccountAddressViewHolder(View view) {
            super(view);
            mAddressCategory = (RobotoTextView) view.findViewById(R.id.account_user_address_category_tv);
            mDefaultAddress = (RobotoTextView) view.findViewById(R.id.account_default_address_tv);
            mUserName = (RobotoTextView) view.findViewById(R.id.account_user_name_tv);
            mFullAddress = (RobotoTextView) view.findViewById(R.id.account_user_full_address_tv);
            mMobileNumber = (RobotoTextView) view.findViewById(R.id.account_user_mobile_number_tv);
            mOverflow = (ImageView) view.findViewById(R.id.account_overflow_icon_iv);
            mCardView = (CardView) view.findViewById(R.id.card_view);
        }
    }

    private class AccountAddressViewHolderType implements RecyclerViewDataBinder<AccountAddressViewHolder,
            AccountAddressItem> {
        @Override
        public AccountAddressViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.address_list_item, parent, false);
            return new AccountAddressViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(AccountAddressViewHolder viewHolder, final AccountAddressItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            if (TextUtils.isEmpty(data.addressCategory)) {
                viewHolder.mAddressCategory.setVisibility(View.GONE);
            } else {
                viewHolder.mAddressCategory.setVisibility(View.VISIBLE);
                viewHolder.mAddressCategory.setText(Utils.getCapitalizedWords(data.addressCategory));
            }
            viewHolder.mDefaultAddress.setVisibility(data.isDefaultAddress ? View.VISIBLE : View.GONE);
            viewHolder.mUserName.setText(Utils.getCapitalizedWords(data.userName));
            viewHolder.mFullAddress.setText(data.fullAddress);
            viewHolder.mMobileNumber.setText(data.mobileNumber);
            if (recyclerViewClickListener != null) {
                viewHolder.mOverflow.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
                viewHolder.mCardView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.AccountViewType.ACCOUNT_VIEW_TYPE_ADDRESS;
        }
    }

    /**
     * ACCOUNT VIEW TYPE FOOTER
     */

    public static class AccountAddressFooterItem implements IViewType {

        public String addressFooter;

        @Override
        public int getViewType() {
            return ViewTypes.AccountViewType.ACCOUNT_VIEW_TYPE_FOOTER;
        }
    }

    public static class AccountAddressFooterViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mAddNewDeliveryAddress;

        public AccountAddressFooterViewHolder(View view) {
            super(view);
            mAddNewDeliveryAddress = (RobotoTextView) view.findViewById(R.id.add_new_delivery_address_tv);
        }
    }

    private class AccountAddressFooterViewHolderType implements RecyclerViewDataBinder<AccountAddressFooterViewHolder,
            AccountAddressFooterItem> {
        @Override
        public AccountAddressFooterViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.add_new_delivery_address, parent, false);
            return new AccountAddressFooterViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(AccountAddressFooterViewHolder viewHolder, final AccountAddressFooterItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mAddNewDeliveryAddress.setText(data.addressFooter);
            if (recyclerViewClickListener != null) {
                viewHolder.mAddNewDeliveryAddress.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.AccountViewType.ACCOUNT_VIEW_TYPE_FOOTER;
        }
    }
}
