/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.checkout;

import com.emamifrankross.frankross.core.apimodels.ApiOrderReminder;

/**
 * Created by gauthami on 21/8/15.
 */

/**
 * Interface definition for a callback to be invoked when reorder reminder submitted
 */
public interface IRemindOrderDoneClickNotifier {
    /**
     * Called when user sets reminder to reorder
     *
     * @param apiOrderReminderRequest the date when the reminder has to be set
     */
    void onRemindOrderDoneClick(ApiOrderReminder.Request apiOrderReminderRequest);

    void onRemindOrderCancel();
}
