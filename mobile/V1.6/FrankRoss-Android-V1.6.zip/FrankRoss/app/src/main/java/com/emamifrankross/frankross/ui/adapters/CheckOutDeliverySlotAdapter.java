/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 23/7/15.
 * <p> Adapter class for CheckOut Delivery Slot Section</p>
 * <p>Supports the Two View Types </p>
 * <p> 1 : CHECKOUT DELIVERY SLOT HEADER VIEW TYPE </p>
 * <p> 2 : CHECKOUT DELIVERY SLOT TIME TO VIEW TYPE </p>
 */
public class CheckOutDeliverySlotAdapter extends BaseRecyclerAdapter {

    public CheckOutDeliverySlotAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<BaseRecyclerAdapter.RecyclerViewDataBinder> getViewDataBinders() {
        List<BaseRecyclerAdapter.RecyclerViewDataBinder> viewHolderTypeList = new ArrayList<>(1);
        viewHolderTypeList.add(new CheckOutDeliverySlotHeaderViewHolderType());
        viewHolderTypeList.add(new CheckOutDeliverySlotTimeViewHolderType());

        return viewHolderTypeList;
    }

    /**
     * CHECKOUT DELIVERY SLOT HEADER VIEW TYPE
     */

    public static class CheckOutDeliverySlotHeaderDataItem implements BaseRecyclerAdapter.IViewType {

        public String deliverySlotHeader;

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutDeliverySlotViewType.CHECKOUT_DELIVERY_SLOT_HEADER_VIEW_TYPE;
        }
    }

    private static class CheckOutDeliverySlotHeaderViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mDeliverySlotHeader;

        public CheckOutDeliverySlotHeaderViewHolder(View itemView) {
            super(itemView);
            mDeliverySlotHeader = (RobotoTextView) itemView.findViewById(R.id.check_out_delivery_slot_header_tv);
        }
    }

    private static class CheckOutDeliverySlotHeaderViewHolderType implements
            BaseRecyclerAdapter.RecyclerViewDataBinder<CheckOutDeliverySlotHeaderViewHolder, CheckOutDeliverySlotHeaderDataItem> {

        @Override
        public CheckOutDeliverySlotHeaderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.check_out_delivery_slot_hedaer, parent, false);

            return new CheckOutDeliverySlotHeaderViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(CheckOutDeliverySlotHeaderViewHolder viewHolder,
                                         final CheckOutDeliverySlotHeaderDataItem data, final int position,
                                         final BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mDeliverySlotHeader.setText(data.deliverySlotHeader);
        }

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutDeliverySlotViewType.CHECKOUT_DELIVERY_SLOT_HEADER_VIEW_TYPE;
        }
    }

    /**
     * CHECKOUT DELIVERY SLOT TIME TO VIEW TYPE
     */

    public static class CheckOutDeliverySlotTimeDataItem implements BaseRecyclerAdapter.IViewType {

        public String deliverySlotHeader;
        public String deliverySlotTime;
        public long deliverySlotId = -1;
        public boolean isChecked = false;

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutDeliverySlotViewType.CHECKOUT_DELIVERY_SLOT_TIME_TO_VIEW_TYPE;
        }
    }

    private static class CheckOutDeliverySlotTimeViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mDeliverySlotHeader;
        private ImageView mDeliverySlotIndicator;
        private LinearLayout mDeliverySlotLinLyt;

        public CheckOutDeliverySlotTimeViewHolder(View itemView, Context context) {
            super(itemView);
            mDeliverySlotIndicator = (ImageView) itemView.findViewById(R.id.sort_indicator_iv);
            mDeliverySlotHeader = (RobotoTextView) itemView.findViewById(R.id.sort_by_text_tv);
            mDeliverySlotLinLyt = (LinearLayout) itemView.findViewById(R.id.sort_products_linLyt);

            mDeliverySlotHeader.setPadding(context.getResources().getDimensionPixelOffset(R.dimen.check_out_delivery_slot_time_left_padding), 0, 0, 0);
            mDeliverySlotHeader.setTextColor(ContextCompat.getColor(context, R.color.delivery_slot_text_color));
            mDeliverySlotHeader.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        }
    }

    private static class CheckOutDeliverySlotTimeViewHolderType implements
            BaseRecyclerAdapter.RecyclerViewDataBinder<CheckOutDeliverySlotTimeViewHolder, CheckOutDeliverySlotTimeDataItem> {

        @Override
        public CheckOutDeliverySlotTimeViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sort_products_list_item, parent, false);

            return new CheckOutDeliverySlotTimeViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(final CheckOutDeliverySlotTimeViewHolder viewHolder,
                                         final CheckOutDeliverySlotTimeDataItem data, final int position,
                                         final BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mDeliverySlotHeader.setText(data.deliverySlotTime);
            Context context = viewHolder.mDeliverySlotHeader.getContext();
            viewHolder.mDeliverySlotIndicator.setImageResource((data.isChecked) ? R.mipmap.select : R.drawable.abc_list_divider_mtrl_alpha);
            viewHolder.mDeliverySlotHeader.setTextColor(ContextCompat.getColor(context,
                    data.isChecked ? R.color.delivery_slot_selected_text_color : R.color.delivery_slot_text_color));

            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutDeliverySlotViewType.CHECKOUT_DELIVERY_SLOT_TIME_TO_VIEW_TYPE;
        }
    }
}
