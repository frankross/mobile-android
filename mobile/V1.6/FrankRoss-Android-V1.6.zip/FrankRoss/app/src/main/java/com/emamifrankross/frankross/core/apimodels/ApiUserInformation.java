/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.viewmodels.UserInformation;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 16/7/15.
 */
public class ApiUserInformation {

    public static class Response {

        @SerializedName("user")
        private User user;

        private UserInformation uiData;

        public User getUser() {
            return user;
        }

        public void setUser(User user) {
            this.user = user;
        }

        public UserInformation getUiData() {
            return uiData;
        }

        public void setUiData(UserInformation uiData) {
            this.uiData = uiData;
        }

        public static class User {
            @SerializedName("id")
            private String id;

            @SerializedName("email")
            private String email;

            @SerializedName("name")
            private String name;

            @SerializedName("primary_phone")
            private String primary_phone;

            public String getId() {
                return id;
            }

            public void setId(String id) {
                this.id = id;
            }

            public String getEmail() {
                return email;
            }

            public void setEmail(String email) {
                this.email = email;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getPrimary_phone() {
                return primary_phone;
            }

            public void setPrimary_phone(String primary_phone) {
                this.primary_phone = primary_phone;
            }
        }
    }
}
