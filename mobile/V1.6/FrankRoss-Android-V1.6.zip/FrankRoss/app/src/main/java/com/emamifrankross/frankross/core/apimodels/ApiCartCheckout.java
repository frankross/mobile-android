/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 7/8/15.
 */
public class ApiCartCheckout {

    public static class Request {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("doctor_names")
        private String doctorName = "";

        @SerializedName("patient_name")
        private String patientName = "";


        public String getDoctorName() {
            return doctorName;
        }

        public void setDoctorName(String doctorName) {
            this.doctorName = doctorName;
        }

        public String getPatientName() {
            return patientName;
        }

        public void setPatientName(String patientName) {
            this.patientName = patientName;
        }
    }

    public static class Response {

        @SerializedName("order")
        private Order cartOrder;

        public Order getCartOrder() {
            return cartOrder;
        }

        public void setCartOrder(Order cartOrder) {
            this.cartOrder = cartOrder;
        }

        public static class Order {

            @SerializedName("id")
            private long id;

            public long getId() {
                return id;
            }

            public void setId(long id) {
                this.id = id;
            }
        }
    }

    public static class ErrorResponse {

        @SerializedName("order")
        private Order order;

        public Order getOrder() {
            return order;
        }

        public void setOrder(Order order) {
            this.order = order;
        }

        public static class Order {
            @SerializedName("id")
            private int id;

            @SerializedName("errors")
            private List<String> errors = new ArrayList<>(1);

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public List<String> getErrors() {
                return errors;
            }

            public void setErrors(List<String> errors) {
                this.errors = errors;
            }
        }
    }
}
