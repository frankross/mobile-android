/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.viewmodels.CommonRecyclerHeaderViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderDataBinder;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 7/4/16.
 * <p/>
 * <p> Adapter class for FAQ Section</p>
 * <p> Supports the Four View Types </p>
 * <p> 1 : FAQ TOP QUERY VIEW TYPE  </p>
 * <p> 2 : FAQ HEALP TOPICS VIEW TYPE </p>
 * <p> 3 : COMMON BORDER VIEW TYPE </p>
 * <p> 4 : COMMON HEADER VIEW TYPE </p>
 */
public class FaqTopQueryAdapter extends BaseRecyclerAdapter {

    public FaqTopQueryAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        ArrayList<RecyclerViewDataBinder> viewHolderTypes = new ArrayList<>(1);
        viewHolderTypes.add(new CommonRecyclerHeaderViewDataBinder());
        viewHolderTypes.add(new RecyclerBorderDataBinder());
        viewHolderTypes.add(new FAQHelpTopicsViewHolderType());
        viewHolderTypes.add(new FAQTopQueryAlternateViewHolderType());

        return viewHolderTypes;
    }

    /**
     * FAQ HELP TOPICS VIEW TYPE
     */
    public static class FAQHelpTopicsDataItem implements IViewType {

        public String faqHelpTopic = "";
        public long faqHelpTopicId = 0;

        @Override
        public int getViewType() {
            return ViewTypes.FAQViewType.FAQ_HELP_TOPICS_ITEM_VIEW_TYPE;
        }
    }

    public static class FAQHelpTopicsViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mFAQHelpTopic;
        private ImageView mFAQIcon;
        private LinearLayout mFaqLinLyt;

        public FAQHelpTopicsViewHolder(View view) {
            super(view);
            mFAQHelpTopic = (RobotoTextView) view.findViewById(R.id.faq_expandable_group_title_tv);
            mFAQIcon = (ImageView) view.findViewById(R.id.faq_expandable_group_expand_iv);
            mFaqLinLyt = (LinearLayout) view.findViewById(R.id.faq_expandable_group_parent_linLyt);
        }
    }

    private class FAQHelpTopicsViewHolderType implements RecyclerViewDataBinder<FAQHelpTopicsViewHolder,
            FAQHelpTopicsDataItem> {
        @Override
        public FAQHelpTopicsViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.faq_help_topics_item, parent, false);
            return new FAQHelpTopicsViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(FAQHelpTopicsViewHolder viewHolder, final FAQHelpTopicsDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mFAQHelpTopic.setText(data.faqHelpTopic);

            if (recyclerViewClickListener != null) {
                viewHolder.mFaqLinLyt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.FAQViewType.FAQ_HELP_TOPICS_ITEM_VIEW_TYPE;
        }
    }

    /**
     * FAQ TOP QUERY ALTERNATE VIEW TYPE
     */
    public static class FAQTopQueryAlternateDataItem implements IViewType {

        public String faqHelpTopic = "";
        public String faqTopicAnswer = "";
        public long faqHelpTopicId = 0;
        public boolean isExpanded = false;

        @Override
        public int getViewType() {
            return ViewTypes.FAQViewType.FAQ_TOP_QUERY_ALTERNATE_ITEM_VIEW_TYPE;
        }
    }

    public static class FAQTopQueryAlternateViewHolder extends RecyclerView.ViewHolder {

        private final RobotoTextView mFaqChildText;
        private RobotoTextView mFAQHelpTopic;
        private ImageView mFAQIcon;
        private LinearLayout mFaqLinLyt;

        public FAQTopQueryAlternateViewHolder(View view) {
            super(view);
            mFAQHelpTopic = (RobotoTextView) view.findViewById(R.id.faq_expandable_group_title_tv);
            mFAQIcon = (ImageView) view.findViewById(R.id.faq_expandable_group_expand_iv);
            mFaqLinLyt = (LinearLayout) view.findViewById(R.id.faq_expandable_group_parent_linLyt);
            mFaqChildText = (RobotoTextView) view.findViewById(R.id.faq_expandable_child_tv);
        }
    }

    private class FAQTopQueryAlternateViewHolderType implements RecyclerViewDataBinder<FAQTopQueryAlternateViewHolder,
            FAQTopQueryAlternateDataItem> {
        @Override
        public FAQTopQueryAlternateViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.faq_top_query_item, parent, false);
            return new FAQTopQueryAlternateViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(FAQTopQueryAlternateViewHolder viewHolder, final FAQTopQueryAlternateDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mFAQHelpTopic.setText(data.faqHelpTopic);
            viewHolder.mFaqChildText.setText(data.faqTopicAnswer);
            Context context = viewHolder.mFaqLinLyt.getContext();
            if (data.isExpanded) {
                viewHolder.mFAQIcon.setRotation(180);
                viewHolder.mFaqLinLyt.setBackgroundColor(ContextCompat.getColor(context, R.color.background_darker_grey));
                viewHolder.mFAQHelpTopic.setTextColor(ContextCompat.getColor(context, R.color.common_sub_title_header_text_color));
                viewHolder.mFaqChildText.setVisibility(View.VISIBLE);
            } else {
                viewHolder.mFAQIcon.setRotation(0);
                viewHolder.mFaqLinLyt.setBackgroundColor(ContextCompat.getColor(context, R.color.white_background));
                viewHolder.mFAQHelpTopic.setTextColor(ContextCompat.getColor(context, R.color.pharmacy_dash_board_text_color));
                viewHolder.mFaqChildText.setVisibility(View.GONE);
            }

            if (recyclerViewClickListener != null) {
                viewHolder.mFaqLinLyt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.FAQViewType.FAQ_TOP_QUERY_ALTERNATE_ITEM_VIEW_TYPE;
        }
    }
}

