/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.order.returnorder;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.CheckOutDeliverySlotAdapter;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 5/8/16.
 */

/**
 * This class represents the UI for Pick up slot for Return products screen
 */
public class ReturnPickUpSlotFragment extends ApiRequestBaseFragment implements IToolbar,
        BaseRecyclerAdapter.RecyclerItemClickListener {


    private CheckOutDeliverySlotAdapter mPickUpSlotAdapter;
    private List<BaseRecyclerAdapter.IViewType> mPickUpSlotInfoList = new ArrayList<>();
    private IReturnPickUpSlotNotifier iReturnPickUpSlotNotifier;

    private RobotoTextView mNoSlotsFound;

    public static ReturnPickUpSlotFragment create(List<BaseRecyclerAdapter.IViewType> deliverySlots) {
        ReturnPickUpSlotFragment fragment = new ReturnPickUpSlotFragment();
        fragment.setPickUpSlots(deliverySlots);
        return fragment;
    }

    private void setPickUpSlots(List<BaseRecyclerAdapter.IViewType> pickUpSlots) {
        mPickUpSlotInfoList.addAll(pickUpSlots);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPickUpSlotAdapter = new CheckOutDeliverySlotAdapter(mPickUpSlotInfoList);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            iReturnPickUpSlotNotifier = (IReturnPickUpSlotNotifier) context;
        } catch (ClassCastException exception) {
            throw new ClassCastException(context.toString()
                    + " must implement IReturnPickUpSlotNotifier");
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_checkout_delivery_slot, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initPickUpSlotRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);

        if (mPickUpSlotInfoList.size() > 0) {
            mNoSlotsFound.setVisibility(View.GONE);
            mPickUpSlotAdapter.notifyDataSetChanged();
        } else {
            mNoSlotsFound.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Method that initializes the views
     *
     * @param view the root view
     */
    private void initPickUpSlotRecyclerView(View view) {
        RecyclerView pickUpSlotRecyclerView = (RecyclerView) view.findViewById(R.id.checkout_delivery_slot_container);
        pickUpSlotRecyclerView.setHasFixedSize(false);
        pickUpSlotRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mPickUpSlotAdapter.setRecyclerItemClickListener(this);
        pickUpSlotRecyclerView.setAdapter(mPickUpSlotAdapter);
        mNoSlotsFound = (RobotoTextView) view.findViewById(R.id.checkout_delivery_slots_empty_view_tv);
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getResources().getString(R.string.return_products_pickup_slot);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;

        switch (((CheckOutDeliverySlotAdapter.IViewType) object).getViewType()) {

            case ViewTypes.CheckOutDeliverySlotViewType.CHECKOUT_DELIVERY_SLOT_TIME_TO_VIEW_TYPE:
                closeFragment();
                iReturnPickUpSlotNotifier.onPickUpSlotSelect((CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem) object);
                break;
            default:
                break;
        }
    }

    /**
     * Interface definition for a callback to be invoked when a delivery slot is selected
     */
    public interface IReturnPickUpSlotNotifier {
        /**
         * Called when Pick up slot selected
         *
         * @param pickUpSlot the pick up slot that was selected
         */
        void onPickUpSlotSelect(CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem pickUpSlot);
    }
}
