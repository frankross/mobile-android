/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.aloglia.datamodel;

import com.google.gson.JsonArray;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gauthami on 6/7/15.
 */
public class AlgoliaProductDataModel {

    @SerializedName("id")
    private long id = -1;

    @SerializedName("name")
    private String name = "";

    @SerializedName("brand_name")
    private String brandName = "";

    @SerializedName("manufacturer")
    private String manufacturer = "";

    @SerializedName("category_details")
    private CategoryDetails categoryDetails = new CategoryDetails();

    @SerializedName("cities_mapping")
    private JsonArray citiesMapping;

    @SerializedName("main_image_url")
    private String mainImageUrl = "";

    @SerializedName("icon_image_url")
    private String iconImageUrl = "";

    @SerializedName("generic_keywords1")
    private String genericKeyWord1 = "";

    @SerializedName("generic_keywords2")
    private String genericKeyWord2 = "";

    @SerializedName("generic_keywords3")
    private String genericKeyWord3 = "";

    @SerializedName("generic_keywords4")
    private String genericKeyWord4 = "";

    @SerializedName("inner_package_quantity")
    private String innerPackagingQty = "";

    @SerializedName("unit_of_sale")
    private String unitOfSale = "";

    private AlgoliaProductInfo algoliaProductInfo = new AlgoliaProductInfo();

    private int numberOfProducts;

    public JsonArray getCitiesMapping() {
        return citiesMapping;
    }

    public String getName() {
        return name;
    }

    public void setAlgoliaProductInfo(AlgoliaProductInfo algoliaProductInfo) {
        this.algoliaProductInfo = algoliaProductInfo;
    }

    public AlgoliaProductInfo getAlgoliaProductInfo() {
        return algoliaProductInfo;
    }

    public String getMainImageUrl() {
        return mainImageUrl;
    }

    public void setMainImageUrl(String mainImageUrl) {
        this.mainImageUrl = mainImageUrl;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getBrandName() {
        return brandName;
    }

    public CategoryDetails getCategoryDetails() {
        return categoryDetails;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public String getGenericKeyWord1() {
        return genericKeyWord1;
    }

    public void setGenericKeyWord1(String genericKeyWord1) {
        this.genericKeyWord1 = genericKeyWord1;
    }

    public String getGenericKeyWord2() {
        return genericKeyWord2;
    }

    public void setGenericKeyWord2(String genericKeyWord2) {
        this.genericKeyWord2 = genericKeyWord2;
    }

    public String getGenericKeyWord3() {
        return genericKeyWord3;
    }

    public void setGenericKeyWord3(String genericKeyWord3) {
        this.genericKeyWord3 = genericKeyWord3;
    }

    public String getGenericKeyWord4() {
        return genericKeyWord4;
    }

    public void setGenericKeyWord4(String genericKeyWord4) {
        this.genericKeyWord4 = genericKeyWord4;
    }

    public String getIconImageUrl() {
        return iconImageUrl;
    }

    public void setIconImageUrl(String iconImageUrl) {
        this.iconImageUrl = iconImageUrl;
    }

    public String getUnitOfSale() {
        return unitOfSale;
    }

    public void setUnitOfSale(String unitOfSale) {
        this.unitOfSale = unitOfSale;
    }

    public String getInnerPackagingQty() {
        return innerPackagingQty;
    }

    public void setInnerPackagingQty(String innerPackagingQty) {
        this.innerPackagingQty = innerPackagingQty;
    }

    public int getNumberOfProducts() {
        return numberOfProducts;
    }

    public void setNumberOfProducts(int numberOfProducts) {
        this.numberOfProducts = numberOfProducts;
    }

    public static class CategoryDetails {

        @SerializedName("pharma")
        private boolean isPharma;

        @SerializedName("base_category")
        private Category baseCategory;

        @SerializedName("primary_category")
        private Category primaryCategory;

        @SerializedName("secondary_category")
        private Category secondaryCategory;

        public boolean isPharma() {
            return isPharma;
        }

        public Category getBaseCategory() {
            return baseCategory;
        }

        public Category getPrimaryCategory() {
            return primaryCategory;
        }

        public Category getSecondaryCategory() {
            return secondaryCategory;
        }
    }

    public static class Category {

        @SerializedName("id")
        private long id = -1;

        @SerializedName("name")
        private String name = "";

        public long getId() {
            return id;
        }

        public String getName() {
            return name;
        }
    }
}
