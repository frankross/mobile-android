/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.utils;

import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.text.format.DateUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class FrankRossDateUtils {

    private static final String TAG = FrankRossDateUtils.class.getSimpleName();

    private static final String NOTIFICATIONS_SENT_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSSzzz";

    private static final String DEFAULT_IN_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ssZZZ";
    private static final String DEFAULT_OUT_DATE_FORMAT = "dd MMM yyyy";

    private static final String ORDER_IN_DATE_FORMAT = "yyyy-MM-dd";
    private static final String ORDER_OUT_DATE_FORMAT = "dd MMM yyyy";

    private static final String DELIVERY_SLOT_IN_DATE_FORMAT = "yyyy-MM-dd";
    private static final String DELIVERY_SLOT_OUT_DATE_FORMAT = "dd MMM yyyy";

    private static final String DELIVERY_SLOT_LISTING_IN_DATE_FORMAT = "yyyy-MM-dd";
    private static final String DELIVERY_SLOT_LISTING_OUT_DATE_FORMAT = "EEEE";

    /**
     * Constants to calculate the Notification screen formatted date
     */
    private static final int SECOND = 1000;
    private static final int MINUTE = 60 * SECOND;
    private static final int HOUR = 60 * MINUTE;
    private static final int DAY = 24 * HOUR;
    private static final long WEEK = 7 * DAY;
    private static final long MONTH = 4 * WEEK;
    private static final long YEAR = 12 * MONTH;

    /**
     * Method that formats the Date using the Timestamp date passes as input
     *
     * @param date the date along with the timestamp
     * @return the date in the format of Today,Tomorrow or dd MMM yyyy
     */
    public static String getFormattedDate(@NonNull String date) {
        try {
            if (!TextUtils.isEmpty(date)) {
                SimpleDateFormat inFormat = new SimpleDateFormat(DEFAULT_IN_DATE_FORMAT, Locale.ENGLISH);
                Date inputDate = inFormat.parse(date);

                SimpleDateFormat outFormat = new SimpleDateFormat(DEFAULT_OUT_DATE_FORMAT, Locale.ENGLISH);

                if (isToday(inputDate.getTime())) {
                    return "Today";
                } else if (isTomorrow(inputDate.getTime())) {
                    return "Tomorrow";
                } else {
                    return outFormat.format(inputDate);
                }
            }

        } catch (ParseException e) {
            Log.d(TAG, "Date Parsing Failed while parsing \"txndate\"");
        }

        return "";
    }

    /**
     * Method that formats the Date to dd MMM yyyy format using yyyy-MM-dd format of date as input
     *
     * @param date the date in yyyy-MM-dd format
     * @return the date in the format dd MMM yyyy
     */
    public static String getOrderFormattedDate(@NonNull String date) {
        try {
            if (!TextUtils.isEmpty(date)) {
                SimpleDateFormat inFormat = new SimpleDateFormat(ORDER_IN_DATE_FORMAT, Locale.ENGLISH);
                Date inputDate = inFormat.parse(date);

                SimpleDateFormat outFormat = new SimpleDateFormat(ORDER_OUT_DATE_FORMAT, Locale.ENGLISH);

                return outFormat.format(inputDate);
            }

        } catch (ParseException e) {
            Log.d(TAG, "Date Parsing Failed while parsing \"txndate\"");
        }

        return "";
    }

    /**
     * Method that formats the Date to dd MMM yyyy format using yyyy-MM-dd format of date as input
     *
     * @param date the date in yyyy-MM-dd format
     * @return the date in the format dd MMM yyyy
     */
    public static String getDeliverySlotFormattedDate(@NonNull String date) {
        try {
            if (!TextUtils.isEmpty(date)) {
                SimpleDateFormat inFormat = new SimpleDateFormat(DELIVERY_SLOT_IN_DATE_FORMAT, Locale.ENGLISH);
                Date inputDate = inFormat.parse(date);

                SimpleDateFormat outFormat = new SimpleDateFormat(DELIVERY_SLOT_OUT_DATE_FORMAT, Locale.ENGLISH);

                return outFormat.format(inputDate);
            }

        } catch (ParseException e) {
            Log.d(TAG, "Date Parsing Failed while parsing \"txndate\"");
        }

        return "";
    }

    /**
     * Method that checks if the input date is Today's date
     *
     * @param date the input date
     * @return the flag that identifies if the input date matches the today's date
     */
    private static boolean isToday(long date) {
        return DateUtils.isToday(date);
    }

    /**
     * Method that checks if the date matches to Tomorrow's date
     *
     * @param dateTimeStamp the date in String format
     * @return the flag that denotes if the date matches to Tomorrow's date
     */
    private static boolean isTomorrow(long dateTimeStamp) {
        Calendar c1 = Calendar.getInstance(); // today
        c1.add(Calendar.DAY_OF_YEAR, +1); // Tomorrow

        Calendar c2 = Calendar.getInstance();
        c2.setTime(new Date(dateTimeStamp)); // your date

        return c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR)
                && c1.get(Calendar.DAY_OF_YEAR) == c2.get(Calendar.DAY_OF_YEAR);

    }

    /**
     * Method that calculates the days difference between two date objects
     *
     * @param d1 the recent date
     * @param d2 the older date
     * @return the difference between two date object
     */
    public static int daysBetween(Date d1, Date d2) {
        return (int) ((d2.getTime() - d1.getTime()) / (1000 * 60 * 60 * 24));
    }

    /**
     * Method that calculates the day of the week
     *
     * @param dateStr the date in String format
     * @return the day of the week
     */
    public static String getDayOfWeek(String dateStr) {
        SimpleDateFormat inFormat = new SimpleDateFormat(DELIVERY_SLOT_LISTING_IN_DATE_FORMAT, Locale.ENGLISH);
        Date date = null;
        try {
            date = inFormat.parse(dateStr);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        SimpleDateFormat outFormat = new SimpleDateFormat(DELIVERY_SLOT_LISTING_OUT_DATE_FORMAT, Locale.ENGLISH);
        return outFormat.format(date);
    }

    /**
     * Method that calculates the number of weeks using the days difference
     *
     * @param daysDifference the number of days
     * @return the number of weeks
     */
    public static String getNumberOfWeeks(int daysDifference) {
        int counter = 0;
        while (true) {
            if (daysDifference > 0) {
                counter++;
                daysDifference -= 7;
            } else {
                return counter + "";
            }
        }
    }

    /**
     * Method that calculates the number of months using the days difference
     *
     * @param daysDifference the number of days
     * @return the number of months
     */
    public static String getNumberOfMonths(int daysDifference) {
        int counter = 0;
        while (true) {
            if (daysDifference > 29) {
                counter++;
                daysDifference -= 30;
            } else {
                return counter + "";
            }
        }
    }

    /**
     * Method that calculates the difference of minutes/hours/days/weeks/months/years
     * between current date and notification create date
     *
     * @param createdOn the notification creation date
     * @return the calculated date difference in terms of minutes/hours/days/weeks/months/years
     */
    public static String getNotificationsFormattedDate(String createdOn) {
        //HH converts hour in 24 hours format (0-23), day calculation
        SimpleDateFormat format = new SimpleDateFormat(NOTIFICATIONS_SENT_DATE_FORMAT, Locale.ENGLISH);
        Date dateNow = new Date();
        Date dateCreated;
        try {
            dateCreated = format.parse(createdOn);
            //in milliseconds
            long diff = dateNow.getTime() - dateCreated.getTime();
            if (diff < MINUTE) {
                return "Just now";
            } else if (diff < 2 * MINUTE) {
                return "1 minute ago";
            } else if (diff < 50 * MINUTE) {
                return diff / MINUTE + " minutes";
            } else if (diff < 90 * MINUTE) {
                return "1 hour";
            } else if (diff < 24 * HOUR) {
                long time = (diff / HOUR);
                String timeStatus;
                if (time == 1) {
                    timeStatus = time + " hour";
                } else {
                    timeStatus = time + " hours";
                }
                return timeStatus;
            } else if (diff < 7 * DAY) {
                long time = (diff / DAY);
                String timeStatus;
                if (time == 1) {
                    timeStatus = time + " day";
                } else {
                    timeStatus = time + " days";
                }
                return timeStatus;
            } else if (diff < 4 * WEEK) {
                long time = (diff / WEEK);
                String timeStatus;
                if (time == 1) {
                    timeStatus = time + " week";
                } else {
                    timeStatus = time + " weeks";
                }
                return timeStatus;
            } else if (diff < 12 * MONTH) {
                long time = (diff / MONTH);
                String timeStatus;
                if (time == 1) {
                    timeStatus = time + " month";
                } else {
                    timeStatus = time + " months";
                }
                return timeStatus;
            } else {
                long time = (diff / YEAR);
                String timeStatus;
                if (time == 1) {
                    timeStatus = time + " year";
                } else {
                    timeStatus = time + " years";
                }
                return timeStatus;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "";
    }
}
