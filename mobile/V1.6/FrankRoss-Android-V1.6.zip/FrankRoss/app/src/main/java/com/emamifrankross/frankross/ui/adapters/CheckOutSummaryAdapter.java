/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.text.SpannableStringBuilder;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.PaymentMethods;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryProductInfoHeaderViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryProductInfoViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryShippingChargesViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryTotalAmountViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderDataBinder;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 22/7/15.
 * <p> Adapter class for OrderDetails History Details Section</p>
 * <p>Supports the Seven View Types </p>
 * <p> 1 : PRODUCT DETAIL HEADER ITEM VIEW TYPE</p>
 * <p> 2 : PRODUCT DETAIL ITEM VIEW TYPE </p>
 * <p> 3 : TOTAL AMOUNT VIEW TYPE </p>
 * <p> 4 : SHIPPING CHARGES VIEW TYPE </p>
 * <p> 5 : PAY USING VIEW TYPE </p>
 * <p> 6 : SUMMARY TEXT VIEW TYPE </p>
 * <p> 7 : BORDER VIEW TYPE </p>
 * <p> 8 : REWARD POINTS VIEW TYPE</p>
 */
public class CheckOutSummaryAdapter extends BaseRecyclerAdapter {

    public CheckOutSummaryAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<BaseRecyclerAdapter.RecyclerViewDataBinder> getViewDataBinders() {
        ArrayList<RecyclerViewDataBinder> viewHolderTypes = new ArrayList<>(1);
        viewHolderTypes.add(new OrderHistoryProductInfoHeaderViewDataBinder());
        viewHolderTypes.add(new OrderHistoryProductInfoViewDataBinder());
        viewHolderTypes.add(new OrderHistoryShippingChargesViewDataBinder());
        viewHolderTypes.add(new OrderHistoryTotalAmountViewDataBinder());
        viewHolderTypes.add(new CheckOutPayUsingViewHolderType());
        viewHolderTypes.add(new CheckOutSummaryTextViewHolderType());
        viewHolderTypes.add(new RecyclerBorderDataBinder());
        viewHolderTypes.add(new CheckOutRewardPointsViewHolderType());
        viewHolderTypes.add(new CheckOutRadioButtonViewHolderType());
        return viewHolderTypes;
    }

    /**
     * PAY USING HEADER VIEW TYPE
     */

    public static class CheckOutPayUsingItem implements IViewType {

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutSummaryViewType.CHECKOUT_SUMMARY_PAY_USING_HEADER_VIEW_TYPE;
        }
    }

    public static class CheckOutPayUsingViewHolder extends RecyclerView.ViewHolder {

        public CheckOutPayUsingViewHolder(View view) {
            super(view);
        }
    }

    private class CheckOutPayUsingViewHolderType implements RecyclerViewDataBinder<CheckOutPayUsingViewHolder,
            CheckOutPayUsingItem> {
        @Override
        public CheckOutPayUsingViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_checkout_pay_using, parent, false);
            return new CheckOutPayUsingViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final CheckOutPayUsingViewHolder viewHolder, final CheckOutPayUsingItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
        }

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutSummaryViewType.CHECKOUT_SUMMARY_PAY_USING_HEADER_VIEW_TYPE;
        }
    }

    /**
     * PAY USING RADIO BUTTON VIEW TYPE
     */
    public static class CheckOutSummaryRadioButtonDataItem implements IViewType {

        public PaymentMethods paymentMethod;
        public List<PaymentMethods> paymentMethods;
        public String paymentType;
        public boolean isSelected = false;

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutSummaryViewType.CHECKOUT_SUMMARY_PAY_USING_RADIO_BUTTON_VIEW_TYPE;
        }
    }

    public static class CheckOutSummaryRadioButtonViewHolder extends RecyclerView.ViewHolder {

        private final ImageView mRadioPaytm;
        private ImageView mRadioButton;
        private RobotoTextView mRadioText;
        private LinearLayout mRadioButtonLinLyt;

        public CheckOutSummaryRadioButtonViewHolder(View view) {
            super(view);
            mRadioButton = (ImageView) view.findViewById(R.id.cart_checkout_pay_using_radio_button_tv);
            mRadioPaytm = (ImageView) view.findViewById(R.id.cart_checkout_paytm_icon_iv);
            mRadioButtonLinLyt = (LinearLayout) view.findViewById(R.id.checkout_pay_using_radio_button_linLyt);
            mRadioText = (RobotoTextView) view.findViewById(R.id.cart_checkout_summary_pay_using_tv);
        }
    }

    private class CheckOutRadioButtonViewHolderType implements RecyclerViewDataBinder<CheckOutSummaryRadioButtonViewHolder,
            CheckOutSummaryRadioButtonDataItem> {
        @Override
        public CheckOutSummaryRadioButtonViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.checkout_summary_radio_item, parent, false);
            return new CheckOutSummaryRadioButtonViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(CheckOutSummaryRadioButtonViewHolder viewHolder, final CheckOutSummaryRadioButtonDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mRadioPaytm.setVisibility(data.paymentMethod.getId().equalsIgnoreCase("wallet") ? View.VISIBLE : View.GONE);
            viewHolder.mRadioText.setText(data.paymentMethod.getName());
            viewHolder.mRadioButton.setImageResource(data.isSelected ? R.mipmap.radiobutton : R.mipmap.radiobutton_unselect);

            if (recyclerViewClickListener != null) {
                viewHolder.mRadioButtonLinLyt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutSummaryViewType.CHECKOUT_SUMMARY_PAY_USING_RADIO_BUTTON_VIEW_TYPE;
        }
    }

    /**
     * PAY USING DESCRIPTION VIEW TYPE
     */

    public static class CheckOutSummaryTextItem implements IViewType {

        public String checkOutTxt;

        public CheckOutSummaryTextItem(String checkOutTxt) {
            this.checkOutTxt = checkOutTxt;
        }

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutSummaryViewType.CHECKOUT_SUMMARY_PAY_TEXT_USING_VIEW_TYPE;
        }
    }

    public static class CheckOutSummaryTextViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mCheckOutTxt;

        public CheckOutSummaryTextViewHolder(View view) {
            super(view);

            mCheckOutTxt = (RobotoTextView) view.findViewById(R.id.checkout_pay_using_description_tv);
        }
    }

    private class CheckOutSummaryTextViewHolderType implements RecyclerViewDataBinder<CheckOutSummaryTextViewHolder,
            CheckOutSummaryTextItem> {
        @Override
        public CheckOutSummaryTextViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.checkout_pay_using_txt, parent, false);
            return new CheckOutSummaryTextViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(CheckOutSummaryTextViewHolder viewHolder, final CheckOutSummaryTextItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mCheckOutTxt.setText(data.checkOutTxt);
        }

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutSummaryViewType.CHECKOUT_SUMMARY_PAY_TEXT_USING_VIEW_TYPE;
        }
    }

    /**
     * PAY USING REWARD POINTS VIEW TYPE
     */

    public static class CheckOutRewardPointsItem implements IViewType {

        public double checkBoxText = 0.0d;
        public boolean checkBoxState = false;

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutSummaryViewType.CHECKOUT_REWARD_POINTS_VIEW_TYPE;
        }
    }

    public static class CheckOutRewardPointsViewHolder extends RecyclerView.ViewHolder {

        private ImageView mCheckOutRewardPointsCheckBox;
        private RobotoTextView mCheckOutRewardPointsText;
        private LinearLayout mRewardPointsLinLyt;

        public CheckOutRewardPointsViewHolder(View view) {
            super(view);

            mCheckOutRewardPointsCheckBox = (ImageView) view.findViewById(R.id.checkout_pay_reward_points_checkbox_cb);
            mCheckOutRewardPointsText = (RobotoTextView) view.findViewById(R.id.check_out_summary_pay_reward_point_tv);
            mRewardPointsLinLyt = (LinearLayout) view.findViewById(R.id.check_out_reward_points_linLyt);
        }
    }

    private class CheckOutRewardPointsViewHolderType implements RecyclerViewDataBinder<CheckOutRewardPointsViewHolder,
            CheckOutRewardPointsItem> {
        @Override
        public CheckOutRewardPointsViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.checkout_pay_using_reward_points, parent, false);
            return new CheckOutRewardPointsViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final CheckOutRewardPointsViewHolder viewHolder, final CheckOutRewardPointsItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            SpannableStringBuilder checkBoxRewardsValue = Utils.addRupeeSymbol(viewHolder.mCheckOutRewardPointsCheckBox.getContext()
                    , "", Utils.getFormattedDouble(data.checkBoxText));
            viewHolder.mCheckOutRewardPointsText.setText(checkBoxRewardsValue);
            viewHolder.mCheckOutRewardPointsCheckBox.setImageResource(data.checkBoxState ?
                    R.mipmap.checkbox_selected : R.mipmap.checkbox);


            viewHolder.mRewardPointsLinLyt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    data.checkBoxState = !data.checkBoxState;
                    recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                }
            });
        }

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutSummaryViewType.CHECKOUT_REWARD_POINTS_VIEW_TYPE;
        }
    }
}
