/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.products.pharmaproductdetail;

import com.emamifrankross.frankross.core.apimodels.ApiPharmaProduct;
import com.emamifrankross.frankross.ui.common.BaseFragment;

/**
 * Created by gowtham on 2/8/15.
 */

/**
 * This class represents the UI for More info screen for a Pharma product
 */
public class PharmacyMoreInfoFragment extends BaseFragment {

    private ApiPharmaProduct.MoreInfo mMoreInfo;

    public static PharmacyMoreInfoFragment create(ApiPharmaProduct.MoreInfo moreInfo) {
        PharmacyMoreInfoFragment pharmacyMoreInfoFragment = new PharmacyMoreInfoFragment();
        pharmacyMoreInfoFragment.setMoreInfo(moreInfo);

        return pharmacyMoreInfoFragment;
    }

    public void setMoreInfo(ApiPharmaProduct.MoreInfo moreInfo) {
        mMoreInfo = moreInfo;
    }
}
