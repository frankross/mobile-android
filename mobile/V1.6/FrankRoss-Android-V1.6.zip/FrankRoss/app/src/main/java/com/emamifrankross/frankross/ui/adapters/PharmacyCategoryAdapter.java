/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiCategories;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.AutoScrollViewPager;
import com.emamifrankross.frankross.ui.customviews.CirclePageIndicator;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.home.LooperService;
import com.emamifrankross.frankross.ui.viewmodels.CommonRecyclerHeaderViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.HorizontalRecyclerViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.ProductViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderDataBinder;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 6/11/15.
 */
public class PharmacyCategoryAdapter extends BaseRecyclerAdapter {

    private TopOffersAutoScrollViewDataBinder topOffersAutoScrollViewDataBinder;
    private static IAutoScroll sAutoScroll = null;

    public PharmacyCategoryAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
        sAutoScroll = null;
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewDataBinderList = new ArrayList<>();
        //viewDataBinderList.add(new TopOffersViewDataBinder());
        topOffersAutoScrollViewDataBinder = new TopOffersAutoScrollViewDataBinder();
        viewDataBinderList.add(topOffersAutoScrollViewDataBinder);
        viewDataBinderList.add(new ExpandableGroupViewDataBinder());
        viewDataBinderList.add(new CommonRecyclerHeaderViewDataBinder());
        viewDataBinderList.add(new ProductViewDataBinder());
        viewDataBinderList.add(new RecyclerBorderDataBinder());
        viewDataBinderList.add(new ShowAllCategoryViewDataBinder());
        viewDataBinderList.add(new ViewMoreProductViewDataBinder());
        viewDataBinderList.add(new PharmacyHorizontalScrollerViewHolderType());
        viewDataBinderList.add(new HomeRecyclerAdapter.FeaturedProductsViewHolderType());
        viewDataBinderList.add(new HorizontalRecyclerViewDataBinder());

        return viewDataBinderList;
    }

    public void onScrollNext() {
        if (sAutoScroll != null)
            sAutoScroll.scrollNext();
    }

    public void setLooperBinder(LooperService.LooperBinder looperBinder) {
        topOffersAutoScrollViewDataBinder.setLooperBinder(looperBinder);
    }

    /**
     * TOP OFFERS AUTO SCROLL VIEW TYPE
     */
    public static class TopOffersAutoScrollDataItem implements IViewType {
        public List<ApiCategories.Promotion> mBanner;
        public boolean isCached = false;

        @Override
        public int getViewType() {
            return ViewTypes.PharmacyCategoryViewType.PHARMACY_AUTO_SCROLL_BANNER;
        }
    }

    public static class TopOffersAutoScrollViewHolder extends RecyclerView.ViewHolder {
        public AutoScrollViewPager mTopOffersViewPager;
        public CirclePageIndicator mTopOffersPagerIndicator;

        public TopOffersAutoScrollViewHolder(View itemView) {
            super(itemView);
            mTopOffersViewPager = (AutoScrollViewPager) itemView.findViewById(R.id.home_top_offers_pager);
            mTopOffersPagerIndicator = (CirclePageIndicator) itemView.findViewById(R.id.top_offers_pager_indicator);

            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (int) (0.23 * Utils.getDisplayHeight((Activity) mTopOffersViewPager.getContext())));
            mTopOffersViewPager.setLayoutParams(layoutParams);
            mTopOffersViewPager.setAutoScrollRequired(true);
            mTopOffersPagerIndicator.getBackground().setAlpha((int) (0.7F * 255));
        }
    }

    public static class TopOffersAutoScrollViewDataBinder implements
            RecyclerViewDataBinder<TopOffersAutoScrollViewHolder, TopOffersAutoScrollDataItem> {

        private IAutoScroll mAutoScroll = null;
        private LooperService.LooperBinder mLooperBinder = null;

        @Override
        public TopOffersAutoScrollViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pharmacy_auto_scroll_view_pager, parent, false);

            return new TopOffersAutoScrollViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final TopOffersAutoScrollViewHolder viewHolder,
                                         final TopOffersAutoScrollDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            HomeBannerAdapter homeBannerAdapter = new HomeBannerAdapter(viewHolder.mTopOffersViewPager.getContext(),
                    true, data);
            homeBannerAdapter.setOnRecyclerItemClickListener(recyclerViewClickListener);
            viewHolder.mTopOffersViewPager.setAdapter(homeBannerAdapter);
            viewHolder.mTopOffersViewPager.setAdapterSize(homeBannerAdapter.getCount());
            viewHolder.mTopOffersViewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
                @Override
                public void onPageSelected(int position) {
                    super.onPageSelected(position);
                    if (mLooperBinder != null)
                        mLooperBinder.onPageChanged();
                }
            });
            mAutoScroll = viewHolder.mTopOffersViewPager.getAutoScrollNotifier();
            sAutoScroll = mAutoScroll;
            viewHolder.mTopOffersPagerIndicator.setViewPager(viewHolder.mTopOffersViewPager);
        }

        @Override
        public int getViewType() {
            return ViewTypes.PharmacyCategoryViewType.PHARMACY_AUTO_SCROLL_BANNER;
        }

        public void setLooperBinder(LooperService.LooperBinder looperBinder) {
            mLooperBinder = looperBinder;
        }
    }

    /**
     * EXPANDABLE ITEM VIEW
     */
    public static class ExpandableGroupItem implements IViewType {

        public ApiCategories.SubCategory category = new ApiCategories.SubCategory();
        public boolean isExpanded = false;

        @Override
        public int getViewType() {
            return ViewTypes.PharmacyCategoryViewType.PHARMACY_EXPANDABLE_GROUP;
        }
    }

    private static class ExpandableGroupViewHolder extends RecyclerView.ViewHolder {
        private TextView mTitle;
        private ImageView mImageView;
        private LinearLayout mChildLinearLayout;
        private LinearLayout mParentLinearLayout;

        public ExpandableGroupViewHolder(View itemView) {
            super(itemView);
            mTitle = (TextView) itemView.findViewById(R.id.pharmacy_expandable_group_title_tv);
            mImageView = (ImageView) itemView.findViewById(R.id.pharmacy_expandable_group_expand_iv);
            mChildLinearLayout = (LinearLayout) itemView.findViewById(R.id.pharmacy_expandable_child_layout);
            mParentLinearLayout = (LinearLayout) itemView.findViewById(R.id.pharmacy_expanadable_group_layout);
        }
    }

    private static class ExpandableGroupViewDataBinder implements RecyclerViewDataBinder<ExpandableGroupViewHolder, ExpandableGroupItem> {

        @Override
        public ExpandableGroupViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pharmacy_expandable_group_item, parent, false);

            return new ExpandableGroupViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final ExpandableGroupViewHolder viewHolder, final ExpandableGroupItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mTitle.setText(Utils.getCapitalizedWords(data.category.getName()));
            viewHolder.mChildLinearLayout.removeAllViews();
            LayoutInflater inflater = LayoutInflater.from(viewHolder.mChildLinearLayout.getContext());
            addChildViews(inflater, viewHolder.mChildLinearLayout, data.category.getGrandChildren(),
                    recyclerViewClickListener, position);

            if (data.isExpanded) {
                viewHolder.mImageView.setRotation(180);
                viewHolder.mTitle.setTextColor(Color.BLACK);
                viewHolder.mChildLinearLayout.setVisibility(View.VISIBLE);
            } else {
                viewHolder.mImageView.setRotation(0);
                Context context = viewHolder.mTitle.getContext();
                viewHolder.mTitle.setTextColor(ContextCompat.getColor(context, R.color.pharmacy_dash_board_text_color));
                viewHolder.mChildLinearLayout.setVisibility(View.GONE);
            }

            if (recyclerViewClickListener != null) {
                viewHolder.mParentLinearLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (data.category.getGrandChildren().size() > 0) {
                            if (!data.isExpanded) {
                                data.isExpanded = true;
                                viewHolder.mChildLinearLayout.setVisibility(View.VISIBLE);
                            } else {
                                data.isExpanded = false;
                                viewHolder.mChildLinearLayout.setVisibility(View.GONE);
                            }
                        }
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        private void addChildViews(LayoutInflater inflater, LinearLayout childLinearLayout,
                                   final List<ApiCategories.Children> grandChildren,
                                   final RecyclerItemClickListener recyclerViewClickListener, final int position) {
            for (final ApiCategories.Children children : grandChildren) {
                View view = inflater.inflate(R.layout.pharmacy_expandable_child_item, childLinearLayout, false);
                TextView textView = (TextView) view.findViewById(R.id.pharmacy_expandable_child_tv);
                String subCategoryName = children.getName();
                textView.setText(TextUtils.isEmpty(subCategoryName) ? "" : Utils.getCapitalizedSentence(subCategoryName));

                if (recyclerViewClickListener != null) {
                    textView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            recyclerViewClickListener.onRecyclerItemClick(position, v, children);
                        }
                    });
                }
                childLinearLayout.addView(view);
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.PharmacyCategoryViewType.PHARMACY_EXPANDABLE_GROUP;
        }
    }

    /**
     * SHOW ALL CATEGORY VIEW TYPE
     */
    public static class ShowAllCategoryViewItem implements IViewType {
        public boolean isAllCategoryShown = false;

        @Override
        public int getViewType() {
            return ViewTypes.PharmacyCategoryViewType.PHARMACY_CATEGORY_SHOW_ALL;
        }
    }

    private static class ShowAllCategoryViewHolder extends RecyclerView.ViewHolder {
        public TextView mShowCategoryView;

        public ShowAllCategoryViewHolder(View itemView) {
            super(itemView);
            mShowCategoryView = (TextView) itemView.findViewById(R.id.top_selling_list_load_more_tv);
            itemView.findViewById(R.id.view_more_progressBar).setVisibility(View.GONE);
        }
    }

    private static class ShowAllCategoryViewDataBinder implements RecyclerViewDataBinder<ShowAllCategoryViewHolder, ShowAllCategoryViewItem> {

        @Override
        public ShowAllCategoryViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.top_selling_product_list_load_more, parent, false);

            return new ShowAllCategoryViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final ShowAllCategoryViewHolder viewHolder, final ShowAllCategoryViewItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            if (data.isAllCategoryShown) {
                viewHolder.mShowCategoryView.setText("Show less");
            } else {
                viewHolder.mShowCategoryView.setText("Show more");
            }

            if (recyclerViewClickListener != null) {
                viewHolder.mShowCategoryView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (data.isAllCategoryShown) {
                            data.isAllCategoryShown = false;
                            viewHolder.mShowCategoryView.setText("Show more");
                        } else {
                            data.isAllCategoryShown = true;
                            viewHolder.mShowCategoryView.setText("Show less");
                        }
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.PharmacyCategoryViewType.PHARMACY_CATEGORY_SHOW_ALL;

        }
    }

    /**
     * VIEW MORE VIEW TYPE
     */

    public static class ViewMoreDataItem implements IViewType {
        public boolean showProgressBar = false;
        public String viewMore = "View more";

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.VIEW_MORE_PRODUCTS;
        }
    }

    public static class ViewMoreViewHolder extends RecyclerView.ViewHolder {

        public ProgressBar mViewMoreProgressBar;
        public RobotoTextView mViewMore;

        public ViewMoreViewHolder(View itemView) {
            super(itemView);
            mViewMoreProgressBar = (ProgressBar) itemView.findViewById(R.id.view_more_progressBar);
            mViewMore = (RobotoTextView) itemView.findViewById(R.id.top_selling_list_load_more_tv);
        }
    }

    public static class ViewMoreProductViewDataBinder implements
            RecyclerViewDataBinder<ViewMoreViewHolder, ViewMoreDataItem> {

        @Override
        public ViewMoreViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.top_selling_product_list_load_more, parent, false);
            return new ViewMoreViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(ViewMoreViewHolder viewHolder, final ViewMoreDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            //viewHolder.mViewMoreProgressBar.setVisibility((data.showProgressBar) ? View.VISIBLE : View.GONE);
            viewHolder.mViewMoreProgressBar.setVisibility(View.GONE);
            viewHolder.mViewMore.setText(data.viewMore);

            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                        data.showProgressBar = true;
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.VIEW_MORE_PRODUCTS;
        }
    }

    /**
     * PHARMACY HORIZONTAL RECYCLER VIEW TYPE
     */
    public static class PharmacyHorizontalScrollerDataItem implements IViewType {

        public List<ApiCategories.PopularBrands> popularBrands;

        @Override
        public int getViewType() {
            return ViewTypes.PharmacyCategoryViewType.PHARMACY_HORIZONTAL_SCROLL_VIEW_TYPE;
        }
    }

    private static class PharmacyHorizontalScrollerViewHolder extends RecyclerView.ViewHolder {
        public RecyclerView mHorizontalRecyclerView;

        public PharmacyHorizontalScrollerViewHolder(View itemView, Context context) {
            super(itemView);

            mHorizontalRecyclerView = (RecyclerView) itemView.findViewById(R.id.pharmacy_brands_horizontal_scroll_view);
            mHorizontalRecyclerView.setHasFixedSize(false);
            LinearLayoutManager layoutManager
                    = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
            mHorizontalRecyclerView.setLayoutManager(layoutManager);
        }
    }

    private static class PharmacyHorizontalScrollerViewHolderType implements
            RecyclerViewDataBinder<PharmacyHorizontalScrollerViewHolder, PharmacyHorizontalScrollerDataItem> {

        @Override
        public PharmacyHorizontalScrollerViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.pharmacy_brands_horizontal_scroll_view, parent, false);

            return new PharmacyHorizontalScrollerViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(PharmacyHorizontalScrollerViewHolder viewHolder,
                                         final PharmacyHorizontalScrollerDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            List<BaseRecyclerAdapter.IViewType> brandsDataItemList = new ArrayList<>();
            PharmacyTopBrandsAdapter topBrandsAdapter = new PharmacyTopBrandsAdapter(brandsDataItemList);
            topBrandsAdapter.setRecyclerItemClickListener(recyclerViewClickListener);
            viewHolder.mHorizontalRecyclerView.setAdapter(topBrandsAdapter);

            for (ApiCategories.PopularBrands topBrand : data.popularBrands) {
                PharmacyTopBrandsAdapter.PharmacyTopBrandsDataItem topBrandItem =
                        new PharmacyTopBrandsAdapter.PharmacyTopBrandsDataItem();
                topBrandItem.topBrandUrl = topBrand.getBrandImageUrl();
                topBrandItem.topBrandName = topBrand.getBrandName();
                brandsDataItemList.add(topBrandItem);
            }
            topBrandsAdapter.notifyDataSetChanged();
        }

        @Override
        public int getViewType() {
            return ViewTypes.PharmacyCategoryViewType.PHARMACY_HORIZONTAL_SCROLL_VIEW_TYPE;
        }
    }
}
