/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RangeSeekBar;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 13/7/15.
 * <p> Adapter class for Product filter Section</p>
 * <p> Supports the Five View Types </p>
 * <p> 1 : FILTER ITEM VIEW TYPE </p>
 * <p> 2 : FILTER ACTION BUTTON VIEW TYPE </p>
 * <p> 3 : FILTER DOUBLE SEEK BAR PRICE VIEW TYPE </p>
 * <p> 4 : FILTER DOUBLE SEEK BAR DISCOUNT VIEW TYPE </p>
 * <p> 5 : FILTER IDEAL FOR VIEW TYPE </p>
 */
public class ProductFilterAdapter extends BaseRecyclerAdapter {

    public ProductFilterAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewDataBinderList = new ArrayList<>(1);
        viewDataBinderList.add(new SortHeaderViewDataBinder());
        viewDataBinderList.add(new FilterActionBtnViewDataBinder());
        viewDataBinderList.add(new FilterDoubleSeekBarPriceViewDataBinder());
        viewDataBinderList.add(new FilterDoubleSeekBarDiscountViewDataBinder());
        viewDataBinderList.add(new FilterIdealForViewDataBinder());
        return viewDataBinderList;
    }

    /**
     * FILTER ITEM VIEW TYPE
     */
    public static class FilterHeaderDataItem implements IViewType {

        public String filterHeader;
        public int selectedCount;

        @Override
        public int getViewType() {
            return ViewTypes.FilterViewType.FILTER_LIST_ITEM;
        }
    }

    private static class FilterHeaderViewHolder extends RecyclerView.ViewHolder {

        private ImageView mFilterIndicator;
        private RobotoTextView mSelectedCountTextView;
        private RobotoTextView mFilterHeaderText;

        public FilterHeaderViewHolder(View itemView, Context context) {
            super(itemView);
            mFilterIndicator = (ImageView) itemView.findViewById(R.id.sort_indicator_iv);
            mFilterHeaderText = (RobotoTextView) itemView.findViewById(R.id.sort_by_text_tv);
            mSelectedCountTextView = (RobotoTextView) itemView.findViewById(R.id.sort_by_selected_text_tv);
            mSelectedCountTextView.setVisibility(View.VISIBLE);
            mFilterHeaderText.setRobotoFaceType(RobotoTextView.InputTypeFace.MEDIUM);
            mFilterHeaderText.setTextColor(ContextCompat.getColor(context, R.color.pharmacy_dash_board_text_color));
            mFilterIndicator.setImageResource(R.mipmap.nextarrow);
        }
    }

    private static class SortHeaderViewDataBinder implements
            RecyclerViewDataBinder<FilterHeaderViewHolder, FilterHeaderDataItem> {

        @Override
        public FilterHeaderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sort_products_list_item, parent, false);
            return new FilterHeaderViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(final FilterHeaderViewHolder viewHolder,
                                         final FilterHeaderDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mFilterHeaderText.setText(data.filterHeader);

            if (data.selectedCount > 0) {
                viewHolder.mSelectedCountTextView.setText(data.selectedCount + " selected");
                viewHolder.mSelectedCountTextView.setVisibility(View.VISIBLE);
            } else {
                viewHolder.mSelectedCountTextView.setVisibility(View.GONE);
            }


            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.FilterViewType.FILTER_LIST_ITEM;
        }
    }

    /**
     * FILTER ACTION BUTTON VIEW TYPE
     */
    public static class FilterActionBtnDataItem implements IViewType {

        @Override
        public int getViewType() {
            return ViewTypes.FilterViewType.FILTER_ACTION_BUTTON;
        }
    }

    private static class FilterActionBtnViewHolder extends RecyclerView.ViewHolder {

        private Button mFilterApplyBtn;
        private Button mFilterResetBtn;

        public FilterActionBtnViewHolder(View itemView) {
            super(itemView);

            mFilterApplyBtn = (Button) itemView.findViewById(R.id.filter_products_apply_btn);
            mFilterResetBtn = (Button) itemView.findViewById(R.id.filter_products_reset_btn);
        }
    }

    private static class FilterActionBtnViewDataBinder implements
            RecyclerViewDataBinder<FilterActionBtnViewHolder, FilterActionBtnDataItem> {

        @Override
        public FilterActionBtnViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.filter_action_btn, parent, false);

            return new FilterActionBtnViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final FilterActionBtnViewHolder viewHolder,
                                         final FilterActionBtnDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            if (recyclerViewClickListener != null) {
                viewHolder.mFilterApplyBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
                viewHolder.mFilterResetBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.FilterViewType.FILTER_ACTION_BUTTON;
        }
    }

    /**
     * FILTER DOUBLE SEEK BAR PRICE VIEW TYPE
     */

    public static class FilterDoubleSeekBarPriceDataItem implements IViewType {

        public int minValue;
        public int maxValue;
        public int selectedMinVlaue;
        public int selectedMaxValue;

        @Override
        public int getViewType() {
            return ViewTypes.FilterViewType.FILTER_DOUBLE_SEEK_BAR_PRICE;
        }
    }

    private class FilterDoubleSeekBarPriceViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mSeekBarTitle;
        private RobotoTextView mMinValue;
        private RobotoTextView mMaxValue;

        private RangeSeekBar mRangeSeekBar;

        public FilterDoubleSeekBarPriceViewHolder(View view, final Context context) {
            super(view);

            mSeekBarTitle = (RobotoTextView) view.findViewById(R.id.filter_seek_bar_title_tv);
            mMinValue = (RobotoTextView) view.findViewById(R.id.filter_min_value_tv);
            mMaxValue = (RobotoTextView) view.findViewById(R.id.filter_max_value_tv);
            mRangeSeekBar = (RangeSeekBar) view.findViewById(R.id.filter_range_seek_bar);
            mSeekBarTitle.setText(context.getString(R.string.filter_header_price));
            mRangeSeekBar.setNotifyWhileDragging(true);
        }
    }

    private class FilterDoubleSeekBarPriceViewDataBinder implements RecyclerViewDataBinder<FilterDoubleSeekBarPriceViewHolder,
            FilterDoubleSeekBarPriceDataItem> {
        @Override
        public FilterDoubleSeekBarPriceViewHolder getViewHolder(ViewGroup parent) {
            final ViewGroup view = (ViewGroup) LayoutInflater.from(parent.getContext()).inflate(R.layout.filter_double_seek_bar, parent, false);
            return new FilterDoubleSeekBarPriceViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(final FilterDoubleSeekBarPriceViewHolder viewHolder,
                                         final FilterDoubleSeekBarPriceDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mMinValue.setText(Utils.addRupeeSymbol(viewHolder.mSeekBarTitle.getContext(), "", String.valueOf(data.selectedMinVlaue)));
            viewHolder.mMaxValue.setText(Utils.addRupeeSymbol(viewHolder.mSeekBarTitle.getContext(), "", String.valueOf(data.selectedMaxValue)));
            viewHolder.mRangeSeekBar.setAbsoluteValue(data.minValue, data.maxValue);
            viewHolder.mRangeSeekBar.setSelectedMinValue(data.selectedMinVlaue);
            viewHolder.mRangeSeekBar.setSelectedMaxValue(data.selectedMaxValue);

            viewHolder.mRangeSeekBar.setOnRangeSeekBarChangeListener(new RangeSeekBar.OnRangeSeekBarChangeListener() {
                @Override
                public void rangeSeekBarValuesChanged(RangeSeekBar rangeSeekBar, Number minValue, Number maxValue) {
                    Context context = viewHolder.mMaxValue.getContext();
                    viewHolder.mMaxValue.setText(Utils.addRupeeSymbol(context, "", String.valueOf(maxValue.intValue())));
                    viewHolder.mMinValue.setText(Utils.addRupeeSymbol(context, "", String.valueOf(minValue.intValue())));

                    data.selectedMinVlaue = minValue.intValue();
                    data.selectedMaxValue = maxValue.intValue();
                }
            });

            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.FilterViewType.FILTER_DOUBLE_SEEK_BAR_PRICE;
        }
    }

    /**
     * FILTER DOUBLE SEEK BAR DISCOUNT VIEW TYPE
     */

    public static class FilterDoubleSeekBarDiscountDataItem implements IViewType {

        public int minValue;
        public int maxValue;
        public int selectedMinValue;
        public int selectedMaxValue;

        @Override
        public int getViewType() {
            return ViewTypes.FilterViewType.FILTER_DOUBLE_SEEK_BAR_DISCOUNT;
        }
    }

    private class FilterDoubleSeekBarDiscountViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mSeekBarTitle;
        private RobotoTextView mMinValue;
        private RobotoTextView mMaxValue;

        private RangeSeekBar mRangeSeekBar;

        public FilterDoubleSeekBarDiscountViewHolder(View view, final Context context) {
            super(view);

            mSeekBarTitle = (RobotoTextView) view.findViewById(R.id.filter_seek_bar_title_tv);
            mMinValue = (RobotoTextView) view.findViewById(R.id.filter_min_value_tv);
            mMaxValue = (RobotoTextView) view.findViewById(R.id.filter_max_value_tv);
            mRangeSeekBar = (RangeSeekBar) view.findViewById(R.id.filter_range_seek_bar);
            mSeekBarTitle.setText(context.getString(R.string.filter_header_discount));
            mRangeSeekBar.setNotifyWhileDragging(true);
        }
    }

    private class FilterDoubleSeekBarDiscountViewDataBinder implements RecyclerViewDataBinder<FilterDoubleSeekBarDiscountViewHolder,
            FilterDoubleSeekBarDiscountDataItem> {
        @Override
        public FilterDoubleSeekBarDiscountViewHolder getViewHolder(ViewGroup parent) {
            final ViewGroup view = (ViewGroup) LayoutInflater.from(parent.getContext()).inflate(R.layout.filter_double_seek_bar, parent, false);
            return new FilterDoubleSeekBarDiscountViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(final FilterDoubleSeekBarDiscountViewHolder viewHolder,
                                         final FilterDoubleSeekBarDiscountDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mMinValue.setText(String.valueOf(data.selectedMinValue) + "%");
            viewHolder.mMaxValue.setText(String.valueOf(data.selectedMaxValue) + "%");
            viewHolder.mRangeSeekBar.setAbsoluteValue(data.minValue, data.maxValue);
            viewHolder.mRangeSeekBar.setSelectedMinValue(data.selectedMinValue);
            viewHolder.mRangeSeekBar.setSelectedMaxValue(data.selectedMaxValue);

            viewHolder.mRangeSeekBar.setOnRangeSeekBarChangeListener(new RangeSeekBar.OnRangeSeekBarChangeListener() {
                @Override
                public void rangeSeekBarValuesChanged(RangeSeekBar rangeSeekBar, Number minValue, Number maxValue) {
                    viewHolder.mMaxValue.setText(String.valueOf(maxValue.intValue()) + "%");
                    viewHolder.mMinValue.setText(String.valueOf(minValue.intValue()) + "%");
                    data.selectedMinValue = minValue.intValue();
                    data.selectedMaxValue = maxValue.intValue();
                }
            });
            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.FilterViewType.FILTER_DOUBLE_SEEK_BAR_DISCOUNT;
        }
    }

    /**
     * FILTER IDEAL FOR VIEW TYPE
     */
    public static class FilterIdealForDataItem implements IViewType {
        public String title;
        public boolean isMenChecked = false;
        public boolean isWomenChecked = false;

        public FilterIdealForDataItem(String title) {
            this.title = title;
        }

        @Override
        public int getViewType() {
            return ViewTypes.FilterViewType.FILTER_IDEAL_FOR;
        }
    }

    private static class FilterIdealForViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mIdealForTitle;
        private ImageView mIdealForMen;
        private ImageView mIdealForWomen;

        private LinearLayout mIdealForMenLyt;
        private LinearLayout mIdealForWomenLyt;

        public FilterIdealForViewHolder(View itemView) {
            super(itemView);
            mIdealForTitle = (RobotoTextView) itemView.findViewById(R.id.ideal_for_title_tv);
            mIdealForMen = (ImageView) itemView.findViewById(R.id.ideal_for_men_iv);
            mIdealForWomen = (ImageView) itemView.findViewById(R.id.ideal_for_women_iv);
            mIdealForMenLyt = (LinearLayout) itemView.findViewById(R.id.ideal_for_men_linLyt);
            mIdealForWomenLyt = (LinearLayout) itemView.findViewById(R.id.ideal_for_women_linLyt);
        }
    }

    private static class FilterIdealForViewDataBinder implements
            RecyclerViewDataBinder<FilterIdealForViewHolder, FilterIdealForDataItem> {

        @Override
        public FilterIdealForViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.filter_ideal_for, parent, false);

            return new FilterIdealForViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final FilterIdealForViewHolder viewHolder,
                                         final FilterIdealForDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mIdealForTitle.setText(data.title);
            if (recyclerViewClickListener != null) {
                viewHolder.mIdealForWomenLyt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                        viewHolder.mIdealForWomen.setImageResource((!data.isWomenChecked) ? R.mipmap.women_selected : R.mipmap.women);
                        data.isWomenChecked = !data.isWomenChecked;
                    }
                });
                viewHolder.mIdealForMenLyt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                        viewHolder.mIdealForMen.setImageResource((!data.isMenChecked) ? R.mipmap.men_selected : R.mipmap.men);
                        data.isMenChecked = !data.isMenChecked;
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.FilterViewType.FILTER_IDEAL_FOR;
        }
    }
}

