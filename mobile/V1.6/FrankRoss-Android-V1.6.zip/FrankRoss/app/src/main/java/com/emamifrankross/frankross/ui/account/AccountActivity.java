/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.account;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.Address;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.viewmodels.UserInformation;

/**
 * Created by gauthami on 8/7/15.
 */

/**
 * This class manages the Account related fragment transactions based on the intents and its data
 */
public class AccountActivity extends BaseActivity implements EditProfilePasswordDialogFragment.IPasswordValidateListener {

    private static final String ACCOUNT_EDIT_PROFILE_FRAGMENT_ID = "001";
    private static final String ACCOUNT_ADD_NEW_ADDRESS_FRAGMENT_ID = "002";
    private static final String ACCOUNT_UPDATE_ADDRESS_FRAGMENT_ID = "003";

    private static final String EXTRA_FRAGMENT_ID = "fragment_id";
    private static final String EXTRA_USER_INFO = "userInfo";
    private static final String EXTRA_ADDRESS = "Address";

    /**
     * Method to launch the Edit Profile screen
     *
     * @param appContext      the application context
     * @param userInformation the user information to be displayed
     * @return intent associate to Edit Profile
     */
    public static Intent getActivityIntentForEditProfile(Context appContext, UserInformation userInformation) {
        Intent intent = new Intent(appContext, AccountActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, ACCOUNT_EDIT_PROFILE_FRAGMENT_ID);
        intent.putExtra(EXTRA_USER_INFO, userInformation);
        return intent;
    }

    /**
     * Method to launch Add address screen
     *
     * @param appContext the application context
     * @return intent associate to Add Address
     */
    public static Intent getActivityIntentForAddAddress(Context appContext) {
        Intent intent = new Intent(appContext, AccountActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, ACCOUNT_ADD_NEW_ADDRESS_FRAGMENT_ID);
        return intent;
    }

    /**
     * Method to launch the Update Address screen
     *
     * @param appContext the application context
     * @param address    the address that is to be updated
     * @return intent associate to Update Address
     */
    public static Intent getActivityIntentForUpdateAddress(Context appContext, Address address) {
        Intent intent = new Intent(appContext, AccountActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, ACCOUNT_UPDATE_ADDRESS_FRAGMENT_ID);
        intent.putExtra(EXTRA_ADDRESS, address);
        return intent;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String fragmentId = getIntent().getStringExtra(EXTRA_FRAGMENT_ID);
        initFragment(fragmentId);
    }

    private void initFragment(String fragmentId) {
        if (!TextUtils.isEmpty(fragmentId)) {
            switch (fragmentId) {
                case ACCOUNT_EDIT_PROFILE_FRAGMENT_ID:
                    if (getIntent().hasExtra(EXTRA_USER_INFO) && getIntent().getParcelableExtra(EXTRA_USER_INFO) != null) {
                        loadFragment(getFragmentContainerId(),
                                EditProfileFragment.create(
                                        (UserInformation) getIntent().getParcelableExtra(EXTRA_USER_INFO)),
                                EditProfileFragment.class.getName(), R.anim.push_left_in, R.anim.push_left_out,
                                BaseFragment.FragmentTransactionType.ADD);
                    }
                    break;

                case ACCOUNT_ADD_NEW_ADDRESS_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(), DeliveryAddressFragment.createAddAddress(),
                            null, R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.ADD);
                    break;

                case ACCOUNT_UPDATE_ADDRESS_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(), DeliveryAddressFragment.createUpdateAddress((Address)
                                    getIntent().getSerializableExtra(EXTRA_ADDRESS)),
                            null, R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.ADD);
                    break;

                default:
                    break;

            }
        }
    }

    /**
     * Method that receives the callback for password validation
     *
     * @param password the password entered by the user
     */

    @Override
    public void onPasswordValidated(String password) {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(EditProfileFragment.class.getName());
        if (fragment instanceof EditProfileFragment) {
            ((EditProfileFragment) fragment).onPasswordValidated(password);
        }
    }

    /**
     * Method that receives the callback for verify via OTP
     */
    @Override
    public void onVerifyViaOTPClick() {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(EditProfileFragment.class.getName());
        if (fragment instanceof EditProfileFragment) {
            ((EditProfileFragment) fragment).onVerifyViaOTPClick();
        }
    }
}