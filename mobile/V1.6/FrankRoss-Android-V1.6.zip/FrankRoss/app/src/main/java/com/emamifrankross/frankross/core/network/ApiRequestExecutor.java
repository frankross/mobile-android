/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.network;

import android.content.Context;
import android.graphics.Bitmap;
import android.support.v4.util.LruCache;
import android.text.TextUtils;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.BasicNetwork;
import com.android.volley.toolbox.DiskBasedCache;
import com.android.volley.toolbox.HttpStack;
import com.android.volley.toolbox.HurlStack;
import com.android.volley.toolbox.ImageLoader;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;

/**
 * Created by gowtham on 13/7/15.
 */

/**
 * Singleton class to set up a single instance of RequestQueue that will last the lifetime of the app
 * and adds the request to volley request queue and handles the Request cache
 */
public class ApiRequestExecutor {

    private static Context mAppContext;
    private RequestQueue mRequestQueue;
    private ImageLoader mImageLoader;

    private ApiRequestExecutor() {
        mImageLoader = new ImageLoader(mRequestQueue, new ImageLoader.ImageCache() {
            private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(20);

            @Override
            public Bitmap getBitmap(String url) {
                return cache.get(url);
            }

            @Override
            public void putBitmap(String url, Bitmap bitmap) {
                cache.put(url, bitmap);
            }
        });

        mRequestQueue = getRequestQueue(mAppContext);
    }

    public static ApiRequestExecutor getInstance(Context appContext) {
        mAppContext = appContext.getApplicationContext();

        return RequestExecutorHolder.INSTANCE;
    }

    public ImageLoader getImageLoader() {
        return mImageLoader;
    }

    public void executeRequest(FRGsonRequest request) {
        mRequestQueue.add(request);
    }

    public void cancelRequestsWithTag(String tag) {
        if (!TextUtils.isEmpty(tag)) {
            mRequestQueue.cancelAll(tag);
        }
    }

    private RequestQueue getRequestQueue(Context ctx) {
        if (mRequestQueue == null) {
            DiskBasedCache cache = new DiskBasedCache(ctx.getFilesDir(), 10 * 1024 * 1024);
            mRequestQueue = new RequestQueue(cache, new BasicNetwork(getHttpStack()));
            mRequestQueue.start();
        }

        return mRequestQueue;
    }

    private HttpStack getHttpStack() {
        if (UrlConstants.ACCEPT_ALL_CERTIFICATES) {
            try {
                SSLContext sslCtx = SSLContext.getInstance("SSL");
                sslCtx.init(null, new TrustManager[]{new TrustEverythingSSLTrustManager()}, null);
                SSLSocketFactory sSocketFactory = sslCtx.getSocketFactory();
                HttpsURLConnection.setDefaultSSLSocketFactory(sSocketFactory);
                HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {

                    @Override
                    public boolean verify(String hostname, SSLSession session) {
                        return true;
                    }
                });
                HurlStack hurlStack = new HurlStack(new HurlStack.UrlRewriter() {

                    @Override
                    public String rewriteUrl(String originalUrl) {
                        return originalUrl;
                    }
                }, sSocketFactory);

                return hurlStack;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return new HurlStack();
    }

    public static class RequestExecutorHolder {
        public static ApiRequestExecutor INSTANCE = new ApiRequestExecutor();
    }
}
