/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.aloglia;

import android.content.Context;

import com.algolia.search.saas.APIClient;
import com.algolia.search.saas.AlgoliaException;
import com.algolia.search.saas.Index;
import com.algolia.search.saas.IndexListener;
import com.algolia.search.saas.Query;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.aloglia.datamodel.AlgoliaProductDataModel;
import com.emamifrankross.frankross.core.aloglia.datamodel.AlgoliaProductInfo;
import com.emamifrankross.frankross.core.aloglia.datamodel.AlgoliaProductsFilterInfo;
import com.emamifrankross.frankross.core.network.UrlConstants;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.SearchAdapter;
import com.emamifrankross.frankross.ui.common.FilterSelectionStats;
import com.emamifrankross.frankross.ui.common.SortType;
import com.emamifrankross.frankross.ui.common.Stats;
import com.emamifrankross.frankross.ui.viewmodels.ProductDataModel;
import com.emamifrankross.frankross.utils.Log;
import com.emamifrankross.frankross.utils.Utils;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

/**
 * Created by gowtham on 23/7/15.
 * <p/>
 * Class Manages the Algolia product fetching communication between UI and Algolia SDK based on required index and filters.
 * <p/>
 * It provides methods to fetch the Algolia products
 */
public class AlgoliaManager {

    private final APIClient client;

    /**
     * Interface callback to notify the search results from Algolia.
     */
    private interface IAlgoliaResultNotifier {
        void onResult(List<AlgoliaProductDataModel> productList, AlgoliaProductsFilterInfo algoliaProductsFilterInfo);

        void onSearchError();
    }

    private static class AlgoliaInstanceHolder {
        public static AlgoliaManager INSTANCE = new AlgoliaManager();
    }

    private String getAlgoliaIndex() {
        //return "Variant_Mobile_payment_retry_heroku";
        return "Variant_Mobile_" + UrlConstants.getAlgoliaSuffix();
    }

    private AlgoliaManager() {
        client = new APIClient("T63QHGRW33", "483dd0e5c6d5165b830187abcad40394");
    }

    /**
     * Callback interface for notifying the Algolia products fetched form Algolia server.
     */
    public interface IProductInfoResultNotifier {
        void onProductInfoFetched(List<ProductDataModel> productList);

        void onSearchError();
    }

    /**
     * Callback interface for notifying the Algolia products and Products filter info like brand name, price statistics
     */
    public interface IProductInfoWithFilterResultNotifier {
        void onProductInfoFetched(List<ProductDataModel> productList, AlgoliaProductsFilterInfo algoliaProductsFilterInfo);

        void onSearchError();
    }

    /**
     * Method to get the Algolia Featured Products for Home Screen.
     *
     * @param appContext                Application context
     * @param count                     Number of Algolia products to fetch.
     * @param pageNumber                PageNumber
     * @param productInfoResultNotifier callback for notifying the result back to requester.
     */
    public void performGetFeaturedProducts(Context appContext, int count, int pageNumber, boolean isFilterRequired,
                                           final IProductInfoWithFilterResultNotifier productInfoResultNotifier) {
        String cityFilterKey = Utils.getAlgoliaCityFilterKey(appContext.getApplicationContext());
        AlgoliaManager.getInstance().performSearchAsync(new IAlgoliaResultNotifier() {
            @Override
            public void onResult(List<AlgoliaProductDataModel> productList, AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                if (productList != null) {
                    productInfoResultNotifier.onProductInfoFetched(getMappedUIDataListForProducts(productList), algoliaProductsFilterInfo);
                }
            }

            @Override
            public void onSearchError() {
                productInfoResultNotifier.onSearchError();
            }
        }, AlgoliaQueryProvider.getFeaturedProductQuery(cityFilterKey, count, pageNumber, isFilterRequired), cityFilterKey);
    }


    /**
     * Method to get the featured filtered Algolia Products for the provided filters.
     *
     * @param isFeatured                the flag that indicates the featured products
     * @param appContext                Application context
     * @param sortType                  type value used for sorting the algolia products in Low to High or High to Low Order.
     * @param filterInfo                filter information like brands list, price range, discount range used for filter the products
     * @param count                     Number of Algolia products to fetch.
     * @param pageNumber                PageNumber
     * @param productInfoResultNotifier callback for notifying the result back to requester.
     */
    public void performGetFeaturedProductsWithAppliedFilterAndSortInfo(
            boolean isFeatured, Context appContext, SortType sortType, AlgoliaProductsFilterInfo filterInfo, int count,
            int pageNumber, final IProductInfoResultNotifier productInfoResultNotifier) {

        String cityFilterKey = Utils.getAlgoliaCityFilterKey(appContext.getApplicationContext());
        AlgoliaManager.getInstance().performSearchAsync(new AlgoliaManager.IAlgoliaResultNotifier() {
            @Override
            public void onResult(final List<AlgoliaProductDataModel> productList, AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                if (productList != null) {
                    productInfoResultNotifier.onProductInfoFetched(getMappedUIDataListForProducts(productList));
                }
            }

            @Override
            public void onSearchError() {
                productInfoResultNotifier.onSearchError();
            }
        }, AlgoliaQueryProvider.getProductQueryWithAppliedFilterAndSortInfo(isFeatured, -1, cityFilterKey, count,
                pageNumber, filterInfo), appContext, sortType);
    }

    /**
     * Method to get the Algolia Products for particular category.
     *
     * @param appContext                Application context
     * @param isFeatured                flag used to filter featured products
     * @param categoryId                category id of the Algolia products.
     * @param count                     Number of Algolia products to fetch.
     * @param pageNumber                PageNumber
     * @param productInfoResultNotifier callback for notifying the result back to requester.
     */
    public void performGetNonPharmaCategoryProducts(Context appContext, boolean isFeatured, long categoryId, int count,
                                                    int pageNumber, final IProductInfoWithFilterResultNotifier productInfoResultNotifier) {
        String cityFilterKey = Utils.getAlgoliaCityFilterKey(appContext.getApplicationContext());
        AlgoliaManager.getInstance().performSearchAsync(new AlgoliaManager.IAlgoliaResultNotifier() {
            @Override
            public void onResult(final List<AlgoliaProductDataModel> productList, AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                if (productList != null) {
                    productInfoResultNotifier.onProductInfoFetched(getMappedUIDataListForProducts(productList), algoliaProductsFilterInfo);
                }
            }

            @Override
            public void onSearchError() {
                productInfoResultNotifier.onSearchError();
            }
        }, AlgoliaQueryProvider.getCategoryProductQuery(isFeatured, categoryId, cityFilterKey, count, pageNumber, true), cityFilterKey);
    }


    /**
     * Method to get the Algolia Products for particular category and brand
     *
     * @param appContext                Application context
     * @param categoryId                category id of the Algolia products.
     * @param count                     Number of Algolia products to fetch.
     * @param pageNumber                PageNumber
     * @param productInfoResultNotifier callback for notifying the result back to requester.
     */
    public void performGetNonPharmaCategoryProductsWithBrand(Context appContext, String brandName, long categoryId, int count,
                                                             int pageNumber, final IProductInfoWithFilterResultNotifier productInfoResultNotifier) {
        String cityFilterKey = Utils.getAlgoliaCityFilterKey(appContext.getApplicationContext());
        AlgoliaManager.getInstance().performSearchAsync(new AlgoliaManager.IAlgoliaResultNotifier() {
            @Override
            public void onResult(final List<AlgoliaProductDataModel> productList, AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                if (productList != null) {
                    productInfoResultNotifier.onProductInfoFetched(getMappedUIDataListForProducts(productList), algoliaProductsFilterInfo);
                }
            }

            @Override
            public void onSearchError() {
                productInfoResultNotifier.onSearchError();
            }
        }, AlgoliaQueryProvider.getCategoryProductWithBrandQuery(brandName, categoryId, cityFilterKey, count, pageNumber, true), cityFilterKey);
    }

    /**
     * Method to get the particular category filtered Algolia Products for the provided filters.
     *
     * @param appContext                Application context
     * @param sortType                  type value used for sorting the algolia products in Low to High or High to Low Order.
     * @param filterInfo                filter information like brands list, price range, discount range used for filter the products
     * @param categoryId                category id of the Algolia products.
     * @param count                     Number of Algolia products to fetch.
     * @param pageNumber                PageNumber
     * @param productInfoResultNotifier callback for notifying the result back to requester.
     */
    public void performGetNonPharmaCategoryProductsWithBrandWithAppliedFilterAndSortInfo(
            Context appContext, SortType sortType, AlgoliaProductsFilterInfo filterInfo, String brandName, long categoryId, int count,
            int pageNumber, final IProductInfoResultNotifier productInfoResultNotifier) {

        String cityFilterKey = Utils.getAlgoliaCityFilterKey(appContext.getApplicationContext());
        AlgoliaManager.getInstance().performSearchAsync(new AlgoliaManager.IAlgoliaResultNotifier() {
            @Override
            public void onResult(final List<AlgoliaProductDataModel> productList, AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                if (productList != null) {
                    productInfoResultNotifier.onProductInfoFetched(getMappedUIDataListForProducts(productList));
                }
            }

            @Override
            public void onSearchError() {
                productInfoResultNotifier.onSearchError();
            }
        }, AlgoliaQueryProvider.getCategoryProductWithBrandQueryWithAppliedFilterAndSortInfo(brandName, categoryId, cityFilterKey, count,
                pageNumber, filterInfo), appContext, sortType);
    }

    /**
     * Method to get the Algolia Products for particular category and brand
     *
     * @param appContext                Application context
     * @param categoryId                category id of the Algolia products.
     * @param count                     Number of Algolia products to fetch.
     * @param pageNumber                PageNumber
     * @param productInfoResultNotifier callback for notifying the result back to requester.
     */
    public void performGetNonPharmaCategoryProductsWithPromotionId(Context appContext, long promotionId, long categoryId, int count,
                                                                   int pageNumber, final IProductInfoWithFilterResultNotifier productInfoResultNotifier) {
        String cityFilterKey = Utils.getAlgoliaCityFilterKey(appContext.getApplicationContext());
        AlgoliaManager.getInstance().performSearchAsync(new AlgoliaManager.IAlgoliaResultNotifier() {
            @Override
            public void onResult(final List<AlgoliaProductDataModel> productList, AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                if (productList != null) {
                    productInfoResultNotifier.onProductInfoFetched(getMappedUIDataListForProducts(productList), algoliaProductsFilterInfo);
                }
            }

            @Override
            public void onSearchError() {
                productInfoResultNotifier.onSearchError();
            }
        }, AlgoliaQueryProvider.getCategoryProductWithPromotionQuery(promotionId, categoryId, cityFilterKey, count, pageNumber, true), cityFilterKey);
    }

    /**
     * Method to get the particular category filtered Algolia Products for the provided filters.
     *
     * @param appContext                Application context
     * @param sortType                  type value used for sorting the algolia products in Low to High or High to Low Order.
     * @param filterInfo                filter information like brands list, price range, discount range used for filter the products
     * @param categoryId                category id of the Algolia products.
     * @param count                     Number of Algolia products to fetch.
     * @param pageNumber                PageNumber
     * @param productInfoResultNotifier callback for notifying the result back to requester.
     */
    public void performGetNonPharmaCategoryProductsWithPromotionIdWithAppliedFilterAndSortInfo(
            Context appContext, SortType sortType, AlgoliaProductsFilterInfo filterInfo, long promotionId, long categoryId, int count,
            int pageNumber, final IProductInfoResultNotifier productInfoResultNotifier) {

        String cityFilterKey = Utils.getAlgoliaCityFilterKey(appContext.getApplicationContext());
        AlgoliaManager.getInstance().performSearchAsync(new AlgoliaManager.IAlgoliaResultNotifier() {
            @Override
            public void onResult(final List<AlgoliaProductDataModel> productList, AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                if (productList != null) {
                    productInfoResultNotifier.onProductInfoFetched(getMappedUIDataListForProducts(productList));
                }
            }

            @Override
            public void onSearchError() {
                productInfoResultNotifier.onSearchError();
            }
        }, AlgoliaQueryProvider.getCategoryProductWithPromotionQueryWithAppliedFilterAndSortInfo(promotionId, categoryId, cityFilterKey, count,
                pageNumber, filterInfo), appContext, sortType);
    }

    /**
     * Method to get the particular category Algolia Products with facets values and its statistics .
     *
     * @param appContext                Application context
     * @param categoryId                category id of the Algolia products.
     * @param count                     Number of Algolia products to fetch.
     * @param pageNumber                PageNumber
     * @param productInfoResultNotifier callback for notifying the result back to requester.
     */
    public void performGetNonPharmaCategoryProductsWithFilterInfo(Context appContext, long categoryId, int count,
                                                                  int pageNumber, final IProductInfoWithFilterResultNotifier productInfoResultNotifier) {
        String cityFilterKey = Utils.getAlgoliaCityFilterKey(appContext.getApplicationContext());
        AlgoliaManager.getInstance().performSearchAsync(new AlgoliaManager.IAlgoliaResultNotifier() {
            @Override
            public void onResult(final List<AlgoliaProductDataModel> productList, AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                if (productList != null) {
                    productInfoResultNotifier.onProductInfoFetched(getMappedUIDataListForProducts(productList), algoliaProductsFilterInfo);
                }
            }

            @Override
            public void onSearchError() {
                productInfoResultNotifier.onSearchError();
            }
        }, AlgoliaQueryProvider.getCategoryProductQuery(false, categoryId, cityFilterKey, count, pageNumber, true), cityFilterKey);
    }


    /**
     * Method to get the particular category filtered Algolia Products for the provided filters.
     *
     * @param isFeatured                the flag that indicates the featured products
     * @param appContext                Application context
     * @param sortType                  type value used for sorting the algolia products in Low to High or High to Low Order.
     * @param filterInfo                filter information like brands list, price range, discount range used for filter the products
     * @param categoryId                category id of the Algolia products.
     * @param count                     Number of Algolia products to fetch.
     * @param pageNumber                PageNumber
     * @param productInfoResultNotifier callback for notifying the result back to requester.
     */
    public void performGetNonPharmaCategoryProductsWithAppliedFilterAndSortInfo(
            boolean isFeatured, Context appContext, SortType sortType, AlgoliaProductsFilterInfo filterInfo, long categoryId, int count,
            int pageNumber, final IProductInfoResultNotifier productInfoResultNotifier) {

        String cityFilterKey = Utils.getAlgoliaCityFilterKey(appContext.getApplicationContext());
        AlgoliaManager.getInstance().performSearchAsync(new AlgoliaManager.IAlgoliaResultNotifier() {
            @Override
            public void onResult(final List<AlgoliaProductDataModel> productList, AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                if (productList != null) {
                    productInfoResultNotifier.onProductInfoFetched(getMappedUIDataListForProducts(productList));
                }
            }

            @Override
            public void onSearchError() {
                productInfoResultNotifier.onSearchError();
            }
        }, AlgoliaQueryProvider.getProductQueryWithAppliedFilterAndSortInfo(isFeatured, categoryId, cityFilterKey, count,
                pageNumber, filterInfo), appContext, sortType);
    }

    /**
     * Method to get the Algolia Products for the provided search term.
     *
     * @param appContext                Application context
     * @param searchTerm                search string used for filter.
     * @param count                     Number of Algolia products to fetch.
     * @param pageNumber                PageNumber
     * @param productInfoResultNotifier callback for notifying the result back to requester.
     */
    public void performGetSearchResultProductsWithFilterAndSortInfo(Context appContext, String searchTerm, int count, int pageNumber,
                                                                    final IProductInfoWithFilterResultNotifier productInfoResultNotifier) {
        String cityFilterKey = Utils.getAlgoliaCityFilterKey(appContext.getApplicationContext());
        AlgoliaManager.getInstance().performSearchAsync(new AlgoliaManager.IAlgoliaResultNotifier() {
            @Override
            public void onResult(List<AlgoliaProductDataModel> productList, AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                if (productList != null) {
                    productInfoResultNotifier.onProductInfoFetched(getMappedUIDataListForProducts(productList),
                            algoliaProductsFilterInfo);
                }
            }

            @Override
            public void onSearchError() {
                productInfoResultNotifier.onSearchError();
            }
        }, AlgoliaQueryProvider.getSearchResultsQuery(searchTerm, cityFilterKey, count, pageNumber), cityFilterKey);
    }

    /**
     * Method to get the filtered Searched Products for the provided filters.
     *
     * @param appContext                Application context
     * @param sortType                  type value used for sorting the algolia products in Low to High or High to Low Order.
     * @param filterInfo                filter information like brands list, price range, discount range used for filter the products
     * @param count                     Number of Algolia products to fetch.
     * @param pageNumber                PageNumber
     * @param productInfoResultNotifier callback for notifying the result back to requester.
     */
    public void performGetSearchResultProductsWithAppliedFilterAndSortInfo(
            Context appContext, String searchTerm, SortType sortType, AlgoliaProductsFilterInfo filterInfo, int count,
            int pageNumber, final IProductInfoResultNotifier productInfoResultNotifier) {

        String cityFilterKey = Utils.getAlgoliaCityFilterKey(appContext.getApplicationContext());
        AlgoliaManager.getInstance().performSearchAsync(new AlgoliaManager.IAlgoliaResultNotifier() {
            @Override
            public void onResult(final List<AlgoliaProductDataModel> productList, AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                if (productList != null) {
                    productInfoResultNotifier.onProductInfoFetched(getMappedUIDataListForProducts(productList));
                }
            }

            @Override
            public void onSearchError() {
                productInfoResultNotifier.onSearchError();
            }
        }, AlgoliaQueryProvider.getSearchResultsQueryWithAppliedFilterAndSortInfo(searchTerm, cityFilterKey, count,
                pageNumber, filterInfo), appContext, sortType);
    }

    /**
     * Call back interface used for notifying te search suggestions results.
     */
    public interface IGetSearchSuggestionsResultNotifier {
        void onSuggestionsFetched(List<BaseRecyclerAdapter.IViewType> uiDataList);
    }

    /**
     * Method used for getting the search suggestions for the given search term.
     *
     * @param appContext                      application context.
     * @param searchTerm                      search string used for filter.
     * @param count                           number of products to be fetched
     * @param searchSuggestionsResultNotifier call back for notifying the search suggestion result.
     */
    public void performGetSearchSuggestion(final Context appContext, String searchTerm, int count,
                                           final IGetSearchSuggestionsResultNotifier searchSuggestionsResultNotifier) {
        String cityFilterKey = Utils.getAlgoliaCityFilterKey(appContext.getApplicationContext());
        AlgoliaManager.getInstance().performSearchAsync(new AlgoliaManager.IAlgoliaResultNotifier() {
            @Override
            public void onResult(List<AlgoliaProductDataModel> productList, AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
                searchSuggestionsResultNotifier.onSuggestionsFetched(getMappedUiDataSearchSuggestions(appContext, productList));
            }

            @Override
            public void onSearchError() {

            }
        }, AlgoliaQueryProvider.getSearchSuggestionsQuery(searchTerm, cityFilterKey, count), cityFilterKey);
    }

    /**
     * MAPPED UI DATA METHODS
     */
    private List<ProductDataModel> getMappedUIDataListForProducts(List<AlgoliaProductDataModel> productList) {
        List<ProductDataModel> productDataModels = new ArrayList<>(productList.size());

        for (AlgoliaProductDataModel algoliaProductDataModel : productList) {
            ProductDataModel productData = new ProductDataModel();

            productData.productId = algoliaProductDataModel.getId();
            productData.productName = algoliaProductDataModel.getName();
            productData.productBrandOrManufacturerName = (algoliaProductDataModel.getCategoryDetails().isPharma())
                    ? algoliaProductDataModel.getManufacturer() : "By " + algoliaProductDataModel.getBrandName();
            productData.productImageUrl = algoliaProductDataModel.getMainImageUrl();
            productData.productIconImageUrl = algoliaProductDataModel.getIconImageUrl();
            productData.isAddToCartVisible = true;

            if (algoliaProductDataModel.getAlgoliaProductInfo().getDiscountPercent() == 0) {
                productData.productSellingPrice = algoliaProductDataModel.getAlgoliaProductInfo().getSalesPrice();
                productData.productActualPrice = algoliaProductDataModel.getAlgoliaProductInfo().getMrpPrice();
                productData.productDiscountPercent = algoliaProductDataModel.getAlgoliaProductInfo().getDiscountPercent();
            } else {
                productData.productSellingPrice = algoliaProductDataModel.getAlgoliaProductInfo().getPromotionalPrice();
                productData.productActualPrice = algoliaProductDataModel.getAlgoliaProductInfo().getMrpPrice();
                productData.productDiscountPercent = algoliaProductDataModel.getAlgoliaProductInfo().getDiscountPercent();
            }

            productData.isPharma = algoliaProductDataModel.getCategoryDetails().isPharma();
            productData.isAvailable = algoliaProductDataModel.getAlgoliaProductInfo().isAvailable();
            productData.maxOrderQuantity = algoliaProductDataModel.getAlgoliaProductInfo().getMaxOrderSize();
            productData.innerPackagingQty = algoliaProductDataModel.getInnerPackagingQty();
            productData.outerPackagingQty = algoliaProductDataModel.getUnitOfSale();
            productData.unitOfSale = algoliaProductDataModel.getUnitOfSale();
            productData.totalProducts = algoliaProductDataModel.getNumberOfProducts();
            productData.isCashBack = algoliaProductDataModel.getAlgoliaProductInfo().isCashBack();
            productData.cashBackMessage = algoliaProductDataModel.getAlgoliaProductInfo().getCashBackMessage();

            productDataModels.add(productData);
        }

        return productDataModels;
    }

    /**
     * Method used for mapping the backend data model to UI Adapter data model.
     *
     * @param appContext  Application Context.
     * @param productList Algolia products list.
     * @return List of Ui Data model required for Search screen adapter
     */
    private List<BaseRecyclerAdapter.IViewType> getMappedUiDataSearchSuggestions(Context appContext,
                                                                                 List<AlgoliaProductDataModel> productList) {
        ArrayList<BaseRecyclerAdapter.IViewType> searchScreenData = new ArrayList<>();
        List<BaseRecyclerAdapter.IViewType> pharmaList = new ArrayList<>(5);
        List<BaseRecyclerAdapter.IViewType> nonPharmaList = new ArrayList<>(5);

        if (productList != null && productList.size() > 0) {
            for (AlgoliaProductDataModel dataModel : productList) {
                if (dataModel.getCategoryDetails().isPharma()) {
                    if (pharmaList.size() < 10) {
                        pharmaList.add(getPharmaProductItem(dataModel));
                    } else if (nonPharmaList.size() > 10) {
                        break;
                    }
                } else {
                    if (nonPharmaList.size() < 10) {
                        nonPharmaList.add(getNonPharmaProductItem(dataModel));
                    } else if (pharmaList.size() > 10) {
                        break;
                    }
                }
            }
        }

        if (pharmaList.size() > 0) {
            searchScreenData.add(new SearchAdapter.SearchCategoryDataItem(appContext.getString(R.string.search_header_pharma_products)));
            searchScreenData.addAll(pharmaList);
        }

        if (nonPharmaList.size() > 0) {
            searchScreenData.add(new SearchAdapter.SearchCategoryDataItem(appContext.getString(R.string.search_header_non_pharma_products)));
            searchScreenData.addAll(nonPharmaList);
        }

        return searchScreenData;
    }

    /**
     * Creates  pharma Ui Data model required for UI Adapter class from AlgoliaProductDataModel.
     *
     * @param dataModel the algolia data to be mapped to UI element
     * @return SearchAdapter.SearchPharmaProductDataItem model
     */
    private BaseRecyclerAdapter.IViewType getPharmaProductItem(AlgoliaProductDataModel dataModel) {
        SearchAdapter.SearchPharmaProductDataItem pharmaItem = new SearchAdapter.SearchPharmaProductDataItem();
        pharmaItem.variantId = dataModel.getId();
        pharmaItem.manufacturerName = dataModel.getManufacturer();
        pharmaItem.productName = dataModel.getName();
        pharmaItem.categoryName = dataModel.getCategoryDetails().getPrimaryCategory().getName();
        pharmaItem.categoryId = dataModel.getCategoryDetails().getPrimaryCategory().getId();
        pharmaItem.productIconImageUrl = dataModel.getIconImageUrl();

        return pharmaItem;
    }

    /**
     * Creates Non pharma Ui Data model required for UI Adapter class from AlgoliaProductDataModel.
     *
     * @param dataModel the algolia data to be mapped to UI element
     * @return SearchAdapter.SearchNonPharmaProductDataItem model
     */
    private BaseRecyclerAdapter.IViewType getNonPharmaProductItem(AlgoliaProductDataModel dataModel) {
        SearchAdapter.SearchNonPharmaProductDataItem nonPharmaProductDataItem = new SearchAdapter.SearchNonPharmaProductDataItem();
        nonPharmaProductDataItem.categoryName = dataModel.getCategoryDetails().getPrimaryCategory().getName();
        nonPharmaProductDataItem.genericKeyword = dataModel.getGenericKeyWord1();
        nonPharmaProductDataItem.variantId = dataModel.getId();
        nonPharmaProductDataItem.productName = dataModel.getName();
        nonPharmaProductDataItem.manufacturerName = dataModel.getBrandName();
        nonPharmaProductDataItem.categoryId = dataModel.getCategoryDetails().getPrimaryCategory().getId();
        nonPharmaProductDataItem.isPharma = false;

        return nonPharmaProductDataItem;
    }

    private <T> void performSearchAsync(IAlgoliaResultNotifier algoliaResultNotifier, Query searchQuery, String cityFilterKey) {
        Index alogliaIndex = client.initIndex(getAlgoliaIndex());
        alogliaIndex.searchASync(searchQuery, getIndexListener(algoliaResultNotifier, cityFilterKey));
    }

    private <T> void performSearchAsync(IAlgoliaResultNotifier algoliaResultNotifier, Query searchQuery, Context appContext, SortType sortType) {
        String cityFilterKey = Utils.getAlgoliaCityFilterKey(appContext.getApplicationContext());
        int locationId = Utils.getLocationId(appContext);

        Index alogliaIndex = getClientIndex(sortType, locationId);
        alogliaIndex.searchASync(searchQuery, getIndexListener(algoliaResultNotifier, cityFilterKey));
    }

    private Index getClientIndex(SortType sortType, int locationId) {
        String indexName = getAlgoliaIndex();

        switch (sortType) {
            case LOW_TO_HIGH:
                indexName = "Variant_Mobile_" + locationId + "_promotional_price_asc_" + UrlConstants.getAlgoliaSuffix();
                break;

            case HIGH_TO_LOW:
                indexName = "Variant_Mobile_" + locationId + "_promotional_price_desc_" + UrlConstants.getAlgoliaSuffix();
                break;
        }

        return client.initIndex(indexName);
    }

    public static AlgoliaManager getInstance() {

        return AlgoliaInstanceHolder.INSTANCE;
    }

    private IndexListener getIndexListener(final IAlgoliaResultNotifier algoliaResultNotifier, final String cityFilterKey) {
        return new IndexListener() {
            @Override
            public void addObjectResult(Index index, JSONObject jsonObject, JSONObject jsonObject2) {
                Log.d("Algolia", "addObjectResult");
            }

            @Override
            public void addObjectError(Index index, JSONObject jsonObject, AlgoliaException e) {
                Log.d("Algolia", "addObjectError");
            }

            @Override
            public void addObjectsResult(Index index, List<JSONObject> jsonObjects, JSONObject jsonObject) {
                Log.d("Algolia", "addObjectsResult");
            }

            @Override
            public void addObjectsError(Index index, List<JSONObject> jsonObjects, AlgoliaException e) {
                Log.d("Algolia", "addObjectsError");
            }

            @Override
            public void addObjectsResult(Index index, JSONArray jsonArray, JSONObject jsonObject) {
                Log.d("Algolia", "addObjectsResult");
            }

            @Override
            public void addObjectsError(Index index, JSONArray jsonArray, AlgoliaException e) {
                Log.d("Algolia", "addObjectsError");
            }

            @Override
            public void searchResult(Index index, Query query, JSONObject jsonObject) {
                parseAlgoliaProductsList(jsonObject, algoliaResultNotifier, cityFilterKey);
            }

            @Override
            public void searchError(Index index, Query query, AlgoliaException e) {
                Log.d("Algolia", "searchError");
                algoliaResultNotifier.onSearchError();
            }

            @Override
            public void deleteObjectResult(Index index, String s, JSONObject jsonObject) {
                Log.d("Algolia", "deleteObjectResult");
            }

            @Override
            public void deleteObjectError(Index index, String s, AlgoliaException e) {
                Log.d("Algolia", "deleteObjectError");
            }

            @Override
            public void deleteObjectsResult(Index index, JSONArray jsonArray, JSONObject jsonObject) {
                Log.d("Algolia", "deleteObjectsResult");
            }

            @Override
            public void deleteByQueryError(Index index, Query query, AlgoliaException e) {
                Log.d("Algolia", "deleteByQueryError");
            }

            @Override
            public void deleteByQueryResult(Index index) {
                Log.d("Algolia", "deleteByQueryResult");
            }

            @Override
            public void deleteObjectsError(Index index, List<JSONObject> jsonObjects, AlgoliaException e) {
                Log.d("Algolia", "deleteObjectsError");
            }

            @Override
            public void saveObjectResult(Index index, JSONObject jsonObject, String s, JSONObject jsonObject2) {
                Log.d("Algolia", "saveObjectResult");
            }

            @Override
            public void saveObjectError(Index index, JSONObject jsonObject, String s, AlgoliaException e) {
                Log.d("Algolia", "saveObjectError");
            }

            @Override
            public void saveObjectsResult(Index index, List<JSONObject> jsonObjects, JSONObject jsonObject) {
                Log.d("Algolia", "saveObjectsResult");
            }

            @Override
            public void saveObjectsError(Index index, List<JSONObject> jsonObjects, AlgoliaException e) {
                Log.d("Algolia", "saveObjectsError");
            }

            @Override
            public void saveObjectsResult(Index index, JSONArray jsonArray, JSONObject jsonObject) {
                Log.d("Algolia", "setSettingsResult");
            }

            @Override
            public void saveObjectsError(Index index, JSONArray jsonArray, AlgoliaException e) {
                Log.d("Algolia", "saveObjectsResult");
            }

            @Override
            public void partialUpdateResult(Index index, JSONObject jsonObject, String s, JSONObject jsonObject2) {
                Log.d("Algolia", "partialUpdateResult");
            }

            @Override
            public void partialUpdateError(Index index, JSONObject jsonObject, String s, AlgoliaException e) {
                Log.d("Algolia", "partialUpdateError");
            }

            @Override
            public void partialUpdateObjectsResult(Index index, List<JSONObject> jsonObjects, JSONObject jsonObject) {
                Log.d("Algolia", "partialUpdateObjectsResult");
            }

            @Override
            public void partialUpdateObjectsError(Index index, List<JSONObject> jsonObjects, AlgoliaException e) {
                Log.d("Algolia", "partialUpdateObjectsError");
            }

            @Override
            public void partialUpdateObjectsResult(Index index, JSONArray jsonArray, JSONObject jsonObject) {
                Log.d("Algolia", "partialUpdateObjectsResult");
            }

            @Override
            public void partialUpdateObjectsError(Index index, JSONArray jsonArray, AlgoliaException e) {
                Log.d("Algolia", "partialUpdateObjectsError");
            }

            @Override
            public void getObjectResult(Index index, String s, JSONObject jsonObject) {
                Log.d("Algolia", "getObjectResult");
            }

            @Override
            public void getObjectError(Index index, String s, AlgoliaException e) {
                Log.d("Algolia", "getObjectError");
            }

            @Override
            public void getObjectsResult(Index index, List<String> strings, JSONObject jsonObject) {
                Log.d("Algolia", "getObjectsResult");
            }

            @Override
            public void getObjectsError(Index index, List<String> strings, AlgoliaException e) {
                Log.d("Algolia", "getObjectsError");
            }

            @Override
            public void waitTaskResult(Index index, String s) {
                Log.d("Algolia", "waitTaskResult");
            }

            @Override
            public void waitTaskError(Index index, String s, AlgoliaException e) {
                Log.d("Algolia", "waitTaskError");
            }

            @Override
            public void getSettingsResult(Index index, JSONObject jsonObject) {
                Log.d("Algolia", "getSettingsResult");
            }

            @Override
            public void getSettingsError(Index index, AlgoliaException e) {
                Log.d("Algolia", "getSettingsError");
            }

            @Override
            public void setSettingsResult(Index index, JSONObject jsonObject, JSONObject jsonObject2) {
                Log.d("Algolia", "setSettingsResult");
            }

            @Override
            public void setSettingsError(Index index, JSONObject jsonObject, AlgoliaException e) {
                Log.d("Algolia", "setSettingsError");
            }
        };
    }

    /**
     * Parses the Json Object returned from Aloglia into Aloglia products model.
     *
     * @param jsonObject            the algolia result to be mapped to UI element
     * @param algoliaResultNotifier the result notifier
     * @param cityFilterKey         the city ID based on which filter will be applied
     */
    private void parseAlgoliaProductsList(JSONObject jsonObject, IAlgoliaResultNotifier algoliaResultNotifier, String cityFilterKey) {
        List<AlgoliaProductDataModel> algoliaProductDataModels = null;
        Log.d("Algolia", "Response: " + getPrettyPrintedJson(jsonObject.toString()));
        AlgoliaProductsFilterInfo filterInfo = new AlgoliaProductsFilterInfo();
        try {
            Gson gson = new Gson();

            //Parse the Algolia Products based on filter applied
            if (jsonObject.has("hits")) {
                JSONArray jsonArray = null;

                jsonArray = jsonObject.getJSONArray("hits");
                algoliaProductDataModels = new ArrayList<>(jsonArray.length());


                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject1 = jsonArray.getJSONObject(i);
                    AlgoliaProductDataModel data = gson.fromJson(jsonObject1.toString(), AlgoliaProductDataModel.class);
                    if (data.getCitiesMapping() != null) {
                        parseCitiesData(data.getCitiesMapping(), gson, data, cityFilterKey);
                    }

                    algoliaProductDataModels.add(data);
                }
            }

            if (jsonObject.has("nbHits")) {
                for (int i = 0; i < algoliaProductDataModels.size(); i++) {
                    algoliaProductDataModels.get(i).setNumberOfProducts(jsonObject.getInt("nbHits"));
                }
            }

            // Parse the Facets possible values
            if (jsonObject.has("facets")) {
                JSONObject facetsObject = jsonObject.getJSONObject("facets");
                if (facetsObject.has("brand_name")) {
                    parseBrands(facetsObject.getJSONObject("brand_name"), filterInfo.getBrandStatList());
                }

                if (facetsObject.has("category_details.primary_category.name")) {
                    parsePrimaryCategories(facetsObject.getJSONObject("category_details.primary_category.name"), filterInfo.getCategoryStatList());
                }
            }

            //Parse the Facets statistics values
            if (jsonObject.has("facets_stats")) {
                JSONObject facetsObject = jsonObject.getJSONObject("facets_stats");

                String salesPriceKey = "cities_mapping." + cityFilterKey + ".promotional_price_f";//".sales_price_f";
                if (facetsObject.has(salesPriceKey)) {
                    JSONObject salesObject = facetsObject.getJSONObject(salesPriceKey);
                    Log.d("STATS", "sales Stats object " + salesObject.toString());

                    if (salesObject != null) {
                        Stats salesStats = gson.fromJson(salesObject.toString(), Stats.class);
                        salesStats.setSelectedMax(salesStats.getMax());
                        salesStats.setSelectedMin(salesStats.getMin());
                        filterInfo.setSalesPriceStats(salesStats);


                        Log.d("STATS", "sales Stats object " + salesStats.getMin() + " , " + salesStats.getMax());
                    }
                }

                String discountKey = "cities_mapping." + cityFilterKey + ".discount_percent_f";
                if (facetsObject.has(discountKey)) {
                    JSONObject discountObject = facetsObject.getJSONObject(discountKey);
                    Log.d("STATS", "discount Stats object " + discountObject.toString());

                    if (discountObject != null) {
                        Stats discountStats = gson.fromJson(discountObject.toString(), Stats.class);
                        discountStats.setSelectedMax(discountStats.getMax());
                        discountStats.setSelectedMin(discountStats.getMin());
                        filterInfo.setDiscountStats(discountStats);

                        Log.d("STATS", "discount Stats object " + discountStats.getMin() + " , " + discountStats.getMax());
                    }
                }
            }

            algoliaResultNotifier.onResult(algoliaProductDataModels, filterInfo);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void parseBrands(JSONObject brandNameObject, List<FilterSelectionStats> brandStatsList) {
        if (brandNameObject != null) {
            Iterator<String> iterator = brandNameObject.keys();
            while (iterator.hasNext()) {
                FilterSelectionStats brandStats = new FilterSelectionStats();
                String key = iterator.next();
                brandStats.setHeader(key);
                brandStats.setIsSelected(false);

                brandStatsList.add(brandStats);

                Collections.sort(brandStatsList, new Comparator<FilterSelectionStats>() {
                    public int compare(FilterSelectionStats v1, FilterSelectionStats v2) {
                        return v1.getHeader().compareTo(v2.getHeader());
                    }
                });
            }
        }
    }

    private void parsePrimaryCategories(JSONObject primaryCategoryObject, List<FilterSelectionStats> primaryCategoryList) {
        if (primaryCategoryObject != null) {
            Iterator<String> iterator = primaryCategoryObject.keys();
            while (iterator.hasNext()) {
                FilterSelectionStats brandStats = new FilterSelectionStats();
                String key = iterator.next();
                brandStats.setHeader(key);
                brandStats.setIsSelected(false);

                primaryCategoryList.add(brandStats);

                Collections.sort(primaryCategoryList, new Comparator<FilterSelectionStats>() {
                    public int compare(FilterSelectionStats v1, FilterSelectionStats v2) {
                        return v1.getHeader().compareTo(v2.getHeader());
                    }
                });
            }
        }
    }

    private void parseCitiesData(JsonArray citiesMapping, Gson gson, AlgoliaProductDataModel data, String cityFilterKey) {
        for (JsonElement city : citiesMapping) {
            JsonObject object = city.getAsJsonObject().getAsJsonObject(cityFilterKey);
            if (object != null) {
                AlgoliaProductInfo productInfo = gson.fromJson(object.toString(), AlgoliaProductInfo.class);
                data.setAlgoliaProductInfo(productInfo);
                break;
            }
        }
    }

    private String getPrettyPrintedJson(String unformattedString) {
        String prettyJsonString;
        try {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            JsonParser jp = new JsonParser();
            JsonElement je = jp.parse(unformattedString);
            prettyJsonString = gson.toJson(je);

        } catch (JsonSyntaxException ex) {
            prettyJsonString = unformattedString;
        }
        return prettyJsonString;
    }
}

