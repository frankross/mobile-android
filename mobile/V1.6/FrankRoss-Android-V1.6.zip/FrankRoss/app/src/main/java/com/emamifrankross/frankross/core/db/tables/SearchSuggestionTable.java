/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.db.tables;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.emamifrankross.frankross.core.db.DBQuery;
import com.emamifrankross.frankross.core.db.DeleteQuery;
import com.emamifrankross.frankross.core.db.InsertQuery;
import com.emamifrankross.frankross.core.db.SelectQuery;
import com.emamifrankross.frankross.core.db.UpdateQuery;
import com.emamifrankross.frankross.core.db.dbmodels.SearchSuggestion;
import com.emamifrankross.frankross.utils.Log;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 13/8/15.
 * This table stores the recently search suggestions products searched from Algolia.
 */
public class SearchSuggestionTable extends BaseTable {
    public static final String COLUMN_KEY_VARIANT_ID = "variantId";
    public static final String COLUMN_KEY_VARIANT_NAME = "variantName";
    public static final String COLUMN_KEY_CATEGORY_ID = "categoryId";
    public static final String COLUMN_KEY_CATEGORY_NAME = "categoryName";
    public static final String COLUMN_KEY_GENERIC_KEYWORD = "genericKeyword";
    public static final String COLUMN_KEY_MANUFACTURER_NAME = "ManufacturerName";
    public static final String COLUMN_KEY_ICON_URL = "icon_url";
    public static final String COLUMN_KEY_IS_PHARMA = "isPharma";
    public static final String TABLE_SEARCH_SUGGESTION = "SearchSuggesstions";//other
    public static final String TABLE_SEARCH_SUGGESTION_OLD_TABLE = "SearchSuggestions";//1.4.1 fix
    private static final String TAG = SearchSuggestionTable.class.getSimpleName();
    private static final String CREATE_TABLE_USER_CONTACT_INFO = "CREATE TABLE IF NOT EXISTS "
            + TABLE_SEARCH_SUGGESTION
            + "("
            + COLUMN_KEY_VARIANT_ID
            + " INTEGER PRIMARY KEY , "
            + COLUMN_KEY_VARIANT_NAME
            + " TEXT , "
            + COLUMN_KEY_CATEGORY_ID
            + " INTEGER , "
            + COLUMN_KEY_CATEGORY_NAME
            + " TEXT , "
            + COLUMN_KEY_GENERIC_KEYWORD
            + " TEXT , "
            + COLUMN_KEY_MANUFACTURER_NAME
            + " TEXT , "
            + COLUMN_KEY_ICON_URL
            + " TEXT , "
            + COLUMN_KEY_IS_PHARMA
            + " BOOLEAN ) ";

    @Override
    public void create(SQLiteDatabase db) {
        super.create(db, CREATE_TABLE_USER_CONTACT_INFO);
        Log.d(TAG, CREATE_TABLE_USER_CONTACT_INFO);
    }

    @Override
    public void drop(SQLiteDatabase db) {
        super.drop(db, TABLE_SEARCH_SUGGESTION);
    }

    /**
     * Insert the recently searched algolia product into table
     *
     * @param db
     * @param query insert query to be used for inserting algolia product
     * @return
     * @throws ClassCastException
     * @throws ParseException
     */
    @Override
    public long insert(SQLiteDatabase db, DBQuery query) throws ClassCastException, ParseException {
        InsertQuery<SearchSuggestion> insertQuery = (InsertQuery<SearchSuggestion>) query;
        if (db != null) {
            SearchSuggestion suggestion = insertQuery.getValues();

            long result = db.replace(TABLE_SEARCH_SUGGESTION, null, getContentValues(suggestion));
            Log.d(TAG, "inserted = " + result);
        }
        return 0;
    }

    @Override
    public <T> T select(SQLiteDatabase db, DBQuery query) throws ClassCastException {
        Cursor cursor = null;
        SelectQuery selectQuery = (SelectQuery) query;

        if (db != null) {
            cursor = super.select(TABLE_SEARCH_SUGGESTION, db, selectQuery);

            if (cursor != null) {
                @SuppressWarnings("unchecked")
                T vlaue = (T) getSuggestionList(cursor);
                cursor.close();
                return vlaue;
            }
        }
        return null;
    }

    @Override
    public int update(SQLiteDatabase db, DBQuery query) throws ClassCastException, ParseException {
        UpdateQuery<SearchSuggestion> updateQuery = (UpdateQuery<SearchSuggestion>) query;

        if (db != null) {
            SearchSuggestion suggestion = updateQuery.getValues();

            return db.update(TABLE_SEARCH_SUGGESTION,
                    getContentValues(suggestion),
                    updateQuery.getWhereClause(), updateQuery.getWhereArgs());
        }
        return 0;
    }

    @Override
    public int delete(SQLiteDatabase db, DBQuery query) throws ClassCastException {
        DeleteQuery deleteQuery = (DeleteQuery) query;

        return db.delete(TABLE_SEARCH_SUGGESTION, deleteQuery.getWhereClause(), deleteQuery.getWhereArgs());
    }

    @Override
    public Object raw(SQLiteDatabase db, DBQuery query) {
        return -1;
    }

    private ContentValues getContentValues(SearchSuggestion suggestion) {
        ContentValues contentValues = new ContentValues();
        if (suggestion != null) {
            contentValues.put(COLUMN_KEY_VARIANT_ID, suggestion.getVariantId());
            contentValues.put(COLUMN_KEY_VARIANT_NAME, suggestion.getVariantName());
            contentValues.put(COLUMN_KEY_CATEGORY_ID, suggestion.getCategoryId());
            contentValues.put(COLUMN_KEY_CATEGORY_NAME, suggestion.getCategoryName());
            contentValues.put(COLUMN_KEY_GENERIC_KEYWORD, suggestion.getGenericKeyword());
            contentValues.put(COLUMN_KEY_ICON_URL, suggestion.getProductIconUrl());
            contentValues.put(COLUMN_KEY_MANUFACTURER_NAME, suggestion.getBrandOrManufacturerName());
            contentValues.put(COLUMN_KEY_IS_PHARMA, suggestion.isPharma());
        }

        return contentValues;
    }

    private List<SearchSuggestion> getSuggestionList(Cursor cursor) {

        ArrayList<SearchSuggestion> searchSuggestions = new ArrayList<>();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                SearchSuggestion searchSuggestion = new SearchSuggestion();

                searchSuggestion.setVariantId(cursor.getLong(cursor.getColumnIndex(COLUMN_KEY_VARIANT_ID)));
                searchSuggestion.setVariantName(cursor.getString(cursor.getColumnIndex(COLUMN_KEY_VARIANT_NAME)));
                searchSuggestion.setCategoryId((cursor.getLong(cursor.getColumnIndex(COLUMN_KEY_CATEGORY_ID))));
                searchSuggestion.setCategoryName(cursor.getString(cursor.getColumnIndex(COLUMN_KEY_CATEGORY_NAME)));
                searchSuggestion.setProductIconUrl(cursor.getString(cursor.getColumnIndex(COLUMN_KEY_ICON_URL)));
                searchSuggestion.setGenericKeyword(cursor.getString(cursor.getColumnIndex(COLUMN_KEY_GENERIC_KEYWORD)));
                searchSuggestion.setBrandOrManufacturerName(cursor.getString(cursor.getColumnIndex(COLUMN_KEY_MANUFACTURER_NAME)));
                searchSuggestion.setIsPharma(cursor.getInt(cursor.getColumnIndex(COLUMN_KEY_IS_PHARMA)) > 0);

                searchSuggestions.add(searchSuggestion);
            }
        }

        return searchSuggestions;
    }
}
