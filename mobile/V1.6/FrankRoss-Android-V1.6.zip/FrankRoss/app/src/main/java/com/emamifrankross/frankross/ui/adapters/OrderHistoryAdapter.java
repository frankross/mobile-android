/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiOrdersList;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.FrankRossDateUtils;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 14/7/15.
 * <p> Adapter class for Order History Section</p>
 * <p>Supports the One View Types </p>
 * <p> 1 : ORDER HISTORY ITEM VIEW TYPE </p>
 */
public class OrderHistoryAdapter extends BaseRecyclerAdapter {

    public OrderHistoryAdapter(@NonNull List<BaseRecyclerAdapter.IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<BaseRecyclerAdapter.RecyclerViewDataBinder> getViewDataBinders() {
        ArrayList<BaseRecyclerAdapter.RecyclerViewDataBinder> viewHolderTypes = new ArrayList<>(1);
        viewHolderTypes.add(new OrderHistoryViewHolderType());
        return viewHolderTypes;
    }

    /**
     * ORDER HISTORY ITEM VIEW TYPE
     */

    public static class OrderHistoryItem implements IViewType {

        public ApiOrdersList.Order order;

        @Override
        public int getViewType() {
            return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_VIEW_TYPE;
        }
    }

    private static class OrderHistoryViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mOrderHistoryOrderNumber;
        private RobotoTextView mOrderHistoryOrderDate;
        private RobotoTextView mOrderHistoryOrderDeliveryStatus;
        private RobotoTextView mOrderHistoryOrderProductName1;
        private RobotoTextView mOrderHistoryOrderProductName2;
        private RobotoTextView mProductMoreCount;
        private RobotoTextView mProductTotalAmt;

        private Button mReOrderBtn;
        private ImageView mOrderHistoryRemindOrderImage;
        private LinearLayout mOrderHistoryMoreCountLinLyt;

        public OrderHistoryViewHolder(View view) {
            super(view);
            mOrderHistoryRemindOrderImage = (ImageView) view.findViewById(R.id.order_history_remind_order_iv);
            mOrderHistoryOrderNumber = (RobotoTextView) view.findViewById(R.id.order_history_order_number_tv);
            mOrderHistoryOrderDate = (RobotoTextView) view.findViewById(R.id.order_history_date_tv);
            mOrderHistoryOrderDeliveryStatus = (RobotoTextView) view.findViewById(R.id.order_status_tv);
            mOrderHistoryOrderProductName1 = (RobotoTextView) view.findViewById(R.id.order_history_product_name1_tv);
            mOrderHistoryOrderProductName2 = (RobotoTextView) view.findViewById(R.id.order_history_product_name2_tv);
            mProductMoreCount = (RobotoTextView) view.findViewById(R.id.order_history_product_list_item_more_count_tv);
            mProductTotalAmt = (RobotoTextView) view.findViewById(R.id.order_history_product_total_amt_tv);
            mOrderHistoryMoreCountLinLyt = (LinearLayout) view.findViewById(R.id.order_history_more_count_linLyt);
            mReOrderBtn = (Button) view.findViewById(R.id.order_history_re_order_btn);
        }
    }

    private class OrderHistoryViewHolderType implements RecyclerViewDataBinder<OrderHistoryViewHolder,
            OrderHistoryItem> {
        @Override
        public OrderHistoryViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_history_order_info, parent, false);

            return new OrderHistoryViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(OrderHistoryViewHolder viewHolder, final OrderHistoryItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mOrderHistoryOrderNumber.setText(String.valueOf(data.order.getId()));
            viewHolder.mOrderHistoryOrderDate.setText(FrankRossDateUtils.getOrderFormattedDate(data.order.getConfirmedOn()));
            viewHolder.mOrderHistoryOrderDeliveryStatus.setText(Utils.getCapitalizedWords(data.order.getStateDisplayName()));
            viewHolder.mProductTotalAmt.setText(Utils.addRupeeSymbol(viewHolder.mProductTotalAmt.getContext(), "",
                    Utils.getFormattedDouble(data.order.getTotal())));
            viewHolder.mOrderHistoryRemindOrderImage.setVisibility((data.order.getReorderReminder()) ? View.VISIBLE : View.GONE);

            Context context = viewHolder.mReOrderBtn.getContext();
            if (data.order.getMismatched()) {
                viewHolder.mReOrderBtn.setVisibility(View.VISIBLE);
                viewHolder.mReOrderBtn.setText(context.getString(R.string.update));
            } else if (data.order.getReorderable()) {
                viewHolder.mReOrderBtn.setVisibility(View.VISIBLE);
                viewHolder.mReOrderBtn.setText(context.getString(R.string.re_order_btn_txt));
            } else {
                viewHolder.mReOrderBtn.setVisibility(View.GONE);
            }

            switch (data.order.getOrderItems().size()) {
                case 0:
                    viewHolder.mOrderHistoryOrderProductName1.setVisibility(View.GONE);
                    viewHolder.mOrderHistoryOrderProductName2.setVisibility(View.GONE);
                    viewHolder.mOrderHistoryMoreCountLinLyt.setVisibility(View.GONE);
                    break;
                case 1:
                    viewHolder.mOrderHistoryOrderProductName1.setVisibility(View.VISIBLE);
                    viewHolder.mOrderHistoryOrderProductName1.setText(data.order.getOrderItems().get(0).getVariantName());
                    viewHolder.mOrderHistoryOrderProductName2.setVisibility(View.GONE);
                    viewHolder.mOrderHistoryMoreCountLinLyt.setVisibility(View.GONE);
                    break;
                case 2:
                    viewHolder.mOrderHistoryOrderProductName1.setVisibility(View.VISIBLE);
                    viewHolder.mOrderHistoryOrderProductName2.setVisibility(View.VISIBLE);
                    viewHolder.mOrderHistoryOrderProductName1.setText(data.order.getOrderItems().get(0).getVariantName());
                    viewHolder.mOrderHistoryOrderProductName2.setText(data.order.getOrderItems().get(1).getVariantName());
                    viewHolder.mOrderHistoryMoreCountLinLyt.setVisibility(View.GONE);
                    break;
                default:
                    viewHolder.mOrderHistoryOrderProductName1.setVisibility(View.VISIBLE);
                    viewHolder.mOrderHistoryOrderProductName2.setVisibility(View.VISIBLE);
                    viewHolder.mOrderHistoryOrderProductName1.setText(data.order.getOrderItems().get(0).getVariantName());
                    viewHolder.mOrderHistoryOrderProductName2.setText(data.order.getOrderItems().get(1).getVariantName());
                    viewHolder.mProductMoreCount.setText(String.valueOf(data.order.getOrderItems().size() - 2));
                    viewHolder.mOrderHistoryMoreCountLinLyt.setVisibility(View.VISIBLE);
                    break;
            }

            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
                viewHolder.mReOrderBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_VIEW_TYPE;
        }
    }
}