/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiHomeBanner;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.AutoScrollViewPager;
import com.emamifrankross.frankross.ui.customviews.CirclePageIndicator;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.home.LooperService;
import com.emamifrankross.frankross.ui.viewmodels.CommonRecyclerHeaderViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.HorizontalRecyclerViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.ProductViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.BannerViewDataBinder;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 3/7/15.
 * <p/>
 * <p> Adapter class for Home Section</p>
 * <p>Supports the Nine View Types </p>
 * <p> 1 : UPLOAD PRESCRIPTION VIEW TYPE </p>
 * <p> 2 : DELIVERY STATUS VIEW PAGER VIEW TYPE </p>
 * <p> 3 : TOP OFFERS VIEW PAGER VIEW TYPE </p>
 * <p> 4 : COMMON HEADER VIEW TYPE </p>
 * <p> 5 : COMMON PRODUCT VIEW TYPE </p>
 * <p> 6 : COMMON BORDER VIEW TYPE </p>
 * <p> 7 : HORIZONTAL RECYCLER VIEW TYPE </p>
 * <p> 8 : FEATURED PRODUCTS VIEW TYPE</p>
 * <p> 9 : TOP OFFERS AUTO SCROLL VIEW TYPE </p>
 */
public class HomeRecyclerAdapter extends BaseRecyclerAdapter {

    private TopOffersAutoScrollViewDataBinder topOffersAutoScrollViewDataBinder;
    private static List<IAutoScroll> mAutoScrollList = new ArrayList<>(1);

    public HomeRecyclerAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
        mAutoScrollList.clear();
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewDataBinderList = new ArrayList<>(9);
        viewDataBinderList.add(new UploadPrescriptionViewDataBinder());
        viewDataBinderList.add(new DeliveryStatusPagerViewDataBinder());
        viewDataBinderList.add(new BannerViewDataBinder());
        viewDataBinderList.add(new CommonRecyclerHeaderViewDataBinder());
        viewDataBinderList.add(new ProductViewDataBinder());
        topOffersAutoScrollViewDataBinder = new TopOffersAutoScrollViewDataBinder();
        viewDataBinderList.add(topOffersAutoScrollViewDataBinder);
        viewDataBinderList.add(new RecyclerBorderDataBinder());
        viewDataBinderList.add(new HomeCategoriesFooterViewHolderType());
        viewDataBinderList.add(new FeaturedProductsViewHolderType());
        viewDataBinderList.add(new PharmacyCategoryAdapter.ViewMoreProductViewDataBinder());
        viewDataBinderList.add(new HorizontalRecyclerViewDataBinder());

        return viewDataBinderList;
    }

    public void onScrollNext() {
        for (IAutoScroll autoScroll : mAutoScrollList) {
            autoScroll.scrollNext();
        }
    }

    public void setLooperBinder(LooperService.LooperBinder looperBinder) {
        topOffersAutoScrollViewDataBinder.setLooperBinder(looperBinder);
    }

    /**
     * UPLOAD PRESCRIPTION VIEW TYPE
     */
    public static class UploadPrescriptionDataItem implements IViewType {

        public String searchLinLytTitle = "";

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.UPLOAD_PRESCRIPTION;
        }
    }

    private static class UploadPrescriptionViewHolder extends RecyclerView.ViewHolder {
        private LinearLayout mSearchLayout;
        private Button mUploadPrescriptionButton;
        private RobotoTextView mSearchTitle;

        public UploadPrescriptionViewHolder(View itemView) {
            super(itemView);
            mSearchLayout = (LinearLayout) itemView.findViewById(R.id.home_search_linLay);
            mUploadPrescriptionButton = (Button) itemView.findViewById(R.id.home_upload_button);
            mSearchTitle = (RobotoTextView) itemView.findViewById(R.id.home_search_linLay_title_tv);
        }
    }

    private static class UploadPrescriptionViewDataBinder implements
            RecyclerViewDataBinder<UploadPrescriptionViewHolder, UploadPrescriptionDataItem> {

        @Override
        public UploadPrescriptionViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_uplaod_prescription, parent, false);

            return new UploadPrescriptionViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(UploadPrescriptionViewHolder viewHolder,
                                         final UploadPrescriptionDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mSearchTitle.setText(TextUtils.isEmpty(data.searchLinLytTitle) ? viewHolder
                    .mSearchTitle.getContext().getString(R.string.search_medicines_and_other_products) : data.searchLinLytTitle);
            if (recyclerViewClickListener != null) {
                viewHolder.mSearchLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });

                viewHolder.mUploadPrescriptionButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.UPLOAD_PRESCRIPTION;
        }
    }

    /**
     * DELIVERY STATUS VIEW PAGER VIEW TYPE
     */
    public static class DeliveryStatusPagerDataItem implements IViewType {
        public List<Object> mDeliveryStatusPagerDataList;

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.DELIVERY_STATUS_VIEW_PAGER;
        }
    }

    private static class DeliveryStatusPagerViewHolder extends RecyclerView.ViewHolder {

        private ViewPager mDeliveryStatusViewPager;
        private CirclePageIndicator mPagerIndicator;

        public DeliveryStatusPagerViewHolder(View itemView) {
            super(itemView);
            mDeliveryStatusViewPager = (ViewPager) itemView.findViewById(R.id.home_delivery_status_pager);
            mDeliveryStatusViewPager.setAdapter(new DeliveryStatusAdapter());
            mPagerIndicator = (CirclePageIndicator) itemView.findViewById(R.id.home_delivery_status_pager_indicator);
            mPagerIndicator.getBackground().setAlpha((int) (0.7F * 255));
            mPagerIndicator.setViewPager(mDeliveryStatusViewPager);
        }
    }

    private static class DeliveryStatusPagerViewDataBinder implements
            RecyclerViewDataBinder<DeliveryStatusPagerViewHolder, DeliveryStatusPagerDataItem> {

        @Override
        public DeliveryStatusPagerViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_delivery_status, parent, false);
            return new DeliveryStatusPagerViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final DeliveryStatusPagerViewHolder viewHolder,
                                         DeliveryStatusPagerDataItem data, int position,
                                         RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mDeliveryStatusViewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
                @Override
                public void onPageSelected(int position) {
                    viewHolder.mPagerIndicator.setCurrentItem(position);
                }
            });
        }

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.DELIVERY_STATUS_VIEW_PAGER;
        }
    }

    /**
     * TOP OFFERS AUTO SCROLL VIEW TYPE
     */

    public static class TopOffersAutoScrollDataItem implements IViewType {
        public List<ApiHomeBanner.Banner> mBanner;
        public boolean isCached = false;
        public boolean isStoreBanner = false;

        @Override
        public int getViewType() {
            return ViewTypes.CommonViewType.TOP_OFFERS_VIEW_PAGER;
        }
    }

    public static class TopOffersAutoScrollViewHolder extends RecyclerView.ViewHolder {
        public AutoScrollViewPager mTopOffersViewPager;
        public CirclePageIndicator mTopOffersPagerIndicator;
        public FrameLayout mContainerLyt;

        public TopOffersAutoScrollViewHolder(View itemView) {
            super(itemView);
            mTopOffersViewPager = (AutoScrollViewPager) itemView.findViewById(R.id.home_top_offers_pager);
            mTopOffersPagerIndicator = (CirclePageIndicator) itemView.findViewById(R.id.top_offers_pager_indicator);
            mContainerLyt = (FrameLayout) itemView.findViewById(R.id.auto_scroll_view_pager_container_lyt);

            /*LinearLayout.LayoutParams containerLayoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (int) (0.28 * Utils.getDisplayHeight((Activity) mContainerLyt.getContext())));
            mContainerLyt.setLayoutParams(containerLayoutParams);*/
            //mContainerLyt.setBackgroundColor(mTopOffersViewPager.getContext().getResources().getColor(R.color.black_text_color));

            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (int) (0.23 * Utils.getDisplayHeight((Activity) mTopOffersViewPager.getContext())));
            mTopOffersViewPager.setLayoutParams(layoutParams);
            mTopOffersViewPager.setAutoScrollRequired(true);
            mTopOffersPagerIndicator.getBackground().setAlpha((int) (0.7F * 255));
        }
    }

    public static class TopOffersAutoScrollViewDataBinder implements
            RecyclerViewDataBinder<TopOffersAutoScrollViewHolder, TopOffersAutoScrollDataItem> {

        private LooperService.LooperBinder mLooperBinder = null;
        private IAutoScroll mAutoScroll = null;

        @Override
        public TopOffersAutoScrollViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_auto_scroll_view_pager, parent, false);

            return new TopOffersAutoScrollViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final TopOffersAutoScrollViewHolder viewHolder,
                                         final TopOffersAutoScrollDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            HomeBannerAdapter homeBannerAdapter = new HomeBannerAdapter(viewHolder.mTopOffersViewPager.getContext(),
                    true, data);
            homeBannerAdapter.setOnRecyclerItemClickListener(recyclerViewClickListener);
            viewHolder.mTopOffersViewPager.setAdapter(homeBannerAdapter);
            viewHolder.mTopOffersViewPager.setAdapterSize(homeBannerAdapter.getCount());
            viewHolder.mTopOffersViewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
                @Override
                public void onPageSelected(int position) {
                    super.onPageSelected(position);
                    if (mLooperBinder != null)
                        mLooperBinder.onPageChanged();
                }
            });
            mAutoScroll = viewHolder.mTopOffersViewPager.getAutoScrollNotifier();
            mAutoScrollList.add(mAutoScroll);
            viewHolder.mTopOffersPagerIndicator.setViewPager(viewHolder.mTopOffersViewPager);
        }

        @Override
        public int getViewType() {
            return ViewTypes.CommonViewType.TOP_OFFERS_VIEW_PAGER;
        }

        public void setLooperBinder(LooperService.LooperBinder looperBinder) {
            mLooperBinder = looperBinder;
        }
    }

    /**
     * HOME CATEGORIES FOOTER VIEW TYPE
     */
    public static class HomeCategoriesFooterDataItem implements IViewType {

        public String header;

        @Override
        public int getViewType() {
            return ViewTypes.CommonViewType.COMMON_FOOTER_TEXT;
        }
    }

    private static class HomeCategoriesFooterViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mCategoriesFooter;

        public HomeCategoriesFooterViewHolder(View itemView, Context context) {
            super(itemView);
            mCategoriesFooter = (RobotoTextView) itemView.findViewById(R.id.common_header_tv);
            mCategoriesFooter.setTextColor(ContextCompat.getColor(context, R.color.frankross_common_text_color));
            mCategoriesFooter.setRobotoFaceType(RobotoTextView.InputTypeFace.REGULAR);
            mCategoriesFooter.setText(context.getString(R.string.home_categories_view_all));
        }
    }

    private static class HomeCategoriesFooterViewHolderType implements
            RecyclerViewDataBinder<HomeCategoriesFooterViewHolder, HomeCategoriesFooterDataItem> {

        @Override
        public HomeCategoriesFooterViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.common_header_text_layout, parent, false);

            return new HomeCategoriesFooterViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(HomeCategoriesFooterViewHolder viewHolder,
                                         final HomeCategoriesFooterDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            if (recyclerViewClickListener != null) {
                viewHolder.mCategoriesFooter.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.CommonViewType.COMMON_FOOTER_TEXT;
        }
    }


    /**
     * FEATURED PRODUCTS VIEW TYPE
     */

    public static class FeaturedProductsDataItem implements BaseRecyclerAdapter.IViewType {

        public List<BaseRecyclerAdapter.IViewType> productDataModel = new ArrayList<>();

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.HOME_PRODUCT_ITEM;
        }
    }

    private static class FeaturedProductsViewHolder extends RecyclerView.ViewHolder {

        private ViewPager mFeaturedProductsViewPager;
        private CirclePageIndicator mFeaturedProductsPagerIndicator;

        public FeaturedProductsViewHolder(View itemView) {
            super(itemView);
            mFeaturedProductsViewPager = (ViewPager) itemView.findViewById(R.id.home_featured_products_pager);
            mFeaturedProductsPagerIndicator = (CirclePageIndicator) itemView.findViewById(R.id.home_featured_products_pager_indicator);

         /*   LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (int) (0.23 * Utils.getDisplayHeight((Activity) mFeaturedProductsViewPager.getContext())));
            mFeaturedProductsViewPager.setLayoutParams(layoutParams);*/
        }
    }

    public static class FeaturedProductsViewHolderType implements
            BaseRecyclerAdapter.RecyclerViewDataBinder<FeaturedProductsViewHolder, FeaturedProductsDataItem> {

        @Override
        public FeaturedProductsViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_featured_products, parent, false);

            return new FeaturedProductsViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final FeaturedProductsViewHolder viewHolder,
                                         final FeaturedProductsDataItem data, final int position,
                                         final BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {
            HomeFeaturedProductsAdapter homeFeaturedProductsAdapter = new HomeFeaturedProductsAdapter(data.productDataModel);
            viewHolder.mFeaturedProductsViewPager.setAdapter(homeFeaturedProductsAdapter);

            viewHolder.mFeaturedProductsPagerIndicator.getBackground().setAlpha((int) (0.7F * 255));
            viewHolder.mFeaturedProductsPagerIndicator.setViewPager(viewHolder.mFeaturedProductsViewPager);

            if (recyclerViewClickListener != null) {
                homeFeaturedProductsAdapter.setOnRecyclerItemClickListener(recyclerViewClickListener);
            }

            viewHolder.mFeaturedProductsViewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
                @Override
                public void onPageSelected(int position) {
                    viewHolder.mFeaturedProductsPagerIndicator.setCurrentItem(position);
                }
            });
        }

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.HOME_PRODUCT_ITEM;
        }
    }
}