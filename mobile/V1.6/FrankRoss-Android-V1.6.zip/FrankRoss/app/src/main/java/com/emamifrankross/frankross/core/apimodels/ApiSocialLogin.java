/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gauthami on 20/5/16.
 */
public class ApiSocialLogin {

    public static class Request {

        @SerializedName("user")
        private User user;

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        public User getUser() {
            return user;
        }

        public void setUser(User user) {
            this.user = user;
        }
    }

    public static class User {

        @SerializedName("token")
        private String token;

        @SerializedName("device_type")
        private String device_type = "Android";

        @SerializedName("social_login_uid")
        private String social_login_uid;

        @SerializedName("social_auth_token")
        private String social_auth_token;

        @SerializedName("social_login_provider")
        private String social_login_provider;

        public String getDevice_type() {
            return device_type;
        }

        public void setDevice_type(String device_type) {
            this.device_type = device_type;
        }

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public String getSocial_login_provider() {
            return social_login_provider;
        }

        public void setSocial_login_provider(String social_login_provider) {
            this.social_login_provider = social_login_provider;
        }

        public String getSocial_auth_token() {
            return social_auth_token;
        }

        public void setSocial_auth_token(String social_auth_token) {
            this.social_auth_token = social_auth_token;
        }

        public String getSocial_login_uid() {
            return social_login_uid;
        }

        public void setSocial_login_uid(String social_login_uid) {
            this.social_login_uid = social_login_uid;
        }
    }

    public static class ErrorResponse {

        @SerializedName("message")
        private String message;

        @SerializedName("error_code")
        private String error_code;

        @SerializedName("phone_number")
        private String phone_number;

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getError_code() {
            return error_code;
        }

        public void setError_code(String error_code) {
            this.error_code = error_code;
        }

        public String getPhone_number() {
            return phone_number;
        }

        public void setPhone_number(String phone_number) {
            this.phone_number = phone_number;
        }
    }
}
