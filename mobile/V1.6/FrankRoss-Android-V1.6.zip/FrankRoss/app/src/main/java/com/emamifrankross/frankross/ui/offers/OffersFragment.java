/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.offers;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.OffersAdapter;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.common.WebViewFragment;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.pharmacy.ProductListingActivity;
import com.emamifrankross.frankross.ui.search.SearchActivity;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by gauthami on 5/1/16.
 */

/**
 * This class represents the UI for Offers screen
 */
public class OffersFragment extends ApiRequestBaseFragment implements
        BaseRecyclerAdapter.RecyclerItemClickListener, IToolbar {

    private OffersAdapter mOffersRecyclerAdapter;
    private ArrayList<BaseRecyclerAdapter.IViewType> mOffersScreenData = new ArrayList<>();
    private RobotoTextView mEmptyView;

    public static OffersFragment create() {
        return new OffersFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mOffersRecyclerAdapter = new OffersAdapter(mOffersScreenData);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.OFFERS_SCREEN_VISIT_EVENT);
        performOffersRequest();
    }

    /**
     * Method that requests for Offers
     */
    private void performOffersRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetOffersListRequest(new ApiRequestManager.IOffersResultNotifier() {
            @Override
            public void onOffersFetched(List<BaseRecyclerAdapter.IViewType> offersList) {
                mFragmentInteractionListener.hideBlockingProgressBar();

                if (offersList != null && !offersList.isEmpty()) {
                    mOffersScreenData.clear();
                    mOffersScreenData.addAll(offersList);
                    mOffersRecyclerAdapter.notifyDataSetChanged();
                } else {
                    mEmptyView.setText(getString(R.string.offers_not_found));
                    mEmptyView.setVisibility(View.VISIBLE);
                }
            }
        }, this, this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_store_locator, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initStoreLocatorRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the offers views
     *
     * @param view the view that is associated to the Offers
     */
    private void initStoreLocatorRecyclerView(View view) {
        RecyclerView offersRecyclerView = (RecyclerView) view.findViewById(R.id.store_locator_container);
        offersRecyclerView.setHasFixedSize(false);
        offersRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mOffersRecyclerAdapter.setRecyclerItemClickListener(this);
        offersRecyclerView.setAdapter(mOffersRecyclerAdapter);

        mEmptyView = (RobotoTextView) view.findViewById(R.id.store_locator_empty_view_tv);
        mEmptyView.setText(getString(R.string.offers_not_found));
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {
            case ViewTypes.OffersViewType.OFFER_ITEM_VIEW_TYPE:
                if (view.getId() == R.id.offers_item_background_linLyt) {
                    OffersAdapter.OffersDataItem offersDataItem = (OffersAdapter.OffersDataItem) object;
                    //click on offer item
                    FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.OFFERS_TAP_EVENT);
                    offersCopyToClipboard(((OffersAdapter.OffersDataItem) object).offerPromoCode);
                    handleItemClick(offersDataItem.listable, offersDataItem.offerWebUrl,
                            offersDataItem.offerPromotionId);
                }
                break;
        }
    }

    /**
     * Method to handle the promo code click
     *
     * @param promoCode the promo code that has to be copied to clipboard
     */
    private void offersCopyToClipboard(String promoCode) {
        if (!TextUtils.isEmpty(promoCode)) {
            Utils.copyToClipboard(promoCode, getActivity());
            Toast.makeText(getActivity(), "Coupon code " + promoCode + " is copied to clipboard",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Method to handle the Banner image click
     *
     * @param listable    the flag that determines if the Product listing has to be shown
     * @param webUrl      the web page url for promotional details
     * @param promotionId the promotional ID for each offer
     */
    private void handleItemClick(boolean listable, String webUrl, long promotionId) {
        if (promotionId != 0 && listable) {
            startActivity(ProductListingActivity.getActivityIntentForHomePromotionalProducts(getActivity().getApplicationContext(),
                    ProductListingActivity.PROMOTIONAL_PRODUCTS_FRAGMENT_ID, promotionId));
            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);

        } else if (!TextUtils.isEmpty(webUrl)) {
            mFragmentInteractionListener.loadFragment(getId(),
                    WebViewFragment.create(webUrl,
                            getString(R.string.home_promotion_details)),
                    null, R.anim.push_left_in, R.anim.fade_out,
                    FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());

        mApiRequestManager.registerCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());

        mApiRequestManager.unregisterCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_offers);
    }

    @Override
    public int getToolbarMenuId() {
        return R.menu.menu_pharmacy;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_search:
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_FROM_TOOLBAR_EVENT);
                        startActivity(new Intent(getActivity(), SearchActivity.class));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;

                    case R.id.action_cart:
                        Map<String, String> cartClickData = Utils.cartToolbarClickDataForAnalytics(Constants.OFFERS_SCREEN_NAME,
                                FrankRossEvents.VIEW_CART_FROM_TOOLBAR_SCREEN_NAME);
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_CART_FROM_TOOLBAR_EVENT, cartClickData);
                        startActivity(CartActivity.getActivityIntent(getActivity().getApplicationContext()
                                , CartActivity.CART_FRAGMENT_ID));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;
                }
                return false;
            }
        };
    }
}
