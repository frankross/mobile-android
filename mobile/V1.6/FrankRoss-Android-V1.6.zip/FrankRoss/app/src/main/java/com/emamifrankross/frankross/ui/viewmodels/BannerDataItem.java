/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */
package com.emamifrankross.frankross.ui.viewmodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;

import java.util.List;

/**
 * Created by gowtham on 6/11/15.
 */

/**
 * COMMON VIEW PAGER DATA ITEM WITH CIRCLE INDICATOR
 */
public class BannerDataItem implements BaseRecyclerAdapter.IViewType {

    public String promotionId = "";
    public String promotionUrl = "";
    public List<String> mBannerPromotionIds;
    public List<String> mBannerImages;
    public List<String> mPromotionId;

    @Override
    public int getViewType() {
        return ViewTypes.CommonViewType.TOP_OFFERS_VIEW_PAGER;
    }
}
