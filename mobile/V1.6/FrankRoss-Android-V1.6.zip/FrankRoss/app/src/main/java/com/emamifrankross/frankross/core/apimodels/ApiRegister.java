/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 15/7/15.
 */
public class ApiRegister {

    public static class Request {
        @SerializedName("user")
        private User user;

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        public User getUser() {
            return user;
        }

        public void setUser(User user) {
            this.user = user;
        }

        public static class User {

            @SerializedName("name")
            private String name;

            @SerializedName("email")
            private String email;

            @SerializedName("password")
            private String password;

            @SerializedName("primary_phone")
            private String primaryPhone;

            @SerializedName("primary_phone_type")
            private String primaryPhoneType;


            public String getEmail() {
                return email;
            }

            public void setEmail(String email) {
                this.email = email;
            }

            public String getPassword() {
                return password;
            }

            public void setPassword(String password) {
                this.password = password;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public String getPrimaryPhone() {
                return primaryPhone;
            }

            public void setPrimaryPhone(String primaryPhone) {
                this.primaryPhone = primaryPhone;
            }

            public String getPrimaryPhoneType() {
                return primaryPhoneType;
            }

            public void setPrimaryPhoneType(String primaryPhoneType) {
                this.primaryPhoneType = primaryPhoneType;
            }
        }
    }

    public static class Response {

        @SerializedName("message")
        private String message = "Registration Completed";

        @SerializedName("otp_verified")
        private boolean otpVerified = false;

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public boolean isOtpVerified() {
            return otpVerified;
        }

        public void setOtpVerified(boolean otpVerified) {
            this.otpVerified = otpVerified;
        }
    }
}
