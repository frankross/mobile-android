/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.sdkmanager;

/**
 * This class manages the Flurry events and its respective key values
 */
public class FrankRossEvents {

    /**
     * STAGE 1 ANALYTICS EVENTS
     */
    public static final String APP_LAUNCH_EVENT = "App_Launched";
    public static final String USER_REGISTRATION_EVENT = "App_Registration";
    public static final String USER_REGISTRATION_ORDER_FLOW_EVENT = "Throug_Order_Registration";
    public static final String UPLOAD_PRESCRIPTION_EVENT = "Upload_Prescription";
    public static final String FILTER_APPLY_EVENT = "Filter_Applied";
    public static final String SORT_APPLY_EVENT = "Sort_Applied";
    public static final String ORDER_PLACEMENT_EVENT = "Place_Order";
    public static final String UPDATE_ORDER_EVENT = "Update_Order";
    public static final String PHARMA_PDP_VISIT_EVENT = "Pharma_PDP_Visited";
    public static final String NON_PHARMA_PDP_VISIT_EVENT = " Non_Pharma_PDP_Visited";
    public static final String RE_ORDER_FROM_HISTORY_EVENT = "Reorder_From_List";
    public static final String RE_ORDER_FROM_DERAIL_EVENT = "Reorder_From_Detail";
    public static final String ORDER_FROM_PRESCRIPTION_EVENT = "Order_From_Prescription";
    public static final String ORDER_CANCEL_EVENT = "Order_Cancel";
    public static final String ORDER_RETURN_EVENT = "Order_Return";
    public static final String STORE_LOCATOR_LAUNCH_EVENT = "Store_Locator";
    public static final String SUPPORT_CALL_EVENT = "Support_Call";
    public static final String DELIVERY_SLOT_SELECT_EVENT = "Delivery_Slot_Selected";
    public static final String ADD_NEW_DELIVERY_ADDRESS_EVENT = "Address_Add";
    public static final String DELETE_DELIVERY_ADDRESS_EVENT = "Address_Delete";
    public static final String EDIT_DELIVERY_ADDRESS_EVENT = "Address_Edit";
    public static final String STORE_LOCATOR_LOCATION_CHANGE = "Location_Changed";
    public static final String PHARMACY_CATEGORIES = "Categories";//parameter required
    public static final String PHARMACY_CATEGORY_NAME = "Category_Name";

    public static final String TIME_SPENT_HOME_SCREEN_EVENT = "Home_Screen_Time_Spend";
    public static final String TIME_SPENT_CATEGORY_SCREEN_EVENT = "Categories_Screen_Time_Spend";

    /**
     * STAGE 2 ANALYTICS EVENTS
     */
    public static final String VIEW_CART_FROM_TOOLBAR_EVENT = "Cart_Tapped";//parameter required
    public static final String VIEW_CART_FROM_TOOLBAR_SCREEN_NAME = "Cart_Tapped_Screen_Name";
    public static final String HOME_BANNER_TAP_EVENT = "Home_Page_Banner_Tapped";
    public static final String HOME_STORE_BANNER_TAP_EVENT = "Home_Store_Banner_Tapped";
    public static final String CATEGORY_BANNER_TAP_EVENT = "Category_Page_Banner_Tapped";
    public static final String HOME_FEATURED_PRODUCTS_TAP_EVENT = "Home_Featured_Product_Tapped";
    public static final String CATEGORY_FEATURED_PRODUCTS_TAP_EVENT = "Category_Featured_Product_Tapped";
    public static final String CATEGORY_SHOP_BY_BRAND_TAP_EVENT = "Category_Shopby_Brand_Tapped";
    public static final String PUSH_NOTIFICATION_TAP_EVENT = "Push_Notification_Tapped";
    public static final String SUPPORT_SCREEN_VISIT_EVENT = "Support_Screen_Visited";
    public static final String SEARCH_RESULT_SCREEN_VISIT_EVENT = "Search_Result_Screen_Visited";
    public static final String SEARCH_SCREEN_VISIT_EVENT = "Search_Screen_Visited";
    public static final String QUANTITY_SELECTION_SCREEN_VISIT_EVENT = "Quantity_Selection_Screen_Visited";
    public static final String CHECKOUT_ADDRESS_SELECTION_SCREEN_VISIT_EVENT = "Address_Selection_Screen_Visited";
    public static final String ADD_ADDRESS_SCREEN_VISIT_EVENT = "Add_Address_Screen_Visited";
    public static final String ADD_TO_CART_FROM_LISTING = "Add_To_Cart_Product_List";
    public static final String ADD_TO_CART_FROM_PDP = "Add_To_Cart_PDP";
    public static final String SEARCH_BAR_TAP_EVENT = "Search_Bar_Tapped";//parameter required
    public static final String SEARCH_BAR_SCREEN_NAME_EVENT = "Search_Bar_Name";
    public static final String CATEGORY_LEVEL2_TAP_EVENT = "Category_Level2_Tapped";//parameter required
    public static final String CATEGORY_LEVEL2_NAME_EVENT = "Category_Level2_Name";
    public static final String CATEGORY_LEVEL3_TAP_EVENT = "Category_Level3_Tapped";//parameter required
    public static final String CATEGORY_LEVEL3_NAME_EVENT = "Category_Level3_Name";
    public static final String ORDER_TAP_EVENT = "Order_Tapped";
    public static final String PDP_LAUNCH_FROM_ORDER_DETAIL_EVENT = "PDP_From_Order_Detail";
    public static final String PRESCRIPTION_TAP_EVENT = "Prescription_Tapped";
    public static final String SEARCH_AUTO_SUGGESTION_TAP_EVENT = "Auto_Suggestion_Tapped";
    public static final String QUANTITY_SELECTION_DONE_TAP_EVENT = "Quantity_Done_Tapped";
    public static final String SEARCH_FROM_TOOLBAR_EVENT = "Search_Icon_Tapped";
    public static final String MY_ACCOUNT_EVENT = "MyAccount_Tapped";
    public static final String PLACE_ORDER_TAP_EVENT = "Cart_Place_Order";
    public static final String UPLOAD_PRESCRIPTION_NOW_EVENT = "Prescription_Upload_Now";
    public static final String AT_TIME_OF_DELIVERY_CLICK_EVENT = "Prescription_Time_Of_Delivery";
    public static final String CONFIRM_ORDER_CLICK_EVENT = "Order_Confirm";
    public static final String FORGOT_PASSWORD_CLICK_EVENT = "Forgot_Password_tapped";
    public static final String REGISTER_CLICK_EVENT = "Register_Tapped";
    public static final String CANCEL_FROM_REGISTRATION_SCREEN_EVENT = "Registration_Cancel";
    public static final String NEXT_FROM_REGISTER_SCREEN_EVENT = "Registration_Next";
    public static final String SUBMIT_OTP_CLICK_EVENT = "OTP_Submit";
    public static final String UPLOAD_PRESCRIPTION_FROM_HOME_EVENT = "Prescription_Upload_Home";
    public static final String CLICK_A_PHOTO_EVENT = "Prescription_From_Camera";
    public static final String ADD_FROM_GALLERY_EVENT = "Prescription_From_Gallery";
    public static final String UPLOAD_PRESCRIPTION_DONE_CLICK_EVENT = "Prescription_Done";
    public static final String UPLOAD_PRESCRIPTION_SUBMIT_CLICK_EVENT = "Prescription_Submit";
    public static final String UPLOAD_ANOTHER_PRESCRIPTION_CLICK_EVENT = "Prescription_Add_Another";

    public static final String TIME_SPENT_ORDER_DETAILS_SCREEN_EVENT = "Order_Detail_Time_Spend";
    public static final String TIME_SPENT_CART_SCREEN_EVENT = "Cart_Screen_Time_Spend";
    public static final String TIME_SPENT_DELIVERY_ADDRESS_SCREEN_EVENT = "DeliveryAddress_Screen_Time_Spend";
    public static final String TIME_SPENT_SUMMARY_SCREEN_EVENT = "Summary_Screen_Time_Spend";
    public static final String TIME_SPENT_REGISTRATION_SCREEN_EVENT = "Registration_Screen_Time_Spend";
    public static final String TIME_SPENT_SIGN_IN_SCREEN_EVENT = "SignIn_Screen_Time_Spend";
    public static final String TIME_SPENT_OTP_SCREEN_EVENT = "OTP_Screen_Time_Spend";
    public static final String TIME_SPENT_ENTER_MOBILE_NUMBER_SCREEN_EVENT = "Mobile_Number_Screen_Time_Spend";

    /**
     * Drawer tap events
     */
    public static final String HOME_DRAWER_TAP_EVENT = "Menu_Home_Tapped";
    public static final String CATEGORIES_DRAWER_TAP_EVENT = "Menu_Shop_By_Categories_Tapped";
    public static final String MY_ORDER_DRAWER_TAP_EVENT = "Menu_My_Orders_Tapped";
    public static final String MY_PRESCRIPTIONS_TAP_EVENT = "Menu_My_Prescriptions_Tapped";
    public static final String SUPPORT_DRAWER_TAP_EVENT = "Menu_Support_Tapped";
    public static final String STORE_LOCATOR_DRAWER_TAP_EVENT = "Menu_Store_Locator_Tapped";
    public static final String PRIVACY_POLICY_DRAWER_TAP_EVENT = "Menu_Privacy_Policy_Tapped";

    public static final String COUPON_CODE_APPLIED_EVENT = "Coupon_Code_Applied";
    public static final String DELIVERY_SLOT_SCREEN_VISIT_EVENT = "Delivery_Slot_Screen_Visited";
    public static final String UPLOAD_PRESCRIPTION_SCREEN_VISIT_EVENT = "Upload_Prescription_Screen_Visited";
    public static final String SIGN_IN_TAP_EVENT = "Sign_In_Tapped";
    public static final String CATEGORIES_FROM_HOME_TAP_EVENT = "Categories_Tapped_From_Home";
    public static final String VIEW_MORE_CATEGORIES_TAP_EVENT = "View_More_Categories";
    public static final String VIEW_MORE_CATEGORIES_FEATURED_PRODUCTS_TAP_EVENT = "View_More_Featured_Products_From_Category";
    public static final String VIEW_MORE_HOME_FEATURED_PRODUCTS_TAP_EVENT = "View_More_Featured_Products_From_Home";
    public static final String REGISTRATION_COMPLETE_EVENT = "Registration_Completed";
    public static final String ACCOUNT_SCREEN_VISIT_EVENT = "Account_Screen_Visited";

    public static final String TIME_SPENT_ORDER_HISTORY_EVENT = "Order_History_Time_Spend";
    public static final String TIME_SPENT_PRESCRIPTIONS_EVENT = "Prescriptions_Time_Spend";
    public static final String TIME_SPENT_PRESCRIPTION_DETAILS_EVENT = "Prescription_Detail_Time_Spend";
    public static final String TIME_SPENT_PRODUCT_LISTING = "Product_Listing_Time_Spend";

    /**
     * SCREEN VISIT EVENTS INSTEAD OF TIMED EVENT
     */
    public static final String ORDER_HISTORY_VISIT_EVENT = "Order_History_Screen_Visited";
    public static final String ORDER_DETAILS_VISIT_EVENT = "Order_Details_Screen_Visited";
    public static final String PRESCRIPTIONS_VISIT_EVENT = "Prescriptions_Screen_Visited";
    public static final String PRESCRIPTION_DETAILS_VISIT_EVENT = "Prescription_Details_Screen_Visited";
    public static final String CART_SCREEN_VISIT_EVENT = "Cart_Screen_Visited";
    public static final String PRODUCT_LISTING_VISIT_EVENT = "Product_Listing_Screen_Visited";
    public static final String ENTER_OTP_VISIT_EVENT = "Enter_OTP_Screen_Visited";
    public static final String ENTER_MOBILE_NUMBER_VISIT_EVENT = "Enter_Mobile_Number_Screen_Visited";
    public static final String SIGN_IN_VISIT_EVENT = "Sign_In_Screen_Visited";
    public static final String CHECKOUT_SUMMARY_VISIT_EVENT = "Checkout_Summary_Screen_Visited";
    public static final String CHECKOUT_DELIVERY_ADDRESS_VISIT_EVENT = "Checkout_Delivery_Address_Screen_Visited";
    public static final String REGISTER_VISIT_EVENT = "Register_Screen_Visited";
    public static final String HOME_SCREEN_VISIT_EVENT = "Home_Screen_Visited";
    public static final String CATEGORIES_SCREEN_VISIT_EVENT = "Categories_Screen_Visited";

    /**
     * APP V1.3 EVENTS
     */
    public static final String OFFERS_SCREEN_VISIT_EVENT = "Offers_Screen_Visited";
    public static final String OFFERS_TAP_EVENT = "Offer_Tapped";
    public static final String FAQ_TOPIC_SCREEN_VISIT_EVENT = "FAQ_Topic_Screen_Visited";
    public static final String FAQ_VISIT_EVENT = "FAQ_Screen_Visited";//TOPIC ID
    public static final String FAQ_TOPIC_ID = "Faq_Topic_Id ";//TOPIC ID
    public static final String FRANK_ROSS_WALLET_VISIT_EVENT = "FR_Wallet_Screen_Visited";
    public static final String PAYTM_TRANSACTION_SUCCESS_EVENT = "Paytm_Transaction_Success";
    public static final String PAYTM_TRANSACTION_FAILURE_EVENT = "Paytm_Transaction_Fail";
    public static final String PAYTM_TRANSACTION_BACK_PRESS_EVENT = "Paytm_Transaction_Cancel";
    public static final String PAYMENT_METHOD_SELECTED = "Payment_Mode";//SELECTED PAYMENT METHOD
    public static final String WALLET_STATE = "Wallet_State ";//WALLET STATE

    /**
     * APP V1.3.1 EVENTS
     */
    public static final String OFFERS_DRAWER_TAP_EVENT = "Menu_Offers_Tapped";
    public static final String FRANK_ROSS_WALLET_DRAWER_TAP_EVENT = "Menu_Frank_Ross_Wallet_Tapped";
    public static final String REFER_FRIEND_DRAWER_TAP_EVENT = "Menu_Refer_Friend_Tapped";
    public static final String REFER_FRIEND_SCREEN_VISIT_EVENT = "Refer_Friend_Screen_Visited";
    public static final String REFER_FRIEND_HOW_IT_WORKS_TAP_EVENT = "How_It_Works_Tapped";
    public static final String REFER_FRIEND_INVITE_FRIENDS_TAP_EVENT = "Invite_Friends_Tapped";
    public static final String SOCIAL_SIGNIN_FACEBOOK_TAP_EVENT = "Social_Login_Facebook_Tapped";
    public static final String SOCIAL_SIGNIN_GOOGLE_TAP_EVENT = "Social_Login_Google_Tapped";
    public static final String SOCIAL_SIGNIN_FACEBOOK_SUCCESS_EVENT = "Facebook_Sign_In_Success";
    public static final String SOCIAL_SIGNIN_GOOGLE_SUCCESS_EVENT = "Google_Sign_In_Success";
    public static final String SOCIAL_REGISTRATION_FACEBOOK_SUCCESS_EVENT = "Facebook_Register_Success";
    public static final String SOCIAL_REGISTRATION_GOOGLE_SUCCESS_EVENT = "Google_Register_Success";
    public static final String PAYMENT_RETRY_CONTINUE_TAP_EVENT = "Retry_Continue_Tapped";
    public static final String PAYMENT_RETRY_CANCEL_TAP_EVENT = "Retry_Cancel_Tapped";
    public static final String REFER_FRIEND_SUCCESS_EVENT = "Refer_Friend_Success";

    /**
     * APP 1.5 EVENTS
     */
    public static final String NOTIFY_ME_TAP_EVENT = "Notify_Me_tapped";//NOTIFY_ME_USER_CONFIRMATION
    public static final String NOTIFY_ME_USER_CONFIRMATION = "Notify_Me_User_Type";
    public static final String NOTIFY_ME_CONFIRM_TAP_EVENT = "Notify_Me_confirmation_tapped";
    public static final String HEALTH_ARTICLES_DRAWER_TAP_EVENT = "Menu_Health_Article_Tapped";
    public static final String PDP_SHARING_TAP_EVENT = "PDP_sharing_tapped";
    public static final String PDP_SHARING_MEDIUM_TAP_EVENT = "PDP_sharing_medium_tapped";//SHARING_MEDIUM
    public static final String ORDER_SHARING_FB_TAP_EVENT = "Order_sharing_FB_tapped";
    public static final String ORDER_SHARING_GPLUS_TAP_EVENT = "Order_sharing_Gplus_tapped";
    public static final String ORDER_SHARING_TWITTER_TAP_EVENT = "Order_sharing_Twitter_tapped";
    public static final String ORDER_SHARING_WHATSAPP_TAP_EVENT = "Order_sharing_Whatsapp_tapped";
    public static final String ORDER_SHARING_MORE_TAP_EVENT = "Order_sharing_more_tapped";
    public static final String ORDER_SHARING_MORE_MEDIUM_TAP_EVENT = "Order_sharing_more_medium_tapped ";//SHARING_MEDIUM
    public static final String SHARING_MEDIUM = "Sharing_Channel";
}
