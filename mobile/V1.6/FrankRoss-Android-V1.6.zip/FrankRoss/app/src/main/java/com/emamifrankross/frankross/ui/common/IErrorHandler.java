/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

/**
 * Created by gowtham on 9/7/15.
 */
public interface IErrorHandler {
    <T> void handleError(AlertError<T> alertError, int statusCode);

    void handleCommonError(int errorResourceId);
}
