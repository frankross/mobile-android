/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.checkout;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.home.HomeActivity;

/**
 * Created by gauthami on 21/10/15.
 */

/**
 * This class manages the Checkout success flow fragment transactions based on the intents and its data
 */
public class CheckOutSuccessActivity extends BaseActivity {

    private static final String EXTRA_ORDER_ID = "orderId";
    private static final String EXTRA_IS_ORDER_UPDATE = "isOrderUpdate";
    private static final String EXTRA_PAYMENT_METHOD = "payment_method";

    public static Intent getActivityIntent(Context context, long orderId, boolean isOrderUpdate,
                                           String paymentMethod) {
        Intent intent = new Intent(context, CheckOutSuccessActivity.class);
        intent.putExtra(EXTRA_ORDER_ID, orderId);
        intent.putExtra(EXTRA_IS_ORDER_UPDATE, isOrderUpdate);
        intent.putExtra(EXTRA_PAYMENT_METHOD, paymentMethod);

        return intent;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getIntent() != null) {
            long orderId = getIntent().getLongExtra(EXTRA_ORDER_ID, -1);
            boolean isOrderUpdate = getIntent().getBooleanExtra(EXTRA_IS_ORDER_UPDATE, false);
            String paymentMethod = getIntent().getStringExtra(EXTRA_PAYMENT_METHOD);

            loadFragment(getFragmentContainerId(), CheckOutSuccessFragment.create(orderId,
                    isOrderUpdate, paymentMethod),
                    null, R.anim.push_left_in, R.anim.push_left_out,
                    BaseFragment.FragmentTransactionType.ADD);
        }
    }

    @Override
    public void onBackPressed() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(getFragmentContainerId());

        if (fragment instanceof CheckOutSuccessFragment) {
            startActivity(HomeActivity.getActivityIntent(this, HomeActivity.HOME_FRAGMENT_TAG));
            this.overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        } else {
            super.onBackPressed();
        }
    }
}
