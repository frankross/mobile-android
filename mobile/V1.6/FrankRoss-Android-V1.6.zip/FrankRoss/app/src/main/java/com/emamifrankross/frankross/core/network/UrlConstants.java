/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.network;

import android.content.Context;

import com.emamifrankross.frankross.FrankRossApplication;
import com.emamifrankross.frankross.utils.PreferenceUtils;

/**
 * This class manages the Base urls and the switching between staging and live mode
 */
public class UrlConstants {

    public static final String BASE_URL_STAGING = "https://staging.frankross.in";
    public static final String PRIVACY_URL = "https://www.frankross.in/privacy_policy.html";
    public static final String ALGOLIA_STAGING_SUFFIX = "staging_1_";
    public static final String ALGOLIA_PRODUCTION_SUFFIX = "production";
    //public static final String BASE_URL_STAGING = "https://frankross-pr-1048.herokuapp.com";
    //public static final String BASE_URL_STAGING = "http://frankross-pr-1091.herokuapp.com";
    //public static final String BASE_URL_STAGING = "http://staging.new.frankross.in";
    private static final String BASE_URL_PRODUCTION = "https://www.frankross.in";
    private static final String HEALTH_ARTICLES_URL = "http://blog.frankross.in?dv=1";
    private static final String EMERGENCY_URL = "https://s3-ap-southeast-1.amazonaws.com/emami-images-2/EmergencyServices/ambulance.html";
    public static boolean DEV_MODE = true;
    /**
     * PAYTM URLs
     */
    public static final String PAYTM_CHECKSUM_GENERATION_URL = getBaseUrl() + "/paytm/generate_checksum";
    public static final String PAYTM_CHECKSUM_VALIDATION_URL = getBaseUrl() + "/paytm/verify_checksum";
    public static boolean ACCEPT_ALL_CERTIFICATES = DEV_MODE;
    public static String API_VERSION = "v8";

    public static void initUrls() {
        Context appContext = FrankRossApplication.getFrankrossApplicationContext();
        PreferenceUtils.saveStringIntoSharedPreference(appContext, PreferenceUtils.PREFERENCE_KEY_API_STAGING_URL, BASE_URL_STAGING);
        PreferenceUtils.saveStringIntoSharedPreference(appContext, PreferenceUtils.PREFERENCE_KEY_PRIVACY_URL, PRIVACY_URL);
        PreferenceUtils.saveStringIntoSharedPreference(appContext, PreferenceUtils.PREFERENCE_KEY_ALGOLIA_SUFFIX, ALGOLIA_STAGING_SUFFIX);
    }

    public static String getBaseUrl() {
        return (DEV_MODE) ? /*getStagingBaseUrl()*/ BASE_URL_STAGING : BASE_URL_PRODUCTION;
    }

    public static String getStagingBaseUrl() {
        return PreferenceUtils.getStringFromSharedPreference(FrankRossApplication.getFrankrossApplicationContext(),
                PreferenceUtils.PREFERENCE_KEY_API_STAGING_URL);
    }

    public static String getPrivacyUrl() {
        return PreferenceUtils.getStringFromSharedPreference(FrankRossApplication.getFrankrossApplicationContext(),
                PreferenceUtils.PREFERENCE_KEY_PRIVACY_URL);
    }

    public static String getAlgoliaSuffix() {
        if (DEV_MODE) {
            return PreferenceUtils.getStringFromSharedPreference(FrankRossApplication.getFrankrossApplicationContext(),
                    PreferenceUtils.PREFERENCE_KEY_ALGOLIA_SUFFIX);
        } else {
            return ALGOLIA_PRODUCTION_SUFFIX;
        }
    }

    public static String getHealthArticlesUrl() {
        return HEALTH_ARTICLES_URL;
    }

    public static String getEmergencyUrl() {
        return EMERGENCY_URL;
    }
}
