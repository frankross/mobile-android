/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.pharmacy.ProductListingFragment;

/**
 * Created by gauthami on 1/4/16.
 */
public class WebViewActivity extends BaseActivity {

    public static final String WEB_VIEW_FRAGMENT_ID = "001";

    private static final String EXTRA_FRAGMENT_ID = "fragment_id";
    private static final String EXTRA_URL = "url";
    private static final String EXTRA_TITLE = "title";

    public static Intent getActivityIntentForWebViewFragment(Context appContext, String fragmentId, String url, String title) {
        Intent intent = new Intent(appContext, WebViewActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);
        intent.putExtra(EXTRA_URL, url);
        intent.putExtra(EXTRA_TITLE, title);
        return intent;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        if (intent != null) {
            String fragmentId = intent.getStringExtra(EXTRA_FRAGMENT_ID);
            String url = intent.getStringExtra(EXTRA_URL);
            String title = intent.getStringExtra(EXTRA_TITLE);
            initFragment(fragmentId, url, title);
        }
    }

    private void initFragment(String fragmentId, String url, String title) {
        if (!TextUtils.isEmpty(fragmentId)) {
            switch (fragmentId) {
                case WEB_VIEW_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(), WebViewFragment.create(url, title),
                            ProductListingFragment.class.getName(),
                            R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.ADD);
                    break;
                default:
                    break;

            }
        }
    }

}
