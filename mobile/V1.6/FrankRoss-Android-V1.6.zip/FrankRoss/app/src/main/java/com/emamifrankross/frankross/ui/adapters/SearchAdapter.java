/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.android.volley.toolbox.NetworkImageView;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.customviews.VolleySingleton;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 6/7/15.
 * <p> Adapter class for Search Section</p>
 * <p>Supports the Five View Types </p>
 * <p> 1 : RECENTLY SEARCHED HEADER VIEW TYPE </p>
 * <p> 2 : SEARCH CATEGORY VIEW TYPE </p>
 * <p> 3 : SEARCH PHARMA PRODUCT VIEW TYPE </p>
 * <p> 4 : SEARCH NON PHARMA PRODUCT VIEW TYPE </p>
 * <p> 5 : CLEAR SEARCH HISTORY VIEW TYPE </p>
 */
public class SearchAdapter extends BaseRecyclerAdapter {

    public SearchAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewHolderTypeList = new ArrayList<>(5);
        viewHolderTypeList.add(new RecentlySearchedViewHolderType());
        viewHolderTypeList.add(new SearchCategoryViewHolderType());
        viewHolderTypeList.add(new SearchPharmaProductViewHolderType());
        viewHolderTypeList.add(new SearchNonPharmaProductViewHolderType());
        viewHolderTypeList.add(new ClearSearchHistoryViewHolderType());

        return viewHolderTypeList;
    }

    /**
     * RECENTLY SEARCHED HEADER VIEW TYPE
     */
    public static class RecentlySearchedDataItem implements IViewType {

        public String header;

        public RecentlySearchedDataItem(String headerText) {
            header = headerText;
        }

        @Override
        public int getViewType() {
            return ViewTypes.SearchViewType.RECENTLY_SEARCHED_HEADER;
        }
    }

    private static class RecentlySearchedViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mSearchProductsHeader;

        public RecentlySearchedViewHolder(View itemView, Context context) {
            super(itemView);
            mSearchProductsHeader = (RobotoTextView) itemView.findViewById(R.id.search_products_recently_searched_tv);
            mSearchProductsHeader.setTextColor(Color.GRAY);
            mSearchProductsHeader.setPadding(context.getResources().getDimensionPixelSize(R.dimen.home_search_category_left_padding),
                    context.getResources().getDimensionPixelSize(R.dimen.home_search_recently_searched_top_padding),
                    50, context.getResources().getDimensionPixelSize(R.dimen.home_search_recently_searched_bottom_padding));
        }
    }

    private static class RecentlySearchedViewHolderType implements
            RecyclerViewDataBinder<RecentlySearchedViewHolder, RecentlySearchedDataItem> {

        @Override
        public RecentlySearchedViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.search_header_footer, parent, false);

            return new RecentlySearchedViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(RecentlySearchedViewHolder viewHolder,
                                         final RecentlySearchedDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mSearchProductsHeader.setText(data.header);
            if (recyclerViewClickListener != null) {
                viewHolder.mSearchProductsHeader.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.SearchViewType.RECENTLY_SEARCHED_HEADER;
        }
    }

    /**
     * SEARCH CATEGORY VIEW TYPE
     */
    public static class SearchCategoryDataItem implements IViewType {

        public String categoryName;

        public SearchCategoryDataItem(String categoryName) {
            this.categoryName = categoryName;
        }

        @Override
        public int getViewType() {
            return ViewTypes.SearchViewType.SEARCH_CATEGORY;
        }
    }

    private static class SearchCategoryViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mSearchProductsCategory;
        private LinearLayout mSearchProductsCategoryLinLyt;

        public SearchCategoryViewHolder(View itemView, Context context) {
            super(itemView);
            mSearchProductsCategoryLinLyt = (LinearLayout) itemView.findViewById(R.id.search_products_recently_searched_linLayout);
            mSearchProductsCategoryLinLyt.setPadding(context.getResources().getDimensionPixelSize(R.dimen.home_search_category_left_padding), 0, 0, 0);
            mSearchProductsCategoryLinLyt.setBackgroundColor(ContextCompat.getColor(context, R.color.white_background));
            mSearchProductsCategory = (RobotoTextView) itemView.findViewById(R.id.search_products_recently_searched_tv);
            mSearchProductsCategory.setPadding(0, context.getResources().getDimensionPixelSize(R.dimen.home_search_category_top_padding),
                    0, context.getResources().getDimensionPixelSize(R.dimen.home_search_category_bottom_padding));
            mSearchProductsCategory.setBackgroundColor(Color.WHITE);
            mSearchProductsCategory.setTextColor(ContextCompat.getColor(context, R.color.search_category_txt_color));
            mSearchProductsCategory.setTypeface(null, Typeface.BOLD);
            mSearchProductsCategory.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        }
    }

    private static class SearchCategoryViewHolderType implements
            RecyclerViewDataBinder<SearchCategoryViewHolder, SearchCategoryDataItem> {

        @Override
        public SearchCategoryViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.search_header_footer, parent, false);

            return new SearchCategoryViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(SearchCategoryViewHolder viewHolder,
                                         SearchCategoryDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mSearchProductsCategory.setText(data.categoryName);
        }

        @Override
        public int getViewType() {
            return ViewTypes.SearchViewType.SEARCH_CATEGORY;
        }
    }

    /**
     * SEARCH PHARMA PRODUCT VIEW TYPE
     */
    public static class SearchPharmaProductDataItem implements IViewType {

        public String productName = "";
        public String manufacturerName = "";
        public String categoryName = "";
        public String productIconImageUrl = "";
        public long variantId = -1;
        public long categoryId = -1;
        public boolean isPharma = true;

        @Override
        public int getViewType() {
            return ViewTypes.SearchViewType.SEARCH_PHARMA_PRODUCT;
        }
    }

    private static class SearchPharmaProductViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mSearchProductName;
        private RobotoTextView mSearchProductManufacturerName;
        private LinearLayout mSearchProductsSubCategoryLinLyt;
        private NetworkImageView mSearchProductIcon;

        public SearchPharmaProductViewHolder(View itemView) {
            super(itemView);
            mSearchProductName = (RobotoTextView) itemView.findViewById(R.id.search_pharma_product_name_tv);
            mSearchProductManufacturerName = (RobotoTextView) itemView.findViewById(R.id.search_pharma_product_manufacturer_tv);
            mSearchProductsSubCategoryLinLyt = (LinearLayout) itemView.findViewById(R.id.search_pharma_product_linlay);
            mSearchProductIcon = (NetworkImageView) itemView.findViewById(R.id.search_pharma_product_icon_iv);
        }
    }


    private static class SearchPharmaProductViewHolderType implements
            RecyclerViewDataBinder<SearchPharmaProductViewHolder, SearchPharmaProductDataItem> {

        @Override
        public SearchPharmaProductViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.search_pharma_product, parent, false);

            return new SearchPharmaProductViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(SearchPharmaProductViewHolder viewHolder,
                                         final SearchPharmaProductDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mSearchProductName.setText(data.productName);
            viewHolder.mSearchProductManufacturerName.setText(data.manufacturerName);
            viewHolder.mSearchProductIcon.setImageUrl(data.productIconImageUrl,
                    VolleySingleton.getInstance(viewHolder.mSearchProductIcon.getContext()).getImageLoader());

            if (recyclerViewClickListener != null) {
                viewHolder.mSearchProductsSubCategoryLinLyt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.SearchViewType.SEARCH_PHARMA_PRODUCT;
        }
    }

    /**
     * SEARCH NON PHARMA PRODUCT VIEW TYPE
     */
    public static class SearchNonPharmaProductDataItem implements IViewType {

        public String categoryName = "";
        public String genericKeyword = "";
        public String productName = "";
        public String manufacturerName = "";
        public long variantId = -1;
        public long categoryId = -1;
        public boolean isPharma = false;

        @Override
        public int getViewType() {
            return ViewTypes.SearchViewType.SEARCH_NON_PHARMA_PRODUCT;
        }
    }

    private static class SearchNonPharmaProductViewHolder extends RecyclerView.ViewHolder {

        public RobotoTextView mSearchProductName;
        public LinearLayout mSearchProductsSubCategoryLinLyt;

        public SearchNonPharmaProductViewHolder(View itemView) {
            super(itemView);
            mSearchProductName = (RobotoTextView) itemView.findViewById(R.id.search_non_pharma_product_name_tv);
            mSearchProductsSubCategoryLinLyt = (LinearLayout) itemView.findViewById(R.id.search_non_pharma_product_linlay);
        }
    }


    private static class SearchNonPharmaProductViewHolderType implements
            RecyclerViewDataBinder<SearchNonPharmaProductViewHolder, SearchNonPharmaProductDataItem> {

        @Override
        public SearchNonPharmaProductViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.search_non_pharma_product, parent, false);

            return new SearchNonPharmaProductViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(SearchNonPharmaProductViewHolder viewHolder,
                                         final SearchNonPharmaProductDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            String text = "<font color=\"#14906f\">" + data.productName + "</font> <font color=\"#999999\">" + " in " + data.categoryName + "</font>";
            viewHolder.mSearchProductName.setText(Html.fromHtml(text));

            if (recyclerViewClickListener != null) {
                viewHolder.mSearchProductsSubCategoryLinLyt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.SearchViewType.SEARCH_NON_PHARMA_PRODUCT;
        }
    }


    /**
     * CLEAR SEARCH HISTORY VIEW TYPE
     */
    public static class ClearSearchHistoryDataItem implements IViewType {

        public String searchProductsFooter;

        public ClearSearchHistoryDataItem(String footerText) {
            searchProductsFooter = footerText;
        }

        @Override
        public int getViewType() {
            return ViewTypes.SearchViewType.CLEAR_SEARCH_HISTORY;
        }
    }

    private static class ClearSearchHistoryViewHolder extends RecyclerView.ViewHolder {
        public RobotoTextView mSearchProductsFooter;

        public ClearSearchHistoryViewHolder(View itemView, Context context) {
            super(itemView);
            mSearchProductsFooter = (RobotoTextView) itemView.findViewById(R.id.search_products_recently_searched_tv);
            mSearchProductsFooter.setTextColor(ContextCompat.getColor(context, R.color.search_clear_history_text_color));
            mSearchProductsFooter.setGravity(Gravity.CENTER);
            mSearchProductsFooter.setPadding(context.getResources().getDimensionPixelSize(R.dimen.home_search_category_left_padding),
                    context.getResources().getDimensionPixelSize(R.dimen.home_search_recently_searched_top_padding), 0,
                    context.getResources().getDimensionPixelSize(R.dimen.home_search_recently_searched_bottom_padding));
        }
    }

    private static class ClearSearchHistoryViewHolderType implements
            RecyclerViewDataBinder<ClearSearchHistoryViewHolder, ClearSearchHistoryDataItem> {

        @Override
        public ClearSearchHistoryViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.search_header_footer, parent, false);

            return new ClearSearchHistoryViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(ClearSearchHistoryViewHolder viewHolder,
                                         final ClearSearchHistoryDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mSearchProductsFooter.setText(data.searchProductsFooter);
            if (recyclerViewClickListener != null) {
                viewHolder.mSearchProductsFooter.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.SearchViewType.CLEAR_SEARCH_HISTORY;
        }
    }
}
