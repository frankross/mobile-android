/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 3/9/15.
 */
public class FilterInfo {

    private List<String> brandNames = new ArrayList<>();

    private Stats priceStats = new Stats();

    private Stats discountStats = new Stats();

    public Stats getPriceStats() {
        return priceStats;
    }

    public void setPriceStats(Stats priceStats) {
        this.priceStats = priceStats;
    }

    public Stats getDiscountStats() {
        return discountStats;
    }

    public void setDiscountStats(Stats discountStats) {
        this.discountStats = discountStats;
    }

    public List<String> getBrandNames() {
        return brandNames;
    }

    public void setBrandNames(List<String> brandNames) {
        this.brandNames = brandNames;
    }
}
