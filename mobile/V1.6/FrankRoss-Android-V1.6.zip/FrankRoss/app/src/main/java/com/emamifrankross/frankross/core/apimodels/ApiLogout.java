/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 4/11/15.
 */
public class ApiLogout {

    public static class Request {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        public Request(String token) {
            user = new User();
            user.setToken(token);
        }

        @SerializedName("user")
        private User user;
    }

    public static class User {
        @SerializedName("token")
        private String token = "";

        @SerializedName("device_type")
        private String deviceType = "android";

        public void setToken(String token) {
            this.token = token;
        }

        public void setDeviceType(String deviceType) {
            this.deviceType = deviceType;
        }
    }

    public static class Response {

    }
}
