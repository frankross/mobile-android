/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.android.volley.toolbox.NetworkImageView;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.customviews.VolleySingleton;
import com.emamifrankross.frankross.ui.viewmodels.HorizontalScrollerViewMoreViewDataBinder;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 12/11/15.
 * <p/>
 * <p> Adapter class for Home Top Categories Section</p>
 * <p>Supports the Two View Types </p>
 * <p> 1 : HOME TOP CATEGORIES LIST ITEM VIEW TYPE </p>
 * <p> 2 : HOME VIEW MORE LIST ITEM VIEW TYPE</p>
 */
public class HomeFeaturedCategoriesAdapter extends BaseRecyclerAdapter {

    public HomeFeaturedCategoriesAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewHolderTypeList = new ArrayList<>(2);
        viewHolderTypeList.add(new HomeTopCategoriesViewHolderType());
        viewHolderTypeList.add(new HorizontalScrollerViewMoreViewDataBinder());

        return viewHolderTypeList;
    }

    /**
     * HOME TOP CATEGORIES LIST ITEM VIEW TYPE
     */
    public static class HomeFeaturedCategoryDataItem implements IViewType {

        public String topCategoryUrl = "";
        public String topCategoryName = "";
        public long categoryId;

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.HOME_HORIZONTAL_SCROLL_LIST_ITEM_VIEW_TYPE;
        }
    }

    private static class HomeTopCategoriesViewHolder extends RecyclerView.ViewHolder {

        private NetworkImageView mCategoryIcon;
        private RobotoTextView mCategoryName;

        public HomeTopCategoriesViewHolder(View itemView) {
            super(itemView);
            mCategoryIcon = (NetworkImageView) itemView.findViewById(R.id.home_horizontal_scroll_item_icon_iv);
            mCategoryName = (RobotoTextView) itemView.findViewById(R.id.home_horizontal_scroll_item_category_name_tv);
        }
    }

    private static class HomeTopCategoriesViewHolderType implements
            RecyclerViewDataBinder<HomeTopCategoriesViewHolder, HomeFeaturedCategoryDataItem> {

        @Override
        public HomeTopCategoriesViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_top_categories_horizontal_scroll_list_item, parent, false);

            return new HomeTopCategoriesViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(HomeTopCategoriesViewHolder viewHolder,
                                         final HomeFeaturedCategoryDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            Animation fadeInAnimation = AnimationUtils.loadAnimation(viewHolder.mCategoryIcon.getContext(), R.anim.fade_in);
            viewHolder.mCategoryIcon.startAnimation(fadeInAnimation);
            viewHolder.mCategoryIcon.setImageUrl(data.topCategoryUrl,
                    VolleySingleton.getInstance(viewHolder.mCategoryIcon.getContext()).getImageLoader());
            viewHolder.mCategoryIcon.setErrorImageResId(R.drawable.product_logo);
            viewHolder.mCategoryIcon.setDefaultImageResId(R.drawable.product_logo);
            viewHolder.mCategoryName.setText(data.topCategoryName);

            if (recyclerViewClickListener != null) {
                viewHolder.mCategoryIcon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.HOME_HORIZONTAL_SCROLL_LIST_ITEM_VIEW_TYPE;
        }
    }
}
