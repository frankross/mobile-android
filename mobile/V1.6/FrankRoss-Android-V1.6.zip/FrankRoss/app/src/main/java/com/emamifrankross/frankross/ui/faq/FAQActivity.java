/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.faq;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.prescription.PrescriptionFragment;

/**
 * Created by gauthami on 8/4/16.
 */

/**
 * This class manages the fragment transactions for FAQ module based on the intents and its data
 */
public class FAQActivity extends BaseActivity {

    public static final String FAQ_TOP_QUERY_FRAGMENT = "001";
    public static final String FAQ_FRAGMENT = "002";

    private static final String EXTRA_FRAGMENT_ID = "fragment_id";

    private String mFragmentId = FAQ_TOP_QUERY_FRAGMENT;

    /**
     * Method to launch the Order History and Prescriptions screen
     *
     * @param appContext the application context
     * @param fragmentId the fragment to be launched identified with an id
     * @return the intent associated with the FAQ Top Queries fragment
     */
    public static Intent getActivityIntent(Context appContext, String fragmentId) {
        Intent intent = new Intent(appContext, FAQActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);

        return intent;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFragmentId = getIntent().getStringExtra(EXTRA_FRAGMENT_ID);
        initFragment(mFragmentId);
    }

    @Override
    public void onBackPressed() {
        if (mFragmentId.equals(FAQ_FRAGMENT)) {
            mFragmentId = FAQ_TOP_QUERY_FRAGMENT;
            loadFragment(getFragmentContainerId(), FAQTopQueriesFragment.create(), null,
                    R.anim.push_left_in, R.anim.push_left_out,
                    BaseFragment.FragmentTransactionType.REPLACE);
        } else {
            super.onBackPressed();
        }
    }

    private void initFragment(String fragmentId) {
        if (!TextUtils.isEmpty(fragmentId)) {
            switch (fragmentId) {
                case FAQ_TOP_QUERY_FRAGMENT:
                    loadFragment(getFragmentContainerId(),
                            FAQTopQueriesFragment.create(), null, R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.REPLACE);
                    break;

                case FAQ_FRAGMENT:
                    loadFragment(getFragmentContainerId(), FAQFragment.create("", 0),
                            PrescriptionFragment.TAG, R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.REPLACE);
                    break;

                default:
                    break;

            }
        }
    }
}
