/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.android.volley.toolbox.NetworkImageView;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.customviews.VolleySingleton;
import com.emamifrankross.frankross.ui.viewmodels.HorizontalScrollerViewMoreViewDataBinder;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 12/11/15.
 * <p/>
 * <p> Adapter class for Home Top Products Section</p>
 * <p>Supports the Two View Types </p>
 * <p> 1 : HOME TOP PRODUCTS LIST ITEM VIEW TYPE </p>
 * <p> 2 : HOME VIEW MORE LIST ITEM VIEW TYPE</p>
 */
public class NewFeaturedProductsAdapter extends BaseRecyclerAdapter {

    public NewFeaturedProductsAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewHolderTypeList = new ArrayList<>(1);
        viewHolderTypeList.add(new HomeFeaturedProductsViewHolderType());
        viewHolderTypeList.add(new HorizontalScrollerViewMoreViewDataBinder());

        return viewHolderTypeList;
    }

    /**
     * HOME TOP CATEGORIES LIST ITEM VIEW TYPE
     */
    public static class HomeFeaturedProductsDataItem implements IViewType {

        public String productBrandOrManufacturerName = "";
        public String productImageUrl = "";
        public String productIconImageUrl = "";
        public String productName = "";
        public long categoryId = 0;
        public long productId = 0;
        public boolean isAddToCartVisible = false;
        public double productSellingPrice = 0.0d;
        public double productActualPrice = 0.0d;
        public boolean isPharma = false;
        public float productDiscountPercent = 0;

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.HOME_HORIZONTAL_SCROLL_FEATURED_LIST_ITEM_VIEW_TYPE;
        }
    }

    public static class HomeFeaturedProductsViewHolder extends RecyclerView.ViewHolder {

        private NetworkImageView mProductIcon;
        private RobotoTextView mProductName;
        private RobotoTextView mProductPrice;

        public HomeFeaturedProductsViewHolder(View itemView) {
            super(itemView);
            mProductIcon = (NetworkImageView) itemView.findViewById(R.id.home_horizontal_scroll_item_icon_iv);
            mProductName = (RobotoTextView) itemView.findViewById(R.id.home_horizontal_scroll_item_product_name_tv);
            mProductPrice = (RobotoTextView) itemView.findViewById(R.id.home_horizontal_scroll_item_product_discount_tv);
        }
    }

    public static class HomeFeaturedProductsViewHolderType implements
            RecyclerViewDataBinder<HomeFeaturedProductsViewHolder, HomeFeaturedProductsDataItem> {

        @Override
        public HomeFeaturedProductsViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_featured_products_horizontal_scroll_list_item,
                    parent, false);

            return new HomeFeaturedProductsViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(HomeFeaturedProductsViewHolder viewHolder,
                                         final HomeFeaturedProductsDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            Animation fadeInAnimation = AnimationUtils.loadAnimation(viewHolder.mProductIcon.getContext(), R.anim.fade_in);
            viewHolder.mProductIcon.startAnimation(fadeInAnimation);
            viewHolder.mProductIcon.setImageUrl(data.productImageUrl,
                    VolleySingleton.getInstance(viewHolder.mProductIcon.getContext()).getImageLoader());
            viewHolder.mProductIcon.setErrorImageResId(R.drawable.product_logo);
            viewHolder.mProductIcon.setDefaultImageResId(R.drawable.product_logo);
            viewHolder.mProductName.setText(data.productName);
            viewHolder.mProductPrice.setVisibility(data.productDiscountPercent == 0 ? View.GONE : View.VISIBLE);
            viewHolder.mProductPrice.setText(Utils.getDiscountFormattedDouble(data.productDiscountPercent) + "% off");

            if (recyclerViewClickListener != null) {
                viewHolder.mProductIcon.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.HOME_HORIZONTAL_SCROLL_FEATURED_LIST_ITEM_VIEW_TYPE;
        }
    }
}
