/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 18/8/15.
 */
public class RecentPharmaProduct {

    @SerializedName("id")
    private int id;

    @SerializedName("promotional_price")
    private double promotionalPrice;

    @SerializedName("name")
    private String name;

    @SerializedName("mrp")
    private double mrp;

    @SerializedName("product_type")
    private String productType;

    @SerializedName("product_description")
    private String productDescription;

    @SerializedName("manufacturer_name")
    private String manufacturerName;

    @SerializedName("brand_name")
    private String brandName;

    @SerializedName("discount_percent")
    private float discountPercent;

    @SerializedName("sales_price")
    private double salesPrice;

    @SerializedName("main_image_url")
    private String mainImageUrl;

    @SerializedName("max_orderable_quantity")
    private int maxOrderableQty = -1;

    @SerializedName("unit_of_sale")
    private String unitOfSale = "";

    @SerializedName("inner_package_quantity")
    private String innerPackagingQty = "";

    @SerializedName("available")
    private boolean isAvailable = false;

    @SerializedName("cash_back")
    private boolean isCashBack = false;

    @SerializedName("cash_back_desc")
    private String cashBackMessage = "";

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public double getPromotionalPrice() {
        return promotionalPrice;
    }

    public double getMrp() {
        return mrp;
    }

    public String getProductType() {
        return productType;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public String getManufacturerName() {
        return manufacturerName;
    }

    public String getBrandName() {
        return brandName;
    }

    public float getDiscountPercent() {
        return discountPercent;
    }

    public double getSalesPrice() {
        return salesPrice;
    }

    public String getMainImageUrl() {
        return mainImageUrl;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    public String getInnerPackagingQty() {
        return innerPackagingQty;
    }

    public void setInnerPackagingQty(String innerPackagingQty) {
        this.innerPackagingQty = innerPackagingQty;
    }

    public String getUnitOfSale() {
        return unitOfSale;
    }

    public void setUnitOfSale(String unitOfSale) {
        this.unitOfSale = unitOfSale;
    }

    public int getMaxOrderableQty() {
        return maxOrderableQty;
    }

    public void setMaxOrderableQty(int maxOrderableQty) {
        this.maxOrderableQty = maxOrderableQty;
    }

    public boolean isCashBack() {
        return isCashBack;
    }

    public String getCashBackMessage() {
        return cashBackMessage;
    }
}
