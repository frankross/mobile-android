/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 4/3/16.
 */
public class ApiFAQ {

    public class Response {

        @SerializedName("faqs")
        private List<FAQ.Faqs> faqList = new ArrayList<>(1);

        @SerializedName("help_topics")
        private List<HelpTopics> helpTopicsList = new ArrayList<>(1);

        @SerializedName("top_queries")
        private List<FAQ.Faqs> topQueryList = new ArrayList<>(1);

        private List<BaseRecyclerAdapter.IViewType> uiData = new ArrayList<>(1);

        public List<FAQ.Faqs> getFaqList() {
            return faqList;
        }

        public List<BaseRecyclerAdapter.IViewType> getUiData() {
            return uiData;
        }

        public void setUiData(List<BaseRecyclerAdapter.IViewType> uiData) {
            this.uiData = uiData;
        }

        public List<FAQ.Faqs> getTopQueryList() {
            return topQueryList;
        }

        public void setTopQueryList(List<FAQ.Faqs> topQueryList) {
            this.topQueryList = topQueryList;
        }

        public List<HelpTopics> getHelpTopicsList() {
            return helpTopicsList;
        }

        public void setHelpTopicsList(List<HelpTopics> helpTopicsList) {
            this.helpTopicsList = helpTopicsList;
        }
    }
}
