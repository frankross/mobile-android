/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.sdkmanager;

import android.content.Context;

import com.emamifrankross.frankross.utils.Constants;
import com.flurry.android.FlurryAgent;

/**
 * This class manages the Flurry SDK initialization based on the live/production key
 */
public class FlurryManager {

    private static final String FLURRY_API_KEY_PROD = "VT3G295PZSCSKJZ4T5X5";
    private static final String FLURRY_API_KEY_DEV = "VT3G295PZSCSKJZ4T5X5";
    /*private static final String FLURRY_API_KEY = UrlConstants.USE_STAGING_SERVER ? FLURRY_API_KEY_DEV
            : FLURRY_API_KEY_PROD;*/

    public static void init(Context context) {
        FlurryAgent.setLogEnabled(Constants.ENABLE_DEBUG_LOG);
        FlurryAgent.init(context, FLURRY_API_KEY_DEV);
    }
}
