/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.db;

/**
 * Created by gowtham on 7/9/15.
 */
public class RawQuery extends DBQuery {

    private byte rawOperationId = 0;

    private String mSqlStatement = null;

    private String[] mSelectionArgs = null;

    public String getSqlStatement() {
        return mSqlStatement;
    }

    public void setSqlStatement(String mSqlStatement) {
        this.mSqlStatement = mSqlStatement;
    }

    public String[] getSelectionArgs() {
        return mSelectionArgs;
    }

    public void setSelectionArgs(String[] selectionArgs) {
        this.mSelectionArgs = selectionArgs;
    }

    public byte getRawOperationId() {
        return rawOperationId;
    }

    public void setRawOperationId(byte rawOperationId) {
        this.rawOperationId = rawOperationId;
    }
}
