/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 10/9/15.
 * <p> Adapter class for Variants Section</p>
 * <p>Supports the One View Types </p>
 * <p> 1 : VARIANT SELECTION VIEW TYPE </p>
 */
public class VariantSelectionAdapter extends BaseRecyclerAdapter {

    public VariantSelectionAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        ArrayList<RecyclerViewDataBinder> viewHolderTypes = new ArrayList<>(1);
        viewHolderTypes.add(new VariantSelectionViewHolderType());

        return viewHolderTypes;
    }

    public enum VariantStates {
        SELECTED, UNSELECTED, NOT_AVAILABLE
    }

    /**
     * VARIANT SELECTION VIEW TYPE
     */

    public static class VariantSelectionItem implements IViewType {

        public String variantName = "";
        public VariantStates state = VariantStates.UNSELECTED;

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.VARIANT_SELECTION_VIEW;
        }
    }


    public static class VariantSelectionViewHolder extends RecyclerView.ViewHolder {

        private LinearLayout mVariantSelectionLayout;
        private RobotoTextView mVariantSelectionType;
        private ImageView mVariantChooserImage;

        public VariantSelectionViewHolder(View view) {
            super(view);
            mVariantSelectionLayout = (LinearLayout) view.findViewById(R.id.variant_selection_linLay);
            mVariantSelectionType = (RobotoTextView) view.findViewById(R.id.variant_name_tv);
            mVariantChooserImage = (ImageView) view.findViewById(R.id.variant_chooser_iv);
        }
    }

    private class VariantSelectionViewHolderType implements RecyclerViewDataBinder<VariantSelectionViewHolder,
            VariantSelectionItem> {
        @Override
        public VariantSelectionViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.variant_selection_view, parent, false);

            return new VariantSelectionViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(VariantSelectionViewHolder viewHolder, final VariantSelectionItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mVariantSelectionType.setText(data.variantName);
            Context context = viewHolder.mVariantSelectionType.getContext();
            switch (data.state) {
                case SELECTED:
                    viewHolder.mVariantChooserImage.setImageResource(R.mipmap.radiobutton);
                    viewHolder.mVariantChooserImage.setVisibility(View.VISIBLE);
                    viewHolder.mVariantSelectionLayout.setEnabled(true);
                    viewHolder.mVariantSelectionLayout.setClickable(true);
                    viewHolder.mVariantSelectionType.setTextColor(ContextCompat.getColor(context,
                            R.color.frankross_common_text_color));
                    break;

                case UNSELECTED:
                    viewHolder.mVariantChooserImage.setImageResource(R.mipmap.radiobutton_unselect);
                    viewHolder.mVariantChooserImage.setVisibility(View.VISIBLE);
                    viewHolder.mVariantSelectionLayout.setEnabled(true);
                    viewHolder.mVariantSelectionLayout.setClickable(true);
                    viewHolder.mVariantSelectionType.setTextColor(ContextCompat.getColor(context,
                            R.color.frankross_common_text_color));
                    break;

                case NOT_AVAILABLE:
                    viewHolder.mVariantChooserImage.setVisibility(View.INVISIBLE);
                    viewHolder.mVariantSelectionLayout.setEnabled(false);
                    viewHolder.mVariantSelectionLayout.setClickable(false);
                    viewHolder.mVariantSelectionType.setTextColor(ContextCompat.getColor(context,
                            R.color.common_header_text_color));
                    break;
            }

            if (recyclerViewClickListener != null) {
                viewHolder.mVariantSelectionLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        recyclerViewClickListener.onRecyclerItemClick(position, view, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.VARIANT_SELECTION_VIEW;
        }
    }
}
