/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

/**
 * Created by gowtham on 7/7/15.
 */
public interface ViewTypes {

    interface CommonViewType {
        int PRODUCT_ITEM = 1;
        int COMMON_HEADER_TEXT = 2;
        int BORDER_ITEM = 3;
        int TOP_OFFERS_VIEW_PAGER = 4;
        int COMMON_FOOTER_TEXT = 5;

        int VIEW_PAGER_ITEM = 6;
        int VIEW_HORIZONTAL_RECYCLER_ITEM = 7;
        int HORIZONTAL_SCROLL_LIST_VIEW_MORE_ITEM_VIEW_TYPE = 8;
    }

    interface DrawerViewTypes {
        int DRAWER_VIEW_TYPE_HEADER = 111;
        int DRAWER_VIEW_TYPE_CATEGORY = 112;
        int DRAWER_VIEW_TYPE_SUBCATEGORY = 113;
        int DRAWER_VIEW_TYPE_SECONDARY_CATEGORY = 114;
    }

    interface HomeViewType {
        int UPLOAD_PRESCRIPTION = 10;
        int DELIVERY_STATUS_VIEW_PAGER = 11;
        // int TOP_OFFERS_VIEW_PAGER = 12;
        int TOP_SELLING_PRODUCTS_HEADER = 13;
        int VIEW_MORE_PRODUCTS = 14;
        int HORIZONTAL_VIEW_TYPE = 15;
        int HOME_HORIZONTAL_SCROLL_LIST_ITEM_VIEW_TYPE = 16;
        int HOME_PRODUCT_ITEM = 17;
        int HOME_HORIZONTAL_SCROLL_FEATURED_LIST_ITEM_VIEW_TYPE = 18;
    }

    interface SortViewType {
        int SORT_LIST_ITEM = 21;
        int SORT_HEADER = 22;
    }

    interface FilterViewType {
        int FILTER_LIST_ITEM = 31;
        int FILTER_ACTION_BUTTON = 32;
        int FILTER_DOUBLE_SEEK_BAR_PRICE = 33;
        int FILTER_IDEAL_FOR = 34;
        int FILTER_DOUBLE_SEEK_BAR_DISCOUNT = 35;
        int FILTER_DETAILS_DATA_ITEM = 23;
    }

    interface ProductDetailViewType {
        int PRODUCT_DETAILS = 41;
        int KEY_FEATURES = 42;
        int PRODUCT_VARIANTS = 43;
        int KEY_FEATURES_HEADER = 48;
        int PRODUCT_SPECS_HEADER = 49;
        int VARIANT_SELECTION_VIEW = 50;

        int TAB_HEADER = 45;
        int MEDICINE_BASIC_INFO = 46;
        int QUESTION_AND_ANSWER = 47;
    }

    interface AccountViewType {
        int ACCOUNT_VIEW_TYPE_USER_INFO = 51;
        int ACCOUNT_VIEW_TYPE_ORDER_INFO = 52;
        int ACCOUNT_VIEW_TYPE_ADDRESS = 53;
        int ACCOUNT_VIEW_TYPE_FOOTER = 54;
    }

    interface OrderHistoryViewType {
        int ORDER_HISTORY_VIEW_TYPE = 61;
        int ORDER_HISTORY_PRODUCT_INFO_HEADER = 62;
        int ORDER_HISTORY_PRODUCT_DISCOUNT_INFO_HEADER = 71;
        int ORDER_HISTORY_PRODUCT_INFO_FOOTER = 63;
        int ORDER_HISTORY_RE_ORDER = 64;

        int ORDER_HISTORY_DELIVER_TO = 65;
        int ORDER_HISTORY_SHIPPED_FROM = 66;
        int ORDER_HISTORY_TOTAL_AMOUNT = 67;
        int ORDER_HISTORY_PRODUCT_ITEM = 68;
        int ORDER_HISTORY_PRODUCT_HEADER = 69;
        int ORDER_HISTORY_DOCTOR_PATIENT_INFO = 70;
    }

    interface PrescriptionViewType {
        int PRESCRIPTION_PAGER = 71;
        int PRESCRIPTION_UPLOAD = 72;
        int PRESCRIPTION_INFO = 73;
        int PRESCRIPTION_FILTER_HEADER = 74;
        int PRESCRIPTION_DOSAGE_INFO_HEADER = 75;
        int PRESCRIPTION_DOSAGE_INFO = 76;
        int PRESCRIPTION_DELETE_PRESC = 77;
        int PRESCRIPTION_REMARKS = 78;
    }

    interface PharmacyViewTypes {
        int PHARMACY_LIST = 81;
    }

    interface SearchViewType {
        int RECENTLY_SEARCHED_HEADER = 91;
        int SEARCH_CATEGORY = 92;
        int SEARCH_PHARMA_PRODUCT = 93;
        int SEARCH_NON_PHARMA_PRODUCT = 94;
        int SEARCH_SUB_CATEGORY = 95;
        int CLEAR_SEARCH_HISTORY = 96;
    }

    interface CartViewType {
        int CART_ITEM_INACTIVE_VIEW_TYPE = 111;
        int CART_ITEM_VIEW_TYPE = 112;
        int CART_COUPON_CODE_VIEW_TYPE = 113;
        int CART_ORDER_SUMMARY_VIEW_TYPE = 114;
        int CART_AVAILABILITY_VIEW_TYPE = 115;
        int CART_ITEM_REVISED_ORDER_VIEW_TYPE = 116;
        int CART_DIGITIZATION_CANCELLATION_REASON_VIEW_TYPE = 117;
        int CART_ORDER_FAILURE_REASON_HEADER_VIEW_TYPE = 118;
        int CART_ITEM_UNAVAILABLE_VIEW_TYPE = 119;
        int CART_ITEM_BACK_IN_STOCK_VIEW_TYPE = 120;
        int CART_ITEM_OFFER_HEADER_VIEW_TYPE = 121;
        int CART_OFFERS_VIEW_PAGER_VIEW_TYPE = 122;
        int CART_APPLIED_COUPON_CODES_VIEW_TYPE = 123;
        int CART_APPLIED_COUPON_CODES_LIST_ITEM_VIEW_TYPE = 124;
    }

    interface CartUploadPrescriptionViewType {
        int CART_UPLOAD_PRESCRIPTION_HEADER_VIEW_TYPE = 171;
        int CART_UPLOAD_PRESCRIPTION_LIST_ITEM_VIEW_TYPE = 172;
        int CART_UPLOAD_PRESCRIPTION_VIEW_TYPE = 173;
    }

    interface CheckOutSummaryViewType {
        int CHECKOUT_SUMMARY_PAY_USING_RADIO_BUTTON_VIEW_TYPE = 121;
        int CHECKOUT_SUMMARY_PAY_USING_HEADER_VIEW_TYPE = 122;
        int CHECKOUT_SUMMARY_PAY_TEXT_USING_VIEW_TYPE = 123;
        int CHECKOUT_REWARD_POINTS_VIEW_TYPE = 124;
    }

    interface CheckOutDeliveryAddressViewType {
        int CHECKOUT_HEADER_VIEW_TYPE = 131;
        int CHECKOUT_DELIVER_TO_VIEW_TYPE = 132;
        int CHECKOUT_DELIVERY_SLOT_VIEW_TYPE = 133;
        int CHECKOUT_DOCTOR_PATIENT_INFO_VIEW_TYPE = 134;
    }

    interface LocationChooserViewType {
        int LOCATION_HEADER = 141;
        int LOCATION_LIST_ITEM = 142;
        int LOCATION_FOOTER = 143;
    }

    interface CheckOutDeliverySlotViewType {
        int CHECKOUT_DELIVERY_SLOT_HEADER_VIEW_TYPE = 151;
        int CHECKOUT_DELIVERY_SLOT_TIME_TO_VIEW_TYPE = 152;
    }

    interface StoreLocatorViewType {
        int STORE_LOCATOR_ITEM_VIEW_TYPE = 161;
    }

    interface PrescriptionFilterViewType {
        int HEADER_ITEM_VIEW_TYPE = 171;
        int SUB_HEADER_ITEM_VIEW_TYPE = 172;
    }

    interface PharmacyCategoryViewType {
        int PHARMACY_EXPANDABLE_GROUP = 181;
        int PHARMACY_EXPANDABLE_CHILD = 182;
        int PHARMACY_CATEGORY_SHOW_ALL = 183;
        int PHARMACY_HORIZONTAL_SCROLL_VIEW_TYPE = 184;
        int PHARMACY_HORIZONTAL_SCROLL_LIST_ITEM_VIEW_TYPE = 185;
        int PHARMACY_AUTO_SCROLL_BANNER = 186;
    }

    interface OffersViewType {
        int OFFER_ITEM_VIEW_TYPE = 191;
    }

    interface RewardPointsViewType {
        int REWARD_POINTS_VIEW_TYPE = 201;
        int REWARD_POINTS_INVITE_FRIENDS_VIEW_TYPE = 202;
        int REWARD_POINTS_TRANSACTIONS_HEADER_VIEW_TYPE = 203;
        int REWARD_POINTS_TRANSACTIONS_VIEW_TYPE = 204;
    }

    interface FAQViewType {
        int FAQ_TOP_QUERY_ITEM_VIEW_TYPE = 211;
        int FAQ_HELP_TOPICS_ITEM_VIEW_TYPE = 212;
        int FAQ_TOP_QUERY_ALTERNATE_ITEM_VIEW_TYPE = 213;
    }

    interface ReturnManagementViewType {
        int RETURNABLE_PRODUCT_VIEW_TYPE = 221;
        int NON_RETURNABLE_PRODUCT_VIEW_TYPE = 222;
        int RETURN_REASON_COMMENT_VIEW_TYPE = 223;
        int RETURN_PICK_UP_SLOT_VIEW_TYPE = 224;
    }

    interface NotificationCenterViewType {
        int NOTIFICATION_DEFAULT_ITEM_VIEW_TYPE = 231;
        int NOTIFICATION_BACK_IN_STOCK_ITEM_VIEW_TYPE = 232;
        int NOTIFICATION_OFFER_ITEM_VIEW_TYPE = 233;
        int NOTIFICATION_EMPTY_ITEM_VIEW_TYPE = 234;
        int NOTIFICATION_PDP_ITEM_VIEW_TYPE = 235;
    }
}
