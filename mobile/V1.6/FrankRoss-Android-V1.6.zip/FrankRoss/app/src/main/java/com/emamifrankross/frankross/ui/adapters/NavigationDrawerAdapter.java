/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.graphics.Typeface;
import android.graphics.drawable.StateListDrawable;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderDataBinder;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 1/7/15.
 * <p/>
 * <p> Adapter class for Navigation Drawer. Handles the Header categories and sub categories.</p>
 * <p>Supports the Five View Types </p>
 * <p> 1 : DRAWER_VIEW_TYPE_HEADER </p>
 * <p> 2 : DRAWER_VIEW_TYPE_CATEGORY  </p>
 * <p> 3 : DRAWER_VIEW_TYPE_SUBCATEGORY </p>
 * <p> 4 : DRAWER_VIEW_TYPE_SECONDARY_CATEGORY </p>
 * <p> 5 : COMMON BORDER VIEW TYPE </p>
 */
public class NavigationDrawerAdapter extends BaseRecyclerAdapter implements ViewTypes.DrawerViewTypes {

    public NavigationDrawerAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        ArrayList<RecyclerViewDataBinder> viewHolderTypes = new ArrayList<>(1);
        viewHolderTypes.add(new DrawerHeaderViewHolderType());
        viewHolderTypes.add(new DrawerCategoryViewHolderType());
        viewHolderTypes.add(new DrawerSubCategoryViewHolderType());
        viewHolderTypes.add(new DrawerSecondaryCategoryViewHolderType());
        viewHolderTypes.add(new RecyclerBorderDataBinder());

        return viewHolderTypes;
    }

    /**
     * Header View Type classes
     */
    public static class DrawerHeaderItem implements IViewType {

        public String headerName;
        public String userName;

        @Override
        public int getViewType() {
            return DRAWER_VIEW_TYPE_HEADER;
        }
    }

    public static class DrawerHeaderViewHolder extends RecyclerView.ViewHolder {

        public RobotoTextView mHeaderTextView;
        public RobotoTextView mHeaderAccountTextView;
        public LinearLayout mHeaderLinLyt;
        public LinearLayout mLocationLinLay;

        public DrawerHeaderViewHolder(View view) {
            super(view);
            mHeaderTextView = (RobotoTextView) view.findViewById(R.id.drawer_header_text);
            mHeaderAccountTextView = (RobotoTextView) view.findViewById(R.id.drawer_header_user_name_tv);
            mHeaderLinLyt = (LinearLayout) view.findViewById(R.id.drawer_header_user_name_linLyt);
            mLocationLinLay = (LinearLayout) view.findViewById(R.id.drawer_location_linLay);
        }
    }

    public static class DrawerHeaderViewHolderType implements RecyclerViewDataBinder<DrawerHeaderViewHolder, DrawerHeaderItem> {

        @Override
        public DrawerHeaderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.drawer_header, parent, false);

            return new DrawerHeaderViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(DrawerHeaderViewHolder viewHolder,
                                         DrawerHeaderItem drawerHeaderItem, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mHeaderTextView.setText(drawerHeaderItem.headerName);
            viewHolder.mHeaderAccountTextView.setText(drawerHeaderItem.userName);

            if (recyclerViewClickListener != null) {
                viewHolder.mHeaderLinLyt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, null);
                    }
                });
                viewHolder.mLocationLinLay.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, null);
                    }
                });
            }
        }


        @Override
        public int getViewType() {
            return DRAWER_VIEW_TYPE_HEADER;
        }
    }

    /**
     * Category View Type classes
     */
    public static class DrawerCategoryItem implements IViewType {

        public String categoryName;
        public String categoryTagName;
        public int categoryDrawableId;
        public int categorySelectedDrawableId;
        public int backgroundColorId = android.R.color.white;
        public boolean categoryIsNew = false;

        @Override
        public int getViewType() {
            return DRAWER_VIEW_TYPE_CATEGORY;
        }
    }

    public static class DrawerCategoryViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mCategoryNewTagText;
        public ImageView mCategoryIcon;
        public RobotoTextView mCategoryText;
        public LinearLayout mPaddingLayout;

        public DrawerCategoryViewHolder(View view) {
            super(view);
            mCategoryIcon = (ImageView) view.findViewById(R.id.drawer_category_img);
            mCategoryText = (RobotoTextView) view.findViewById(R.id.drawer_category_tv);
            mCategoryNewTagText = (RobotoTextView) view.findViewById(R.id.drawer_category_new_tag_tv);
            mPaddingLayout = (LinearLayout) view.findViewById(R.id.drawer_item_padding_linlay);
        }
    }

    public static class DrawerCategoryViewHolderType implements RecyclerViewDataBinder<DrawerCategoryViewHolder, DrawerCategoryItem> {

        @Override
        public DrawerCategoryViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.drawer_list_item, parent, false);

            return new DrawerCategoryViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(DrawerCategoryViewHolder viewHolder,
                                         DrawerCategoryItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            StateListDrawable states = new StateListDrawable();
            states.addState(new int[]{android.R.attr.state_pressed},
                    ContextCompat.getDrawable(viewHolder.mCategoryIcon.getContext(), data.categorySelectedDrawableId));
            states.addState(new int[]{android.R.attr.state_selected},
                    ContextCompat.getDrawable(viewHolder.mCategoryIcon.getContext(), data.categorySelectedDrawableId));
            states.addState(new int[]{-android.R.attr.state_pressed, -android.R.attr.state_selected},
                    ContextCompat.getDrawable(viewHolder.mCategoryIcon.getContext(), data.categoryDrawableId));

            viewHolder.mCategoryIcon.setImageDrawable(states);
            viewHolder.mCategoryText.setText(data.categoryName);
            viewHolder.mCategoryNewTagText.setText(data.categoryTagName);
            viewHolder.mCategoryNewTagText.setVisibility(data.categoryIsNew ? View.VISIBLE : View.GONE);

            if (recyclerViewClickListener != null)
                viewHolder.mPaddingLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, null);
                    }
                });
        }

        @Override
        public int getViewType() {
            return DRAWER_VIEW_TYPE_CATEGORY;
        }
    }

    /**
     * Subcategory View Type classes
     */
    public static class DrawerSubCategoryItem extends DrawerCategoryItem {

        @Override
        public int getViewType() {
            return DRAWER_VIEW_TYPE_SUBCATEGORY;
        }
    }

    public static class DrawerSubCategoryViewHolder extends DrawerCategoryViewHolder {

        public LinearLayout mBackgroundLayout;

        public DrawerSubCategoryViewHolder(View view) {
            super(view);
            mBackgroundLayout = (LinearLayout) view.findViewById(R.id.drawer_item_background_linlay);
            mCategoryText.setTextSize(12);
            mBackgroundLayout.setBackgroundColor(ContextCompat.getColor(view.getContext(), R.color.background_darker_grey));
            Utils.setPaddingInDp(mPaddingLayout, view.getContext(), 24, 12, 16, 12);
        }
    }

    public static class DrawerSubCategoryViewHolderType implements RecyclerViewDataBinder<DrawerSubCategoryViewHolder, DrawerSubCategoryItem> {
        @Override
        public DrawerSubCategoryViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.drawer_list_item, parent, false);

            return new DrawerSubCategoryViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(DrawerSubCategoryViewHolder viewHolder,
                                         DrawerSubCategoryItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            StateListDrawable states = new StateListDrawable();
            states.addState(new int[]{android.R.attr.state_pressed},
                    ContextCompat.getDrawable(viewHolder.mCategoryIcon.getContext(), data.categorySelectedDrawableId));
            states.addState(new int[]{android.R.attr.state_selected},
                    ContextCompat.getDrawable(viewHolder.mCategoryIcon.getContext(), data.categorySelectedDrawableId));
            states.addState(new int[]{-android.R.attr.state_pressed, -android.R.attr.state_selected},
                    ContextCompat.getDrawable(viewHolder.mCategoryIcon.getContext(), data.categoryDrawableId));

            viewHolder.mCategoryIcon.setImageDrawable(states);
            viewHolder.mCategoryText.setText(data.categoryName);

            if (recyclerViewClickListener != null)
                viewHolder.mPaddingLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, null);
                    }
                });
        }


        @Override
        public int getViewType() {
            return DRAWER_VIEW_TYPE_SUBCATEGORY;
        }
    }

    /**
     * Secondary category View Type classes
     */

    public static class DrawerSecondaryCategoryItem implements IViewType {

        public String secondaryCategoryName;
        public String categoryTagName;
        public boolean categoryIsNew = false;

        @Override
        public int getViewType() {
            return DRAWER_VIEW_TYPE_SECONDARY_CATEGORY;
        }
    }

    public static class DrawerSecondaryCategoryViewHolder extends DrawerSubCategoryViewHolder {

        private final RobotoTextView mCategoryNewTagText;

        public DrawerSecondaryCategoryViewHolder(View view) {
            super(view);
            mCategoryIcon.setVisibility(View.GONE);
            mCategoryText.setTextSize(15);
            Utils.setPaddingInDp(mPaddingLayout, view.getContext(), 24, 10, 16, 10);
            mCategoryText.setTypeface(Typeface.defaultFromStyle(Typeface.NORMAL));
            mBackgroundLayout.setBackgroundColor(ContextCompat.getColor(view.getContext(), R.color.white_background));
            mCategoryNewTagText = (RobotoTextView) view.findViewById(R.id.drawer_category_new_tag_tv);
        }
    }

    public static class DrawerSecondaryCategoryViewHolderType implements RecyclerViewDataBinder
            <DrawerSecondaryCategoryViewHolder, DrawerSecondaryCategoryItem> {

        @Override
        public DrawerSecondaryCategoryViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.drawer_list_item, parent, false);

            return new DrawerSecondaryCategoryViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(DrawerSecondaryCategoryViewHolder viewHolder,
                                         DrawerSecondaryCategoryItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mCategoryText.setText(data.secondaryCategoryName);
            viewHolder.mCategoryNewTagText.setText(data.categoryTagName);
            viewHolder.mCategoryNewTagText.setVisibility(data.categoryIsNew ? View.VISIBLE : View.GONE);

            if (recyclerViewClickListener != null)
                viewHolder.mPaddingLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, null);
                    }
                });
        }


        @Override
        public int getViewType() {
            return DRAWER_VIEW_TYPE_SECONDARY_CATEGORY;
        }
    }
}
