/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gauthami on 10/8/16.
 */
public class ApiNotifyMe {

    public static class NotifyMeNonSignedInUserRequest {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        private long variantId;

        @SerializedName("phone_number")
        private String phoneNumber;

        public long getVariantId() {
            return variantId;
        }

        public void setVariantId(long variantId) {
            this.variantId = variantId;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }

        public void setPhoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
        }
    }

    public static class NotifyMeSignedInUserRequest {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        private long variantId;

        @SerializedName("user_id")
        private String userId;

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public long getVariantId() {
            return variantId;
        }

        public void setVariantId(long variantId) {
            this.variantId = variantId;
        }
    }


    public static class Response {

        @SerializedName("message")
        private String message = "";

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}
