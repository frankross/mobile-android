/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gauthami on 22/7/15.
 */

/**
 * COMMON SHIPPING CHARGES VIEW TYPE
 * Common product shipping charges details : contains two texts
 */
public class OrderHistoryShippingChargesViewDataBinder implements BaseRecyclerAdapter.RecyclerViewDataBinder<
        OrderHistoryShippingChargesViewHolder,
        OrderHistoryShippingChargesItem> {
    @Override
    public OrderHistoryShippingChargesViewHolder getViewHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_history_product_info_header, parent, false);

        return new OrderHistoryShippingChargesViewHolder(view, parent.getContext());
    }

    @Override
    public void bindDataToViewHolder(OrderHistoryShippingChargesViewHolder viewHolder, final OrderHistoryShippingChargesItem data,
                                     final int position, final BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {
        viewHolder.mShippingChargesTitle.setText(data.shippingChargesTxt);
        viewHolder.mShippingCharge.setText(Utils.addRupeeSymbol(viewHolder.mShippingCharge.getContext(), "",
                Utils.getFormattedDouble(data.shippingCharge)));

        viewHolder.mDiscountTotalLinLyt.setVisibility(data.discountTotal == 0.0d ? View.GONE : View.VISIBLE);
        viewHolder.mDiscountTotalTitle.setText(data.discountTotalTitle);
        viewHolder.mDiscountTotal.setText(Utils.addRupeeSymbol(viewHolder.mDiscountTotal.getContext(), "- ",
                Utils.getFormattedDouble(data.discountTotal)));

        viewHolder.mRewardPointsLinLyt.setVisibility(data.isChecked && data.rewardPoints != 0.0d ? View.VISIBLE : View.GONE);
        viewHolder.mRewardPoints.setText(Utils.addRupeeSymbol(viewHolder.mRewardPoints.getContext(), "- ",
                Utils.getFormattedDouble(data.rewardPoints)));
    }

    @Override
    public int getViewType() {
        return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_PRODUCT_INFO_HEADER;
    }
}