/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.utils;

import android.os.Parcel;
import android.os.Parcelable;

import java.io.Serializable;

public class GalleryPhotoInfo implements Parcelable, Serializable {

    public String photoPath;

    public int rotationDegree;

    public static final Creator<GalleryPhotoInfo> CREATOR = new Creator<GalleryPhotoInfo>() {

        @Override
        public GalleryPhotoInfo createFromParcel(Parcel source) {

            return new GalleryPhotoInfo(source);
        }

        @Override
        public GalleryPhotoInfo[] newArray(int size) {

            return new GalleryPhotoInfo[size];
        }
    };

    public GalleryPhotoInfo() {
    }

    public GalleryPhotoInfo(Parcel source) {
        photoPath = source.readString();
        rotationDegree = source.readInt();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(photoPath);
        dest.writeInt(rotationDegree);
    }

}
