/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.annotations.SerializedName;

/**
 * Created by gauthami on 2/5/16.
 */
public class ApiSettings {

    public static class Response {

        @SerializedName("app_settings")
        private SettingsInfo settingsInfo;

        public SettingsInfo getSettingsInfo() {
            return settingsInfo;
        }

        public void setSettingsInfo(SettingsInfo settingsInfo) {
            this.settingsInfo = settingsInfo;
        }

        public static class SettingsInfo {

            @SerializedName("otp_sender_id")
            private String otpSender = "";

            @SerializedName("otp_prefix_message")
            private String otpPrefixMessage = "";

            @SerializedName("otp_auto_read_timeout")
            private int otpTimeInterval;//1sec = 1000 milliseconds

            @SerializedName("show_redeem")
            private boolean showRedeem = false;

            @SerializedName("app_share_subject")
            private String appShareSubject;

            @SerializedName("app_share_text")
            private String appShareText;

            @SerializedName("pdp_share_subject")
            private String pdpShareSubject;

            @SerializedName("pdp_share_text")
            private String pdpShareText;

            @SerializedName("app_sharing_link_title")
            private String appShareLinkTitle;

            @SerializedName("app_sharing_link_description")
            private String appShareLinkDescription;

            @SerializedName("app_sharing_link_image_url")
            private String appShareLinkImageUrl;

            @SerializedName("referral_link_title")
            private String referralLinkTitle;

            @SerializedName("referral_link_description")
            private String referralLinkDescription;

            @SerializedName("referral_link_image_url")
            private String referralLinkImageUrl;

            public long getOtpTimeInterval() {
                return otpTimeInterval * 1000;
            }

            public String getOtpPrefixMessage() {
                return otpPrefixMessage;
            }

            public void setOtpPrefixMessage(String otpPrefixMessage) {
                this.otpPrefixMessage = otpPrefixMessage;
            }

            public String getOtpSender() {
                return otpSender;
            }

            public String getPdpShareText() {
                return pdpShareText;
            }

            public String getPdpShareSubject() {
                return pdpShareSubject;
            }

            public String getAppShareText() {
                return appShareText;
            }

            public String getAppShareSubject() {
                return appShareSubject;
            }

            public String getAppShareLinkTitle() {
                return appShareLinkTitle;
            }

            public String getAppShareLinkDescription() {
                return appShareLinkDescription;
            }

            public String getAppShareLinkImageUrl() {
                return appShareLinkImageUrl;
            }

            public String getReferralLinkTitle() {
                return referralLinkTitle;
            }

            public String getReferralLinkDescription() {
                return referralLinkDescription;
            }

            public String getReferralLinkImageUrl() {
                return referralLinkImageUrl;
            }

            public boolean isShowRedeem() {
                return showRedeem;
            }

            public void setOtpTimeInterval(int otpTimeInterval) {
                this.otpTimeInterval = otpTimeInterval;
            }

            public void setShowRedeem(boolean showRedeem) {
                this.showRedeem = showRedeem;
            }

            public void setOtpSender(String otpSender) {
                this.otpSender = otpSender;
            }

            public void setAppShareSubject(String appShareSubject) {
                this.appShareSubject = appShareSubject;
            }

            public void setAppShareText(String appShareText) {
                this.appShareText = appShareText;
            }

            public void setPdpShareSubject(String pdpShareSubject) {
                this.pdpShareSubject = pdpShareSubject;
            }

            public void setPdpShareText(String pdpShareText) {
                this.pdpShareText = pdpShareText;
            }

            public void setAppShareLinkTitle(String appShareLinkTitle) {
                this.appShareLinkTitle = appShareLinkTitle;
            }

            public void setAppShareLinkDescription(String appShareLinkDescription) {
                this.appShareLinkDescription = appShareLinkDescription;
            }

            public void setAppShareLinkImageUrl(String appShareLinkImageUrl) {
                this.appShareLinkImageUrl = appShareLinkImageUrl;
            }

            public void setReferralLinkTitle(String referralLinkTitle) {
                this.referralLinkTitle = referralLinkTitle;
            }

            public void setReferralLinkDescription(String referralLinkDescription) {
                this.referralLinkDescription = referralLinkDescription;
            }

            public void setReferralLinkImageUrl(String referralLinkImageUrl) {
                this.referralLinkImageUrl = referralLinkImageUrl;
            }
        }
    }
}
