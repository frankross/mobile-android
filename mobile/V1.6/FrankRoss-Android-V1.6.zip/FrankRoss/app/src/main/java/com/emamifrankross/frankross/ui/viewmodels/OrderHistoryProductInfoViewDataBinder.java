/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

/**
 * Created by gauthami on 22/7/15.
 */

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.utils.Utils;

/**
 * COMMON PRODUCT DETAIL ITEM VIEW TYPE
 * Common product info row that contains three info texts
 */
public class OrderHistoryProductInfoViewDataBinder implements BaseRecyclerAdapter.RecyclerViewDataBinder<OrderHistoryProductInfoViewHolder,
        OrderHistoryProductInfoItem> {
    @Override
    public OrderHistoryProductInfoViewHolder getViewHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_history_details_product_info_item, parent, false);
        return new OrderHistoryProductInfoViewHolder(view, parent.getContext());
    }

    @Override
    public void bindDataToViewHolder(OrderHistoryProductInfoViewHolder viewHolder, final OrderHistoryProductInfoItem data,
                                     final int position, final BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {
        viewHolder.mProductName.setText(data.productName);
        viewHolder.mProductQuantity.setText(String.valueOf(data.productQuantity));
        viewHolder.mProductPrice.setText(Utils.getFormattedDouble(data.productPrice));

        if (recyclerViewClickListener != null) {
            viewHolder.mProductName.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                }
            });
        }
    }

    @Override
    public int getViewType() {
        return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_PRODUCT_ITEM;
    }
}
