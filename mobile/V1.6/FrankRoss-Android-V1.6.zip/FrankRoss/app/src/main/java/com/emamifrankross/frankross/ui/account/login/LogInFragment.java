/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */
package com.emamifrankross.frankross.ui.account.login;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.emamifrankross.frankross.FrankRossApplication;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiSocialLogin;
import com.emamifrankross.frankross.core.apimodels.ApiSocialRegister;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.core.network.IApiRequestCancel;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.AlertError;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.AppRuntimePermissionsManager;
import com.emamifrankross.frankross.ui.common.IErrorHandler;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.home.HomeActivity;
import com.emamifrankross.frankross.utils.NetworkUtils;
import com.emamifrankross.frankross.utils.PreferenceUtils;
import com.emamifrankross.frankross.utils.Utils;
import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.HttpMethod;
import com.facebook.Profile;
import com.facebook.ProfileTracker;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.OptionalPendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Arrays;
import java.util.List;

/**
 * Created by gauthami on 2/7/15.
 */

/**
 * This class represents the UI for Login screen
 */
public class LogInFragment extends ApiRequestBaseFragment implements IToolbar, View.OnClickListener,
        View.OnFocusChangeListener, GoogleApiClient.OnConnectionFailedListener {

    private static final String TAG = LogInFragment.class.getSimpleName();

    private static final String FACEBOOK_TAG = "FACEBOOK";
    private static final String GOOGLE_TAG = "GOOGLE";

    private static final int REQUEST_CODE_REGISTRATION_FRAGMENT = 111;
    private static final int REQUEST_CODE_GOOGLE_SIGN_IN = 2222;

    private static final String FACEBOOK_EMAIL_KEY = "email";
    private static final String FACEBOOK_NAME_KEY = "name";
    private static final String FACEBOOK_UID_KEY = "id";

    private EditText mEmailOrPhoneNumber;
    private EditText mPassword;
    private RobotoTextView mMailClearBtn;
    private RobotoTextView mPasswordClearBtn;
    private RobotoTextView mMobileNumberPrefix;

    private boolean mIsFromCart = false;

    /**
     * Social login information to be shared with Server
     */
    private LogInCase mSocialLogIn;
    private String mSocialLoginUserName;
    private String mSocialLoginUserMailId;
    private String mSocialLoginUID;
    private String mSocialLoginAccessToken;//Token id for google;access token for facebook

    public enum LogInCase {
        DEFAULT,
        FACEBOOK,
        GOOGLE
    }

    /**
     * FACEBOOK
     */
    private CallbackManager mCallbackManager;
    private ProfileTracker mProfileTracker;

    /**
     * GOOGLE
     */
    private GoogleApiClient mGoogleApiClient;

    public static LogInFragment create(boolean isFromCart) {
        LogInFragment fragment = new LogInFragment();
        fragment.mIsFromCart = isFromCart;
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        FacebookSdk.sdkInitialize(getActivity().getApplicationContext());
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the views
     *
     * @param view the root view
     */
    private void initViews(View view) {
        CardView cartLogInCardView = (CardView) view.findViewById(R.id.log_in_from_cart_card_view);
        mEmailOrPhoneNumber = (EditText) view.findViewById(R.id.login_user_email_address_et);
        mPassword = (EditText) view.findViewById(R.id.login_user_password_et);
        Button signIn = (Button) view.findViewById(R.id.login_sign_in_btn);
        Button register = (Button) view.findViewById(R.id.login_register_btn);
        ImageView signInWithFB = (ImageView) view.findViewById(R.id.sign_in_facebook_btn);
        ImageView signInWithGoogle = (ImageView) view.findViewById(R.id.sign_in_google_button);
        mMailClearBtn = (RobotoTextView) view.findViewById(R.id.email_clear_txt_btn);
        mPasswordClearBtn = (RobotoTextView) view.findViewById(R.id.password_clear_txt_btn);
        RobotoTextView forgotPasswordBtn = (RobotoTextView) view.findViewById(R.id.login_forgot_password_tv);
        mMobileNumberPrefix = (RobotoTextView) view.findViewById(R.id.log_in_mobile_number_prefix);
        cartLogInCardView.setVisibility(mIsFromCart ? View.VISIBLE : View.GONE);
        mEmailOrPhoneNumber.addTextChangedListener(mMailIdTextChangeListener);
        mPassword.addTextChangedListener(mPasswordTextChangeListener);
        mEmailOrPhoneNumber.setOnFocusChangeListener(this);
        mPassword.setOnFocusChangeListener(this);

        mMailClearBtn.setOnClickListener(this);
        mPasswordClearBtn.setOnClickListener(this);
        signIn.setOnClickListener(this);
        register.setOnClickListener(this);
        forgotPasswordBtn.setOnClickListener(this);
        signInWithGoogle.setOnClickListener(this);
        signInWithFB.setOnClickListener(this);

        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SIGN_IN_VISIT_EVENT);

        initSocialLogIn();
    }

    /**
     * Method that initializes the Social Login Clients
     */
    private void initSocialLogIn() {
        initGoogleClient();
        initFacebookCallbackManager();
    }

    /**
     * Method to initialize the Facebook callback manager
     */
    private void initFacebookCallbackManager() {
        mCallbackManager = CallbackManager.Factory.create();
    }

    /**
     * Text watcher for mail id that helps in setting the clear button visibility
     */
    private TextWatcher mMailIdTextChangeListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            setMailIdClearButtonVisibility(charSequence);
            setViewVisibility(charSequence.toString());
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    };

    private void setViewVisibility(String charSequence) {
        if ((!TextUtils.isEmpty(charSequence) && TextUtils.isDigitsOnly(charSequence))) {
            mMobileNumberPrefix.setVisibility(View.VISIBLE);
            mEmailOrPhoneNumber.setFilters(new InputFilter[]{new InputFilter.LengthFilter(10)});
        } else {
            mMobileNumberPrefix.setVisibility(View.GONE);
            mEmailOrPhoneNumber.setFilters(new InputFilter[]{new InputFilter.LengthFilter(50)});
        }
    }

    /**
     * Method that sets the visibility of the clear buttons associated with Mail Id field
     *
     * @param charSequence that determines the state of visibility
     */
    private void setMailIdClearButtonVisibility(CharSequence charSequence) {
        mPasswordClearBtn.setVisibility(View.INVISIBLE);
        mMailClearBtn.setVisibility((!TextUtils.isEmpty(charSequence) && charSequence.length() > 0) ? View.VISIBLE : View.INVISIBLE);
    }

    /**
     * Text watcher for password id that helps in setting the clear button visibility
     */
    private TextWatcher mPasswordTextChangeListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            setPasswordClearButtonVisibility(charSequence);
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    };

    /**
     * Method that sets the visibility of the clear buttons associated with Password field
     *
     * @param charSequence that determines the state of visibility
     */
    private void setPasswordClearButtonVisibility(CharSequence charSequence) {
        mMailClearBtn.setVisibility(View.INVISIBLE);
        mPasswordClearBtn.setVisibility((!TextUtils.isEmpty(charSequence) && charSequence.length() > 0) ? View.VISIBLE : View.INVISIBLE);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.login_sign_in_btn:
                mSocialLogIn = LogInCase.DEFAULT;
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SIGN_IN_TAP_EVENT);
                performSignIn();
                break;
            case R.id.login_register_btn:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.REGISTER_CLICK_EVENT);
                loadRegistrationFragment(false);
                break;
            case R.id.email_clear_txt_btn:
                mEmailOrPhoneNumber.getText().clear();
                break;
            case R.id.password_clear_txt_btn:
                mPassword.getText().clear();
                break;
            case R.id.login_forgot_password_tv:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.FORGOT_PASSWORD_CLICK_EVENT);
                hide_keyboard(view.getContext(), view);
                mFragmentInteractionListener.loadFragment(getId(), RegisterExistingUserFragment.create(false), null,
                        R.anim.push_left_in, R.anim.fade_out,
                        FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                break;
            case R.id.sign_in_google_button:
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                        AppRuntimePermissionsManager.checkPermissionForSocialLogin(getActivity())) {
                    FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SOCIAL_SIGNIN_GOOGLE_TAP_EVENT);
                    try {
                        resetSocialLogInDetails(LogInCase.GOOGLE);
                        googleSignOut();
                    } catch (SecurityException securityException) {

                    }
                } else {
                    requestPermissions(new String[]{Manifest.permission.GET_ACCOUNTS},
                            AppRuntimePermissionsManager.REQUEST_CODE_OTP_AUTO_READ_GOOGLE_PERMISSIONS);
                }
                break;
            case R.id.sign_in_facebook_btn:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SOCIAL_SIGNIN_FACEBOOK_TAP_EVENT);
                resetSocialLogInDetails(LogInCase.FACEBOOK);
                disconnectFromFacebook();
                break;
            default:
                break;
        }
    }

    /**
     * Method to reset the Social login details
     *
     * @param logInCase the social/default login
     */
    private void resetSocialLogInDetails(LogInCase logInCase) {
        mSocialLoginAccessToken = "";
        mSocialLoginUID = "";
        mSocialLoginUserName = "";
        mSocialLoginUserMailId = "";
        mSocialLogIn = logInCase;
    }

    /**
     * GOOGLE
     */
    private void initGoogleClient() {
        Log.d(GOOGLE_TAG, "Initialize Google client for google");
        GoogleSignInOptions googleSignInOptions = new
                GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.server_debug_client_id))
                .requestEmail()
                .build();
        mGoogleApiClient = new GoogleApiClient.Builder(getActivity())
                .enableAutoManage(getActivity(), this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, googleSignInOptions)
                .build();
    }

    /**
     * Method that performs the Google sign out;To ensure that the user is not already logged-in
     */
    private void googleSignOut() {
        if (mGoogleApiClient != null) {
            mFragmentInteractionListener.showBlockingProgressBar();
            Log.d(GOOGLE_TAG, "Requesting google sign out");
            Auth.GoogleSignInApi.signOut(mGoogleApiClient).setResultCallback(
                    new ResultCallback<Status>() {
                        @Override
                        public void onResult(Status status) {
                            Log.d(GOOGLE_TAG, "Google sign out success");
                            revokeAccess();
                        }
                    });
        }
    }

    /**
     * Method that revokes the Google user login
     */
    private void revokeAccess() {
        Auth.GoogleSignInApi.revokeAccess(mGoogleApiClient).setResultCallback(
                new ResultCallback<Status>() {
                    @Override
                    public void onResult(Status status) {
                        signInWithGoogle();
                    }
                });
    }

    /**
     * Method that handles the Sign in with google button click
     */
    private void signInWithGoogle() {
        mFragmentInteractionListener.hideBlockingProgressBar();
        Intent googleSignInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
        startActivityForResult(googleSignInIntent, REQUEST_CODE_GOOGLE_SIGN_IN);
    }

    /**
     * Method that handles the Google sign in intent
     *
     * @param result the Google sign in intent result
     */
    private void handleGoogleSignInResult(GoogleSignInResult result) {
        Log.d(GOOGLE_TAG, "handle Google SignIn Result:" + result.isSuccess());
        if (result.isSuccess()) {
            GoogleSignInAccount acct = result.getSignInAccount();

            mSocialLoginUserName = acct.getDisplayName();
            mSocialLoginUserMailId = acct.getEmail();
            mSocialLoginUID = acct.getId();//UID
            mSocialLoginAccessToken = acct.getIdToken();//ID TOKEN

            Log.d(GOOGLE_TAG, "Google Personal info: Email = " + mSocialLoginUserMailId +
                    " Name = " + mSocialLoginUserName);
            Log.d(GOOGLE_TAG, "Server info: UID = " + mSocialLoginUID +
                    " Token ID = " + mSocialLoginAccessToken);
            performSocialSignIn();
        } else {
            Log.d(GOOGLE_TAG, "Failure :" + result.getStatus().getStatusMessage());
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {
        Log.d(GOOGLE_TAG, "onConnectionFailed :" + connectionResult);
    }

    /**
     * FACEBOOK REQUEST
     */
    private void requestFacebookPermissions() {
        mFragmentInteractionListener.hideBlockingProgressBar();
        LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("public_profile", "email"));
        LoginManager.getInstance().registerCallback(mCallbackManager, mFacebookCallback);
    }

    /**
     * FACEBOOK CALLBACKS
     */
    private FacebookCallback<LoginResult> mFacebookCallback = new FacebookCallback<LoginResult>() {
        @Override
        public void onSuccess(LoginResult loginResult) {
            AccessToken accessToken = loginResult.getAccessToken();
            Log.d(FACEBOOK_TAG, "Access token = " + accessToken.getToken());
            ProfileTracker profileTracker = new ProfileTracker() {
                @Override
                protected void onCurrentProfileChanged(Profile oldProfile, Profile currentProfile) {
                    this.stopTracking();
                    Profile.setCurrentProfile(currentProfile);
                    Profile profile = currentProfile == null ? oldProfile : currentProfile;
                    getFacebookUserInfo(profile);
                }
            };
            profileTracker.startTracking();
        }

        @Override
        public void onCancel() {
            Log.d(FACEBOOK_TAG, "onCancel");
        }

        @Override
        public void onError(FacebookException e) {
            Log.d(FACEBOOK_TAG, "Exception " + e);
        }
    };

    /**
     * MANAGE TO EXTRACT THE FACEBOOK INFO
     * Method that handles the Facebook sign in result
     *
     * @param profile the Facebook profile model
     */
    private void getFacebookUserInfo(final Profile profile) {
        mFragmentInteractionListener.showBlockingProgressBar();
        AccessToken accessToken = AccessToken.getCurrentAccessToken();
        mSocialLoginAccessToken = accessToken == null ? "" : accessToken.getToken();

        if (profile != null) {
            Log.d(FACEBOOK_TAG, "FB UID using profile: " + profile.getId());
            mSocialLoginUID = profile.getId();
            mSocialLoginUserName = profile.getName();
        }

        /**
         * Graph API to make sure the Login details are fetched
         */
        GraphRequest request = GraphRequest.newMeRequest(
                AccessToken.getCurrentAccessToken(),
                new GraphRequest.GraphJSONObjectCallback() {
                    @Override
                    public void onCompleted(JSONObject object, GraphResponse response) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        Log.d(FACEBOOK_TAG, response.toString());
                        if (object != null) {
                            if (object.has(FACEBOOK_NAME_KEY)) {
                                try {
                                    mSocialLoginUserName = object.getString(FACEBOOK_NAME_KEY);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                            if (object.has(FACEBOOK_UID_KEY)) {
                                try {
                                    mSocialLoginUID = object.getString(FACEBOOK_UID_KEY);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }
                            if (object.has(FACEBOOK_EMAIL_KEY)) {
                                try {
                                    mSocialLoginUserMailId = object.getString(FACEBOOK_EMAIL_KEY);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }
                            }

                            if (!TextUtils.isEmpty(mSocialLoginUID)) {
                                performSocialSignIn();
                            } else {
                                Toast.makeText(getActivity().getApplicationContext(),
                                        "Failed to connect with facebook.Please try again later", Toast.LENGTH_SHORT).show();
                            }
                        }
                        Log.d(FACEBOOK_TAG, "Personal info: Email = " + mSocialLoginUserMailId +
                                " Name = " + mSocialLoginUserName);
                    }
                });
        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,email");
        request.setParameters(parameters);
        request.executeAsync();
    }

    /**
     * Method to disconnect from Facebook account;Clears the access token
     */
    public void disconnectFromFacebook() {
        mFragmentInteractionListener.showBlockingProgressBar();
        if (AccessToken.getCurrentAccessToken() == null) {
            requestFacebookPermissions();
            return;
        }
        new GraphRequest(AccessToken.getCurrentAccessToken(), "/me/permissions/", null,
                HttpMethod.DELETE, new GraphRequest
                .Callback() {
            @Override
            public void onCompleted(GraphResponse graphResponse) {
                LoginManager.getInstance().logOut();
                AccessToken.setCurrentAccessToken(null);
                Profile.setCurrentProfile(null);
                requestFacebookPermissions();
            }
        }).executeAsync();
    }

    /**
     * Method that loads the Registration screen for Normal use case user
     */
    private void loadRegistrationFragment(boolean isSocialLogin) {
        startActivityForResult(LogInActivity.getActivityIntentForSocialLogIn(getActivity().getApplicationContext(),
                isSocialLogin ? LogInActivity.REGISTER_SOCIAL_FRAGMENT : LogInActivity.REGISTER_IN_FRAGMENT,
                mSocialLoginUserName, mSocialLoginUserMailId, mSocialLogIn == LogInCase.FACEBOOK ?
                        getString(R.string.log_in_facebook) : getString(R.string.log_in_google),
                mSocialLoginAccessToken, mSocialLoginUID), REQUEST_CODE_REGISTRATION_FRAGMENT);
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    /**
     * Method requests for Log In;If success, updates the cart count
     */
    private void performSignIn() {
        if (validateSignIn()) {
            hide_keyboard(getActivity(), mEmailOrPhoneNumber);
            mFragmentInteractionListener.showBlockingProgressBar();
            mApiRequestManager.performLoginRequest(getUserMailOrPhoneNumber(), getUserPassword(), new ApiRequestManager.ILoginResultNotifier() {
                @Override
                public void onLoginCompleted(String accessToken) {
                    getCartItems();
                }
            }, this, this);
        }
    }

    /**
     * Method requests for Social Log In;If success, updates the cart count
     */
    private void performSocialSignIn() {
        if (isAdded() && getActivity() != null) {
            hide_keyboard(getActivity(), mEmailOrPhoneNumber);
            mFragmentInteractionListener.showBlockingProgressBar();

            ApiSocialLogin.Request socialLoginRequest = new ApiSocialLogin.Request();
            ApiSocialLogin.User socialLogInUser = new ApiSocialLogin.User();
            socialLogInUser.setSocial_auth_token(mSocialLoginAccessToken);
            socialLogInUser.setSocial_login_uid(mSocialLoginUID);
            socialLogInUser.setSocial_login_provider(mSocialLogIn == LogInCase.FACEBOOK ?
                    getString(R.string.log_in_facebook) : getString(R.string.log_in_google));
            socialLogInUser.setToken(PreferenceUtils.getStringFromSharedPreference(
                    FrankRossApplication.getFrankrossApplicationContext(), PreferenceUtils.PREFERENCE_KEY_GCM_TOKEN));
            socialLoginRequest.setUser(socialLogInUser);

            mApiRequestManager.performSocialLoginRequest(socialLoginRequest, new ApiRequestManager.ISocialLoginResultNotifier() {
                @Override
                public void onSocialLoginSuccess(String accessToken) {
                    FrankRossAnalytics.getFrankRossTracker().logEvent(mSocialLogIn == LogInCase.FACEBOOK ?
                            FrankRossEvents.SOCIAL_SIGNIN_FACEBOOK_SUCCESS_EVENT
                            : FrankRossEvents.SOCIAL_SIGNIN_GOOGLE_SUCCESS_EVENT);
                    getCartItems();
                }

                @Override
                public void onSocialNewUserLoginError(String message) {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    loadRegistrationFragment(true);
                }

                @Override
                public void onSocialNewUserOtpError(String phoneNumber) {
                    mFragmentInteractionListener.hideBlockingProgressBar();

                    ApiSocialRegister.Request apiSocialRegisterRequest = new ApiSocialRegister.Request();
                    ApiSocialRegister.Request.User apiSocialRegisterUser = new ApiSocialRegister.Request.User();
                    apiSocialRegisterUser.setSocial_login_provider(mSocialLogIn == LogInCase.FACEBOOK ?
                            getString(R.string.log_in_facebook) : getString(R.string.log_in_google));
                    apiSocialRegisterUser.setSocial_login_uid(mSocialLoginUID);
                    apiSocialRegisterUser.setSocial_auth_token(mSocialLoginAccessToken);
                    apiSocialRegisterUser.setEmail(mSocialLoginUserMailId);
                    apiSocialRegisterUser.setName(mSocialLoginUserName);
                    apiSocialRegisterUser.setPrimary_phone("");
                    apiSocialRegisterRequest.setUser(apiSocialRegisterUser);
                    mFragmentInteractionListener.loadFragment(getId(), EnterOTPFragment.create(false, false, getUserMailOrPhoneNumber(),
                            phoneNumber, getUserPassword(), apiSocialRegisterRequest), null, R.anim.push_left_in, R.anim.fade_out,
                            FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                }

                @Override
                public void onSocialLoginError(String message) {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    showAlert(message);
                }
            }, this, this);
        }
    }

    /**
     * Method requests for the updated cart count
     */
    private void getCartItems() {
        final IApiRequestCancel apiRequestCancel = new IApiRequestCancel() {
            @Override
            public String getRequestTag() {
                return "Cart";
            }
        };
        mApiRequestManager.registerRequest(apiRequestCancel);
        mApiRequestManager.performGetCartItemsRequest(new ApiRequestManager.ICartItemDeleteResultNotifier() {
            @Override
            public void onCartItemDeleted() {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }

            @Override
            public void onCartResult(List<BaseRecyclerAdapter.IViewType> cartDataList) {
                mFragmentInteractionListener.hideBlockingProgressBar();

                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, new IErrorHandler() {
            @Override
            public <T> void handleError(AlertError<T> alertError, int statusCode) {
                mFragmentInteractionListener.hideBlockingProgressBar();

                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }

            @Override
            public void handleCommonError(int errorResourceId) {
                mFragmentInteractionListener.hideBlockingProgressBar();

                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, apiRequestCancel);
    }

    /**
     * @return returns user mobile number if not empty or null,else returns empty string
     */
    private String getUserMailOrPhoneNumber() {
        return (mEmailOrPhoneNumber.getText() == null) ? "" : mEmailOrPhoneNumber.getText().toString();
    }

    /**
     * @return returns user password if not empty or null,else returns empty string
     */
    private String getUserPassword() {
        return (mPassword.getText() == null) ? "" : mPassword.getText().toString();
    }

    /**
     * @return If false,displays the input or network error dialog with appropriate message;else true.
     */
    private boolean validateSignIn() {
        boolean isValid = false;

        if (TextUtils.isEmpty(getUserMailOrPhoneNumber())) {
            showAlert(getString(R.string.please_enter_your_email_or_mobile_number));
        } else if (!Utils.isValidEmail(getUserMailOrPhoneNumber()) &&
                !Utils.isValidPhoneNumber(getUserMailOrPhoneNumber())) {
            showAlert(getString(R.string.please_enter_a_valid_email_or_mobile_number));
        } else if (TextUtils.isEmpty(getUserPassword())) {
            showAlert(getString(R.string.please_enter_your_password));
        } else if (!NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
            showAlert(getString(R.string.please_check_your_network_connection));
        } else {
            isValid = true;
        }

        return isValid;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d(GOOGLE_TAG, "Login fragment on Activity result");
        mCallbackManager.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_REGISTRATION_FRAGMENT && resultCode == Activity.RESULT_OK) {
            if (mIsFromCart) {
                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
            } else {
                startActivity(HomeActivity.getActivityIntent(getActivity(), HomeActivity.ACCOUNT_FRAGMENT_TAG));
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
            }
        } else if (requestCode == REQUEST_CODE_GOOGLE_SIGN_IN) {
            OptionalPendingResult<GoogleSignInResult> opr = Auth.GoogleSignInApi.silentSignIn(mGoogleApiClient);
            if (opr.isDone()) {
                Log.d(GOOGLE_TAG, "Got cached sign-in");
                handleGoogleSignInResult(opr.get());
            } else {
                mFragmentInteractionListener.showBlockingProgressBar();
                opr.setResultCallback(new ResultCallback<GoogleSignInResult>() {
                    @Override
                    public void onResult(GoogleSignInResult googleSignInResult) {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        handleGoogleSignInResult(googleSignInResult);
                    }
                });
            }
        }
    }

    /**
     * Method that handles the error of mobile number not being verified by the user
     * Directs user to the Enter OTP screen
     *
     * @param alertError the alert error
     * @param statusCode the error status code for the request
     */
    @Override
    public <T> void handleError(AlertError<T> alertError, int statusCode) {
        if (statusCode == 403) {
            mFragmentInteractionListener.hideBlockingProgressBar();
            mFragmentInteractionListener.loadFragment(getId(), EnterOTPFragment.create(false, false, getUserMailOrPhoneNumber(),
                    getUserMailOrPhoneNumber(), getUserPassword(), null), null, R.anim.push_left_in, R.anim.fade_out,
                    FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
        } else {
            super.handleError(alertError, statusCode);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        if (mGoogleApiClient != null)
            mGoogleApiClient.connect();
        //FrankRossAnalytics.getFrankRossTracker().logTimedEvent(FrankRossEvents.TIME_SPENT_SIGN_IN_SCREEN_EVENT, null);
    }

    @Override
    public void onStop() {
        if (mGoogleApiClient != null && mGoogleApiClient.isConnected()) {
            mGoogleApiClient.stopAutoManage(getActivity());
            mGoogleApiClient.disconnect();
        }
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
        //FrankRossAnalytics.getFrankRossTracker().endTimedEvent(FrankRossEvents.TIME_SPENT_SIGN_IN_SCREEN_EVENT, null);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mGoogleApiClient.isConnected()) {
            mGoogleApiClient.connect();
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mGoogleApiClient.stopAutoManage(getActivity());
        mGoogleApiClient.disconnect();
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.log_in_btn_text);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        switch (v.getId()) {
            case R.id.login_user_password_et:
                if (!TextUtils.isEmpty(mPassword.getText().toString())) {
                    mMailClearBtn.setVisibility(View.INVISIBLE);
                    mPasswordClearBtn.setVisibility(View.VISIBLE);
                }
                break;
            case R.id.login_user_email_address_et:
                if (!TextUtils.isEmpty(mEmailOrPhoneNumber.getText().toString())) {
                    mPasswordClearBtn.setVisibility(View.INVISIBLE);
                    mMailClearBtn.setVisibility(View.VISIBLE);
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case AppRuntimePermissionsManager.REQUEST_CODE_OTP_AUTO_READ_GOOGLE_PERMISSIONS:
                if (grantResults != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SOCIAL_SIGNIN_GOOGLE_TAP_EVENT);
                    resetSocialLogInDetails(LogInCase.GOOGLE);
                    googleSignOut();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}