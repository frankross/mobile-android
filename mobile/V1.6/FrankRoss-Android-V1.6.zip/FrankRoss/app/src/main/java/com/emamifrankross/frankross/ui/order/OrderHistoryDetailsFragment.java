/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.order;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiOrderCancel;
import com.emamifrankross.frankross.core.apimodels.ApiOrderReminder;
import com.emamifrankross.frankross.core.apimodels.OrderDetails;
import com.emamifrankross.frankross.core.apimodels.RequestCartItem;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.OrderHistoryAdapter;
import com.emamifrankross.frankross.ui.adapters.OrderHistoryDetailsAdapter;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.checkout.IRemindOrderDoneClickNotifier;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.products.ProductDetailActivity;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryProductInfoItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 15/7/15.
 */

/**
 * This class represents the UI for Order details screen
 */
public class OrderHistoryDetailsFragment extends ApiRequestBaseFragment implements IToolbar,
        BaseRecyclerAdapter.RecyclerItemClickListener,
        View.OnClickListener, IRemindOrderDoneClickNotifier, OrderCancellationDialogFragment.IOrderCancelSubmitListener {

    private static final String TAG = OrderHistoryDetailsFragment.class.getSimpleName();
    private static final String ORDER_DETAILS_KEY = "order_id_key";
    private static final String ORDER_DETAILS_MESSAGE = "paytm_message";

    private List<BaseRecyclerAdapter.IViewType> mOrderHistoryDetailData = new ArrayList<>();
    private OrderHistoryDetailsAdapter mOrderHistoryDetailAdapter;
    private List<OrderDetails.OrderProductItem> mOrderDetailsList = new ArrayList<>();
    private Button mOrderBtn;

    private String mDoctorName;
    private String mPatientName;
    private String mAlertMessage;
    private long mOrderId;
    private boolean isOrderMismatched = false;

    public static OrderHistoryDetailsFragment create(long orderId, String responseMessage) {
        OrderHistoryDetailsFragment fragment = new OrderHistoryDetailsFragment();

        Bundle bundle = new Bundle();
        bundle.putLong(ORDER_DETAILS_KEY, orderId);
        bundle.putString(ORDER_DETAILS_MESSAGE, responseMessage);

        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mOrderId = getArguments().getLong(ORDER_DETAILS_KEY);
            mAlertMessage = getArguments().getString(ORDER_DETAILS_MESSAGE);
        }
        mOrderHistoryDetailAdapter = new OrderHistoryDetailsAdapter(mOrderHistoryDetailData);
    }

    /**
     * Method that requests for Order details
     */
    private void performOrderHistoryDetailsRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performOrderDetailsRequest(
                mOrderId, new ApiRequestManager.IOderDetailsResultNotifier() {
                    @Override
                    public void onOrderDetailsFetched(List<BaseRecyclerAdapter.IViewType> orderList, List<OrderDetails.OrderProductItem> orderDetailsList,
                                                      String doctorName, String patientName) {
                        if (orderList != null && orderList.size() > 0 && getActivity() != null && isAdded()) {

                            mOrderBtn.setVisibility(View.VISIBLE);
                            OrderHistoryDetailsAdapter.OrderHistoryItem orderHistoryItem =
                                    (OrderHistoryDetailsAdapter.OrderHistoryItem) orderList.get(0);
                            if (orderHistoryItem.isOrderMismatched) {
                                mOrderBtn.setEnabled(true);
                                isOrderMismatched = true;
                                mOrderId = orderHistoryItem.orderId;
                                mOrderBtn.setText(getString(R.string.update_order));
                            } else {
                                isOrderMismatched = false;
                                mOrderBtn.setEnabled(orderHistoryItem.isReOrderable);
                                mOrderBtn.setTextColor(ContextCompat.getColor(getActivity(),
                                        !((OrderHistoryDetailsAdapter.OrderHistoryItem) orderList.get(0)).isReOrderable ?
                                                R.color.common_header_text_color : R.color.white_background));
                                mOrderBtn.setText(getString(R.string.re_order_btn_txt));
                            }
                            mOrderDetailsList.clear();
                            mOrderDetailsList.addAll(orderDetailsList);

                            mOrderHistoryDetailData.clear();
                            mOrderHistoryDetailData.addAll(orderList);
                            mOrderHistoryDetailAdapter.notifyDataSetChanged();
                            mFragmentInteractionListener.hideBlockingProgressBar();

                            //Whether to show the Transaction failure message from mapped Paytm strings
                            if (!TextUtils.isEmpty(mAlertMessage)) {
                                showAlert(mAlertMessage);
                                mAlertMessage = null;//Display the pop up only first time navigation to Order detail screen
                            }

                            mDoctorName = doctorName;
                            mPatientName = patientName;
                        }
                    }
                }, this, this);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_order_history_details, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initOrderDetailsRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the views associated to Order details views
     *
     * @param view the root view
     */
    private void initOrderDetailsRecyclerView(View view) {
        RecyclerView orderHistoryDetailsRecyclerView = (RecyclerView) view.
                findViewById(R.id.order_details_recycler_view);
        orderHistoryDetailsRecyclerView.setHasFixedSize(false);
        orderHistoryDetailsRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mOrderHistoryDetailAdapter.setRecyclerItemClickListener(this);
        orderHistoryDetailsRecyclerView.setAdapter(mOrderHistoryDetailAdapter);

        mOrderBtn = (Button) view.findViewById(R.id.order_details_bottom_btn);
        mOrderBtn.setOnClickListener(this);
        mOrderBtn.setVisibility(View.GONE);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ORDER_DETAILS_VISIT_EVENT);
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        performOrderHistoryDetailsRequest();
        //FrankRossAnalytics.getFrankRossTracker().logTimedEvent(FrankRossEvents.TIME_SPENT_ORDER_DETAILS_SCREEN_EVENT, null);
    }

    @Override
    public void onStop() {
        super.onStop();
        //FrankRossAnalytics.getFrankRossTracker().endTimedEvent(FrankRossEvents.TIME_SPENT_ORDER_DETAILS_SCREEN_EVENT, null);
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return (getString(R.string.drawer_menu_order_number) + " " + mOrderId);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {

        if (object == null) return;
        switch (((OrderHistoryAdapter.IViewType) object).getViewType()) {
            case ViewTypes.OrderHistoryViewType.ORDER_HISTORY_PRODUCT_INFO_FOOTER:
                OrderHistoryDetailsAdapter.CancelOrderDataItem dataItem =
                        (OrderHistoryDetailsAdapter.CancelOrderDataItem) object;
                if (dataItem.footerTxt.contains(getString(R.string.order_history_cancel_this_order))) {
                    performOrderCancellationReasonsRequest(dataItem.isPostPaid);
                } else {
                    FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ORDER_RETURN_EVENT);
                    mFragmentInteractionListener.showAlert(getString(R.string.return_this_order_title),
                            getString(R.string.return_this_order_dialog_msg), getString(R.string.ok), null, null, null, true);
                }
                break;
            case ViewTypes.OrderHistoryViewType.ORDER_HISTORY_RE_ORDER:
                switch (view.getId()) {
                    case R.id.order_history_re_order_reminder_switch_btn:
                        OrderHistoryDetailsAdapter.ReOrderDataItem reOrderItem =
                                (OrderHistoryDetailsAdapter.ReOrderDataItem) object;
                        if (reOrderItem.isChecked) {
                            showRemindOrderDialog();
                        } else {
                            performDeleteReOrderReminderRequest();
                        }
                        break;
                    case R.id.order_history_re_order_reminder_edit_tv:
                        showRemindOrderDialog();
                        break;
                }
                break;

            case ViewTypes.OrderHistoryViewType.ORDER_HISTORY_PRODUCT_ITEM:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PDP_LAUNCH_FROM_ORDER_DETAIL_EVENT);
                OrderHistoryProductInfoItem productInfoItem = (OrderHistoryProductInfoItem) object;
                handleProductItemClick(productInfoItem.variantId,
                        productInfoItem.isPharma, productInfoItem.isActive);
                break;
        }
    }

    /**
     * Method handles the PDP launch
     *
     * @param variantId the product ID
     * @param isPharma  the flag to identify the category of product(Pharma /Non Pharma)
     * @param isActive  the flag that identifies if the Product is available in the User selected city
     */
    private void handleProductItemClick(long variantId, boolean isPharma, boolean isActive) {
        if (isActive) {
            startActivity(ProductDetailActivity.getActivityIntent(getActivity().getApplicationContext(),
                    isPharma ? ProductDetailActivity.PHARMA_PRODUCT_DETAIL_FRAGMENT_ID :
                            ProductDetailActivity.NON_PHARMA_PRODUCT_DETAIL_FRAGMENT_ID,
                    variantId));
            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        } else {
            showAlert(getString(R.string.no_variant_information));
        }
       /* mFragmentInteractionListener.loadFragment(getId(),
                ReturnProductsListingFragment.create(), null,
                R.anim.push_left_in, R.anim.push_left_out,
                FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);*/
    }

    /**
     * Method that requests for Turning off the reorder reminder
     */
    private void performDeleteReOrderReminderRequest() {
        mApiRequestManager.performReOrderReminderDeleteRequest(mOrderId, new ApiRequestManager.IReOrderReminderDeleteResultNotifier() {
            @Override
            public void onReminderDelete() {
                mOrderBtn.setVisibility(View.VISIBLE);
                mFragmentInteractionListener.showAlert(getString(R.string.remind_order_delete_title),
                        getString(R.string.remind_order_delete_msg),
                        getString(R.string.ok), null, null, null, true);
                refreshOrderHistoryDetailsData();
            }
        }, this, this);
    }

    /**
     * Method pops up a Remind order dialog where user is allowed to
     * choose the reminder interval for an order
     */
    private void showRemindOrderDialog() {
        RemindOrderDialogFragment remindOrderDialogFragment = RemindOrderDialogFragment.create(this);
        remindOrderDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.order_details_bottom_btn:
                if (isOrderMismatched) {
                    startActivity(CartActivity.getActivityIntentForRevisedOrder(mDoctorName,
                            mPatientName, getActivity(), mOrderId));
                    getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                } else {
                    mFragmentInteractionListener.showBlockingProgressBar();
                    addReorderedItemsToCart();
                }
                break;
        }
    }

    /**
     * Method to add the products into the cart which are to be reordered
     */
    private void addReorderedItemsToCart() {
        new AsyncTask<Void, Void, List<RequestCartItem>>() {

            @Override
            protected List<RequestCartItem> doInBackground(Void... params) {
                List<RequestCartItem> requestCartItems = new ArrayList<>(1);
                for (OrderDetails.OrderProductItem orderedItem : mOrderDetailsList) {
                    if (orderedItem.getVariantId() > 0) {
                        RequestCartItem cartItem = new RequestCartItem();
                        cartItem.setVariantId(orderedItem.getVariantId());

                        int quantity = mApiRequestManager.getCartItemQuantityForReOrder(
                                orderedItem.getVariantId(), orderedItem.getQuantity());

                        cartItem.setQuantity(quantity);

                        requestCartItems.add(cartItem);
                    }
                }

                return requestCartItems;
            }

            @Override
            protected void onPostExecute(List<RequestCartItem> requestCartItems) {
                super.onPostExecute(requestCartItems);
                performAddToCart(requestCartItems);
            }
        }.execute();
    }

    /**
     * Method requests for Adding multiple products to cart
     *
     * @param requestCartItems the cart items to be added
     */
    private void performAddToCart(final List<RequestCartItem> requestCartItems) {

        mApiRequestManager.performAddCartRequest(requestCartItems, new ApiRequestManager.IAddCartResultNotifier() {

            @Override
            public void onProductAdded() {
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.RE_ORDER_FROM_DERAIL_EVENT);
                mFragmentInteractionListener.hideBlockingProgressBar();
                startActivity(CartActivity.getActivityIntentForPatientDetails(mDoctorName, mPatientName, getActivity()));
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
            }

            @Override
            public void onProductAddFailed() {
                Toast.makeText(getActivity().getApplicationContext(),
                        getString(R.string.add_to_cart_failure_msg), Toast.LENGTH_SHORT).show();
                mFragmentInteractionListener.hideBlockingProgressBar();
            }
        }, this, this);
    }

    /**
     * Callback invoked once the reorder reminder is turned on
     *
     * @param apiOrderReminderRequest the date when the reminder has to be set
     */
    @Override
    public void onRemindOrderDoneClick(ApiOrderReminder.Request apiOrderReminderRequest) {
        mApiRequestManager.performReOrderReminderListRequest(mOrderId, apiOrderReminderRequest, new ApiRequestManager.IReOrderReminderResultNotifier() {
            @Override
            public void onReminderSet() {
                mFragmentInteractionListener.showAlert(getString(R.string.remind_order_success_title),
                        getString(R.string.remind_order_succes_msg), getString(R.string.ok), null, null, null, true);
                refreshOrderHistoryDetailsData();
            }
        }, this, this);
    }

    /**
     * Callback to be invoked on not turning on reorder reminder
     */
    @Override
    public void onRemindOrderCancel() {
        refreshOrderHistoryDetailsData();
    }

    private void refreshOrderHistoryDetailsData() {
        performOrderHistoryDetailsRequest();
    }

    /**
     * Method requests for Reasons to Cancel the order
     *
     * @param isPostPaid the flag that determines the Payment mode- Postpaid or Prepaid
     */
    private void performOrderCancellationReasonsRequest(final boolean isPostPaid) {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performOrderCancellationReasonRequest(new ApiRequestManager.IOrderCancellationReasonResultNotifier() {
            @Override
            public void onCancellationReasons(List<String> uiDataList) {
                mFragmentInteractionListener.hideBlockingProgressBar();
                mOrderBtn.setVisibility(View.VISIBLE);
                OrderCancellationDialogFragment orderCancellationDialogFragment = OrderCancellationDialogFragment.
                        create(OrderHistoryDetailsFragment.this, uiDataList, isPostPaid);
                orderCancellationDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
            }
        }, this, this);
    }

    /**
     * Callback to be invoked on cancel order tap with a valid reason
     *
     * @param reason  the mandatory field;reason for cancelling the order
     * @param comment the optional field; editable field for entering the comments if any
     */
    @Override
    public void onOrderCancelListener(String reason, String comment) {
        performCancelOrderRequest(reason, comment);
    }

    /**
     * Method that requests for cancelling the order
     *
     * @param reason  reason for cancelling the order
     * @param comment comments if any
     */
    private void performCancelOrderRequest(String reason, String comment) {
        mFragmentInteractionListener.showBlockingProgressBar();
        ApiOrderCancel.Request apiOrderCancel = new ApiOrderCancel.Request();
        apiOrderCancel.setReason(reason);
        apiOrderCancel.setRemarks(comment);
        mApiRequestManager.performCancelOrderRequest(mOrderId, apiOrderCancel, new ApiRequestManager.ICancelOrderResultNotifier() {
            @Override
            public void onOrderCancelled(String message) {
                refreshOrderHistoryDetailsData();
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ORDER_CANCEL_EVENT);
                mFragmentInteractionListener.hideBlockingProgressBar();
                mOrderBtn.setVisibility(View.VISIBLE);
                mFragmentInteractionListener.showAlert(getString(R.string.cancel_order_success_dialog_title),
                        message,
                        null, getString(R.string.ok),
                        null, null, false);
            }
        }, this, this);
    }
}
