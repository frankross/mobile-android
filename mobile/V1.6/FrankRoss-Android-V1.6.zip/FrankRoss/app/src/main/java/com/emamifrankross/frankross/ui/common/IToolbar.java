/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

import android.support.v7.widget.Toolbar;
import android.view.View;

/**
 * Created by gowtham on 5/7/15.
 */
public interface IToolbar {

    int getToolbarNavigationIconId();

    View.OnClickListener getNavigationClickListener();

    String getToolbarTitleId();

    int getToolbarMenuId();

    Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener();
}
