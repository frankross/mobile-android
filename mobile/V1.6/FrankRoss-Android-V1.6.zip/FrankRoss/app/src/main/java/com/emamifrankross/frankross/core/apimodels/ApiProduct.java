/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 31/7/15.
 */
public class ApiProduct {

    private long id;

    private long primaryCategoryId;

    private String productName = "";

    private String brandName = "";

    private String manufacturerName = "";

    private String productType = "";

    private String productInventoryLabel = "";

    private String productDescription = "";

    private String productCashBackMessage = "";

    private double mrpPrice = 0d;

    private double sellingPrice = 0d;

    private double promotionalPrice = 0d;

    private double discount = 0d;

    private List<String> medicineTypeImageUrls = new ArrayList<>(1);

    private List<String> productImageUrls = new ArrayList<>(1);

    private boolean isAvailable = true;

    private boolean isNotifyMe = false;

    private boolean isCashBack = false;

    private boolean isPrescriptionRequired = true;

    private int maxOrderableQuantity = 0;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getProductName() {
        return productName;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType;
    }

    public double getMrpPrice() {
        return mrpPrice;
    }

    public void setMrpPrice(double mrpPrice) {
        this.mrpPrice = mrpPrice;
    }

    public double getSellingPrice() {
        return sellingPrice;
    }

    public void setSellingPrice(double sellingPrice) {
        this.sellingPrice = sellingPrice;
    }

    public List<String> getMedicineTypeImageUrl() {
        return medicineTypeImageUrls;
    }

    public void setMedicineTypeImageUrl(List<String> medicineTypeImageUrl) {
        this.medicineTypeImageUrls = medicineTypeImageUrl;
    }

    public List<String> getProductImageUrls() {
        return productImageUrls;
    }

    public void setProductImageUrls(List<String> productImageUrls) {
        this.productImageUrls = productImageUrls;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setIsAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    public int getMaxOrderableQuantity() {
        return maxOrderableQuantity;
    }

    public void setMaxOrderableQuantity(int maxOrderableQuantity) {
        this.maxOrderableQuantity = maxOrderableQuantity;
    }

    public String getManufacturerName() {
        return manufacturerName;
    }

    public void setManufacturerName(String manufactureName) {
        this.manufacturerName = manufactureName;
    }

    public boolean isPrescriptionRequired() {
        return isPrescriptionRequired;
    }

    public void setIsPrescriptionRequired(boolean isPrescriptionRequired) {
        this.isPrescriptionRequired = isPrescriptionRequired;
    }

    public long getPrimaryCategoryId() {
        return primaryCategoryId;
    }

    public void setPrimaryCategoryId(long primaryCategoryId) {
        this.primaryCategoryId = primaryCategoryId;
    }

    public double getPromotionalPrice() {
        return promotionalPrice;
    }

    public void setPromotionalPrice(double promotionalPrice) {
        this.promotionalPrice = promotionalPrice;
    }

    public double getDiscount() {
        return discount;
    }

    public void setDiscount(double discount) {
        this.discount = discount;
    }

    public String getProductInventoryLabel() {
        return productInventoryLabel;
    }

    public void setProductInventoryLabel(String productInventoryLabel) {
        this.productInventoryLabel = productInventoryLabel;
    }

    public void setIsNotifyMe(boolean notifyMe) {
        this.isNotifyMe = notifyMe;
    }

    public boolean isNotifyMe() {
        return isNotifyMe;
    }

    public boolean isCashBack() {
        return isCashBack;
    }

    public void setIsCashBack(boolean cashBack) {
        isCashBack = cashBack;
    }

    public String getProductCashBackMessage() {
        return productCashBackMessage;
    }

    public void setProductCashBackMessage(String productCashBackMessage) {
        this.productCashBackMessage = productCashBackMessage;
    }
}
