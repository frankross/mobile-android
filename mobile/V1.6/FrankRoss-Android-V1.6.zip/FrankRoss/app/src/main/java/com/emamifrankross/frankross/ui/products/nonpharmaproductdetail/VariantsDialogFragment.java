/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.products.nonpharmaproductdetail;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.VariantSelectionAdapter;
import com.emamifrankross.frankross.ui.common.BaseDialogFragment;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 10/7/15.
 */

/**
 * This class represents the UI for Variants selection dialog fragment
 */
public class VariantsDialogFragment extends BaseDialogFragment implements
        BaseRecyclerAdapter.RecyclerItemClickListener {

    public static final String TAG = VariantsDialogFragment.class.getSimpleName();

    private IVariantSelectNotifier mVariantSelectNotifier;

    private String mTitle = "";
    private boolean mIsPrimaryVariant = true;
    private boolean isTapped = false;

    private VariantSelectionAdapter mVariantSelectionAdapter;
    private List<BaseRecyclerAdapter.IViewType> mVariantValues = new ArrayList<>();

    public static VariantsDialogFragment create() {
        return new VariantsDialogFragment();
    }

    public void create(String title, List<BaseRecyclerAdapter.IViewType> variantValues, boolean isPrimaryVariant) {
        mTitle = title;
        mVariantValues = variantValues;
        mIsPrimaryVariant = isPrimaryVariant;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mVariantSelectionAdapter = new VariantSelectionAdapter(mVariantValues);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        try {
            mVariantSelectNotifier = (IVariantSelectNotifier) activity;
        } catch (ClassCastException exception) {
            throw new ClassCastException(activity.toString()
                    + " must implement IVariantSelectNotifier");
        }
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_variant_selection_dialog;
    }

    @Override
    public void initViews(Dialog view) {
        view.setCanceledOnTouchOutside(true);
        RobotoTextView dialogTitle = (RobotoTextView) view.findViewById(R.id.variant_selection_dialog_title);
        RecyclerView variantsRecyclerView = (RecyclerView) view.findViewById(R.id.variant_selection_recycler_view);

        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (int) (0.3 * Utils.getDisplayHeight(getActivity())));
        variantsRecyclerView.setLayoutParams(layoutParams);
        variantsRecyclerView.setHasFixedSize(false);
        variantsRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mVariantSelectionAdapter.setRecyclerItemClickListener(this);
        variantsRecyclerView.setAdapter(mVariantSelectionAdapter);

        dialogTitle.setText(mTitle);
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        isTapped = true;
        VariantSelectionAdapter.VariantSelectionItem variantSelectionItem =
                (VariantSelectionAdapter.VariantSelectionItem) object;
        variantSelectionItem.state = VariantSelectionAdapter.VariantStates.SELECTED;
        mVariantSelectNotifier.onVariantSelect(variantSelectionItem, mIsPrimaryVariant);
        getDialog().dismiss();
    }

    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        if (!isTapped)
            mVariantSelectNotifier.onDialogDismiss(mIsPrimaryVariant);
    }

    /**
     * Interface definition for a callback to be invoked when variant selection made
     */
    public interface IVariantSelectNotifier {
        /**
         * Called when user selects a variant
         *
         * @param variantDataItem  the variant info that was selected
         * @param isPrimaryVariant true if the variant selected is primary variant
         */
        void onVariantSelect(VariantSelectionAdapter.VariantSelectionItem variantDataItem, boolean isPrimaryVariant);

        /**
         * Called when user do not make any selection or tap outside the dialog
         *
         * @param isPrimaryVariant true if the variant selected is primary variant
         */
        void onDialogDismiss(boolean isPrimaryVariant);
    }
}
