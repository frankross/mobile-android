/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross;

import android.app.Application;
import android.content.Context;

import com.apptentive.android.sdk.Apptentive;
import com.emamifrankross.frankross.core.network.UrlConstants;
import com.emamifrankross.frankross.sdkmanager.ApptentiveManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.utils.Utils;

import io.branch.referral.Branch;

/**
 * Created by gowtham on 22/7/15.
 */

/**
 * This class represents the Application and initializes the sdks and base urls
 */
public class FrankRossApplication extends Application {

    public static FrankRossApplication sAppInstance;

    public static Context getFrankrossApplicationContext() {
        return sAppInstance.getApplicationContext();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        sAppInstance = this;
        Branch.getAutoInstance(this);
        Utils.printKeyHash(this);
        FrankRossAnalytics.getFrankRossTracker().init(getApplicationContext());
        Apptentive.register(this, ApptentiveManager.APPTENTIVE_TOKEN);
        UrlConstants.initUrls();
    }
}
