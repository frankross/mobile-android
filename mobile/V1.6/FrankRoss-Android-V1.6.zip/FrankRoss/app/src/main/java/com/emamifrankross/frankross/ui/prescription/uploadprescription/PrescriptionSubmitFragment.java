/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.prescription.uploadprescription;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.customviews.TouchImageView;
import com.emamifrankross.frankross.utils.BitmapUtils;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Log;

/**
 * Created by gowtham on 6/7/15.
 */

/**
 * This class represents the UI for Prescription submit screen
 */
public class PrescriptionSubmitFragment extends ApiRequestBaseFragment implements IToolbar,
        View.OnClickListener, View.OnTouchListener {
    public static final String TAG = PrescriptionSubmitFragment.class.getSimpleName();

    private static final String PHOTO_PATH = "photo_path";
    private static final String PHOTO_ROTATION_DEGREE = "photo_rotation_degree";
    private static final String PRESCRIPTION_ID = "prescription_id";
    private static final String IS_CHECK_OUT = "is_check_out";
    private static final String IS_FROM_CART = "is_from_cart";
    private LinearLayout mUploadAnotherPrescriptionLayout;
    private TouchImageView mPrescriptionImage;
    private Button mSubmitButton;
    private Button mRetakeButton;
    private String mPhotoPath;
    private IUploadPrescriptionListener mUploadPrescriptionListener;
    private long mPrescriptionUploadId = -1;
    private float mPhotoRotationDegree = 0;
    private boolean mIsPrescriptionUploaded;
    private boolean mIsFromCart;

    public static PrescriptionSubmitFragment create(String photoPath, float rotationDegree, long prescriptionId,
                                                    boolean isCheckout, boolean isFromCart) {
        PrescriptionSubmitFragment fragment = new PrescriptionSubmitFragment();
        Bundle bundle = new Bundle();
        bundle.putString(PHOTO_PATH, photoPath);
        bundle.putFloat(PHOTO_ROTATION_DEGREE, rotationDegree);
        bundle.putLong(PRESCRIPTION_ID, prescriptionId);
        bundle.putBoolean(IS_CHECK_OUT, isCheckout);
        bundle.putBoolean(IS_FROM_CART, isFromCart);

        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();

        if (bundle != null && bundle.containsKey(PHOTO_PATH) && bundle.containsKey(PHOTO_ROTATION_DEGREE)) {
            mPhotoPath = bundle.getString(PHOTO_PATH);
            mPhotoRotationDegree = bundle.getFloat(PHOTO_ROTATION_DEGREE);
            mPrescriptionUploadId = bundle.getLong(PRESCRIPTION_ID);
            mIsFromCart = bundle.getBoolean(IS_FROM_CART);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            mUploadPrescriptionListener = (IUploadPrescriptionListener) context;
        } catch (ClassCastException classCastException) {
            throw new ClassCastException(classCastException.toString()
                    + " must implement IUploadPrescriptionListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_upload_another_prescription, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);

        setValues();
    }

    private void initViews(View view) {
        mUploadAnotherPrescriptionLayout = (LinearLayout) view.findViewById(R.id.upload_another_prescription_linlay);
        mUploadAnotherPrescriptionLayout.setVisibility(View.GONE);
        mPrescriptionImage = (TouchImageView) view.findViewById(R.id.upload_prescription_image);
        RobotoTextView uploadAnotherPrescription = (RobotoTextView) view.findViewById(R.id.upload_another_prescription_tv);
        mSubmitButton = (Button) view.findViewById(R.id.upload_prescription_submit_btn);
        mRetakeButton = (Button) view.findViewById(R.id.upload_prescription_retake_btn);
        mRetakeButton.setVisibility(View.VISIBLE);

        mSubmitButton.setOnClickListener(this);
        mRetakeButton.setOnClickListener(this);
        uploadAnotherPrescription.setOnClickListener(this);
    }

    private void setValues() {
        if (mPhotoPath != null) {
            setScaledImage();
        }
    }

    private void setScaledImage() {
        mFragmentInteractionListener.showBlockingProgressBar();
        // Get screen size in pixels.
        DisplayMetrics metrics = new DisplayMetrics();
        getActivity().getWindowManager().getDefaultDisplay().getMetrics(metrics);

        getGalleryImage(mPhotoPath, mPhotoRotationDegree,
                metrics.widthPixels, metrics.heightPixels, new GetScaledImageCallback() {

                    @Override
                    public void onImageScaled(Bitmap bitmap) {
                        if (bitmap != null) {
                            Log.d(TAG, " scaled bitmap width = " + bitmap.getWidth() + " scaled bitmap height = " + bitmap.getHeight());
                            mPrescriptionImage.setImageBitmap(bitmap);
                            mPrescriptionImage.invalidate();
                        }
                        mFragmentInteractionListener.hideBlockingProgressBar();
                    }

                    @Override
                    public void onImageCorrupted() {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        showAlert("Corrupted Image. Please choose another image.", new AlertDialogFragment.AlertPositiveActionListener() {
                            @Override
                            public void onPositiveAction() {
                                closeFragment();
                            }
                        }, false);
                    }
                });
    }

    public void getGalleryImage(final String imagePath, final float rotationDegree, final int reqWidth,
                                final int reqHeight, final GetScaledImageCallback callback) {
        new AsyncTask<Void, Void, Bitmap>() {

            @Override
            protected Bitmap doInBackground(Void... params) {
                Bitmap bitmap = BitmapUtils.getScaledBitmap(imagePath, reqWidth, reqHeight);
                if (bitmap != null) {
                    Matrix matrix = new Matrix();
                    matrix.postRotate(rotationDegree);

                    return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
                }

                return bitmap;
            }

            @Override
            protected void onPostExecute(Bitmap result) {
                if (result != null) {
                    android.util.Log.d(TAG,
                            " scaled bitmap width = " + result.getWidth() + " scaled bitmap height = " + result.getHeight());
                    callback.onImageScaled(result);
                } else {
                    callback.onImageCorrupted();
                }
            }
        }.execute();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.upload_prescription_submit_btn:
                if (mIsPrescriptionUploaded) {
                    completePrescriptionUpload();
                } else {
                    uploadPrescription();
                }
                break;

            case R.id.upload_another_prescription_tv:
                getActivity().onBackPressed();
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.UPLOAD_ANOTHER_PRESCRIPTION_CLICK_EVENT);
                break;
            case R.id.upload_prescription_retake_btn:
            default:
                getActivity().onBackPressed();
                break;
        }
    }

    private void completePrescriptionUpload() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.UPLOAD_PRESCRIPTION_DONE_CLICK_EVENT);
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performPrescriptionUploadComplete(mPrescriptionUploadId, new ApiRequestManager.IPrescriptionCompleteListener() {

            @Override
            public void onPrescriptionUploadCompleted() {
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.UPLOAD_PRESCRIPTION_EVENT);
                Intent data = new Intent();
                data.putExtra(Constants.INTENT_EXTRA_PRESCRIPTION_ID, mPrescriptionUploadId);

                getActivity().setResult(Activity.RESULT_OK, data);
                getActivity().finish();
            }
        }, this, this);
    }

    private void uploadPrescription() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.UPLOAD_PRESCRIPTION_SUBMIT_CLICK_EVENT);
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performUploadPrescriptionRequest(mPrescriptionUploadId, mPhotoPath, mIsFromCart, new ApiRequestManager.IUploadPrescriptionNotifier() {
            @Override
            public void onPrescriptionUploaded(long prescriptionId) {
                mPrescriptionUploadId = prescriptionId;
                mUploadPrescriptionListener.prescriptionUploaded(prescriptionId);
                mIsPrescriptionUploaded = true;
                mSubmitButton.setText(getString(R.string.done));
                mRetakeButton.setVisibility(View.GONE);
                mPrescriptionImage.resetZoom();
                mUploadAnotherPrescriptionLayout.setVisibility(View.VISIBLE);
                mUploadAnotherPrescriptionLayout.setOnTouchListener(PrescriptionSubmitFragment.this);
                mFragmentInteractionListener.hideBlockingProgressBar();
            }
        }, this, this);
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        return true;
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return 0;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {

        return null;
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_upload_prescription);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    public interface IUploadPrescriptionListener {
        void prescriptionUploaded(long prescriptionId);
    }

    public interface GetScaledImageCallback {
        void onImageScaled(Bitmap bitmap);

        void onImageCorrupted();
    }
}
