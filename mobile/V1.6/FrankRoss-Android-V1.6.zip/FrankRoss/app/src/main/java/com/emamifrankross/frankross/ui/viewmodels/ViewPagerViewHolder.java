/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.app.Activity;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.customviews.CirclePageIndicator;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gowtham on 17/12/15.
 */

/**
 * COMMON VIEW PAGER  VIEW HOLDER
 */
public class ViewPagerViewHolder extends RecyclerView.ViewHolder {

    public ViewPager mViewPager;
    public CirclePageIndicator mPagerIndicator;

    public ViewPagerViewHolder(View itemView) {
        super(itemView);

        mViewPager = (ViewPager) itemView.findViewById(R.id.home_top_offers_pager);
        mPagerIndicator = (CirclePageIndicator) itemView.findViewById(R.id.top_offers_pager_indicator);

        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, (int) (0.23 * Utils.getDisplayHeight((Activity) mViewPager.getContext())));
        mViewPager.setLayoutParams(layoutParams);
    }
}
