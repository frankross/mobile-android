/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.utils;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.support.v4.app.ActivityCompat;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.Patterns;

import java.util.regex.Pattern;

/**
 * Created by gauthami on 18/5/16.
 */
public class UserInfoUtils {

    /**
     * Method that Reads the User's name
     *
     * @param context the application context
     * @return User's name
     */
    public static String getUsername(Context context) {
        String userName = "";
        Cursor c = context.getContentResolver().query(ContactsContract.Profile.CONTENT_URI, null, null, null, null);

        if (c != null) {
            int count = c.getCount();
            String[] columnNames = c.getColumnNames();
            c.moveToFirst();
            int position = c.getPosition();
            if (count == 1 && position == 0) {
                for (String columnName : columnNames) {
                    if (!TextUtils.isEmpty(columnName) && columnName.equals(ContactsContract.Profile.DISPLAY_NAME))
                        userName = c.getString(c.getColumnIndex(columnName));
                }
            }
            c.close();
        }

        return userName;
    }

    /**
     * Method that reads the User's mail address which he is currently logged in
     *
     * @param context the application context
     * @return User's mail address
     */
    public static String getUserMailId(Context context) {
        Pattern emailPattern = Patterns.EMAIL_ADDRESS; // API level 8+
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.GET_ACCOUNTS) != PackageManager.PERMISSION_GRANTED) {
            Account[] accounts = AccountManager.get(context).getAccounts();
            for (Account account : accounts) {
                if (emailPattern.matcher(account.name).matches()) {
                    return account.name;
                }
            }
        }
        return null;
    }

    /**
     * Method that reads the User's phone number from the mobile app
     *
     * @param context the application context
     * @return User's phone number
     */
    public static String getUserPhoneNumber(Context context) {
        TelephonyManager tm = (TelephonyManager) context.getSystemService(context.TELEPHONY_SERVICE);
        String number = tm.getLine1Number();
        if (!TextUtils.isEmpty(number) && number.startsWith("+91"))
            number = number.substring(3, number.length());
        return number;
    }
}
