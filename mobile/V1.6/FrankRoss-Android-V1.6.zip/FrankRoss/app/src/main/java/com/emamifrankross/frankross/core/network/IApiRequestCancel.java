/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.network;

/**
 * Created by gowtham on 14/7/15.
 */
public interface IApiRequestCancel {

    String getRequestTag();
}
