/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

/**
 * Created by gauthami on 22/7/15.
 */

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;

/**
 * COMMON PRODUCT DETAIL HEADER ITEM VIEW TYPE
 * Common product header row that contains three header texts
 */
public class OrderHistoryProductInfoHeaderViewDataBinder implements
        BaseRecyclerAdapter.RecyclerViewDataBinder<OrderHistoryProductInfoHeaderViewHolder,
                OrderHistoryProductInfoHeaderItem> {
    @Override
    public OrderHistoryProductInfoHeaderViewHolder getViewHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_history_details_product_info_item, parent, false);

        return new OrderHistoryProductInfoHeaderViewHolder(view, parent.getContext());
    }

    @Override
    public void bindDataToViewHolder(OrderHistoryProductInfoHeaderViewHolder viewHolder,
                                     final OrderHistoryProductInfoHeaderItem data,
                                     final int position,
                                     final BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {
    }

    @Override
    public int getViewType() {
        return ViewTypes.OrderHistoryViewType.ORDER_HISTORY_PRODUCT_HEADER;
    }
}
