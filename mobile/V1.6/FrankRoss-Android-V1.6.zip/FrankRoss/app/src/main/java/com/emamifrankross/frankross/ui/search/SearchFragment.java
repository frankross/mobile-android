/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.search;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.aloglia.AlgoliaManager;
import com.emamifrankross.frankross.core.db.IDataBaseResultNotifier;
import com.emamifrankross.frankross.core.db.QueryExecutor;
import com.emamifrankross.frankross.core.db.QueryProvider;
import com.emamifrankross.frankross.core.db.dbmodels.SearchSuggestion;
import com.emamifrankross.frankross.core.db.tables.DataBaseTableConstants;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.SearchAdapter;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.pharmacy.ProductListingActivity;
import com.emamifrankross.frankross.ui.products.ProductDetailActivity;
import com.emamifrankross.frankross.utils.NetworkUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 6/7/15.
 */

/**
 * This class represents the UI for search result screen with the search result count and a search bar
 */
public class SearchFragment extends BaseFragment implements BaseRecyclerAdapter.RecyclerItemClickListener,
        IToolbar, TextView.OnEditorActionListener, View.OnClickListener {

    private static final String TAG = SearchFragment.class.getSimpleName();
    private static final String SEARCH_TEXT_KEY = "search_text";

    private ImageButton mClearBtn;
    private EditText mSearchEditText;
    private RobotoTextView mEmptyView;
    private SearchAdapter mSearchAdapter;
    private List<BaseRecyclerAdapter.IViewType> mSearchScreenData = new ArrayList<>();
    /**
     * Text watcher to display the search suggestion as well as setting the clear button visibility
     */
    private TextWatcher mTextChangeListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            setClearButtonVisibility(charSequence);
            if (!TextUtils.isEmpty(charSequence) && charSequence.length() > 2) {
                getAlgoliaSearchSuggestions(charSequence.toString());
            } else {
                setSearchResultAdapterCachedData();
            }
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    };

    public static SearchFragment create(String searchText) {
        SearchFragment searchFragment = new SearchFragment();
        Bundle bundle = new Bundle();
        bundle.putString(SEARCH_TEXT_KEY, searchText);
        searchFragment.setArguments(bundle);

        return searchFragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setSearchResultAdapterCachedData();
        mSearchAdapter = new SearchAdapter(mSearchScreenData);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_search, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the views
     *
     * @param view the view that is associated with the Search fragment
     */
    private void initViews(View view) {
        mEmptyView = (RobotoTextView) view.findViewById(R.id.search_empty_view_tv);
        mSearchEditText = (EditText) view.findViewById(R.id.search_edit_text_tv);
        mClearBtn = (ImageButton) view.findViewById(R.id.search_clear_txt_btn);
        mClearBtn.setOnClickListener(this);
        mSearchEditText.addTextChangedListener(mTextChangeListener);
        mSearchEditText.setOnEditorActionListener(this);

        RecyclerView searchResultRecyclerView = (RecyclerView) view.findViewById(R.id.search_view_container);
        searchResultRecyclerView.setHasFixedSize(false);
        searchResultRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mSearchAdapter.setRecyclerItemClickListener(this);
        searchResultRecyclerView.setAdapter(mSearchAdapter);

        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_SCREEN_VISIT_EVENT);
    }

    /**
     * Method that sets the visibility of views based on the characters
     *
     * @param charSequence the characters entered in the search editable field
     */
    private void setClearButtonVisibility(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && charSequence.length() > 0) {
            mClearBtn.setVisibility(View.VISIBLE);
        } else {
            mClearBtn.setVisibility(View.INVISIBLE);
        }
    }

    /**
     * Method that gets the algolia search suggestions based on search text
     *
     * @param searchTerm the search text
     */
    private void getAlgoliaSearchSuggestions(String searchTerm) {
        if (!NetworkUtils.isNetworkConnected(getActivity())) {
            showAlert(getString(R.string.please_check_your_network_connection));
        } else {
            mFragmentInteractionListener.showBlockingProgressBar();
            AlgoliaManager.getInstance().performGetSearchSuggestion(getActivity(), searchTerm, 10,
                    new AlgoliaManager.IGetSearchSuggestionsResultNotifier() {
                        @Override
                        public void onSuggestionsFetched(final List<BaseRecyclerAdapter.IViewType> uiDataList) {
                            if (getActivity() != null && getView() != null) {
                                getActivity().runOnUiThread(new Runnable() {
                                    @Override
                                    public void run() {
                                        if (uiDataList != null && uiDataList.size() > 0) {
                                            mEmptyView.setVisibility(View.GONE);
                                            mSearchScreenData.clear();
                                            mSearchScreenData.addAll(uiDataList);
                                            mSearchAdapter.notifyDataSetChanged();
                                        } else {
                                            if (uiDataList != null) {
                                                mSearchScreenData.clear();
                                                mSearchScreenData.addAll(uiDataList);
                                                mSearchAdapter.notifyDataSetChanged();
                                            }
                                            mEmptyView.setText(getActivity().getString(R.string.search_suggestions_no_result_found));
                                            mEmptyView.setVisibility(View.VISIBLE);
                                        }
                                    }
                                });
                            }
                        }
                    });
            mFragmentInteractionListener.hideBlockingProgressBar();
        }
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {
            case ViewTypes.SearchViewType.SEARCH_PHARMA_PRODUCT:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_AUTO_SUGGESTION_TAP_EVENT);
                SearchAdapter.SearchPharmaProductDataItem item =
                        (SearchAdapter.SearchPharmaProductDataItem) object;
                savePharmaSearchSuggestion(item);
                loadProductDetailScreen(item.variantId, item.isPharma);
                break;

            case ViewTypes.SearchViewType.SEARCH_NON_PHARMA_PRODUCT:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_AUTO_SUGGESTION_TAP_EVENT);
                SearchAdapter.SearchNonPharmaProductDataItem nonPharmaItem =
                        (SearchAdapter.SearchNonPharmaProductDataItem) object;
                saveNonPharmaSearchSuggestion(nonPharmaItem);
                loadProductDetailScreen(nonPharmaItem.variantId, nonPharmaItem.isPharma);

                break;
            case ViewTypes.SearchViewType.CLEAR_SEARCH_HISTORY:
                clearSearchHistory();
                break;
        }
    }

    /**
     * Method that clears the search history from the Database
     */
    private void clearSearchHistory() {
        new QueryExecutor(getActivity().getApplicationContext(),
                QueryProvider.getDeleteAllQuery(new IDataBaseResultNotifier() {
                    @Override
                    public <T> void OnDataBaseDataUpdated(T data) {
                        if (getActivity() != null && getView() != null) {
                            mSearchScreenData.clear();
                            mEmptyView.setText(getString(R.string.search_suggestions_no_recent_history));
                            mEmptyView.setVisibility(View.VISIBLE);
                        }
                    }
                }, DataBaseTableConstants.TableID.ID_SEARCH_SUGGESTIONS_TABLE)).execute();
    }

    /**
     * Method that saves the non pharma product search suggestion to the database
     *
     * @param nonPharmaItem the non pharma product details that are to be inserted into the database table
     */
    private void saveNonPharmaSearchSuggestion(SearchAdapter.SearchNonPharmaProductDataItem nonPharmaItem) {
        SearchSuggestion suggestion = new SearchSuggestion();
        suggestion.setIsPharma(false);
        suggestion.setVariantId(nonPharmaItem.variantId);
        suggestion.setVariantName(nonPharmaItem.productName);
        suggestion.setBrandOrManufacturerName(nonPharmaItem.manufacturerName);
        suggestion.setGenericKeyword(nonPharmaItem.genericKeyword);
        suggestion.setCategoryId(nonPharmaItem.categoryId);
        suggestion.setCategoryName(nonPharmaItem.categoryName);
        suggestion.setProductIconUrl("");

        new QueryExecutor(getActivity().getApplicationContext(),
                QueryProvider.getInsertSearchSuggestionQuery(suggestion)).execute();
    }

    /**
     * Method that saves the pharma product search suggestion to the database
     *
     * @param pharmaItem the  pharma product details that are to be inserted into the database table
     */
    private void savePharmaSearchSuggestion(SearchAdapter.SearchPharmaProductDataItem pharmaItem) {
        SearchSuggestion suggestion = new SearchSuggestion();
        suggestion.setIsPharma(true);
        suggestion.setVariantId(pharmaItem.variantId);
        suggestion.setVariantName(pharmaItem.productName);
        suggestion.setBrandOrManufacturerName(pharmaItem.manufacturerName);
        suggestion.setGenericKeyword(pharmaItem.productName);
        suggestion.setCategoryId(pharmaItem.categoryId);
        suggestion.setCategoryName(pharmaItem.categoryName);
        suggestion.setProductIconUrl(pharmaItem.productIconImageUrl);

        new QueryExecutor(getActivity().getApplicationContext(),
                QueryProvider.getInsertSearchSuggestionQuery(suggestion)).execute();
    }

    /**
     * Method that loads the product detail page
     *
     * @param variantId the unique id to identify the product
     * @param isPharma  the flag that helps to load pharma /non pharma PDP
     */
    private void loadProductDetailScreen(long variantId, boolean isPharma) {

        startActivity(ProductDetailActivity.getActivityIntent(getActivity().getApplicationContext(),
                (isPharma) ? ProductDetailActivity.PHARMA_PRODUCT_DETAIL_FRAGMENT_ID
                        : ProductDetailActivity.NON_PHARMA_PRODUCT_DETAIL_FRAGMENT_ID,
                variantId));
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    /**
     * Method that retrieves the search suggestions from database
     */
    private void setSearchResultAdapterCachedData() {
        new QueryExecutor(getActivity(), QueryProvider.
                getAllSearchSuggestionsQuery(new IDataBaseResultNotifier() {
                    @Override
                    public <T> void OnDataBaseDataUpdated(T data) {
                        //Log.d(TAG, data.toString());
                        if (data != null) {
                            getSearchSuggestions((List<SearchSuggestion>) data);
                        }
                    }
                })).execute();
    }

    /**
     * Method that requests the search suggestions for the search text
     *
     * @param data the cached search suggestions
     */
    private void getSearchSuggestions(final List<SearchSuggestion> data) {
        new AsyncTask<Void, Void, List<BaseRecyclerAdapter.IViewType>>() {

            @Override
            protected List<BaseRecyclerAdapter.IViewType> doInBackground(Void... params) {

                return getMappedUiDataSearchSuggestions(getActivity(), data);
            }

            @Override
            protected void onPostExecute(List<BaseRecyclerAdapter.IViewType> uiDataList) {
                super.onPostExecute(uiDataList);
                if (getActivity() != null && getView() != null && isAdded()) {
                    if (uiDataList != null
                            && uiDataList.size() > 0) {
                        mEmptyView.setVisibility(View.GONE);
                        mSearchScreenData.clear();
                        mSearchScreenData.addAll(uiDataList);
                        mSearchAdapter.notifyDataSetChanged();
                    } else {
                        mEmptyView.setText(getResources().getString(R.string.search_suggestions_no_recent_history));
                        mEmptyView.setVisibility(View.VISIBLE);
                    }
                }
            }
        }.execute();
    }

    /**
     * Method that maps the Search suggestions data to the UI data list
     *
     * @param appContext     the application context
     * @param suggestionList the search suggestions
     * @return the mapped UI data for Search suggestion
     */
    private List<BaseRecyclerAdapter.IViewType> getMappedUiDataSearchSuggestions(Context appContext,
                                                                                 List<SearchSuggestion> suggestionList) {
        ArrayList<BaseRecyclerAdapter.IViewType> searchScreenData = new ArrayList<>();

        if (appContext != null) {
            List<BaseRecyclerAdapter.IViewType> pharmaList = new ArrayList<>(5);
            List<BaseRecyclerAdapter.IViewType> nonPharmaList = new ArrayList<>(5);

            if (suggestionList != null && suggestionList.size() > 0) {
                for (SearchSuggestion dataModel : suggestionList) {
                    if (dataModel.isPharma()) {
                        if (pharmaList.size() < 5) {
                            pharmaList.add(getPharmaProductItem(dataModel));
                        } else if (nonPharmaList.size() > 5) {
                            break;
                        }
                    } else {
                        if (nonPharmaList.size() < 5) {
                            nonPharmaList.add(getNonPharmaProductItem(dataModel));
                        } else if (pharmaList.size() > 5) {
                            break;
                        }
                    }
                }
            }

            if (pharmaList.size() > 0 || nonPharmaList.size() > 0 && isAdded()) {
                SearchAdapter.RecentlySearchedDataItem recentlySearchedDataItem =
                        new SearchAdapter.RecentlySearchedDataItem(
                                appContext.getString(R.string.search_suggestions_recently_searched_header));
                searchScreenData.add(recentlySearchedDataItem);
            }

            if (pharmaList.size() > 0) {
                searchScreenData.addAll(pharmaList);
            }

            if (nonPharmaList.size() > 0 && isAdded()) {
                searchScreenData.add(new SearchAdapter.
                        SearchCategoryDataItem(appContext.getString(R.string.search_header_non_pharma_products)));
                searchScreenData.addAll(nonPharmaList);
            }

            if (pharmaList.size() > 0 || nonPharmaList.size() > 0 && isAdded()) {
                SearchAdapter.ClearSearchHistoryDataItem clearSearchHistoryDataItem =
                        new SearchAdapter.ClearSearchHistoryDataItem(
                                appContext.getString(R.string.search_suggestions_clear_search_history_header));
                searchScreenData.add(clearSearchHistoryDataItem);
            }

        }

        return searchScreenData;
    }

    /**
     * Method to map the Pharma product item
     *
     * @param dataModel the Pharma products suggestion mapped to model
     * @return the mapped UI data of Search suggestions for pharma products
     */
    private BaseRecyclerAdapter.IViewType getPharmaProductItem(SearchSuggestion dataModel) {
        SearchAdapter.SearchPharmaProductDataItem pharmaItem =
                new SearchAdapter.SearchPharmaProductDataItem();
        pharmaItem.variantId = dataModel.getVariantId();
        pharmaItem.manufacturerName = dataModel.getBrandOrManufacturerName();
        pharmaItem.productName = dataModel.getVariantName();
        pharmaItem.categoryName = dataModel.getCategoryName();
        pharmaItem.categoryId = dataModel.getCategoryId();
        pharmaItem.productIconImageUrl = dataModel.getProductIconUrl();

        return pharmaItem;
    }

    /**
     * Method to map the Non Pharma product item
     *
     * @param dataModel the Non Pharma products suggestion mapped to model
     * @return the mapped UI data of Search suggestions for non pharma products
     */
    private BaseRecyclerAdapter.IViewType getNonPharmaProductItem(SearchSuggestion dataModel) {
        SearchAdapter.SearchNonPharmaProductDataItem nonPharmaProductDataItem =
                new SearchAdapter.SearchNonPharmaProductDataItem();
        nonPharmaProductDataItem.variantId = dataModel.getVariantId();
        nonPharmaProductDataItem.productName = dataModel.getVariantName();
        nonPharmaProductDataItem.manufacturerName = dataModel.getBrandOrManufacturerName();
        nonPharmaProductDataItem.categoryId = dataModel.getCategoryId();
        nonPharmaProductDataItem.categoryName = dataModel.getCategoryName();
        nonPharmaProductDataItem.genericKeyword = dataModel.getGenericKeyword();
        nonPharmaProductDataItem.isPharma = false;

        return nonPharmaProductDataItem;
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_SEARCH) {
            hide_keyboard(getActivity(), v);

            String text = v.getText().toString();
            loadSearchResultFragment(text);
            return true;
        }

        return false;
    }

    private void loadSearchResultFragment(String searchTerm) {
        startActivity(ProductListingActivity.
                getActivityIntentForSearchResultProducts(getActivity().getApplicationContext(),
                        ProductListingActivity.SEARCH_PRODUCTS_LISTING_FRAGMENT_ID, searchTerm));
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.search_clear_txt_btn:
                mSearchEditText.getText().clear();
                break;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_search);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

}
