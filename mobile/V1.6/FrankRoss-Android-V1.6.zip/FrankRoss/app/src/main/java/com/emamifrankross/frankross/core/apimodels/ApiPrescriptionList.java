/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.PrescriptionFilterAdapter;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 7/8/15.
 */
public class ApiPrescriptionList {

    public static class Response {

        private List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>();

        private List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> doctorNamesList = new ArrayList<>();
        private List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> patientNamesList = new ArrayList<>();

        @SerializedName("undigitisedImageURLs")
        private List<String> unDigitisedImageUrls = new ArrayList<>(1);

        @SerializedName("digitisedPrescriptions")
        private List<DigitisedPrescription> digitisedPrescriptions = new ArrayList<>(1);

        public List<String> getUnDigitisedImageUrls() {
            return unDigitisedImageUrls;
        }

        public List<DigitisedPrescription> getDigitisedPrescriptions() {
            return digitisedPrescriptions;
        }

        public List<BaseRecyclerAdapter.IViewType> getUiDataList() {
            return uiDataList;
        }

        public void setUiDataList(List<BaseRecyclerAdapter.IViewType> uiDataList) {
            this.uiDataList = uiDataList;
        }

        public List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> getPatientNamesList() {
            return patientNamesList;
        }

        public void setPatientNamesList(List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> patientNamesList) {
            this.patientNamesList = patientNamesList;
        }

        public List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> getDoctorNamesList() {
            return doctorNamesList;
        }

        public void setDoctorNamesList(List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> doctorNamesList) {
            this.doctorNamesList = doctorNamesList;
        }
    }
}
