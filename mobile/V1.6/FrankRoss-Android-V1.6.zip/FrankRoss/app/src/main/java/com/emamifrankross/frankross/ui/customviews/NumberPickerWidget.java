/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.customviews;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.InputType;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;

public class NumberPickerWidget extends LinearLayout {

    public interface OnNumberChangedListener {
        void onNumberIncremented(int number);

        void onNumberDecremented(int number);
    }

    private final int DEFAULT_MIN_VALUE = 0;
    private final int DEFAULT_MAX_VALUE = 999;
    private final int mDecrementDrawable;
    private final int mIncrementDrawable;
    private int mMinValue;
    private int mMaxValue;
    private View mDecrementButton;
    private View mIncrementButton;
    private EditText mValueEditText;
    private int mValue;
    private int mIncrementValue = 1;

    private OnNumberChangedListener mOnNumberChangedListener;

    public NumberPickerWidget(Context context, AttributeSet attrs) {
        super(context, attrs);
        TypedArray array = context.obtainStyledAttributes(attrs, R.styleable.NumberPickerWidget);
        mDecrementDrawable = array.getResourceId(R.styleable.NumberPickerWidget_decrementIcon, 0);
        mIncrementDrawable = array.getResourceId(R.styleable.NumberPickerWidget_incrementIcon, 0);
        mValue = mMinValue = array.getInt(R.styleable.NumberPickerWidget_minValue, DEFAULT_MIN_VALUE);
        mMaxValue = array.getInt(R.styleable.NumberPickerWidget_maxValue, DEFAULT_MAX_VALUE);
        int layout = array.getResourceId(R.styleable.NumberPickerWidget_custom_layout,
                R.layout.number_picker_widget);
        array.recycle();

        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        if (layout == R.layout.number_picker_widget) {
            inflater.inflate(getOrientation() == VERTICAL ? R.layout.number_picker_widget_vertical
                    : layout, this, true);
        } else {
            inflater.inflate(layout, this, true);
        }

        initDecrementButton();
        initValueEditText();
        initIncrementButton();
    }

    public void setMinValue(int minValue) {
        mMinValue = minValue;
    }

    public void setMaxValue(int maxValue) {
        mMaxValue = maxValue;
    }

    public void setIncrementValue(int incrementValue) {
        mIncrementValue = incrementValue;
    }

    private void initValueEditText() {
        mValueEditText = (EditText) findViewById(R.id.value_field);
        mValueEditText.setFocusable(false);
        mValueEditText.setText(String.valueOf(mMinValue));
        mValueEditText.setInputType(InputType.TYPE_NULL);
    }

    private void initIncrementButton() {
        mIncrementButton = findViewById(R.id.increment_button);
        OnClickListener onClickListener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                increment();
            }
        };
        mIncrementButton.setOnClickListener(onClickListener);
    }

    private void increment() {
        if (mValue < mMaxValue) {
            mValue += mIncrementValue;
            mValueEditText.setText(String.valueOf(mValue));
            if (mOnNumberChangedListener != null) {
                mOnNumberChangedListener.onNumberIncremented(mValue);
            }
        }
    }

    private void initDecrementButton() {
        mDecrementButton = findViewById(R.id.decrement_button);
        OnClickListener onClickListener = new OnClickListener() {
            @Override
            public void onClick(View v) {
                decrement();
            }
        };
        mDecrementButton.setOnClickListener(onClickListener);
    }

    private void decrement() {
        if (mValue > mMinValue) {
            mValue = mValue - mIncrementValue;
            mValueEditText.setText(String.valueOf(mValue));
            if (mOnNumberChangedListener != null) {
                mOnNumberChangedListener.onNumberDecremented(mValue);
            }
        }
    }

    public double getValue() {
        return mValue;
    }

    public void setValue(int value) {
        mValue = value;
        mValueEditText.setText(String.valueOf(mValue));
    }

    public void setOnNumberChangedListener(OnNumberChangedListener onNumberChangedListener) {
        mOnNumberChangedListener = onNumberChangedListener;
    }
}
