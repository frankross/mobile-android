/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.sdkmanager;

import android.content.Context;
import android.os.Bundle;

import com.emamifrankross.frankross.core.network.UrlConstants;
import com.emamifrankross.frankross.utils.Log;
import com.facebook.FacebookSdk;
import com.facebook.FacebookSdkNotInitializedException;
import com.facebook.LoggingBehavior;
import com.facebook.appevents.AppEventsConstants;
import com.facebook.appevents.AppEventsLogger;
import com.facebook.applinks.AppLinkData;

import java.math.BigDecimal;
import java.util.Currency;

/**
 * Created by gauthami on 7/6/16.
 */

/**
 * This class manages the Facebook SDK event logging and differed deeplinking
 */
public class FacebookManager {

    private static final String TAG = FacebookManager.class.getSimpleName();
    private static final boolean LOG_FACEBOOK_EVENTS = !UrlConstants.DEV_MODE;

    public static void logFacebookActivateAppEvent(Context context) {
        try {
            if (UrlConstants.DEV_MODE) {
                FacebookSdk.setIsDebugEnabled(UrlConstants.DEV_MODE);
                FacebookSdk.addLoggingBehavior(LoggingBehavior.APP_EVENTS);
            }

            if (LOG_FACEBOOK_EVENTS) {
                AppEventsLogger.activateApp(context);
            }
        } catch (FacebookSdkNotInitializedException facebookSdkInitializeException) {
            Log.d(TAG, "" + facebookSdkInitializeException);
        } catch (Exception exception) {
            Log.d(TAG, "" + exception);
        }
    }

    public static void logFacebookRegisterEvent(Context context, String registrationMethod) {
        try {
            if (UrlConstants.DEV_MODE) {
                FacebookSdk.setIsDebugEnabled(UrlConstants.DEV_MODE);
                FacebookSdk.addLoggingBehavior(LoggingBehavior.APP_EVENTS);
            }

            if (LOG_FACEBOOK_EVENTS) {
                AppEventsLogger logger = AppEventsLogger.newLogger(context);
                Bundle parameters = new Bundle();
                parameters.putString(AppEventsConstants.EVENT_PARAM_REGISTRATION_METHOD, registrationMethod);
                logger.logEvent(AppEventsConstants.EVENT_NAME_COMPLETED_REGISTRATION, parameters);
            }
        } catch (FacebookSdkNotInitializedException facebookSdkInitializeException) {
            Log.d(TAG, "" + facebookSdkInitializeException);
        } catch (Exception exception) {
            Log.d(TAG, "" + exception);
        }
    }

    public static void logFacebookAddToCartEvent(Context context, String contentType,
                                                 String contentId, String currency) {
        try {
            if (UrlConstants.DEV_MODE) {
                FacebookSdk.setIsDebugEnabled(UrlConstants.DEV_MODE);
                FacebookSdk.addLoggingBehavior(LoggingBehavior.APP_EVENTS);
            }

            if (LOG_FACEBOOK_EVENTS) {
                AppEventsLogger logger = AppEventsLogger.newLogger(context);
                Bundle parameters = new Bundle();
                parameters.putString(AppEventsConstants.EVENT_PARAM_CONTENT_TYPE, contentType);//product name
                parameters.putString(AppEventsConstants.EVENT_PARAM_CONTENT_ID, contentId);//variant id
                parameters.putString(AppEventsConstants.EVENT_PARAM_CURRENCY, currency);//INR
                logger.logEvent(AppEventsConstants.EVENT_NAME_ADDED_TO_CART, parameters);
            }
        } catch (FacebookSdkNotInitializedException facebookSdkInitializeException) {
            Log.d(TAG, "" + facebookSdkInitializeException);
        } catch (Exception exception) {
            Log.d(TAG, "" + exception);
        }
    }

    public static void logFacebookInitiatedCheckOutEvent(Context context) {
        try {
            if (UrlConstants.DEV_MODE) {
                FacebookSdk.setIsDebugEnabled(UrlConstants.DEV_MODE);
                FacebookSdk.addLoggingBehavior(LoggingBehavior.APP_EVENTS);
            }

            if (LOG_FACEBOOK_EVENTS) {
                AppEventsLogger logger = AppEventsLogger.newLogger(context);
                logger.logEvent(AppEventsConstants.EVENT_NAME_INITIATED_CHECKOUT);
            }
        } catch (FacebookSdkNotInitializedException facebookSdkInitializeException) {
            Log.d(TAG, "" + facebookSdkInitializeException);
        } catch (Exception exception) {
            Log.d(TAG, "" + exception);
        }
    }

    public static void logFacebookPurchasedEvent(Context context, double orderTotal,
                                                 String currency) {
        try {
            if (UrlConstants.DEV_MODE) {
                FacebookSdk.setIsDebugEnabled(UrlConstants.DEV_MODE);
                FacebookSdk.addLoggingBehavior(LoggingBehavior.APP_EVENTS);
            }

            if (LOG_FACEBOOK_EVENTS) {
                AppEventsLogger logger = AppEventsLogger.newLogger(context);
                logger.logPurchase(BigDecimal.valueOf(orderTotal), Currency.getInstance(currency));
            }
        } catch (FacebookSdkNotInitializedException facebookSdkInitializeException) {
            Log.d(TAG, "" + facebookSdkInitializeException);
        } catch (Exception exception) {
            Log.d(TAG, "" + exception);
        }
            /*Bundle parameters = new Bundle();
            parameters.putString(AppEventsConstants.EVENT_PARAM_CONTENT_TYPE, contentType);
            parameters.putString(AppEventsConstants.EVENT_PARAM_CONTENT_ID, contentId);
            parameters.putString(AppEventsConstants.EVENT_PARAM_CURRENCY, currency);
            parameters.putString(AppEventsConstants.EVENT_PARAM_NUM_ITEMS, numberOfItems);
            logger.logEvent(AppEventsConstants.EVENT_NAME_PURCHASED, parameters);*/
    }

    public static void logFacebookDifferedDeepLinking(Context context) {
        AppLinkData.fetchDeferredAppLinkData(context,
                new AppLinkData.CompletionHandler() {
                    @Override
                    public void onDeferredAppLinkDataFetched(AppLinkData appLinkData) {
                    }
                }
        );
    }
}
