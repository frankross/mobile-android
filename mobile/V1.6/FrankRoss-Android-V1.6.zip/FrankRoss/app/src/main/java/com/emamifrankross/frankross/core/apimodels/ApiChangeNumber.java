/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 27/8/15.
 */
public class ApiChangeNumber {

    public static class Request {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("password")
        private String password = "";

        @SerializedName("user")
        private User user = new User();

        @SerializedName("email")
        private String email = "";

        public void setPassword(String password) {
            this.password = password;
        }

        public User getUser() {
            return user;
        }

        public void setUser(User user) {
            this.user = user;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public static class User {
            @SerializedName("primary_phone")
            private String primary_phone;

            public String getPrimary_phone() {
                return primary_phone;
            }

            public void setPrimary_phone(String primary_phone) {
                this.primary_phone = primary_phone;
            }
        }
    }

    public static class SocialUserRequest {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("social_auth_token")
        private String authToken = "";

        @SerializedName("user")
        private User user = new User();

        @SerializedName("social_login_uid")
        private String userId = "";

        @SerializedName("social_login_provider")
        private String userSocialProvider = "";

        public User getUser() {
            return user;
        }

        public void setUser(User user) {
            this.user = user;
        }

        public String getAuthToken() {
            return authToken;
        }

        public void setAuthToken(String authToken) {
            this.authToken = authToken;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getUserSocialProvider() {
            return userSocialProvider;
        }

        public void setUserSocialProvider(String userSocialProvider) {
            this.userSocialProvider = userSocialProvider;
        }

        public static class User {
            @SerializedName("primary_phone")
            private String primary_phone;

            public String getPrimary_phone() {
                return primary_phone;
            }

            public void setPrimary_phone(String primary_phone) {
                this.primary_phone = primary_phone;
            }
        }
    }

    public static class Response {

    }
}
