/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

/**
 * Created by gowtham on 22/7/15.
 */

/**
 * Common header view holder
 */
public class CommonRecyclerHeaderViewHolder extends RecyclerView.ViewHolder {

    public RobotoTextView mAddressHeader;

    public CommonRecyclerHeaderViewHolder(View view) {
        super(view);
        mAddressHeader = (RobotoTextView) view.findViewById(R.id.common_header_tv);
    }
}
