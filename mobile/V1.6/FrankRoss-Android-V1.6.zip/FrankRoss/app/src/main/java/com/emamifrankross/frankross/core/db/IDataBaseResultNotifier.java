/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.db;

/**
 * Call back interface defined for notifying the result from database.
 */
public interface IDataBaseResultNotifier {

	<T> void OnDataBaseDataUpdated(T data);
}
