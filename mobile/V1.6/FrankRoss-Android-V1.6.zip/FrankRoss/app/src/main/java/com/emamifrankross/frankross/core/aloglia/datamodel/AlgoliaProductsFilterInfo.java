/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.aloglia.datamodel;

import com.emamifrankross.frankross.ui.common.FilterSelectionStats;
import com.emamifrankross.frankross.ui.common.Stats;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 28/8/15.
 */
public class AlgoliaProductsFilterInfo {

    public AlgoliaProductsFilterInfo() {
    }

    //Copy Constructor
    public AlgoliaProductsFilterInfo(AlgoliaProductsFilterInfo algoliaProductsFilterInfo) {
        for (FilterSelectionStats brandStat : algoliaProductsFilterInfo.brandStatList) {
            brandStatList.add(brandStat);
        }

        for (FilterSelectionStats brandStat : algoliaProductsFilterInfo.categoryStatList) {
            categoryStatList.add(brandStat);
        }

        salesPriceStats = new Stats(algoliaProductsFilterInfo.getSalesPriceStats());
        discountStats = new Stats(algoliaProductsFilterInfo.getDiscountStats());
    }

    private List<FilterSelectionStats> brandStatList = new ArrayList<>(1);

    private List<FilterSelectionStats> categoryStatList = new ArrayList<>(1);

    private Stats salesPriceStats;

    private Stats discountStats;

    public Stats getSalesPriceStats() {
        return salesPriceStats;
    }

    public void setSalesPriceStats(Stats salesPriceStats) {
        this.salesPriceStats = salesPriceStats;
    }

    public Stats getDiscountStats() {
        return discountStats;
    }

    public void setDiscountStats(Stats discountStats) {
        this.discountStats = discountStats;
    }

    public List<FilterSelectionStats> getCategoryStatList() {
        return categoryStatList;
    }

    public void setCategoryStatList(List<FilterSelectionStats> categoryStatList) {
        this.categoryStatList = categoryStatList;
    }

    public List<FilterSelectionStats> getBrandStatList() {
        return brandStatList;
    }

    public void setBrandStatList(List<FilterSelectionStats> brandStatList) {
        this.brandStatList = brandStatList;
    }
}
