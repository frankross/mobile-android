/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiCategories;
import com.emamifrankross.frankross.core.apimodels.ApiHomeBanner;
import com.emamifrankross.frankross.ui.customviews.VolleySingleton;
import com.emamifrankross.frankross.ui.viewmodels.BannerDataItem;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 30/6/15.
 * <p> Adapter class for Banner Section in Home </p>
 * <p>Supports the One View Types </p>
 * <p> 1 : BANNER IMAGE VIEW TYPE</p>
 */
public class HomeBannerAdapter extends PagerAdapter {

    private BannerDataItem mTopOffersDataItem;
    private HomeRecyclerAdapter.TopOffersAutoScrollDataItem mTopOffersAutoScrollDataItem;
    private PharmacyCategoryAdapter.TopOffersAutoScrollDataItem mPharmacyAutoScrollDataItem;
    private List<String> mBannerImages = new ArrayList<>(1);
    private ImageLoader mImageLoader;
    private BaseRecyclerAdapter.RecyclerItemClickListener mRecyclerItemClickListener;

    public HomeBannerAdapter(Context context, boolean isAutoScroll, BaseRecyclerAdapter.IViewType dataItem) {
        mImageLoader = VolleySingleton.getInstance(context).getImageLoader();
        if (isAutoScroll) {
            List<String> bannerUrl = new ArrayList<>();
            if (dataItem instanceof HomeRecyclerAdapter.TopOffersAutoScrollDataItem) {
                mTopOffersAutoScrollDataItem = (HomeRecyclerAdapter.TopOffersAutoScrollDataItem) dataItem;
                for (ApiHomeBanner.Banner banner : mTopOffersAutoScrollDataItem.mBanner) {
                    bannerUrl.add(banner.getUrl());
                }
            } else if (dataItem instanceof PharmacyCategoryAdapter.TopOffersAutoScrollDataItem) {
                mPharmacyAutoScrollDataItem = (PharmacyCategoryAdapter.TopOffersAutoScrollDataItem) dataItem;
                for (ApiCategories.Promotion banner : mPharmacyAutoScrollDataItem.mBanner) {
                    bannerUrl.add(banner.getPromotionImageUrl());
                }
            }
            mBannerImages.addAll(bannerUrl);
        } else {
            mTopOffersDataItem = (BannerDataItem) dataItem;
            mBannerImages.addAll(mTopOffersDataItem.mBannerImages);
        }
    }

    public void setOnRecyclerItemClickListener(BaseRecyclerAdapter.RecyclerItemClickListener recyclerItemClickListener) {
        mRecyclerItemClickListener = recyclerItemClickListener;
    }

    @Override
    public int getCount() {
        return mBannerImages.size();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        ViewPager pager = (ViewPager) container;
        int count = pager.getChildCount();
        View view = LayoutInflater.from(container.getContext()).inflate(R.layout.home_banner_item, container, false);
        initViews(view, position);
        pager.addView(view, count > position ? position : count);
        return view;
    }

    private void initViews(View view, final int position) {
        NetworkImageView networkImageView = (NetworkImageView) view.findViewById(R.id.home_banner_iv);
        /*networkImageView.setErrorImageResId(R.drawable.product_logo);
        networkImageView.setDefaultImageResId(R.drawable.product_logo);*/
        networkImageView.setImageUrl(mBannerImages.get(position), mImageLoader);
        Animation fadeInAnimation = AnimationUtils.loadAnimation(view.getContext(), R.anim.fade_in);
        networkImageView.startAnimation(fadeInAnimation);

        networkImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mRecyclerItemClickListener != null) {
                    if (mTopOffersDataItem == null) {
                        if(mTopOffersAutoScrollDataItem == null){
                            mRecyclerItemClickListener.onRecyclerItemClick(position, v, mPharmacyAutoScrollDataItem);
                        }else {
                            mRecyclerItemClickListener.onRecyclerItemClick(position, v, mTopOffersAutoScrollDataItem);
                        }
                    } else {
                        mRecyclerItemClickListener.onRecyclerItemClick(position, v, mTopOffersDataItem);
                    }
                }
            }
        });
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }
}