/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.faq;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.FaqTopQueryAdapter;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 7/4/16.
 */

/**
 * This class represents the UI for FAQ screen that lists top queries and help topics
 */
public class FAQTopQueriesFragment extends ApiRequestBaseFragment implements BaseRecyclerAdapter.RecyclerItemClickListener,
        IToolbar {

    private RobotoTextView mEmptyView;
    private FaqTopQueryAdapter mFAQTopQueryRecyclerAdapter;
    private ArrayList<BaseRecyclerAdapter.IViewType> mFAQTopQueryScreenData = new ArrayList<>();

    //To make only one parent expandable at a time
    private int mLastExpandedPosition = -1;

    public static FAQTopQueriesFragment create() {
        return new FAQTopQueriesFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFAQTopQueryRecyclerAdapter = new FaqTopQueryAdapter(mFAQTopQueryScreenData);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.FAQ_TOPIC_SCREEN_VISIT_EVENT);
        performFAQTopQueryRequest();
    }

    /**
     * Method that requests for the FAQ top queries
     */
    private void performFAQTopQueryRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetFAQHomeListRequest(new ApiRequestManager.IFAQHomeResultNotifier() {
            @Override
            public void onFAQHomeFetched(List<BaseRecyclerAdapter.IViewType> faqHomeList) {
                mFragmentInteractionListener.hideBlockingProgressBar();
                if (faqHomeList != null && faqHomeList.size() > 0) {
                    mFAQTopQueryScreenData.clear();
                    mFAQTopQueryScreenData.addAll(faqHomeList);
                    mFAQTopQueryRecyclerAdapter.notifyDataSetChanged();
                } else {
                    mEmptyView.setText(getString(R.string.faq_empty_view_txt));
                    mEmptyView.setVisibility(View.VISIBLE);
                }
            }
        }, this, this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_store_locator, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mToolbarInteractionListener.updateToolbar(this);
        initFaqTopicsRecyclerView(view);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    /**
     * Method that initializes the views
     *
     * @param view the view that is associated with the Faq Top queries
     */
    private void initFaqTopicsRecyclerView(View view) {
        RecyclerView faqTopQueriesRecyclerView = (RecyclerView) view.findViewById(R.id.store_locator_container);
        faqTopQueriesRecyclerView.setHasFixedSize(false);
        faqTopQueriesRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mFAQTopQueryRecyclerAdapter.setRecyclerItemClickListener(this);
        faqTopQueriesRecyclerView.setAdapter(mFAQTopQueryRecyclerAdapter);

        mEmptyView = (RobotoTextView) view.findViewById(R.id.store_locator_empty_view_tv);
        mEmptyView.setText(getString(R.string.faq_empty_view_txt));
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;

        if (object instanceof FaqTopQueryAdapter.FAQHelpTopicsDataItem) {

            FaqTopQueryAdapter.FAQHelpTopicsDataItem helpTopicsDataItem =
                    (FaqTopQueryAdapter.FAQHelpTopicsDataItem) object;
            loadFaqFragment(helpTopicsDataItem);

        } else if (object instanceof FaqTopQueryAdapter.FAQTopQueryAlternateDataItem) {
            manageExpandCollapseBehaviour(position, object);
        }
    }

    /**
     * Method that handles the Expand and Collapse behavior
     *
     * @param position the position of the view in the UI list that was tapped
     * @param object   the object corresponding to the tapped UI item
     */
    private void manageExpandCollapseBehaviour(int position, Object object) {

        if (mLastExpandedPosition != position) {
            //expand new position
            FaqTopQueryAdapter.FAQTopQueryAlternateDataItem faqTopQueryAlternateDataItem =
                    (FaqTopQueryAdapter.FAQTopQueryAlternateDataItem) object;
            faqTopQueryAlternateDataItem.isExpanded = true;
            mFAQTopQueryRecyclerAdapter.notifyItemChanged(position);

            //collapse previous position
            if (mLastExpandedPosition != -1) {
                if (mFAQTopQueryScreenData.size() > mLastExpandedPosition &&
                        mFAQTopQueryScreenData.get(mLastExpandedPosition) != null &&
                        mFAQTopQueryScreenData.get(mLastExpandedPosition) instanceof
                                FaqTopQueryAdapter.FAQTopQueryAlternateDataItem) {

                    FaqTopQueryAdapter.FAQTopQueryAlternateDataItem previousExpandedItem =
                            (FaqTopQueryAdapter.FAQTopQueryAlternateDataItem)
                                    mFAQTopQueryScreenData.get(mLastExpandedPosition);
                    previousExpandedItem.isExpanded = false;
                    mFAQTopQueryRecyclerAdapter.notifyItemChanged(mLastExpandedPosition);
                }
            }

        } else {
            //collapse - expand if same item
            FaqTopQueryAdapter.FAQTopQueryAlternateDataItem faqTopQueryAlternateDataItem =
                    (FaqTopQueryAdapter.FAQTopQueryAlternateDataItem) object;
            faqTopQueryAlternateDataItem.isExpanded = !faqTopQueryAlternateDataItem.isExpanded;
            mFAQTopQueryRecyclerAdapter.notifyItemChanged(position);
        }
        mLastExpandedPosition = position;
    }

    /**
     * Method that loads the FAQs containing questions/answers
     *
     * @param helpTopicsDataItem the help topics data item that was clicked
     */
    private void loadFaqFragment(FaqTopQueryAdapter.FAQHelpTopicsDataItem helpTopicsDataItem) {

        long faqHelpTopicId = helpTopicsDataItem.faqHelpTopicId;
        String faqTopic = helpTopicsDataItem.faqHelpTopic;

        mFragmentInteractionListener.loadFragment(getId(),
                FAQFragment.create(faqTopic, faqHelpTopicId), null,
                R.anim.push_left_in, R.anim.push_left_out,
                FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    @Override
    public void onStart() {
        super.onStart();
        mApiRequestManager.registerCartCountChangeNotifier((BaseActivity) getActivity());
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        mApiRequestManager.unregisterCartCountChangeNotifier((BaseActivity) getActivity());
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_faqs);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                return false;
            }
        };
    }
}

