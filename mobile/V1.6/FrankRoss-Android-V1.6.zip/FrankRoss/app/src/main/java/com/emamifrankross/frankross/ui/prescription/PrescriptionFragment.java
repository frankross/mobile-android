/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.prescription;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.ApptentiveManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.OrderHistoryAdapter;
import com.emamifrankross.frankross.ui.adapters.PrescriptionAdapter;
import com.emamifrankross.frankross.ui.adapters.PrescriptionFilterAdapter;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.prescription.uploadprescription.UploadPrescriptionActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 15/7/15.
 */

/**
 * This class represents the UI for Prescriptions listing screen
 */
public class PrescriptionFragment extends ApiRequestBaseFragment implements IToolbar, BaseRecyclerAdapter.RecyclerItemClickListener,
        View.OnClickListener {

    public static final String TAG = PrescriptionFragment.class.getName();
    private List<BaseRecyclerAdapter.IViewType> mPrescriptionAdapterData = new ArrayList<>();
    private List<BaseRecyclerAdapter.IViewType> mPrescriptionsList = new ArrayList<>();
    private PrescriptionAdapter mPrescriptionAdapter;
    private LinearLayout mEmptyLinLyt;

    private List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> mDoctorNames = new ArrayList<>();
    private List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> mPatientNames = new ArrayList<>();

    public static PrescriptionFragment create() {
        return new PrescriptionFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFragmentInteractionListener.showBlockingProgressBar();
        mPrescriptionAdapter = new PrescriptionAdapter(mPrescriptionAdapterData);
        getPrescriptionList();
        ApptentiveManager.registerPrescriptionScreenVisitEvent(getActivity());
    }

    /**
     * Method that requests for the prescriptions
     */
    private void getPrescriptionList() {
        mApiRequestManager.performGetPrescriptionListRequest(new ApiRequestManager.IPrescriptionListResultNotifier() {
            @Override
            public void onPrescriptionListFetched(List<BaseRecyclerAdapter.IViewType> prescriptionList,
                                                  List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem>
                                                          doctorNames,
                                                  List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem>
                                                          patientNames) {
                if (prescriptionList != null && prescriptionList.size() > 0) {
                    mPrescriptionsList.clear();
                    mPrescriptionsList.addAll(prescriptionList);

                    mPrescriptionAdapterData.clear();
                    mPrescriptionAdapterData.addAll(mPrescriptionsList);
                    mPrescriptionAdapter.notifyDataSetChanged();

                    mPatientNames.addAll(patientNames);
                    mDoctorNames.addAll(doctorNames);

                } else {
                    mEmptyLinLyt.setVisibility(View.VISIBLE);
                }
                mFragmentInteractionListener.hideBlockingProgressBar();
            }
        }, this, this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    private void initViews(View view) {
        RecyclerView prescriptionRecyclerView = (RecyclerView) view.findViewById(R.id.home_container);
        mEmptyLinLyt = (LinearLayout) view.findViewById(R.id.prescription_empty_linLyt);
        prescriptionRecyclerView.setHasFixedSize(false);
        prescriptionRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mPrescriptionAdapter.setRecyclerItemClickListener(this);
        prescriptionRecyclerView.setAdapter(mPrescriptionAdapter);

        Button uploadPrescriptionBtn = (Button) view.findViewById(R.id.prescription_upload_button);
        uploadPrescriptionBtn.setOnClickListener(this);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PRESCRIPTIONS_VISIT_EVENT);
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (((OrderHistoryAdapter.IViewType) object).getViewType()) {
            case ViewTypes.PrescriptionViewType.PRESCRIPTION_INFO:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PRESCRIPTION_TAP_EVENT);
                PrescriptionAdapter.PrescriptionInfoDataItem prescription =
                        (PrescriptionAdapter.PrescriptionInfoDataItem) object;
                mFragmentInteractionListener.loadFragment(getId(),
                        PrescriptionDetailFragment.create(prescription.digitisedPrescription.getId()),
                        null, R.anim.push_left_in, R.anim.push_left_out,
                        FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                break;
            case ViewTypes.PrescriptionViewType.PRESCRIPTION_UPLOAD:
                handleUploadPrescriptionClick(view);
                break;

            case ViewTypes.PrescriptionViewType.PRESCRIPTION_FILTER_HEADER:
                loadPrescriptionFilterFragment();
                break;
        }
    }

    private void loadPrescriptionFilterFragment() {
        mFragmentInteractionListener.loadFragment(getId(),
                PrescriptionFilterFragment.create(mDoctorNames, mPatientNames),
                null, R.anim.push_left_in, R.anim.push_left_out,
                FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    /**
     * Method that receives the callback after applying the Prescription Filter
     *
     * @param selectedDoctorNames  the doctor names that are checked
     * @param selectedPatientNames the patient names that are checked
     */
    public void onFilterApplied(final List<PrescriptionFilterAdapter.
            PrescriptionSubHeaderFilterDataItem> selectedDoctorNames,
                                final List<PrescriptionFilterAdapter.
                                        PrescriptionSubHeaderFilterDataItem> selectedPatientNames) {
        mFragmentInteractionListener.showBlockingProgressBar();

        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... params) {
                mPrescriptionAdapterData.clear();

                List<Long> addedPrescriptions = new ArrayList<Long>(1);

                for (BaseRecyclerAdapter.IViewType view : mPrescriptionsList) {
                    if (view instanceof PrescriptionAdapter.PrescriptionInfoDataItem) {
                        PrescriptionAdapter.PrescriptionInfoDataItem prescription =
                                (PrescriptionAdapter.PrescriptionInfoDataItem) view;
                        String doctorName = prescription.digitisedPrescription.getDoctorName();
                        String patientName = prescription.digitisedPrescription.getPatientName();

                        /**
                         * To avoid adding the Prescription with same id multiple times
                         */
                        boolean isPrescriptionAdded = false;

                        for (PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem
                                doctorPrescriptionDataItem : selectedDoctorNames) {
                            if (doctorPrescriptionDataItem.prescriptionFilterSubHeader.equalsIgnoreCase(doctorName)) {
                                mPrescriptionAdapterData.add(view);
                                addedPrescriptions.add(prescription.digitisedPrescription.getId());
                                isPrescriptionAdded = true;
                                break;
                            }
                        }

                        if (isPrescriptionAdded) continue;

                        for (PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem
                                patientPrescriptionDataItem : selectedPatientNames) {
                            if (patientPrescriptionDataItem.prescriptionFilterSubHeader.equalsIgnoreCase(patientName)
                                    && !addedPrescriptions.contains(prescription.digitisedPrescription.getId())) {
                                mPrescriptionAdapterData.add(view);
                                addedPrescriptions.add(prescription.digitisedPrescription.getId());
                                isPrescriptionAdded = true;
                                break;
                            }
                        }

                        if (isPrescriptionAdded) continue;
                    } else {
                        mPrescriptionAdapterData.add(view);
                    }
                }

                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                mFragmentInteractionListener.hideBlockingProgressBar();
                mPrescriptionAdapter.notifyDataSetChanged();
            }
        }.execute();
    }

    /**
     * Method that receives the callback after clearing the Prescription Filter
     */
    public void onFilterCleared() {
        mPrescriptionAdapterData.clear();
        mPrescriptionAdapterData.addAll(mPrescriptionsList);
        mPrescriptionAdapter.notifyDataSetChanged();
    }

    private void handleUploadPrescriptionClick(View view) {
        switch (view.getId()) {
            case R.id.prescription_upload_button:
                startActivity(UploadPrescriptionActivity.getActivityIntent(getActivity(), false, false));
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.prescription_upload_button:
                startActivity(UploadPrescriptionActivity.getActivityIntent(getActivity(), false, false));
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        //FrankRossAnalytics.getFrankRossTracker().logTimedEvent(FrankRossEvents.TIME_SPENT_PRESCRIPTIONS_EVENT, null);
    }

    @Override
    public void onStop() {
        super.onStop();
        //FrankRossAnalytics.getFrankRossTracker().endTimedEvent(FrankRossEvents.TIME_SPENT_PRESCRIPTIONS_EVENT, null);
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_prescriptions);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }
}
