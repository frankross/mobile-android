/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import android.text.TextUtils;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

/**
 * Created by gowtham on 16/7/15.
 */
public class Address implements Serializable {

    @SerializedName("id")
    private int id;

    @SerializedName("full_name")
    private String fullName = "";

    @SerializedName("address_line_1")
    private String addressLine1 = "";

    @SerializedName("address_line_2")
    private String addressLine2 = "";

    @SerializedName("state")
    private String state = "";

    @SerializedName("pincode")
    private String pincode = "";

    //Specific field for Add Address API
    @SerializedName("area_id")
    private int areaId = -1;

    @SerializedName("country")
    private String country = "";

    @SerializedName("phone_number")
    private String phoneNumber = "";

    @SerializedName("optional_details")
    private String optionalDetails;

    @SerializedName("landmark")
    private String landmark = "";

    @SerializedName("address_type")
    private String addressType = "";

    @SerializedName("default")
    private boolean defaultValue = false;

    @SerializedName("city_name")
    private String cityName = "";

    @SerializedName("city")
    private City city = new City();

    @SerializedName("area")
    private Area area = new Area();

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getOptionalDetails() {
        return optionalDetails;
    }

    public void setOptionalDetails(String optionalDetails) {
        this.optionalDetails = optionalDetails;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    public boolean isDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(boolean defaultValue) {
        this.defaultValue = defaultValue;
    }

    public City getCity() {
        return city;
    }

    public void setCity(City city) {
        this.city = city;
    }

    public Area getArea() {
        return area;
    }

    public void setArea(Area area) {
        this.area = area;
    }

    public int getAreaId() {
        return areaId;
    }

    public void setAreaId(int areaId) {
        this.areaId = areaId;
    }

    public String getCityName() {
        return cityName;
    }

    public static class City implements Serializable {
        @SerializedName("id")
        private int id;

        @SerializedName("name")
        private String name;

        @SerializedName("state")
        private String state;

        @SerializedName("warehouse_code")
        private int warehouse_code;

        @SerializedName("country")
        private String country;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public int getWarehouse_code() {
            return warehouse_code;
        }

        public void setWarehouse_code(int warehouse_code) {
            this.warehouse_code = warehouse_code;
        }

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    public static class Area implements Serializable {
        @SerializedName("pincode")
        private int pincode;

        @SerializedName("id")
        private int id;

        @SerializedName("name")
        private String name;

        @SerializedName("active")
        private boolean isActive = false;

        public int getPincode() {
            return pincode;
        }

        public void setPincode(int pincode) {
            this.pincode = pincode;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public boolean isActive() {
            return isActive;
        }
    }

    public String getFullAddress() {
        StringBuilder stringBuilder = new StringBuilder();

        if (!TextUtils.isEmpty(addressLine1)) {
            stringBuilder.append(addressLine1);
        }

        if (!TextUtils.isEmpty(addressLine2)) {
            stringBuilder.append(", ");
            stringBuilder.append(addressLine2);
        }

        if (!TextUtils.isEmpty(landmark)) {
            stringBuilder.append(", ");
            stringBuilder.append(landmark);
        }
        stringBuilder.append(",\n");

        if (TextUtils.isEmpty(cityName)) {
            stringBuilder.append(getCity().getName());
        } else {
            stringBuilder.append(cityName);
        }

        if (!TextUtils.isEmpty(pincode)) {
            stringBuilder.append(" - ");
            stringBuilder.append(pincode);
        }

        return stringBuilder.toString();
    }
}
