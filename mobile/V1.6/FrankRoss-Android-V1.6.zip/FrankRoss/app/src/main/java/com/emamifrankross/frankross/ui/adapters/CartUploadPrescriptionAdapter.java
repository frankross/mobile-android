/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 24/9/15.
 * <p> Adapter class for Cart Upload Prescription Section</p>
 * <p>Supports the Three View Types </p>
 * <p> 1 : CART UPLOAD PRESCRIPTION HEADER VIEW TYPE </p>
 * <p> 2 : CART ITEM INFO VIEW TYPE </p>
 * <p> 3 : CART ITEM UPLOAD PRESCRIPTION VIEW TYPE </p>
 */
public class CartUploadPrescriptionAdapter extends BaseRecyclerAdapter {

    public CartUploadPrescriptionAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<BaseRecyclerAdapter.RecyclerViewDataBinder> getViewDataBinders() {
        List<BaseRecyclerAdapter.RecyclerViewDataBinder> viewHolderTypeList = new ArrayList<>(1);
        viewHolderTypeList.add(new CartUploadPrescriptionHeaderViewHolderType());
        viewHolderTypeList.add(new CartUploadPrescriptionViewHolderType());
        viewHolderTypeList.add(new UploadPrescriptionViewDataBinder());

        return viewHolderTypeList;
    }

    /**
     * CART UPLOAD PRESCRIPTION HEADER VIEW TYPE
     */

    public static class CartUploadPrescriptionHeaderDataItem implements BaseRecyclerAdapter.IViewType {

        public String cartItemHeader;

        @Override
        public int getViewType() {
            return ViewTypes.CartUploadPrescriptionViewType.CART_UPLOAD_PRESCRIPTION_HEADER_VIEW_TYPE;
        }
    }

    private static class CartUploadPrescriptionHeaderViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mCartItemHeader;

        public CartUploadPrescriptionHeaderViewHolder(View itemView, Context context) {
            super(itemView);
            mCartItemHeader = (RobotoTextView) itemView.findViewById(R.id.top_selling_products_list_header_tv);

            mCartItemHeader.setPadding(context.getResources().getDimensionPixelOffset(R.dimen.cart_header_text_left_margin),
                    context.getResources().getDimensionPixelOffset(R.dimen.cart_header_text_top_margin),
                    context.getResources().getDimensionPixelOffset(R.dimen.cart_order_summary_left_padding),
                    context.getResources().getDimensionPixelOffset(R.dimen.cart_header_text_bottom_margin));
            mCartItemHeader.setGravity(Gravity.LEFT);
            mCartItemHeader.setRobotoFaceType(RobotoTextView.InputTypeFace.REGULAR);
            mCartItemHeader.setTextColor(ContextCompat.getColor(context, R.color.black_text_color));
        }
    }

    private static class CartUploadPrescriptionHeaderViewHolderType implements
            BaseRecyclerAdapter.RecyclerViewDataBinder<CartUploadPrescriptionHeaderViewHolder, CartUploadPrescriptionHeaderDataItem> {

        @Override
        public CartUploadPrescriptionHeaderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.top_selling_products_list_header, parent, false);

            return new CartUploadPrescriptionHeaderViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(CartUploadPrescriptionHeaderViewHolder viewHolder,
                                         final CartUploadPrescriptionHeaderDataItem data, final int position,
                                         final BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mCartItemHeader.setText(data.cartItemHeader);
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartUploadPrescriptionViewType.CART_UPLOAD_PRESCRIPTION_HEADER_VIEW_TYPE;
        }
    }

    /**
     * CART ITEM VIEW TYPE
     */

    public static class CartUploadPrescriptionDataItem implements IViewType {

        public String productName;
        public String productStripInfo;

        @Override
        public int getViewType() {
            return ViewTypes.CartUploadPrescriptionViewType.CART_UPLOAD_PRESCRIPTION_LIST_ITEM_VIEW_TYPE;
        }
    }

    private static class CartUploadPrescriptionViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mCartUploadPrescriptionProductName;
        private RobotoTextView mCartUploadPrescriptionProductStripInfo;

        public CartUploadPrescriptionViewHolder(View itemView) {
            super(itemView);
            mCartUploadPrescriptionProductName = (RobotoTextView) itemView.findViewById(R.id.cart_upload_prescription_list_item_product_name_tv);
            mCartUploadPrescriptionProductStripInfo = (RobotoTextView) itemView.findViewById(R.id.cart_upload_prescription_list_item_product_strip_info_tv);
        }
    }

    private static class CartUploadPrescriptionViewHolderType implements
            RecyclerViewDataBinder<CartUploadPrescriptionViewHolder, CartUploadPrescriptionDataItem> {

        @Override
        public CartUploadPrescriptionViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_upload_prescription_list_item, parent, false);

            return new CartUploadPrescriptionViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(CartUploadPrescriptionViewHolder viewHolder,
                                         final CartUploadPrescriptionDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mCartUploadPrescriptionProductName.setText(data.productName);
            viewHolder.mCartUploadPrescriptionProductStripInfo.setText(data.productStripInfo);
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartUploadPrescriptionViewType.CART_UPLOAD_PRESCRIPTION_LIST_ITEM_VIEW_TYPE;
        }
    }

    /**
     * UPLOAD PRESCRIPTION VIEW TYPE
     */
    public static class UploadPrescriptionDataItem implements IViewType {

        @Override
        public int getViewType() {
            return ViewTypes.CartUploadPrescriptionViewType.CART_UPLOAD_PRESCRIPTION_VIEW_TYPE;
        }
    }

    private static class UploadPrescriptionViewHolder extends RecyclerView.ViewHolder {

        private LinearLayout mSearchLayout;
        private LinearLayout mOrLayout;
        private LinearLayout mUploadLinLyt;
        private Button mUploadPrescriptionButton;
        private RobotoTextView mUploadTxt;

        public UploadPrescriptionViewHolder(View itemView, Context context) {
            super(itemView);
            mSearchLayout = (LinearLayout) itemView.findViewById(R.id.home_search_linLay);
            mUploadLinLyt = (LinearLayout) itemView.findViewById(R.id.home_upload_button_linLay);
            mOrLayout = (LinearLayout) itemView.findViewById(R.id.home_or_linLay);
            mUploadTxt = (RobotoTextView) itemView.findViewById(R.id.home_upload_text);
            mUploadPrescriptionButton = (Button) itemView.findViewById(R.id.home_upload_button);

            mSearchLayout.setVisibility(View.GONE);
            mOrLayout.setVisibility(View.GONE);
            mUploadTxt.setVisibility(View.GONE);
            itemView.findViewById(R.id.home_upload_prescription_vertical_saperator).setVisibility(View.GONE);

            mUploadLinLyt.setPadding(0, context.getResources().getDimensionPixelSize(R.dimen.cart_upload_prescription_top_margin)
                    , 0, context.getResources().getDimensionPixelSize(R.dimen.cart_upload_prescription_top_margin));
        }
    }

    private static class UploadPrescriptionViewDataBinder implements
            RecyclerViewDataBinder<UploadPrescriptionViewHolder, UploadPrescriptionDataItem> {

        @Override
        public UploadPrescriptionViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_uplaod_prescription, parent, false);

            return new UploadPrescriptionViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(UploadPrescriptionViewHolder viewHolder,
                                         final UploadPrescriptionDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            if (recyclerViewClickListener != null) {
                viewHolder.mUploadPrescriptionButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.CartUploadPrescriptionViewType.CART_UPLOAD_PRESCRIPTION_VIEW_TYPE;
        }
    }
}
