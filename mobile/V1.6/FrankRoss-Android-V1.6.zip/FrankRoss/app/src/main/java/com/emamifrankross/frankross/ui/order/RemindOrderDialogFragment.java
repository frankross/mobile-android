/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.order;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.View;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiOrderReminder;
import com.emamifrankross.frankross.ui.checkout.IRemindOrderDoneClickNotifier;
import com.emamifrankross.frankross.ui.common.BaseDialogFragment;
import com.emamifrankross.frankross.ui.customviews.NumberPickerWidget;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.FrankRossDateUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Created by gauthami on 10/7/15.
 */

/**
 * This class represents the UI for Set Reminder for reorder dialog
 */
public class RemindOrderDialogFragment extends BaseDialogFragment implements View.OnClickListener,
        NumberPickerWidget.OnNumberChangedListener {

    private static final int DAY = 1;
    private static final int WEEK = 7;
    private static final int MONTH = 30;

    private static final String DAYS = "days";
    private static final String WEEKS = "weeks";
    private static final String MONTHS = "months";

    private RobotoTextView mRemindOrderDate;
    private RobotoTextView mDaysTitle;
    private RobotoTextView mWeeksTitle;
    private RobotoTextView mMonthTitle;

    private NumberPickerWidget mNumberPicker;
    private Calendar mCalendar;
    private IRemindOrderDoneClickNotifier mIRemindOrderDoneClickNotifier;

    private boolean isDaysSelected = false;
    private boolean isWeeksSelected = false;
    private boolean isMonthSelected = false;
    private boolean isDoneClicked = false;

    public static RemindOrderDialogFragment create(IRemindOrderDoneClickNotifier remindOrderDoneClickNotifier) {
        RemindOrderDialogFragment fragment = new RemindOrderDialogFragment();
        fragment.mIRemindOrderDoneClickNotifier = remindOrderDoneClickNotifier;
        return fragment;
    }

    @Override
    public int getLayoutId() {
        return R.layout.fragment_remind_order_dialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mCalendar = Calendar.getInstance();
    }

    @Override
    public void initViews(Dialog view) {
        mCalendar = Calendar.getInstance();
        mRemindOrderDate = (RobotoTextView) view.findViewById(R.id.order_history_dialog_description_tv);
        RobotoTextView remindOrderDoneButton = (RobotoTextView) view.findViewById(R.id.order_history_dialog_done_btn);
        mDaysTitle = (RobotoTextView) view.findViewById(R.id.order_history_dialog_title_days_tv);
        mWeeksTitle = (RobotoTextView) view.findViewById(R.id.order_history_dialog_title_weeks_tv);
        mMonthTitle = (RobotoTextView) view.findViewById(R.id.order_history_dialog_title_month_tv);
        mNumberPicker = (NumberPickerWidget) view.findViewById(R.id.order_history_dialog_number_picker);
        mNumberPicker.setOnNumberChangedListener(this);

        remindOrderDoneButton.setOnClickListener(this);
        mDaysTitle.setOnClickListener(this);
        mWeeksTitle.setOnClickListener(this);
        mMonthTitle.setOnClickListener(this);

        mDaysTitle.performClick();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.order_history_dialog_done_btn:
                ApiOrderReminder.Request apiOrderReminderRequest = new ApiOrderReminder.Request();
                apiOrderReminderRequest.setDuration(getDuration());
                apiOrderReminderRequest.setDuration_unit(getDurationUnit());
                if (mIRemindOrderDoneClickNotifier != null) {
                    isDoneClicked = true;
                    mIRemindOrderDoneClickNotifier.onRemindOrderDoneClick(apiOrderReminderRequest);
                }
                getDialog().dismiss();
                break;
            case R.id.order_history_dialog_title_days_tv:
                isDaysSelected = true;
                isMonthSelected = false;
                isWeeksSelected = false;

                //mNumberPicker.setValue(1);
                updateDate((int) (mNumberPicker.getValue() * DAY), true, true);

                mDaysTitle.setTextColor(ContextCompat.getColor(getActivity(), R.color.frankross_green));
                mWeeksTitle.setTextColor(ContextCompat.getColor(getActivity(), R.color.common_header_text_color));
                mMonthTitle.setTextColor(ContextCompat.getColor(getActivity(), R.color.common_header_text_color));
                break;
            case R.id.order_history_dialog_title_weeks_tv:
                isDaysSelected = false;
                isWeeksSelected = true;
                isMonthSelected = false;

                //mNumberPicker.setValue(1);
                updateDate((int) (mNumberPicker.getValue() * WEEK), true, true);

                mWeeksTitle.setTextColor(ContextCompat.getColor(getActivity(), R.color.frankross_green));
                mDaysTitle.setTextColor(ContextCompat.getColor(getActivity(), R.color.common_header_text_color));
                mMonthTitle.setTextColor(ContextCompat.getColor(getActivity(), R.color.common_header_text_color));
                break;
            case R.id.order_history_dialog_title_month_tv:
                isDaysSelected = false;
                isWeeksSelected = false;
                isMonthSelected = true;

                //mNumberPicker.setValue(1);
                updateDate((int) (mNumberPicker.getValue() * MONTH), true, true);

                mMonthTitle.setTextColor(ContextCompat.getColor(getActivity(), R.color.frankross_green));
                mDaysTitle.setTextColor(ContextCompat.getColor(getActivity(), R.color.common_header_text_color));
                mWeeksTitle.setTextColor(ContextCompat.getColor(getActivity(), R.color.common_header_text_color));
                break;
            default:
                break;
        }
    }

    @Override
    public void onNumberIncremented(int number) {
        if (isDaysSelected) {
            updateDate(DAY, true, false);
        } else if (isWeeksSelected) {
            updateDate(WEEK, true, false);
        } else if (isMonthSelected) {
            updateDate(MONTH, true, false);
        }
    }

    @Override
    public void onNumberDecremented(int number) {
        if (isDaysSelected) {
            updateDate(DAY, false, false);
        } else if (isWeeksSelected) {
            updateDate(WEEK, false, false);
        } else if (isMonthSelected) {
            updateDate(MONTH, false, false);
        }
    }

    /**
     * Method that updates the date when incremented or decremented
     *
     * @param numberOfDays the number of days to be incremented/decremented
     * @param isIncrement  identify the operation
     * @param isReset      flag used to reset the reminder date to the current date
     */
    private void updateDate(int numberOfDays, boolean isIncrement, boolean isReset) {
        DateFormat dateFormat = new SimpleDateFormat("dd MMMM yyyy", Locale.ENGLISH);
        String updatedDateString;
        if (isReset) {
            mCalendar = Calendar.getInstance();
        }
        if (isIncrement) {
            mCalendar.add(Calendar.DAY_OF_YEAR, +numberOfDays);
        } else {
            mCalendar.add(Calendar.DAY_OF_YEAR, -numberOfDays);
        }
        updatedDateString = dateFormat.format(mCalendar.getTime());
        mRemindOrderDate.setText(updatedDateString);
    }

    /**
     * Method identifies the duration unit
     *
     * @return the duration unit based on the tab selected by user
     */
    private String getDurationUnit() {
        if (isDaysSelected) {
            return getString(R.string.order_history_remind_reorder_days);
        } else if (isWeeksSelected) {
            return getString(R.string.order_history_remind_reorder_weeks);
        } else if (isMonthSelected) {
            return getString(R.string.order_history_remind_reorder_months);
        }

        return "";
    }

    /**
     * Method calculates the days difference between the current day and
     * the day to which reminder is set
     *
     * @return the days gap in terms of days or weeks or months
     */
    private String getDuration() {
        int daysDifference = FrankRossDateUtils.daysBetween(new Date(), mCalendar.getTime()) + 1;
        switch (getDurationUnit()) {
            case DAYS:
                return daysDifference + "";
            case WEEKS:
                return FrankRossDateUtils.getNumberOfWeeks(daysDifference);
            case MONTHS:
                return FrankRossDateUtils.getNumberOfMonths(daysDifference);
        }
        return "";
    }

    /**
     * Callback to be invoked on dismissing the Set Reminder alert
     *
     * @param dialog the dialog that was dismissed
     */
    @Override
    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        if (!isDoneClicked) {
            if (mIRemindOrderDoneClickNotifier != null) {
                mIRemindOrderDoneClickNotifier.onRemindOrderCancel();
            }
        }
    }
}
