/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.sdkmanager;

import android.app.Activity;
import android.content.Context;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.UrlConstants;
import com.emamifrankross.frankross.utils.Log;
import com.emamifrankross.frankross.utils.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import io.branch.indexing.BranchUniversalObject;
import io.branch.referral.Branch;
import io.branch.referral.BranchError;
import io.branch.referral.util.LinkProperties;
import io.branch.referral.util.ShareSheetStyle;

/**
 * Created by gauthami on 7/6/16.
 */

/**
 * This class manages the Branch SDK instance creation, event logging, deep linking and branch share sheet,
 * Branch SDK response json validation and its keys
 */
public class BranchManager {

    public static final String TAG = BranchManager.class.getSimpleName();
    public static final String BRANCH_REFERRAL_DATA_KEY = "data";
    public static final String BRANCH_PDP_SHARE_VARIANT_ID = "variant_id";
    public static final String BRANCH_PDP_SHARE_SCREEN_NAME = "product_type";
    public static final String BRANCH_PDP_SHARE_LINK_CLICKED = "+clicked_branch_link";
    public static final String BRANCH_APP_SHARE_CONTENT_IMAGE_URL = "https://s3-ap-southeast-1.amazonaws.com/emami-production-2/brand/FRLogo.png";
    private static final String BRANCH_REFERRAL_IS_FIRST_SESSION_KEY = "+is_first_session";
    private static final String BRANCH_REFERRAL_INVITING_USER_FULL_NAME_KEY = "BRANCH_INVITE_USER_FULLNAME_KEY";
    private static final String BRANCH_REFERRAL_INVITING_USER_ID_KEY = "BRANCH_INVITE_USER_ID_KEY";
    private static final String BRANCH_REFERRAL_INVITING_USER_IMAGE_URL_KEY = "BRANCH_INVITE_USER_IMAGE_URL_KEY";
    private static final String BRANCH_REFERRAL_INVITING_SHORT_NAME_KEY = "BRANCH_INVITE_USER_SHORT_NAME_KEY";
    private static final String BRANCH_REGISTRATION_EVENT = "registered";
    private static final String BRANCH_REFERRAL_FEATURE = "referral";
    private static final String BRANCH_APP_SHARE_FEATURE = "App share";
    private static final String BRANCH_PDP_SHARE_FEATURE = "Product share";
    private static Branch mBranch;

    private BranchManager() {
    }

    /**
     * Method that returns the test or live instance of the Branch
     *
     * @param context the application context
     * @return returns the test/live instance of the Branch depending on the flag
     */
    public static Branch getBranchInstance(Context context) {
        if (mBranch == null) {
            mBranch = UrlConstants.DEV_MODE ? Branch.getTestInstance(context) : Branch.getInstance(context);
        }
        return mBranch;
    }

    /**
     * Method that handles the 'Invite Friends' button tap and thereby launches the
     * Simple Share Intent provided by BRANCH SDK
     */
    public static void launchBranchSdkShareIntent(Context context, String shareSubject, String shareMessage,
                                                  String linkTitle, String linkDescription, String linkImageUrl) {
        String referrerName = Utils.getUserName(context.getApplicationContext());
        String referrerId = Utils.getUserID(context.getApplicationContext());

        LinkProperties linkProperties = new LinkProperties()
                .setFeature(BRANCH_REFERRAL_FEATURE);
        ShareSheetStyle shareSheetStyle = new ShareSheetStyle(context, shareSubject, shareMessage)
                .setAsFullWidthStyle(true)
                .setSharingTitle(context.getResources().getString(R.string.branch_share_sheet_title));

        new BranchUniversalObject()
                .setTitle(linkTitle)
                .setContentDescription(linkDescription)
                .setContentImageUrl(linkImageUrl)
                .addContentMetadata(BRANCH_REFERRAL_INVITING_USER_ID_KEY,
                        referrerId)
                .addContentMetadata(BRANCH_REFERRAL_INVITING_USER_FULL_NAME_KEY,
                        referrerName)
                .addContentMetadata(BRANCH_REFERRAL_INVITING_SHORT_NAME_KEY,
                        "")
                .addContentMetadata(BRANCH_REFERRAL_INVITING_USER_IMAGE_URL_KEY,
                        "")
                .showShareSheet((Activity) context,
                        linkProperties,
                        shareSheetStyle, null);
    }

    /**
     * Method that logs the user registration event to Branch after completion of registration flow
     *
     * @param context the application context
     */
    public static void logBranchUserRegistrationEvent(Context context) {
        BranchManager.getBranchInstance(context).userCompletedAction(BRANCH_REGISTRATION_EVENT);
    }

    /**
     * Method that validates the Branch response to show the refer successful dialog
     *
     * @param referringParams the Branch SDK response
     * @return boolean that decides if it is a referred session
     */
    public static boolean validateJsonForReferSuccessSession(JSONObject referringParams) {

        boolean isWelcomeDialogShowable = false;
        try {
            if (referringParams != null
                    && referringParams.has(BranchManager.BRANCH_REFERRAL_IS_FIRST_SESSION_KEY)
                    && referringParams.has(BranchManager.BRANCH_REFERRAL_INVITING_USER_FULL_NAME_KEY)
                    && referringParams.has(BranchManager.BRANCH_REFERRAL_INVITING_USER_ID_KEY)
                    && Boolean.parseBoolean(String.valueOf(referringParams.get(BranchManager.BRANCH_REFERRAL_IS_FIRST_SESSION_KEY)))
                    && referringParams.get(String.valueOf(BranchManager.BRANCH_REFERRAL_INVITING_USER_FULL_NAME_KEY)) != null
                    && referringParams.get(String.valueOf(BranchManager.BRANCH_REFERRAL_INVITING_USER_ID_KEY)) != null) {
                isWelcomeDialogShowable = true;
            }
        } catch (JSONException e) {
            Log.d(BranchManager.TAG, "Parse error = " + e.toString());
        }
        Log.d(BranchManager.TAG, "isReferredSession = " + isWelcomeDialogShowable);
        return isWelcomeDialogShowable;
    }

    /**
     * Method that validates the Branch response to show the refer failure dialog
     *
     * @param referringParams the Branch SDK response
     * @return boolean that decides if it is a referred session
     */
    public static boolean validateJsonForReferFailureSession(JSONObject referringParams) {

        boolean isFailureDialogShowable = false;
        try {
            if (referringParams != null
                    && referringParams.has(BranchManager.BRANCH_REFERRAL_IS_FIRST_SESSION_KEY)
                    && referringParams.has(BranchManager.BRANCH_REFERRAL_INVITING_USER_FULL_NAME_KEY)
                    && referringParams.has(BranchManager.BRANCH_REFERRAL_INVITING_USER_ID_KEY)
                    && !Boolean.parseBoolean(String.valueOf(referringParams.get(BranchManager.BRANCH_REFERRAL_IS_FIRST_SESSION_KEY)))
                    && referringParams.get(String.valueOf(BranchManager.BRANCH_REFERRAL_INVITING_USER_FULL_NAME_KEY)) != null
                    && referringParams.get(String.valueOf(BranchManager.BRANCH_REFERRAL_INVITING_USER_ID_KEY)) != null) {
                isFailureDialogShowable = true;
            }
        } catch (JSONException e) {
            Log.d(BranchManager.TAG, "Parse error = " + e.toString());
        }
        Log.d(BranchManager.TAG, "isFailureDialogShowable = " + isFailureDialogShowable);
        return isFailureDialogShowable;
    }

    /**
     * Method that generates App share link using Branch Universal object
     *
     * @param context      the application
     * @param shareSubject the share subject
     * @param shareMessage the share message/body
     * @param variantId    the product id
     * @param screenType   the product type- pharma or non pharma
     */
    public static void showBranchShareSheetForPdp(Context context,
                                                  String shareSubject,
                                                  String shareMessage,
                                                  long variantId,
                                                  String screenType, String title, String description, String imageurl) {
        LinkProperties linkProperties = new LinkProperties()
                .setFeature(BRANCH_PDP_SHARE_FEATURE);
        ShareSheetStyle shareSheetStyle = new ShareSheetStyle(context, shareSubject, shareMessage)
                .setAsFullWidthStyle(true)
                .setSharingTitle(context.getResources().getString(R.string.branch_share_sheet_title));

        new BranchUniversalObject()
                .setTitle(title)
                .setContentDescription(description)
                .setContentImageUrl(imageurl)
                .addContentMetadata(BRANCH_PDP_SHARE_VARIANT_ID,
                        String.valueOf(variantId))
                .addContentMetadata(BRANCH_PDP_SHARE_SCREEN_NAME,
                        screenType)
                .showShareSheet((Activity) context,
                        linkProperties,
                        shareSheetStyle,
                        new Branch.BranchLinkShareListener() {
                            @Override
                            public void onShareLinkDialogLaunched() {
                            }

                            @Override
                            public void onShareLinkDialogDismissed() {
                            }

                            @Override
                            public void onLinkShareResponse(String sharedLink, String sharedChannel, BranchError error) {
                            }

                            @Override
                            public void onChannelSelected(String channelName) {
                                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PDP_SHARING_MEDIUM_TAP_EVENT,
                                        Utils.shareDataForAnalytics(channelName));
                            }
                        });
    }

    /**
     * Method that generates App share link using Branch Universal object
     *
     * @param context      the application
     * @param shareSubject the share subject
     * @param shareMessage the share message/body
     */
    public static void showBranchShareSheetForAppSharing(Context context, String shareSubject, String shareMessage,
                                                         String linkTitle, String linkDescription, String linkImageUrl) {
        LinkProperties linkProperties = new LinkProperties()
                .setFeature(BRANCH_APP_SHARE_FEATURE);
        ShareSheetStyle shareSheetStyle = new ShareSheetStyle(context, shareSubject, shareMessage)
                .setAsFullWidthStyle(true)
                .setSharingTitle(context.getResources().getString(R.string.branch_share_sheet_title));

        new BranchUniversalObject()
                .setTitle(linkTitle)
                .setContentDescription(linkDescription)
                .setContentImageUrl(linkImageUrl)
                .showShareSheet((Activity) context,
                        linkProperties,
                        shareSheetStyle,
                        new Branch.BranchLinkShareListener() {
                            @Override
                            public void onShareLinkDialogLaunched() {
                            }

                            @Override
                            public void onShareLinkDialogDismissed() {
                            }

                            @Override
                            public void onLinkShareResponse(String sharedLink, String sharedChannel, BranchError error) {
                            }

                            @Override
                            public void onChannelSelected(String channelName) {
                                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ORDER_SHARING_MORE_MEDIUM_TAP_EVENT,
                                        Utils.shareDataForAnalytics(channelName));
                            }
                        });
    }

    /**
     * Method that generates App share link using Branch Universal object
     *
     * @param context the application
     * @return the Branch generated share link
     */
    public static String getAppSharableLink(Context context, String channel,
                                            String linkTitle, String linkDescription, String linkImageUrl) {
        LinkProperties linkProperties
                = new LinkProperties()
                .setChannel(channel)
                .setFeature(BRANCH_APP_SHARE_FEATURE);
        return new BranchUniversalObject()
                .setTitle(linkTitle)
                .setContentDescription(linkDescription)
                .setContentImageUrl(linkImageUrl)
                .getShortUrl(context, linkProperties);
    }
}
