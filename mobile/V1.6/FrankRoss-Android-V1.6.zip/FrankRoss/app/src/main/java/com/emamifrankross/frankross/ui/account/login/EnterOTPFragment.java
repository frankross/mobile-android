/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.account.login;

import android.Manifest;
import android.app.Activity;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import com.emamifrankross.frankross.FrankRossApplication;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiSettings;
import com.emamifrankross.frankross.core.apimodels.ApiSocialLogin;
import com.emamifrankross.frankross.core.apimodels.ApiSocialRegister;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.AppRuntimePermissionsManager;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.NetworkUtils;
import com.emamifrankross.frankross.utils.PreferenceUtils;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gauthami on 2/7/15.
 */

/**
 * This class represents the UI for OTP verification & submission
 */
public class EnterOTPFragment extends ApiRequestBaseFragment implements View.OnClickListener, IToolbar,
        ChangeMobileNumberDialogFragment.IChangeNumberListener, OtpSmsReceiver.IOtpReceivedListener {

    private static final String TAG = EnterOTPFragment.class.getSimpleName();

    private static final String OTP_AUTO_READ_MESSAGE_READ_PERMISSION = "android.provider.Telephony.SMS_RECEIVED";
    protected static final String MAIL_KEY = "mailId";
    protected static final String PASSWORD_KEY = "password";
    protected static final String MOBILE_KEY = "mobile_number";
    protected static final String NEW_MOBILE_KEY = "new_mobile_number";
    protected static final String IS_ALREADY_PLACED = "isAlreadyPlacedOrder";
    protected static final String IS_OLD_NUMBER_VERIFIED = "isNOldNumberVerified";
    protected static final String USER_NAME_KEY = "user_name";
    protected static final String IS_REGISTER_LISTENER = "isRegisterListener";
    public static final String IS_NEW_USER_REGISTRATION_FLOW = "mIsNewUserRegistrationFlow";
    private static final long OTP_AUTO_READ_COUNT_DOWN_INTERVAL = 500;

    private EditText mEnteredOTP;
    private RobotoTextView mEnterOTPTitle;
    private RobotoTextView mChangeNumber;
    private RobotoTextView mOrTxt;
    private RobotoTextView mClearBtn;
    private RobotoTextView mOtpStatus;
    protected LinearLayout mOtpOverlayLinLyt;
    protected LinearLayout mOtpContentLinLyt;
    private ProgressBar mOtpProgressBar;

    private String mUserMail;
    protected String mPhoneNumber;
    private String mUserPassword;
    protected String mUserNewNumber;
    protected String mUserName;
    protected String mOldPhoneNumber;
    private String mAutoReadOtp;
    protected boolean mIsOldNumberVerified;
    protected boolean mIsUnRegisterListeners;
    private boolean mIsRegisterListeners = true;
    private boolean mIsOrderPlaced = false;
    private boolean mIsNewUserRegistrationFlow = false;

    private ApiSocialRegister.Request mSocialRegisterRequest;
    protected OtpSmsReceiver mOtpSmsReceiver;
    private ApiSettings.Response.SettingsInfo mOtpSettings;

    public static EnterOTPFragment create(boolean isPlaced, boolean isNewUserRegistrationFlow,
                                          String mailAddress, String phoneNumber, String userPassword,
                                          ApiSocialRegister.Request apiSocialRegisterRequest) {
        EnterOTPFragment fragment = new EnterOTPFragment();
        Bundle bundle = new Bundle();
        bundle.putString(MAIL_KEY, mailAddress);
        bundle.putString(MOBILE_KEY, phoneNumber);
        bundle.putString(PASSWORD_KEY, userPassword);
        bundle.putBoolean(IS_ALREADY_PLACED, isPlaced);
        bundle.putBoolean(IS_NEW_USER_REGISTRATION_FLOW, isNewUserRegistrationFlow);
        fragment.setArguments(bundle);
        fragment.setRegisterRequestData(apiSocialRegisterRequest);
        return fragment;
    }

    protected void setRegisterRequestData(ApiSocialRegister.Request apiSocialRegisterRequest) {
        mSocialRegisterRequest = apiSocialRegisterRequest;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        if (this.getArguments() != null) {
            mUserMail = this.getArguments().getString(MAIL_KEY);
            mPhoneNumber = this.getArguments().getString(MOBILE_KEY);
            mOldPhoneNumber = this.getArguments().getString(MOBILE_KEY);
            mUserNewNumber = this.getArguments().getString(NEW_MOBILE_KEY);
            mUserPassword = this.getArguments().getString(PASSWORD_KEY);
            mUserName = this.getArguments().getString(USER_NAME_KEY);
            mIsOrderPlaced = getArguments().getBoolean(IS_ALREADY_PLACED);
            mIsRegisterListeners = getArguments().getBoolean(IS_REGISTER_LISTENER);
            mIsNewUserRegistrationFlow = getArguments().getBoolean(IS_NEW_USER_REGISTRATION_FLOW);
            mIsOldNumberVerified = getArguments().getBoolean(IS_OLD_NUMBER_VERIFIED);
        }

        return inflater.inflate(R.layout.fragment_enter_otp, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the views
     *
     * @param view the root view
     */
    private void initViews(View view) {
        mEnteredOTP = (EditText) view.findViewById(R.id.enter_otp_et);
        Button registerBtn = (Button) view.findViewById(R.id.otp_submit_btn);
        RobotoTextView resendOtp = (RobotoTextView) view.findViewById(R.id.resend_otp_tv);
        mChangeNumber = (RobotoTextView) view.findViewById(R.id.change_number_tv);
        mEnterOTPTitle = (RobotoTextView) view.findViewById(R.id.enter_otp_title);
        mOrTxt = (RobotoTextView) view.findViewById(R.id.enter_otp_or_tv);
        mClearBtn = (RobotoTextView) view.findViewById(R.id.enter_otp_clear_txt_btn);
        mOtpStatus = (RobotoTextView) view.findViewById(R.id.enter_otp_otp_status_tv);
        mOtpContentLinLyt = (LinearLayout) view.findViewById(R.id.otp_content_linLyt);
        mOtpOverlayLinLyt = (LinearLayout) view.findViewById(R.id.otp_overlay_linLyt);
        mOtpProgressBar = (ProgressBar) view.findViewById(R.id.otp_overlay_progress_bar);

        mEnteredOTP.addTextChangedListener(mOTPTextChangeListener);
        registerBtn.setOnClickListener(this);
        resendOtp.setOnClickListener(this);
        mChangeNumber.setOnClickListener(this);
        mClearBtn.setOnClickListener(this);

        initData();
        performRegisterOrUnregisterToAutoReadOtp();

        FrankRossAnalytics.getFrankRossTracker().

                logEvent(FrankRossEvents.ENTER_OTP_VISIT_EVENT);

    }

    /**
     * Method that checks for Runtime permissions
     */
    protected void performRegisterOrUnregisterToAutoReadOtp() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                AppRuntimePermissionsManager.checkPermissionForOtpReadFromMessage(getActivity())) {
            try {
                registerListeners();
            } catch (SecurityException securityException) {

            }
        } else {
            requestPermissions(new String[]{Manifest.permission.READ_SMS},
                    AppRuntimePermissionsManager.REQUEST_CODE_OTP_AUTO_READ_PERMISSIONS);
        }
    }

    /**
     * Registers the OTP received broadcast listener.
     */
    private void registerListeners() {
        startCountDownTimer();
        Utils.enableViews(mOtpOverlayLinLyt);
        Utils.disableViews(mOtpContentLinLyt);
        mOtpOverlayLinLyt.setVisibility(View.VISIBLE);

        mOtpSmsReceiver = new OtpSmsReceiver(mOtpSettings);
        mOtpSmsReceiver.setOtpReceivedListener(this);
        IntentFilter otpReceiverIntentFilter = new IntentFilter(OTP_AUTO_READ_MESSAGE_READ_PERMISSION);
        getActivity().registerReceiver(mOtpSmsReceiver, otpReceiverIntentFilter);
    }

    /**
     * Method that starts the Count down timer to register/unregister the OTP listeners
     */
    private void startCountDownTimer() {
        CountDownTimer countDownTimer;
        mOtpProgressBar.setMax((int) mOtpSettings.getOtpTimeInterval());
        mOtpProgressBar.setProgress(0);
        countDownTimer = new CountDownTimer(mOtpSettings.getOtpTimeInterval(), OTP_AUTO_READ_COUNT_DOWN_INTERVAL) {

            @Override
            public void onTick(long millisUntilFinished) {
                mOtpProgressBar.setProgress((int) (mOtpSettings.getOtpTimeInterval() - (int) millisUntilFinished));
            }

            @Override
            public void onFinish() {
            }
        };
        countDownTimer.start();

        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                unRegisterOtpAutoReadProcess();
            }
        }, mOtpSettings.getOtpTimeInterval());
    }

    /**
     * Method that manages to unregister the OTP auto read process
     */
    private void unRegisterOtpAutoReadProcess() {
        unregisterOtpAutoReadListener();
        if (TextUtils.isEmpty(mAutoReadOtp) && getActivity() != null) {
            mOtpStatus.setVisibility(View.VISIBLE);
            mOtpStatus.setText("Failed to auto-read the OTP");
            mOtpStatus.setTextColor(ContextCompat.getColor(getActivity(), R.color.prescription_reference_expired_txt_color));
        }
    }

    /**
     * Method that sets the content/overlay layout
     */
    public void unregisterOtpAutoReadListener() {
        mFragmentInteractionListener.hideBlockingProgressBar();
        Utils.enableViews(mOtpContentLinLyt);
        Utils.disableViews(mOtpOverlayLinLyt);

        mOtpOverlayLinLyt.setVisibility(View.GONE);
        mOtpStatus.setVisibility(View.GONE);

        if (mOtpSmsReceiver != null) {
            getActivity().unregisterReceiver(mOtpSmsReceiver);
            mOtpSmsReceiver = null;
        }
    }

    /**
     * Text watcher for entered otp that helps in setting the clear button visibility
     */
    private TextWatcher mOTPTextChangeListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            setClearButtonVisibility(charSequence);
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    };

    /**
     * Method that sets the visibility of clear button associated with the OTP
     *
     * @param charSequence that determines visibility of clear button
     */
    private void setClearButtonVisibility(CharSequence charSequence) {
        mClearBtn.setVisibility((!TextUtils.isEmpty(charSequence) && charSequence.length() > 0) ? View.VISIBLE : View.INVISIBLE);
    }

    /**
     * Method that initializes the data for views
     */
    private void initData() {
        mEnterOTPTitle.setText(getString(R.string.log_in_enter_otp_title) + " " + mPhoneNumber +
                ".\n Enter it below so we know it's really you.");
        mChangeNumber.setVisibility(mIsNewUserRegistrationFlow ? View.VISIBLE : View.GONE);
        mOrTxt.setVisibility(mIsNewUserRegistrationFlow ? View.VISIBLE : View.GONE);
        mOtpSettings = mApiRequestManager.getSettingsResponse();
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.otp_submit_btn:
                performOTPSubmit();
                break;
            case R.id.resend_otp_tv:
                performReSendOTP(mPhoneNumber);
                break;
            case R.id.change_number_tv:
                showChangeNumberDialog();
                break;
            case R.id.enter_otp_clear_txt_btn:
                mEnteredOTP.getText().clear();
                break;
        }
    }

    /**
     * Method that pops out the Change mobile number dialog
     */
    private void showChangeNumberDialog() {
        ChangeMobileNumberDialogFragment changeMobileNumberDialogFragment = ChangeMobileNumberDialogFragment.create(this);
        changeMobileNumberDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    /**
     * Method requests for Resend OTP;If success,sets a message to title of the screen
     */
    protected void performReSendOTP(final String number) {
        if (NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
            hide_keyboard(getActivity(), mEnteredOTP);

            mFragmentInteractionListener.showBlockingProgressBar();
            mApiRequestManager.performCreateOTPRequest(number, new ApiRequestManager.ICreateOTPResultNotifier() {
                @Override
                public void onOtpSent(String message) {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    showAlert(message, new AlertDialogFragment.AlertPositiveActionListener() {
                        @Override
                        public void onPositiveAction() {
                            mPhoneNumber = number;
                            mEnterOTPTitle.setText(getString(R.string.log_in_enter_otp_title) + " " + number +
                                    ".\n Enter it below so we know it's really you.");
                        }
                    }, false);
                }
            }, this, this);
        } else {
            showAlert(getString(R.string.please_check_your_network_connection));
        }
    }

    /**
     * @return If false,displays the input or network error dialog with appropriate message;else true.
     */
    private boolean validateEnteredOTP() {
        if (TextUtils.isEmpty(mEnteredOTP.getText().toString())) {
            showAlert(getString(R.string.please_enter_otp));
        } else if (!NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
            showAlert(getString(R.string.please_check_your_network_connection));
        } else {
            return true;
        }

        return false;
    }

    /**
     * Method requests for Verify OTP;If success,requests for Sign in
     */
    private void performOTPSubmit() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SUBMIT_OTP_CLICK_EVENT);
        hide_keyboard(getActivity(), mEnteredOTP);

        if (validateEnteredOTP()) {
            mFragmentInteractionListener.showBlockingProgressBar();
            final String otp = mEnteredOTP.getText().toString();

            mApiRequestManager.performVerifyOtpRequest(otp, mPhoneNumber,
                    new ApiRequestManager.IVerifyOtpResultNotifier() {

                        @Override
                        public void onOtpVerified() {
                            performOtpVerified(otp);
                        }

                        @Override
                        public void onOtpApiError(String message) {
                            mFragmentInteractionListener.hideBlockingProgressBar();
                            showAlert(message, new AlertDialogFragment.AlertPositiveActionListener() {
                                @Override
                                public void onPositiveAction() {
                                }
                            }, false);
                        }

                        @Override
                        public void onCommonError(int messageId) {
                            mFragmentInteractionListener.hideBlockingProgressBar();
                            showAlert(getString(messageId), new AlertDialogFragment.AlertPositiveActionListener() {
                                @Override
                                public void onPositiveAction() {
                                }
                            }, false);
                        }
                    }, this);
        }
    }

    /**
     * Method that verifies the entered OTP
     *
     * @param otp the OTP that has to be verified with the server
     */
    protected void performOtpVerified(String otp) {
        if (TextUtils.isEmpty(mUserPassword)) {
            mFragmentInteractionListener.hideBlockingProgressBar();
            if (mSocialRegisterRequest != null) {
                performSocialSignIn();
            } else {
                mFragmentInteractionListener.loadFragment(getId(), SetPasswordFragment.create(mIsOrderPlaced, mPhoneNumber, otp),
                        null, R.anim.push_left_in, R.anim.fade_out,
                        BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
            }
        } else {
            FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.REGISTRATION_COMPLETE_EVENT);
            performSignIn();
        }
    }

    /**
     * Method requests for Social Log In;If success, updates the cart count
     */
    private void performSocialSignIn() {
        hide_keyboard(getActivity(), mEnteredOTP);
        mFragmentInteractionListener.showBlockingProgressBar();

        ApiSocialLogin.Request socialLoginRequest = new ApiSocialLogin.Request();
        ApiSocialLogin.User socialLogInUser = new ApiSocialLogin.User();
        socialLogInUser.setSocial_auth_token(mSocialRegisterRequest.getUser().getSocial_auth_token());
        socialLogInUser.setSocial_login_uid(mSocialRegisterRequest.getUser().getSocial_login_uid());
        socialLogInUser.setSocial_login_provider(mSocialRegisterRequest.getUser().getSocial_login_provider());
        socialLogInUser.setToken(PreferenceUtils.getStringFromSharedPreference(
                FrankRossApplication.getFrankrossApplicationContext(), PreferenceUtils.PREFERENCE_KEY_GCM_TOKEN));
        socialLoginRequest.setUser(socialLogInUser);

        mApiRequestManager.performSocialLoginRequest(socialLoginRequest, new ApiRequestManager.ISocialLoginResultNotifier() {
            @Override
            public void onSocialLoginSuccess(String accessToken) {
                FrankRossAnalytics.getFrankRossTracker().logEvent(mSocialRegisterRequest.getUser().getSocial_login_provider().
                        equalsIgnoreCase(getString(R.string.log_in_facebook)) ?
                        FrankRossEvents.SOCIAL_SIGNIN_FACEBOOK_SUCCESS_EVENT
                        : FrankRossEvents.SOCIAL_SIGNIN_GOOGLE_SUCCESS_EVENT);
                mFragmentInteractionListener.hideBlockingProgressBar();

                PreferenceUtils.saveStringIntoSharedPreference(getActivity().getApplicationContext(),
                        PreferenceUtils.PREFERENCE_KEY_ACCESS_TOKEN, accessToken);

                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
            }

            @Override
            public void onSocialNewUserLoginError(String message) {
                mFragmentInteractionListener.hideBlockingProgressBar();
                showAlert(message);
            }

            @Override
            public void onSocialNewUserOtpError(String phoneNumber) {
                mFragmentInteractionListener.hideBlockingProgressBar();
            }

            @Override
            public void onSocialLoginError(String message) {
                mFragmentInteractionListener.hideBlockingProgressBar();
                showAlert(message);
            }
        }, this, this);
    }

    /**
     * Method requests for Sign In;If success, notifies parent for action
     */
    private void performSignIn() {
        mApiRequestManager.performLoginRequest(mPhoneNumber, mUserPassword, new ApiRequestManager.ILoginResultNotifier() {
            @Override
            public void onLoginCompleted(String accessToken) {
                if (getActivity() != null) {
                    mFragmentInteractionListener.hideBlockingProgressBar();

                    PreferenceUtils.saveStringIntoSharedPreference(getActivity().getApplicationContext(),
                            PreferenceUtils.PREFERENCE_KEY_ACCESS_TOKEN, accessToken);

                    getActivity().setResult(Activity.RESULT_OK);
                    getActivity().finish();
                }
            }
        }, this, this);
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        //FrankRossAnalytics.getFrankRossTracker().logTimedEvent(FrankRossEvents.TIME_SPENT_OTP_SCREEN_EVENT, null);
    }

    @Override
    public void onStop() {
        super.onStop();
        //FrankRossAnalytics.getFrankRossTracker().endTimedEvent(FrankRossEvents.TIME_SPENT_OTP_SCREEN_EVENT, null);
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public void onDestroy() {
        unRegisterOtpAutoReadProcess();
        super.onDestroy();
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_enter_otp);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    @Override
    public void onChangeNumber(final String newNumber) {
        mFragmentInteractionListener.showBlockingProgressBar();
        if (TextUtils.isEmpty(mUserPassword) && mSocialRegisterRequest != null) {
            mApiRequestManager.performChangeNumberForSocialUserRequest(mSocialRegisterRequest.getUser().getSocial_login_uid(),
                    mSocialRegisterRequest.getUser().getSocial_auth_token(),
                    mSocialRegisterRequest.getUser().getSocial_login_provider(), newNumber,
                    new ApiRequestManager.IChangeNumberResultNotifier() {
                        @Override
                        public void onNumberChanged() {
                            performReSendOTP(newNumber);
                        }
                    }, this, this);
        } else {
            mApiRequestManager.performChangeNumberRequest(mUserMail, mUserPassword, newNumber,
                    new ApiRequestManager.IChangeNumberResultNotifier() {
                        @Override
                        public void onNumberChanged() {
                            performReSendOTP(newNumber);
                        }
                    }, this, this);
        }
    }

    /**
     * Method that receives the callback after the successful read of OTP
     *
     * @param otpCode the otp code that is read from the authorized message
     */
    @Override
    public void onOtpReceived(String otpCode) {
        unregisterOtpAutoReadListener();
        mAutoReadOtp = otpCode;
        mEnteredOTP.setText(otpCode);
        performOTPSubmit();
    }

    /**
     * Method that receives the callback when the OTP could not be read from the message
     */
    @Override
    public void onOtpReadError() {
        unregisterOtpAutoReadListener();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode) {
            case AppRuntimePermissionsManager.REQUEST_CODE_OTP_AUTO_READ_PERMISSIONS:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    registerListeners();
                } else {
                    unregisterOtpAutoReadListener();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
