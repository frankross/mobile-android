/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.cart;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.widget.Toast;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.Address;
import com.emamifrankross.frankross.ui.account.login.LogInActivity;
import com.emamifrankross.frankross.ui.adapters.AccountAdapter;
import com.emamifrankross.frankross.ui.adapters.CheckOutDeliverySlotAdapter;
import com.emamifrankross.frankross.ui.checkout.CheckOutDeliveryAddressFragment;
import com.emamifrankross.frankross.ui.checkout.CheckOutDeliverySlotFragment;
import com.emamifrankross.frankross.ui.checkout.CheckOutSummaryFragment;
import com.emamifrankross.frankross.ui.checkout.ICheckOutAddressNotifier;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.order.OrderRevisedFragment;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Utils;

import java.util.List;

/**
 * Created by gauthami on 22/7/15.
 */

/**
 * This class manages the Cart flow fragment transactions based on the intents and its data
 */
public class CartActivity extends BaseActivity implements CheckOutDeliverySlotFragment.ICheckoutDeliverySlotNotifier,
        ICheckOutAddressNotifier {

    public static final String CART_FRAGMENT_ID = "001";
    public static final String REVISED_ORDER_FRAGMENT_ID = "002";
    public static final String CART_PREPARED_FRAGMENT_ID = "003";
    public static final String REVISED_CART_FRAGMENT_ID = "004";

    private static final String BUNDLE_KEY_DOCTOR_NAME = "doctorName";
    private static final String BUNDLE_KEY_PATIENT_NAME = "patientName";

    private static final String EXTRA_FRAGMENT_ID = "fragment_id";
    private static final String EXTRA_REVISED_ORDER_ID = "order_id";
    private static final String EXTRA_REVISED_CART_ADDRESS_ID = "address_id";
    private static final String EXTRA_REVISED_CART_DELIVERY_SLOT_ID = "delivery_slot_id";
    private static final String EXTRA_REVISED_CART_PRESCRIPTION_ID = "prescription_id";

    private String doctorName = "";
    private String patientName = "";
    private Toast mToast;

    public static Intent getActivityIntent(Context appContext, String fragmentId) {
        Intent intent = new Intent(appContext, CartActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);

        return intent;
    }

    /**
     * Method to launch Revised Order screen
     *
     * @param doctorName     the doctor name if any;for that order
     * @param patientName    the patient name if any;for that order
     * @param appContext     the application context
     * @param revisedOrderId the Order id for the order to be revised
     * @return the intent associated with the Revise order fragment
     */
    public static Intent getActivityIntentForRevisedOrder(String doctorName, String patientName,
                                                          Context appContext, long revisedOrderId) {
        Intent intent = new Intent(appContext, CartActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, REVISED_ORDER_FRAGMENT_ID);
        intent.putExtra(EXTRA_REVISED_ORDER_ID, revisedOrderId);
        intent.putExtra(BUNDLE_KEY_DOCTOR_NAME, doctorName);
        intent.putExtra(BUNDLE_KEY_PATIENT_NAME, patientName);

        return intent;
    }

    /**
     * Method to launch the Revised Cart screen
     *
     * @param appContext     the application context
     * @param orderId        the order id
     * @param doctorName     the doctor name if any;for that order
     * @param patientName    the patient name if any;for that order
     * @param addressId      the address Id of the previously selected address
     * @param deliverySlotId the delivery slot Id of the previously selected address
     * @param prescriptionId the prescription id for the order      @return
     */
    public static Intent getActivityIntentForRevisedCart(Context appContext, long orderId, String doctorName, String patientName,
                                                         long addressId, long deliverySlotId, long prescriptionId) {
        Intent intent = new Intent(appContext, CartActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, REVISED_CART_FRAGMENT_ID);
        intent.putExtra(EXTRA_REVISED_ORDER_ID, orderId);
        intent.putExtra(EXTRA_REVISED_CART_ADDRESS_ID, addressId);
        intent.putExtra(EXTRA_REVISED_CART_DELIVERY_SLOT_ID, deliverySlotId);
        intent.putExtra(EXTRA_REVISED_CART_PRESCRIPTION_ID, prescriptionId);
        intent.putExtra(BUNDLE_KEY_DOCTOR_NAME, doctorName);
        intent.putExtra(BUNDLE_KEY_PATIENT_NAME, patientName);

        return intent;
    }

    /**
     * Method to launch the Cart screen
     *
     * @param doctorName  the doctor name if any;for that order
     * @param patientName the patient name if any;for that order
     * @param appContext  the application context
     * @return the intent associated with the Cart fragment with doctor/patient details
     */
    public static Intent getActivityIntentForPatientDetails(String doctorName, String patientName, Context appContext) {
        Intent intent = new Intent(appContext, CartActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, CART_FRAGMENT_ID);
        intent.putExtra(BUNDLE_KEY_DOCTOR_NAME, doctorName);
        intent.putExtra(BUNDLE_KEY_PATIENT_NAME, patientName);

        return intent;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getIntentsAndLoadFragment(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);

        getIntentsAndLoadFragment(intent);
    }

    private void getIntentsAndLoadFragment(Intent intent) {
        if (intent != null) {
            String fragmentId = intent.getStringExtra(EXTRA_FRAGMENT_ID);
            doctorName = intent.getStringExtra(BUNDLE_KEY_DOCTOR_NAME);
            patientName = intent.getStringExtra(BUNDLE_KEY_PATIENT_NAME);

            initFragment(fragmentId);
        }
    }

    /**
     * Method that initializes the fragment to this activity
     *
     * @param fragmentId determines which fragment to be initialized
     */
    private void initFragment(String fragmentId) {
        long orderId;
        if (!TextUtils.isEmpty(fragmentId)) {
            switch (fragmentId) {
                case CART_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(), CartFragment.create(doctorName, patientName), null,
                            R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.ADD);
                    break;

                case REVISED_ORDER_FRAGMENT_ID:
                    orderId = getIntent().getLongExtra(EXTRA_REVISED_ORDER_ID, -1l);
                    loadFragment(getFragmentContainerId(), OrderRevisedFragment.create(doctorName, patientName, orderId), null,
                            R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.ADD);
                    break;

                case CART_PREPARED_FRAGMENT_ID:
                    if (Utils.isLoggedIn(getApplicationContext())) {
                        loadFragment(getFragmentContainerId(), CartFragment.create(doctorName, patientName), null,
                                R.anim.push_left_in, R.anim.push_left_out,
                                BaseFragment.FragmentTransactionType.ADD);
                    } else {
                        startActivityForResult(LogInActivity.getActivityIntent(getApplicationContext(), false,
                                LogInActivity.LOG_IN_FRAGMENT), Constants.REQUEST_CODE_FOR_LOGIN);
                    }
                    break;

                case REVISED_CART_FRAGMENT_ID:
                    orderId = getIntent().getLongExtra(EXTRA_REVISED_ORDER_ID, -1l);
                    long addressId = getIntent().getLongExtra(EXTRA_REVISED_CART_ADDRESS_ID, -1l);
                    long deliverySlotId = getIntent().getLongExtra(EXTRA_REVISED_CART_DELIVERY_SLOT_ID, -1l);
                    long prescriptionId = getIntent().getLongExtra(EXTRA_REVISED_CART_PRESCRIPTION_ID, -1l);
                    loadFragment(getFragmentContainerId(), CartRevisedFragment.create(orderId,
                            doctorName, patientName, addressId, deliverySlotId, prescriptionId),
                            null, R.anim.push_left_in, R.anim.fade_out,
                            BaseFragment.FragmentTransactionType.ADD);
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
         /*
           Launch the Cart screen after the successful log in
         */
        if (requestCode == Constants.REQUEST_CODE_FOR_LOGIN) {
            if (resultCode == RESULT_OK) {
                setResult(RESULT_OK);
                loadFragment(getFragmentContainerId(), CartFragment.create(doctorName, patientName), null,
                        R.anim.push_left_in, R.anim.push_left_out,
                        BaseFragment.FragmentTransactionType.ADD);
            } else {
                finish();
            }
        }
    }

    @Override
    public void onBackPressed() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(getFragmentContainerId());

        if (fragment != null && fragment instanceof CheckOutSummaryFragment) {
            CheckOutSummaryFragment checkOutSummaryFragment = (CheckOutSummaryFragment) fragment;
            if (checkOutSummaryFragment.getCanGoBackBoolean()) {
                hideBlockingProgressBar();
                super.onBackPressed();
            } else {
                showAToast(getString(R.string.cart_checkout_back_press_toast_message));
            }
        } else {
            hideBlockingProgressBar();
            super.onBackPressed();
        }
    }

    /**
     * <strong>public void showAToast (String st)</strong></br>
     * this little method displays a mToast on the screen.</br>
     * it checks if a mToast is currently visible</br>
     * if so </br>
     * ... it "sets" the new text</br>
     * else</br>
     * ... it "makes" the new text</br>
     * and "shows" either or
     *
     * @param toastMessage the string to be toasted
     */

    public void showAToast(String toastMessage) {
        try {
            mToast.getView().isShown();     // true if visible
            mToast.setText(toastMessage);
        } catch (Exception e) {         // invisible if exception
            mToast = Toast.makeText(getApplicationContext(), toastMessage, Toast.LENGTH_SHORT);
        }
        mToast.show();  //finally display it
    }


    /**
     * Method that receives the callback for Delivery address selection
     *
     * @param address the selected delivery address
     */
    @Override
    public void onAddressSelect(AccountAdapter.AccountAddressItem address) {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(CheckOutDeliveryAddressFragment.TAG);
        if (fragment != null && fragment instanceof CheckOutDeliveryAddressFragment) {
            ((CheckOutDeliveryAddressFragment) fragment).onAddressSelect(address);
        }
    }

    /**
     * Method that receives the callback for address list refresh
     *
     * @param uiAddressList the selected delivery address list mapped for UI
     * @param addressList   the delivery  address list
     */
    @Override
    public void onAddressListRefresh(List<AccountAdapter.AccountAddressItem> uiAddressList, List<Address> addressList) {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(CheckOutDeliveryAddressFragment.TAG);
        if (fragment != null && fragment instanceof CheckOutDeliveryAddressFragment) {
            ((CheckOutDeliveryAddressFragment) fragment).onAddressListRefreshed(uiAddressList, addressList);
        }
    }

    /**
     * Method that receives the callback for Delivery slot selection
     *
     * @param deliverySlot the delivery slot that was selected
     */
    @Override
    public void onDeliverySlotSelect(CheckOutDeliverySlotAdapter.CheckOutDeliverySlotTimeDataItem deliverySlot) {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(CheckOutDeliveryAddressFragment.TAG);
        if (fragment != null && fragment instanceof CheckOutDeliveryAddressFragment) {
            ((CheckOutDeliveryAddressFragment) fragment).onDeliverySlotSelect(deliverySlot);
        }
    }
}
