/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 22/9/15.
 */
public class ApiStatus {

    public final static String STATUS_DEPRECATED = "EFR:Err:API:DEPRECATED";
    public final static String STATUS_DISCONTINUED = "EFR:Err:API:DISCONTINUED";
    public final static String STATUS_LIVE = "Live";

    public static class Response {

        @SerializedName("status")
        public String mStatus = "";
    }
}
