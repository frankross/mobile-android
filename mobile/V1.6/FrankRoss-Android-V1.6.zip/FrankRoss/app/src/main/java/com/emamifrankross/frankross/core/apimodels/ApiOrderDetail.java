/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 11/8/15.
 */
public class ApiOrderDetail {

    public static class Response {

        private List<BaseRecyclerAdapter.IViewType> uiDataList = new ArrayList<>(1);
        private List<OrderDetails.OrderProductItem> productList = new ArrayList<>(1);

        private String doctorName = "";

        private String patientName = "";

        @SerializedName("order")
        private OrderDetails orderDetails;

        public OrderDetails getOrderDetails() {
            return orderDetails;
        }

        public void setOrderDetails(OrderDetails orderDetails) {
            this.orderDetails = orderDetails;
        }

        public List<BaseRecyclerAdapter.IViewType> getUiDataList() {
            return uiDataList;
        }

        public void setUiDataList(List<BaseRecyclerAdapter.IViewType> uiDataList,
                                  List<OrderDetails.OrderProductItem> orderProductItems) {
            this.uiDataList = uiDataList;
            setProductList(orderProductItems);
        }

        public List<OrderDetails.OrderProductItem> getProductList() {
            return productList;
        }

        public void setProductList(List<OrderDetails.OrderProductItem> productList) {
            this.productList = productList;
        }

        public String getDoctorName() {
            return doctorName;
        }

        public void setDoctorName(String doctorName) {
            this.doctorName = doctorName;
        }

        public String getPatientName() {
            return patientName;
        }

        public void setPatientName(String patientName) {
            this.patientName = patientName;
        }
    }

}
