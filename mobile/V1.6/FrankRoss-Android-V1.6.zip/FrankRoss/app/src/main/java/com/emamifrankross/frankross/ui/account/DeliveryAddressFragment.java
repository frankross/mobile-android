/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.account;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.Address;
import com.emamifrankross.frankross.core.apimodels.ApiAddress;
import com.emamifrankross.frankross.core.apimodels.ApiLocation;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.LocationChooserAdapter;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 7/7/15.
 */

/**
 * This class represents the UI for create/add new delivery address screen
 */
public class DeliveryAddressFragment extends ApiRequestBaseFragment implements IToolbar, View.OnClickListener,
        AdapterView.OnItemSelectedListener {

    private List<ApiLocation.Area> mAreaList;
    private Address mApiAddress;

    private EditText mName;
    private EditText mFullAddressLine1;
    private EditText mFullAddressLine2;
    private EditText mLandmark;
    private EditText mCity;
    private EditText mPinCode;
    private EditText mPhone;
    //  private Spinner mTag;

    private boolean mUpdateAddress;
    private String mTagTxt;


    /**
     * Method to create an instance of Add address fragment
     */
    public static DeliveryAddressFragment createAddAddress() {
        DeliveryAddressFragment addNewDeliveryAddressFragment = new DeliveryAddressFragment();
        addNewDeliveryAddressFragment.setAddress(new Address(), false);

        return addNewDeliveryAddressFragment;
    }

    /**
     * Method to create an instance of Update address fragment
     */
    public static DeliveryAddressFragment createUpdateAddress(Address updateAddress) {
        DeliveryAddressFragment addNewDeliveryAddressFragment = new DeliveryAddressFragment();
        addNewDeliveryAddressFragment.setAddress(updateAddress, true);

        return addNewDeliveryAddressFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAreaList = new ArrayList<>(1);
        //To avoid the scenario : When launching the screen the first edit text gets the focus and opens the keyboard
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }

    public void setAddress(Address address, boolean isUpdate) {
        mUpdateAddress = isUpdate;
        mApiAddress = address;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_add_new_delivery_address, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        getLocations();
        if (mUpdateAddress) {
            setData();
        } else {
            FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ADD_ADDRESS_SCREEN_VISIT_EVENT);
        }
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the views
     *
     * @param view the root view
     */
    private void initViews(View view) {
        mName = (EditText) view.findViewById(R.id.add_new_delivery_address_name_et);
        mFullAddressLine1 = (EditText) view.findViewById(R.id.add_new_delivery_address_add_line1_et);
        mFullAddressLine2 = (EditText) view.findViewById(R.id.add_new_delivery_address_add_line2_et);
        mLandmark = (EditText) view.findViewById(R.id.add_new_delivery_address_landmark_et);
        mCity = (EditText) view.findViewById(R.id.add_new_delivery_address_city_tv);
        mPinCode = (EditText) view.findViewById(R.id.add_new_delivery_address_pin_code_et);
        mPhone = (EditText) view.findViewById(R.id.add_new_delivery_address_phone_et);
        Button doneButton = (Button) view.findViewById(R.id.add_new_delivery_address_done_btn);
        /*mTag = (Spinner) view.findViewById(R.id.add_new_delivery_address_tag_spinner);

        ArrayAdapter spinnerAdapter = ArrayAdapter.createFromResource(getActivity(),
                R.array.tag_list, R.layout.custom_spinner_item);
        mTag.setAdapter(spinnerAdapter);
        mTag.setOnItemSelectedListener(this);*/
        doneButton.setOnClickListener(this);

        mName.setText(Utils.getUserName(getActivity()));
        mPhone.setText(Utils.getUseMobileNumber(getActivity()));

        if (!TextUtils.isEmpty(Utils.getUserName(getActivity()))) {
            mName.setSelection(Utils.getUserName(getActivity()).length());
        }

        if (!TextUtils.isEmpty(Utils.getUseMobileNumber(getActivity()))) {
            mPhone.setSelection(Utils.getUseMobileNumber(getActivity()).length());
        }
    }

    /**
     * Method that auto fills the user address details in case of Update address
     */
    private void setData() {
        mName.setText(mApiAddress.getFullName());
        mFullAddressLine1.setText(mApiAddress.getAddressLine1());
        mFullAddressLine2.setText(mApiAddress.getAddressLine2());
        mLandmark.setText(mApiAddress.getLandmark());
        mPinCode.setText(mApiAddress.getPincode());
        mCity.setText(mApiAddress.getCity().getName());
        mPhone.setText(mApiAddress.getPhoneNumber());

        if (mApiAddress != null && !TextUtils.isEmpty(mApiAddress.getFullName())) {
            mName.setSelection(mApiAddress.getFullName().length());
        }

        if (mApiAddress != null && !TextUtils.isEmpty(mApiAddress.getAddressLine1())) {
            mFullAddressLine1.setSelection(mApiAddress.getAddressLine1().length());
        }

        if (mApiAddress != null && !TextUtils.isEmpty(mApiAddress.getAddressLine2())) {
            mFullAddressLine2.setSelection(mApiAddress.getAddressLine2().length());
        }

        if (mApiAddress != null && !TextUtils.isEmpty(mApiAddress.getLandmark())) {
            mLandmark.setSelection(mApiAddress.getLandmark().length());
        }

        if (mApiAddress != null && !TextUtils.isEmpty(mApiAddress.getPincode())) {
            mPinCode.setSelection(mApiAddress.getPincode().length());
        }

        if (mApiAddress != null && !TextUtils.isEmpty(mApiAddress.getCity().getName())) {
            mCity.setSelection(mApiAddress.getCity().getName().length());
        }

        if (mApiAddress != null && !TextUtils.isEmpty(mApiAddress.getPhoneNumber())) {
            mPhone.setSelection(mApiAddress.getPhoneNumber().length());
        }

       /* if (!TextUtils.isEmpty(mApiAddress.getAddressType())) {
            if (mApiAddress.getAddressType().contains("home")) {
                mTag.setSelection(0);
            } else if (mApiAddress.getAddressType().contains("office")) {
                mTag.setSelection(1);
            } else {
                mTag.setSelection(2);
            }
        }*/
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
       /* RobotoTextView spinnerText = (RobotoTextView) view.findViewById(R.id.spinner_text);
        if (position == 0) {
            spinnerText.setText("Tag (Home, Office)");
            spinnerText.setTextColor(getResources().getColor(R.color.sign_in_screen_edit_text_color));
        } else {
            mTagTxt = mTag.getSelectedItem().toString().toLowerCase();
            spinnerText.setTextColor(getResources().getColor(R.color.common_sub_header_text_color));
        }*/
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.add_new_delivery_address_done_btn:
                performAddOrUpdateDeliveryAddress();
                break;
        }
    }

    /**
     * Method gets location info to auto fill the area field
     */
    private void getLocations() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetLocationRequest(new ApiRequestManager.IGetLocationResultNotifier() {
            @Override
            public void onLocationFetched(List<LocationChooserAdapter.LocationChooserListItem> availableLocations, List<ApiLocation.Cities> cities) {
                mFragmentInteractionListener.hideBlockingProgressBar();
                if (availableLocations != null && cities != null) {
                    for (ApiLocation.Cities city : cities) {
                        if (city.getId() == (Utils.getLocationId(getActivity().getApplicationContext()))) {
                            if (city.getAreas() != null && city.getAreas().size() > 0) {
                                mAreaList = city.getAreas();
                                mCity.setText(Utils.getLocationName(getActivity()));
                                if (!TextUtils.isEmpty(Utils.getLocationName(getActivity()))) {
                                    mCity.setSelection(Utils.getLocationName(getActivity()).length());
                                }
                                //mPinCode.setText(city.getAreas().get(0).getPincode() + "");
                            } else {
                                showAlert("Current city doesn't have any delivery support");
                            }
                        }
                    }
                }
            }
        }, this, this);
    }

    /**
     * Method validates and checks the flow using a boolean
     */
    private void performAddOrUpdateDeliveryAddress() {
        String name = (mName.getText() != null) ? mName.getText().toString() : "";
        String fullAddressLine1 = (mFullAddressLine1.getText() != null) ? mFullAddressLine1.getText().toString() : "";
        String fullAddressLine2 = (mFullAddressLine2.getText() != null) ? mFullAddressLine2.getText().toString() : "";
        String landmark = (mLandmark.getText() != null) ? mLandmark.getText().toString() : "";
        String city = (mCity.getText() != null) ? mCity.getText().toString() : "";
        String pinCode = (mPinCode.getText() != null) ? mPinCode.getText().toString() : "";
        String phoneNumber = (mPhone.getText() != null) ? mPhone.getText().toString() : "";
        String tag = (mTagTxt != null) ? mTagTxt : "";

        if (validateData(name, fullAddressLine1, fullAddressLine2, city, pinCode)) {
            mFragmentInteractionListener.showBlockingProgressBar();

            mApiAddress.setFullName(name);
            mApiAddress.setAddressLine1(fullAddressLine1);
            mApiAddress.setAddressLine2(fullAddressLine2);
            mApiAddress.setLandmark(landmark);

            Address.City addressCity = new Address.City();

            mApiAddress.setCity(addressCity);
            mApiAddress.setPincode(pinCode);
            mApiAddress.setPhoneNumber(phoneNumber);
            mApiAddress.setAddressType(tag);

            ApiAddress.Request apiAddAddress = new ApiAddress.Request();
            apiAddAddress.setAddress(mApiAddress);

            if (mUpdateAddress) {
                performUpdateDeliveryAddress(apiAddAddress);
            } else {
                performAddNewDeliveryAddress(apiAddAddress);
            }
        }
    }

    /**
     * Method requests for Update address;If success, closes the fragment and notifies parent
     */
    private void performUpdateDeliveryAddress(ApiAddress.Request apiUpdateAddress) {
        mApiRequestManager.performUpdateAddressRequest(apiUpdateAddress, new ApiRequestManager.IUpdateAddressResultNotifier() {

            @Override
            public void onAddressUpdated() {
                mFragmentInteractionListener.hideBlockingProgressBar();
                showAlert(getString(R.string.update_address_success), new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                        getActivity().setResult(Activity.RESULT_OK);
                        closeFragment();
                    }
                }, true);
            }
        }, this, this);
    }

    /**
     * Method requests for Add new delivery address;If success, closes the fragment and notifies parent
     */
    private void performAddNewDeliveryAddress(ApiAddress.Request apiAddAddress) {
        mApiRequestManager.performAddAddressRequest(apiAddAddress, new ApiRequestManager.IAddAddressResultNotifier() {

            @Override
            public void onAddressAdded() {
                mFragmentInteractionListener.hideBlockingProgressBar();
                showAlert(getString(R.string.add_address_success), new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                        getActivity().setResult(Activity.RESULT_OK);
                        closeFragment();
                    }
                }, true);
            }
        }, this, this);
    }

    /**
     * @return If false,displays the input or network error dialog with appropriate message;else true.
     */
    private boolean validateData(String name, String fullAddressLine1, String fullAddressLine2,
                                 String city, String pinCode) {
        int areaId = getAreaId(pinCode);
        if (TextUtils.isEmpty(name)) {
            showAlert(getString(R.string.add_address_please_enter_name));
        } else if (TextUtils.isEmpty(fullAddressLine1)) {
            showAlert(getString(R.string.add_address_please_enter_address_line1));
        } else if (TextUtils.isEmpty(fullAddressLine2)) {
            showAlert(getString(R.string.add_address_please_enter_address_line2));
        } else if (TextUtils.isEmpty(city)) {
            showAlert(getString(R.string.add_address_please_enter_city));
        } else if (TextUtils.isEmpty(pinCode)) {
            showAlert(getString(R.string.add_address_please_enter_pincode));
        } else if (areaId == -1) {
            showAlert(getString(R.string.add_address_area_not_available));
        } else {
            mApiAddress.setAreaId(areaId);
            return true;
        }

        return false;
    }

    /**
     * Method gets the areaId of particular pin code
     *
     * @param pinCode the pin code of the area selected or entered by the user
     * @return the areaId of the pin code
     */
    private int getAreaId(String pinCode) {
        for (ApiLocation.Area area : mAreaList) {
            if (area.getPincode() == (TextUtils.isEmpty(pinCode) ? 0 : Integer.parseInt(pinCode))) {
                return area.getId();
            }
        }
        return -1;
    }

    protected void showAlert(String alertMessage, AlertDialogFragment.AlertPositiveActionListener clickListener,
                             boolean isCancelable) {
        mFragmentInteractionListener.showAlert(null, alertMessage, getString(R.string.ok), null, clickListener, null, isCancelable);
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_add_address);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }
}
