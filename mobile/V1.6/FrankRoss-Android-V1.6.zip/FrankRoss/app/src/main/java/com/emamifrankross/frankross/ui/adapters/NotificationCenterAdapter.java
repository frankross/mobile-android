/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.LinearLayout;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.customviews.VolleySingleton;
import com.emamifrankross.frankross.ui.viewmodels.CommonRecyclerHeaderViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderDataBinder;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 17/10/16.
 * <p> Adapter class for Notifications Screen</p>
 * <p> Supports the Seven View Types </p>
 * <p> 1 : OFFER ITEM VIEW TYPE </p>
 * <p> 2 : BACK IN STOCK ITEM VIEW TYPE </p>
 * <p> 3 : GENERIC NOTIFICATION ITEM VIEW TYPE </p>
 * <p> 4 : EMPTY ITEM VIEW TYPE </p>
 * <p> 5 : PRODUCT DETAIL VIEW TYPE </p>
 * <p> 6 : COMMON HERDER VIEW TYPE </p>
 * <p> 7 : COMMON BORDER VIEW TYPE </p>
 */
public class NotificationCenterAdapter extends BaseRecyclerAdapter {

    public NotificationCenterAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewHolderTypeList = new ArrayList<>(1);
        viewHolderTypeList.add(new NotificationsOfferItemViewHolderType());
        viewHolderTypeList.add(new RecyclerBorderDataBinder());
        viewHolderTypeList.add(new NotificationsBackInStockViewHolderType());
        viewHolderTypeList.add(new NotificationsDefaultViewHolderType());
        viewHolderTypeList.add(new CommonRecyclerHeaderViewDataBinder());
        viewHolderTypeList.add(new EmptyNotificationsViewHolderType());
        viewHolderTypeList.add(new NotificationsProductDetailViewHolderType());

        return viewHolderTypeList;
    }

    /**
     * OFFER ITEM VIEW TYPE
     */
    public static class NotificationsOfferDataItem implements IViewType {

        public int notificationId = 0;
        public int notificationType = 0;

        public String notificationImageUrl = "";
        public String notificationPromoCode = "";
        public String notificationWebUrl = "";
        public String notificationTitle = "";
        public String notificationSubTitle = "";
        public String notificationDate = "";

        public long variantId = 0;
        public long categoryId = 0;
        public long orderId = 0;
        public long prescriptionId = 0;
        public long promotionId = 0;

        public boolean isPharma = false;
        public boolean isRead = false;

        @Override
        public int getViewType() {
            return ViewTypes.NotificationCenterViewType.NOTIFICATION_OFFER_ITEM_VIEW_TYPE;
        }
    }

    private static class NotificationsOfferItemViewHolder extends RecyclerView.ViewHolder {

        private LinearLayout mOfferItemLinLyt;
        private NetworkImageView mOfferImage;

        public NotificationsOfferItemViewHolder(View itemView) {
            super(itemView);
            mOfferItemLinLyt = (LinearLayout) itemView.findViewById(R.id.offers_item_background_linLyt);
            mOfferImage = (NetworkImageView) itemView.findViewById(R.id.offer_image_iv);

            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (int) (0.23 * Utils.getDisplayHeight((Activity) mOfferImage.getContext())));
            mOfferImage.setLayoutParams(layoutParams);
        }
    }

    private static class NotificationsOfferItemViewHolderType implements
            RecyclerViewDataBinder<NotificationsOfferItemViewHolder, NotificationsOfferDataItem> {

        @Override
        public NotificationsOfferItemViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.offers_list_item, parent, false);

            return new NotificationsOfferItemViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(NotificationsOfferItemViewHolder viewHolder,
                                         final NotificationsOfferDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {

            ImageLoader imageLoader = VolleySingleton.getInstance(viewHolder.mOfferImage.getContext()).getImageLoader();
            viewHolder.mOfferImage.setImageUrl(data.notificationImageUrl, imageLoader);
            viewHolder.mOfferImage.setDefaultImageResId(R.drawable.pdp_placeholder);
            viewHolder.mOfferImage.setErrorImageResId(R.drawable.pdp_placeholder);
            Animation fadeInAnimation = AnimationUtils.loadAnimation(viewHolder.mOfferImage.getContext(), R.anim.fade_in);
            viewHolder.mOfferImage.startAnimation(fadeInAnimation);

            if (recyclerViewClickListener != null) {
                viewHolder.mOfferItemLinLyt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.NotificationCenterViewType.NOTIFICATION_OFFER_ITEM_VIEW_TYPE;
        }
    }

    /**
     * GENERIC NOTIFICATION ITEM VIEW TYPE
     */
    public static class NotificationsDefaultDataItem implements IViewType {

        public int notificationId = 0;
        public int notificationType = 0;

        public String notificationImageUrl = "";
        public String notificationPromoCode = "";
        public String notificationWebUrl = "";
        public String notificationTitle = "";
        public String notificationSubTitle = "";
        public String notificationDate = "";

        public long variantId = 0;
        public long categoryId = 0;
        public long orderId = 0;
        public long prescriptionId = 0;
        public long promotionId = 0;

        public boolean isPharma = false;
        public boolean isRead = false;

        @Override
        public int getViewType() {
            return ViewTypes.NotificationCenterViewType.NOTIFICATION_DEFAULT_ITEM_VIEW_TYPE;
        }
    }

    public static class NotificationsDefaultViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mSubTitle;
        private RobotoTextView mTitle;
        private RobotoTextView mDate;
        private NetworkImageView mIcon;
        private LinearLayout mNotificationLinLyt;

        public NotificationsDefaultViewHolder(View view) {
            super(view);
            mTitle = (RobotoTextView) view.findViewById(R.id.notification_title_tv);
            mIcon = (NetworkImageView) view.findViewById(R.id.notification_icon_iv);
            mNotificationLinLyt = (LinearLayout) view.findViewById(R.id.notification_linLyt);
            mSubTitle = (RobotoTextView) view.findViewById(R.id.notification_sub_title_tv);
            mDate = (RobotoTextView) view.findViewById(R.id.notification_date_tv);
        }
    }

    private class NotificationsDefaultViewHolderType implements RecyclerViewDataBinder<NotificationsDefaultViewHolder,
            NotificationsDefaultDataItem> {
        @Override
        public NotificationsDefaultViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notification_default_item, parent, false);
            return new NotificationsDefaultViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(NotificationsDefaultViewHolder viewHolder, final NotificationsDefaultDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mTitle.setText(data.notificationTitle);
            viewHolder.mSubTitle.setText(data.notificationSubTitle);
            viewHolder.mDate.setText(data.notificationDate);

            viewHolder.mIcon.setDefaultImageResId(R.drawable.product_logo);
            viewHolder.mIcon.setErrorImageResId(R.drawable.product_logo);

            Context context = viewHolder.mNotificationLinLyt.getContext();
            viewHolder.mNotificationLinLyt.setBackgroundColor(
                    ContextCompat.getColor(context, data.isRead ? R.color.background_darker_grey :
                            R.color.notification_center_read_text_color));

            if (!TextUtils.isEmpty(data.notificationImageUrl)) {
                viewHolder.mIcon.setVisibility(View.VISIBLE);
                viewHolder.mIcon.setImageUrl(data.notificationImageUrl,
                        VolleySingleton.getInstance(viewHolder.mIcon.getContext()).getImageLoader());
            } else {
                viewHolder.mIcon.setVisibility(View.GONE);
            }

            if (recyclerViewClickListener != null) {
                viewHolder.mNotificationLinLyt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.NotificationCenterViewType.NOTIFICATION_DEFAULT_ITEM_VIEW_TYPE;
        }
    }

    /**
     * EMPTY VIEW TYPE - NO NOTIFICATIONS
     */
    public static class EmptyNotificationsDataItem implements IViewType {

        @Override
        public int getViewType() {
            return ViewTypes.NotificationCenterViewType.NOTIFICATION_EMPTY_ITEM_VIEW_TYPE;
        }
    }

    public static class EmptyNotificationsViewHolder extends RecyclerView.ViewHolder {

        private Button mContinueShoppingBtn;

        public EmptyNotificationsViewHolder(View view) {
            super(view);

            mContinueShoppingBtn = (Button) view.findViewById(R.id.notifications_continue_shopping_btn);
        }
    }

    private class EmptyNotificationsViewHolderType implements RecyclerViewDataBinder<EmptyNotificationsViewHolder,
            EmptyNotificationsDataItem> {
        @Override
        public EmptyNotificationsViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notifications_empty_item, parent, false);

            return new EmptyNotificationsViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(EmptyNotificationsViewHolder viewHolder, final EmptyNotificationsDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {

            if (recyclerViewClickListener != null) {
                viewHolder.mContinueShoppingBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        recyclerViewClickListener.onRecyclerItemClick(position, view, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.NotificationCenterViewType.NOTIFICATION_EMPTY_ITEM_VIEW_TYPE;
        }
    }

    /**
     * PDP ITEM VIEW TYPE
     */
    public static class NotificationsProductDetailDataItem implements IViewType {

        public int notificationId = 0;
        public int notificationType = 0;

        public String notificationImageUrl = "";
        public String notificationPromoCode = "";
        public String notificationWebUrl = "";
        public String notificationTitle = "";
        public String notificationSubTitle = "";
        public String notificationDate = "";

        public long variantId = 0;
        public long categoryId = 0;
        public long orderId = 0;
        public long prescriptionId = 0;
        public long promotionId = 0;

        public boolean isPharma = false;
        public boolean isRead = false;

        @Override
        public int getViewType() {
            return ViewTypes.NotificationCenterViewType.NOTIFICATION_PDP_ITEM_VIEW_TYPE;
        }
    }

    public static class NotificationsProductDetailViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mTitle;
        private RobotoTextView mMessage;
        private RobotoTextView mDate;
        private NetworkImageView mIcon;
        private LinearLayout mNotificationLinLyt;

        public NotificationsProductDetailViewHolder(View view) {
            super(view);
            mTitle = (RobotoTextView) view.findViewById(R.id.notifications_pdp_title_tv);
            mMessage = (RobotoTextView) view.findViewById(R.id.notifications_pdp_message_tv);
            mIcon = (NetworkImageView) view.findViewById(R.id.notifications_pdp_icon_iv);
            mNotificationLinLyt = (LinearLayout) view.findViewById(R.id.notificathions_pdp_item_background_linLyt);
            mDate = (RobotoTextView) view.findViewById(R.id.notification_pdp_date_tv);


            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (int) (0.23 * Utils.getDisplayHeight((Activity) mIcon.getContext())));
            mIcon.setLayoutParams(layoutParams);
        }
    }

    private class NotificationsProductDetailViewHolderType implements RecyclerViewDataBinder<NotificationsProductDetailViewHolder,
            NotificationsProductDetailDataItem> {
        @Override
        public NotificationsProductDetailViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notification_pdp_item, parent, false);
            return new NotificationsProductDetailViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(NotificationsProductDetailViewHolder viewHolder, final NotificationsProductDetailDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mTitle.setText(data.notificationTitle);
            viewHolder.mMessage.setText(data.notificationSubTitle);
            viewHolder.mDate.setText(data.notificationDate);

            Context context = viewHolder.mNotificationLinLyt.getContext();
            viewHolder.mNotificationLinLyt.setBackgroundColor(
                    ContextCompat.getColor(context, data.isRead ?
                            R.color.background_darker_grey : R.color.notification_center_read_text_color));

            if (!TextUtils.isEmpty(data.notificationImageUrl)) {
                viewHolder.mIcon.setImageUrl(data.notificationImageUrl,
                        VolleySingleton.getInstance(viewHolder.mIcon.getContext()).getImageLoader());
            }
            viewHolder.mIcon.setDefaultImageResId(R.drawable.product_logo);
            viewHolder.mIcon.setErrorImageResId(R.drawable.product_logo);

            if (recyclerViewClickListener != null) {
                viewHolder.mNotificationLinLyt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.NotificationCenterViewType.NOTIFICATION_PDP_ITEM_VIEW_TYPE;
        }
    }


    /**
     * BACK IN STOCK ITEM VIEW TYPE
     */
    public static class NotificationsBackInStockDataItem implements IViewType {

        public int notificationId = 0;
        public int notificationType = 0;

        public String notificationImageUrl = "";
        public String notificationPromoCode = "";
        public String notificationWebUrl = "";
        public String notificationTitle = "";
        public String notificationSubTitle = "";
        public String notificationDate = "";

        public long variantId = 0;
        public long categoryId = 0;
        public long orderId = 0;
        public long prescriptionId = 0;
        public long promotionId = 0;

        public boolean isPharma = false;

        public double productActualPrice = 0d;
        public double productOfferPrice = 0d;
        public boolean isRead = false;

        @Override
        public int getViewType() {
            return ViewTypes.NotificationCenterViewType.NOTIFICATION_BACK_IN_STOCK_ITEM_VIEW_TYPE;
        }
    }

    public static class NotificationsBackInStockViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mTitle;
        private RobotoTextView mDate;
        private NetworkImageView mIcon;
        private LinearLayout mNotificationLinLyt;
        private RobotoTextView mProductOfferPrice;
        private RobotoTextView mProductActualPrice;
        private RobotoTextView mProductAddToCart;
        private RobotoTextView mProductRemindLater;

        public NotificationsBackInStockViewHolder(View view) {
            super(view);
            mTitle = (RobotoTextView) view.findViewById(R.id.notification_title_tv);
            mIcon = (NetworkImageView) view.findViewById(R.id.notification_icon_iv);
            mNotificationLinLyt = (LinearLayout) view.findViewById(R.id.notification_linLyt);
            mDate = (RobotoTextView) view.findViewById(R.id.notification_date_tv);
            mProductOfferPrice = (RobotoTextView) view.findViewById(R.id.notification_product_offer_price_tv);
            mProductActualPrice = (RobotoTextView) view.findViewById(R.id.notification_product_actual_price_tv);
            mProductAddToCart = (RobotoTextView) view.findViewById(R.id.notification_product_add_to_cart_tv);
            mProductRemindLater = (RobotoTextView) view.findViewById(R.id.notification_product_remind_later_tv);
        }
    }

    private class NotificationsBackInStockViewHolderType implements RecyclerViewDataBinder<NotificationsBackInStockViewHolder,
            NotificationsBackInStockDataItem> {
        @Override
        public NotificationsBackInStockViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notification_back_in_stock_item, parent, false);
            return new NotificationsBackInStockViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(NotificationsBackInStockViewHolder viewHolder, final NotificationsBackInStockDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mTitle.setText(data.notificationTitle);
            viewHolder.mDate.setText(data.notificationDate);
            viewHolder.mProductActualPrice.setText(Utils.addRupeeSymbol(viewHolder.mProductActualPrice.getContext(), "",
                    Utils.getFormattedDouble(data.productActualPrice)));
            viewHolder.mProductOfferPrice.setText(Utils.addRupeeSymbol(viewHolder.mProductOfferPrice.getContext(), "",
                    Utils.getFormattedDouble(data.productOfferPrice)));

            Context context = viewHolder.mNotificationLinLyt.getContext();
            viewHolder.mNotificationLinLyt.setBackgroundColor(
                    ContextCompat.getColor(context, data.isRead ?
                            R.color.background_darker_grey : R.color.notification_center_read_text_color));

            if (!TextUtils.isEmpty(data.notificationImageUrl)) {
                viewHolder.mIcon.setImageUrl(data.notificationImageUrl,
                        VolleySingleton.getInstance(viewHolder.mIcon.getContext()).getImageLoader());
            }
            viewHolder.mIcon.setDefaultImageResId(R.drawable.product_logo);
            viewHolder.mIcon.setErrorImageResId(R.drawable.product_logo);

            if (recyclerViewClickListener != null) {
                viewHolder.mNotificationLinLyt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.NotificationCenterViewType.NOTIFICATION_BACK_IN_STOCK_ITEM_VIEW_TYPE;
        }
    }
}

