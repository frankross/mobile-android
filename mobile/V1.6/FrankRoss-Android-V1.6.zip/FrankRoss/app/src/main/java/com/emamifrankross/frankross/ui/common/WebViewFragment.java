/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.search.SearchActivity;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.IntentUtils;
import com.emamifrankross.frankross.utils.NetworkUtils;
import com.emamifrankross.frankross.utils.Utils;

import java.util.Map;

public class WebViewFragment extends ApiRequestBaseFragment implements IToolbar, View.OnClickListener {

    private static final String TAG = WebViewFragment.class.getName();
    private static final String URL = "url";
    private static final String TITLE = "title";
    private static final int TEL_PREFIX_INDEX = 4;

    private WebView mWebView;
    private String mUrl;
    private String mTitleName;
    private LinearLayout mSearchBarLinLyt;

    public WebViewFragment() {
    }

    public static WebViewFragment create(String url, String title) {
        WebViewFragment settingsWebViewFragment = new WebViewFragment();
        Bundle argumentsBundle = new Bundle();
        argumentsBundle.putString(URL, url);
        argumentsBundle.putString(TITLE, title);
        settingsWebViewFragment.setArguments(argumentsBundle);
        return settingsWebViewFragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_web_view, container, false);
        initViews(view);
        initWebView();
        return view;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            mUrl = bundle.getString(URL);
            mTitleName = bundle.getString(TITLE);
        }

        mToolbarInteractionListener.updateToolbar(this);
    }

    @Override
    public void onStart() {
        super.onStart();
        mApiRequestManager.registerCartCountChangeNotifier((BaseActivity) getActivity());
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        mApiRequestManager.unregisterCartCountChangeNotifier((BaseActivity) getActivity());
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    private void initWebView() {
        mSearchBarLinLyt.setVisibility((mTitleName.equals(getString(R.string.home_promotion_details)) ||
                mTitleName.equals(getString(R.string.drawer_menu_health_articles)) ||
                mTitleName.equals(getString(R.string.drawer_menu_emergency))) ? View.VISIBLE : View.GONE);
        mWebView.requestFocus(View.FOCUS_DOWN);
        if (Constants.ENABLE_DEBUG_LOG) {
            enableWebViewDebugging();
        }
        initSettings();
        if (NetworkUtils.isNetworkConnected(getActivity())) {
            mWebView.setWebViewClient(new FrankRossWebClient());
            if (!TextUtils.isEmpty(mUrl)) {
                mFragmentInteractionListener.showBlockingProgressBar();
                mWebView.loadUrl(mUrl);
            }
        } else {
            mFragmentInteractionListener.hideBlockingProgressBar();
            showAlert(getString(R.string.please_check_your_network_connection));
        }
    }

    private void initViews(View view) {
        mWebView = (WebView) view.findViewById(R.id.web_view);
        mSearchBarLinLyt = (LinearLayout) view.findViewById(R.id.search_result_search_linLay);
        mSearchBarLinLyt.setOnClickListener(this);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void initSettings() {
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.getSettings().setDomStorageEnabled(true);
        mWebView.getSettings().setAllowFileAccess(false);
        disablePluginState();
        disableContentAccess();
        disableFileAccessFromFileURLs();
        disableUniversalAccessFromFileUrls();
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void disableUniversalAccessFromFileUrls() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            mWebView.getSettings().setAllowUniversalAccessFromFileURLs(false);
        }
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    private void disableFileAccessFromFileURLs() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            mWebView.getSettings().setAllowFileAccessFromFileURLs(false);
        }
    }

    @SuppressWarnings("deprecation")
    private void disablePluginState() {
        mWebView.getSettings().setPluginState(WebSettings.PluginState.OFF);
    }

    @TargetApi(Build.VERSION_CODES.HONEYCOMB)
    private void disableContentAccess() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            mWebView.getSettings().setAllowContentAccess(false);
        }
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public void enableWebViewDebugging() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            WebView.setWebContentsDebuggingEnabled(true);
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.search_result_search_linLay:
                Map<String, String> searchBarClickData = Utils.categoriesClickDataForAnalytics(mTitleName,
                        FrankRossEvents.SEARCH_BAR_SCREEN_NAME_EVENT);
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_BAR_TAP_EVENT, searchBarClickData);
                loadSearchActivity();
                break;
            default:
                break;
        }
    }

    class FrankRossWebClient extends WebViewClient {

        /*@Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            mFragmentInteractionListener.hideBlockingProgressBar();
            Log.d(TAG, "onLoadResource url : " + url);
        }

        @Override
        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            handler.proceed(); // Ignore SSL certificate errors for now
        }

        @Override
        public void onLoadResource(WebView view, String url) {
            Log.d(TAG, "onLoadResource url : " + url);
            super.onLoadResource(view, url);
        }

        @Override
        public void onReceivedError(WebView view, int errorCode,
                                    String description, String failingUrl) {
            Log.d(TAG, "onReceivedError  errorCode : " + errorCode + "  description : " + description +
                    " failingUrl : " + failingUrl);
            super.onReceivedError(view, errorCode, description, failingUrl);

        }*/

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            mFragmentInteractionListener.showBlockingProgressBar();
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            mUrl = url;
            if (url.startsWith("tel:")) {
                showPopUp(url.substring(TEL_PREFIX_INDEX, url.length()));
                //view.reload();
            } else {
                mWebView.loadUrl(mUrl);
            }
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            mFragmentInteractionListener.hideBlockingProgressBar();
        }
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isAdded() && mTitleName.equals(getString(R.string.home_promotion_details))) {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    closeFragment();
                } else {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    getActivity().onBackPressed();
                }
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return mTitleName;
    }

    @Override
    public int getToolbarMenuId() {
        return (mTitleName.equals(getString(R.string.home_promotion_details)) ||
                mTitleName.equals(getString(R.string.drawer_menu_health_articles)) ||
                mTitleName.equals(getString(R.string.drawer_menu_emergency))) ?
                R.menu.menu_search_result : R.menu.menu_pharmacy;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_search:
                        loadSearchActivity();
                        break;

                    case R.id.action_cart:
                        loadCartActivity();
                        break;
                }
                return false;
            }
        };
    }


    /**
     * Method that displays a pop up to confirm the Call center call action
     */
    private void showPopUp(final String customerCareNumber) {
        mFragmentInteractionListener.showAlert(null, customerCareNumber,
                getString(R.string.call), getString(R.string.cancel),
                new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                        call(customerCareNumber);
                    }
                }, new AlertDialogFragment.AlertNegativeActionListener() {
                    @Override
                    public void onNegativeAction() {
                    }
                }, true);
    }

    /**
     * Method that performs the Telephonic call action
     * using standard Call intent
     *
     * @param customerCareNumber the customer care phone number
     */
    private void call(String customerCareNumber) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                AppRuntimePermissionsManager.checkPermissionForCall(getActivity())) {
            try {
                if (TextUtils.isEmpty(customerCareNumber)) return;
                customerCareNumber = customerCareNumber.trim();
                startActivity(IntentUtils.getCallIntent(customerCareNumber));
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SUPPORT_CALL_EVENT);
            } catch (SecurityException securityException) {

            }
        } else {
            this.requestPermissions(new String[]{Manifest.permission.CALL_PHONE},
                    AppRuntimePermissionsManager.REQUEST_CODE_CALL_PERMISSIONS);
        }
    }

    private void loadSearchActivity() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_FROM_TOOLBAR_EVENT);
        startActivity(new Intent(getActivity(), SearchActivity.class));
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    private void loadCartActivity() {
        Map<String, String> cartClickData = Utils.cartToolbarClickDataForAnalytics(mTitleName,
                FrankRossEvents.VIEW_CART_FROM_TOOLBAR_SCREEN_NAME);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_CART_FROM_TOOLBAR_EVENT, cartClickData);
        startActivity(CartActivity.getActivityIntent(getActivity().getApplicationContext(), CartActivity.CART_FRAGMENT_ID));
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

}
