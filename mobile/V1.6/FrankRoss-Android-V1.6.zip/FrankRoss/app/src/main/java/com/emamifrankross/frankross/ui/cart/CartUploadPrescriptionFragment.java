/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.cart;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.CartUploadPrescriptionAdapter;
import com.emamifrankross.frankross.ui.checkout.CheckOutDeliveryAddressFragment;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.prescription.uploadprescription.UploadPrescriptionActivity;
import com.emamifrankross.frankross.utils.Constants;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 21/7/15.
 */

/**
 * This class represents the UI for Upload prescription screen in Cart flow
 */
public class CartUploadPrescriptionFragment extends ApiRequestBaseFragment implements BaseRecyclerAdapter.RecyclerItemClickListener,
        IToolbar,
        View.OnClickListener {

    private static final int REQUEST_CODE_PRESCRIPTION_ID = 111;

    private static final String BUNDLE_KEY_ORDER_ID = "orderId";
    private static final String BUNDLE_KEY_ADDRESS_ID = "addressId";
    private static final String BUNDLE_KEY_DELIVERY_SLOT_ID = "deliveryId";
    private static final String BUNDLE_KEY_DOCTOR_NAME = "doctorName";
    private static final String BUNDLE_KEY_PATIENT_NAME = "patientName";

    private List<BaseRecyclerAdapter.IViewType> mCartUploadPrescriptionScreenData = new ArrayList<>();
    private CartUploadPrescriptionAdapter mCartUploadPrescriptionAdapter;
    private CheckOutDeliveryAddressFragment.CartFlow mCartFlow = CheckOutDeliveryAddressFragment.CartFlow.CART;

    private long mOrderId = -1;
    private long mAddressId = -1;
    private long mDeliverySlotId = -1;
    private long mPrescriptionId = -1;

    private String mPatientName = "";
    private String mDoctorName = "";

    public static CartUploadPrescriptionFragment create(String doctorName, String patientName,
                                                        long orderId, long addressId,
                                                        long deliverySlotId,
                                                        CheckOutDeliveryAddressFragment.CartFlow cartFlow) {
        CartUploadPrescriptionFragment fragment = new CartUploadPrescriptionFragment();

        Bundle bundle = new Bundle();
        bundle.putLong(BUNDLE_KEY_ORDER_ID, orderId);
        bundle.putLong(BUNDLE_KEY_ADDRESS_ID, addressId);
        bundle.putLong(BUNDLE_KEY_DELIVERY_SLOT_ID, deliverySlotId);

        bundle.putString(BUNDLE_KEY_DOCTOR_NAME, doctorName);
        bundle.putString(BUNDLE_KEY_PATIENT_NAME, patientName);

        fragment.setCartFlow(cartFlow);
        fragment.setArguments(bundle);
        return fragment;
    }

    public void setCartFlow(CheckOutDeliveryAddressFragment.CartFlow flow) {
        mCartFlow = flow;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();
        if (bundle != null) {
            mOrderId = bundle.getLong(BUNDLE_KEY_ORDER_ID);
            mAddressId = bundle.getLong(BUNDLE_KEY_ADDRESS_ID);
            mDeliverySlotId = bundle.getLong(BUNDLE_KEY_DELIVERY_SLOT_ID);

            mDoctorName = bundle.getString(BUNDLE_KEY_DOCTOR_NAME);
            mPatientName = bundle.getString(BUNDLE_KEY_PATIENT_NAME);
        }

        mCartUploadPrescriptionAdapter = new CartUploadPrescriptionAdapter(mCartUploadPrescriptionScreenData);
        getCartPrescriptionData();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cart_upload_prescription, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the Upload prescription for Cart items screen
     *
     * @param view the root view
     */
    private void initRecyclerView(View view) {
        RecyclerView homeRecyclerView = (RecyclerView) view.findViewById(R.id.cart_upload_prescription_recycler_view);
        homeRecyclerView.setHasFixedSize(false);
        homeRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mCartUploadPrescriptionAdapter.setRecyclerItemClickListener(this);
        homeRecyclerView.setAdapter(mCartUploadPrescriptionAdapter);
        Button uploadPrescriptionBtn = (Button) view.findViewById(R.id.cart_upload_prescription_bottom_btn);
        uploadPrescriptionBtn.setOnClickListener(this);
    }

    /**
     * Method gets the products in the cart that requires the prescription
     */
    private void getCartPrescriptionData() {
        ApiRequestManager.ICartUploadPrescriptionRequiredResultNotifier prescriptionRequiredResultNotifier = new ApiRequestManager.ICartUploadPrescriptionRequiredResultNotifier() {
            @Override
            public void onCartPrescriptionRequiredListFetched(List<BaseRecyclerAdapter.IViewType> uploadPrescriptionData) {
                mCartUploadPrescriptionScreenData.clear();
                mCartUploadPrescriptionScreenData.addAll(uploadPrescriptionData);
                mCartUploadPrescriptionAdapter.notifyDataSetChanged();
                mFragmentInteractionListener.hideBlockingProgressBar();
            }
        };

        if (mCartFlow != CheckOutDeliveryAddressFragment.CartFlow.REVISED_ORDER) {
            mApiRequestManager.getCartPrescriptionRequiredItems(prescriptionRequiredResultNotifier);
        } else {
            mApiRequestManager.getRevisedOrderPrescriptionRequiredItems(prescriptionRequiredResultNotifier);
        }
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {
            case ViewTypes.CartUploadPrescriptionViewType.CART_UPLOAD_PRESCRIPTION_VIEW_TYPE:
                break;
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.cart_upload_prescription_bottom_btn:
                startActivityForResult(UploadPrescriptionActivity.getActivityIntent(getActivity(), true, true),
                        REQUEST_CODE_PRESCRIPTION_ID);
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                break;
        }
    }


    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_cart_upload_prescription);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == getActivity().RESULT_OK && requestCode == REQUEST_CODE_PRESCRIPTION_ID) {
            if (data != null && data.hasExtra(Constants.INTENT_EXTRA_PRESCRIPTION_ID)) {
                mPrescriptionId = data.getLongExtra(Constants.INTENT_EXTRA_PRESCRIPTION_ID, -1);
                if (mPrescriptionId > 0) {
                    /*Proceed with the uploaded prescription id when Upload prescription is successful*/
                    mFragmentInteractionListener.loadFragment(getId(), CheckOutDeliveryAddressFragment.
                                    create(mDoctorName, mPatientName, mOrderId, mAddressId, mDeliverySlotId, mPrescriptionId, mCartFlow),
                            CheckOutDeliveryAddressFragment.TAG, R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                }
            }
        }
    }
}
