/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.cart;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Vibrator;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.account.login.LogInActivity;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.CartRecyclerAdapter;
import com.emamifrankross.frankross.ui.checkout.CheckOutDeliveryAddressFragment;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.ICartQuantityNotifier;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.home.HomeActivity;
import com.emamifrankross.frankross.ui.products.ProductDetailActivity;
import com.emamifrankross.frankross.ui.search.SearchActivity;
import com.emamifrankross.frankross.utils.NetworkUtils;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 21/7/15.
 */

/**
 * This class represents the UI for Cart screen of a user
 */
public class CartFragment extends ApiRequestBaseFragment implements BaseRecyclerAdapter.RecyclerItemClickListener,
        IToolbar, View.OnClickListener, ICartQuantityNotifier {

    private static final String TAG = CartFragment.class.getSimpleName();

    private static final int REQUEST_CODE_LOGIN = 211;
    private static final int REQUEST_CODE_LOGIN_COUPON_APPLY = 222;
    private static final long VIBRATE_MILLISECONDS = 500;
    private static final String BUNDLE_KEY_DOCTOR_NAME = "doctorName";
    private static final String BUNDLE_KEY_PATIENT_NAME = "patientName";

    protected List<BaseRecyclerAdapter.IViewType> mCartScreenData = new ArrayList<>();
    protected CartRecyclerAdapter mCartRecyclerAdapter;

    protected Button mPlaceOrderBtn;
    protected boolean mIsUploadPrescription = false;
    protected boolean mIsInsufficientInventory = false;
    /*This will be empty in all the other cases except ReOrder from Order History,
     Order Detail and Prescription Details*/
    private String mPatientName;
    private String mDoctorName;
    private String mCachedCouponCode = "";
    private boolean mApplyCouponCode = false;
    private boolean mIsCartLoginFlow = false;
    private boolean mIsOrderWithoutPrescription = false;

    private long mOrderId;
    private long mVariantId;
    // private boolean mCouponCodeApplied = true;

    public static CartFragment create(String doctorName, String patientName) {

        CartFragment fragment = new CartFragment();

        Bundle bundle = new Bundle();
        bundle.putString(BUNDLE_KEY_DOCTOR_NAME, doctorName);
        bundle.putString(BUNDLE_KEY_PATIENT_NAME, patientName);

        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getArguments();

        if (bundle != null) {
            mDoctorName = bundle.getString(BUNDLE_KEY_DOCTOR_NAME);
            mPatientName = bundle.getString(BUNDLE_KEY_PATIENT_NAME);
        }

        mCartRecyclerAdapter = new CartRecyclerAdapter(mCartScreenData);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cart, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initCartRecyclerView(view);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    public void performRequest() {
        performGetCartRequest();
    }

    /**
     * Method that initializes the views
     *
     * @param view the root view
     */
    protected void initViews(View view) {
        mPlaceOrderBtn = (Button) view.findViewById(R.id.cart_place_order_btn);
        RobotoTextView shopNowBtn = (RobotoTextView) view.findViewById(R.id.cart_empty_view_tv);
        mPlaceOrderBtn.setOnClickListener(this);
        shopNowBtn.setOnClickListener(this);

        if (mCartScreenData.size() > 0) {
            mPlaceOrderBtn.setVisibility(View.VISIBLE);
        }
    }

    /**
     * Method that initializes the Cart recycler view
     *
     * @param view the root view
     */
    private void initCartRecyclerView(View view) {
        RecyclerView cartRecyclerView = (RecyclerView) view.findViewById(R.id.cart_recycler_view);
        cartRecyclerView.setHasFixedSize(false);
        cartRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mCartRecyclerAdapter.setRecyclerItemClickListener(this);
        cartRecyclerView.setAdapter(mCartRecyclerAdapter);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.CART_SCREEN_VISIT_EVENT);
    }

    /**
     * Method that handles the cart information to be populated each time the cart is refreshed
     */
    protected void populateCartData(final List<BaseRecyclerAdapter.IViewType> cartDataList) {
        if (getActivity() == null || getView() == null) return;

        mIsInsufficientInventory = false;
        mIsUploadPrescription = false;

        if (cartDataList.isEmpty()) {
            getView().findViewById(R.id.cart_empty_view_linLyt).setVisibility(View.VISIBLE);
            mPlaceOrderBtn.setVisibility(View.GONE);
        } else {

            for (BaseRecyclerAdapter.IViewType view : cartDataList) {

                if (view.getViewType() == ViewTypes.CartViewType.CART_ITEM_UNAVAILABLE_VIEW_TYPE
                        || view.getViewType() == ViewTypes.CartViewType.CART_ITEM_INACTIVE_VIEW_TYPE) {
                    mIsInsufficientInventory = true;
                } else if (view.getViewType() == ViewTypes.CartViewType.CART_ITEM_BACK_IN_STOCK_VIEW_TYPE) {
                    CartRecyclerAdapter.CartDataStockItem dataItem = (CartRecyclerAdapter.CartDataStockItem) view;
                    if (!dataItem.isProductAvailable) {
                        mIsInsufficientInventory = true;
                    }
                } else if (view.getViewType() == ViewTypes.CartViewType.CART_ITEM_VIEW_TYPE) {
                    CartRecyclerAdapter.CartDataItem dataItem = (CartRecyclerAdapter.CartDataItem) view;
                    if (dataItem.prescriptionRequired && !dataItem.prescriptionAvailable) {
                        mIsUploadPrescription = true;
                    }
                } else if (view.getViewType() == ViewTypes.CartViewType.CART_ITEM_REVISED_ORDER_VIEW_TYPE) {
                    CartRecyclerAdapter.CartDataItem dataItem = (CartRecyclerAdapter.CartDataItem) view;
                    if (dataItem.prescriptionRequired && !dataItem.prescriptionAvailable) {
                        mIsUploadPrescription = true;
                    }
                } else if (view.getViewType() == ViewTypes.CartViewType.CART_COUPON_CODE_VIEW_TYPE) {
                    CartRecyclerAdapter.CartCouponCodeDataItem couponCodeDataItem =
                            (CartRecyclerAdapter.CartCouponCodeDataItem) view;
                    if (TextUtils.isEmpty(couponCodeDataItem.enteredCouponCode) && mIsCartLoginFlow) {
                        couponCodeDataItem.enteredCouponCode = mCachedCouponCode;
                        mApplyCouponCode = true;
                    } else {
                        mApplyCouponCode = false;
                    }
                    mIsCartLoginFlow = false;
                }

            }
            mCartScreenData.clear();
            mCartScreenData.addAll(cartDataList);
            mCartRecyclerAdapter.notifyDataSetChanged();
        }

        if (mApplyCouponCode) {
            applyCouponCode(mCachedCouponCode);
        } else {
            mFragmentInteractionListener.hideBlockingProgressBar();
        }
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;

        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {

            case ViewTypes.CartViewType.CART_COUPON_CODE_VIEW_TYPE:
                switch (view.getId()) {
                    case R.id.cart_enter_coupon_code_apply_btn:
                        hide_keyboard(getActivity(), view);
                        handleCouponCodeApplyBtnClick((CartRecyclerAdapter.CartCouponCodeDataItem) object);
                        break;
                }
                break;

            case ViewTypes.CartViewType.CART_AVAILABILITY_VIEW_TYPE:
                switch (view.getId()) {
                    case R.id.cart_enter_coupon_code_apply_btn:
                        handleAvailabilityCheckBtnClick();
                        break;
                }
                break;

            case ViewTypes.CartViewType.CART_ITEM_VIEW_TYPE:
                mVariantId = ((CartRecyclerAdapter.CartDataItem) object).variantId;
                CartRecyclerAdapter.CartDataItem cartDataItem = ((CartRecyclerAdapter.CartDataItem) object);
                switch (view.getId()) {
                    case R.id.cart_list_item_product_amount_tv:
                        handleProductQuantityBtnClick(cartDataItem.productQuantity, cartDataItem.maxOrderableQty,
                                Utils.getStripInfo(cartDataItem.innerPackagingQty,
                                        cartDataItem.outerPackagingQty, cartDataItem.unitOfSale));
                        break;
                    case R.id.cart_list_item_product_delete_iv:
                        performDeleteProductFromCart(mVariantId);
                        break;
                    default:
                        handleProductItemClick(cartDataItem.isActive, cartDataItem.isPharma,
                                cartDataItem.variantId);
                        break;
                }
                break;

            case ViewTypes.CartViewType.CART_ITEM_BACK_IN_STOCK_VIEW_TYPE:
                mVariantId = ((CartRecyclerAdapter.CartDataStockItem) object).variantId;
                CartRecyclerAdapter.CartDataStockItem backInStockDataItem =
                        ((CartRecyclerAdapter.CartDataStockItem) object);
                switch (view.getId()) {
                    case R.id.cart_stock_info_list_item_product_amount_tv:
                        if (backInStockDataItem.productQuantity > backInStockDataItem.maxOrderableQty) {
                            handleProductQuantityBtnClick(backInStockDataItem.productQuantity,
                                    backInStockDataItem.maxOrderableQty,
                                    Utils.getStripInfo(backInStockDataItem.innerPackagingQty,
                                            backInStockDataItem.outerPackagingQty, backInStockDataItem.unitOfSale));
                        }
                        break;
                    case R.id.cart_stock_info_list_item_product_delete_iv:
                        performDeleteProductFromCart(mVariantId);
                        break;
                    default:
                        handleProductItemClick(backInStockDataItem.isActive, backInStockDataItem.isPharma,
                                backInStockDataItem.variantId);
                        break;
                }
                break;

            case ViewTypes.CartViewType.CART_ITEM_UNAVAILABLE_VIEW_TYPE:
                CartRecyclerAdapter.CartItemUnavailableDataItem unavailableDataItem =
                        (CartRecyclerAdapter.CartItemUnavailableDataItem) object;
                switch (view.getId()) {
                    case R.id.cart_list_unavialable_item_product_delete_iv:
                        performDeleteProductFromCart(unavailableDataItem.variantId);
                        break;
                    default:
                        handleProductItemClick(unavailableDataItem.isActive,
                                unavailableDataItem.isPharma, unavailableDataItem.variantId);
                        break;
                }

                break;

            case ViewTypes.CartViewType.CART_ITEM_REVISED_ORDER_VIEW_TYPE:
                CartRecyclerAdapter.RevisedOrderCartDataItem revisedOrderCartDataItem =
                        (CartRecyclerAdapter.RevisedOrderCartDataItem) object;
                handleProductItemClick(revisedOrderCartDataItem.isActive,
                        revisedOrderCartDataItem.isPharma, revisedOrderCartDataItem.variantId);

                break;

            case ViewTypes.CartViewType.CART_ITEM_INACTIVE_VIEW_TYPE:
                CartRecyclerAdapter.CartInActiveDataItem inActiveDataItem =
                        (CartRecyclerAdapter.CartInActiveDataItem) object;
                switch (view.getId()) {
                    case R.id.cart_list_item_product_delete_iv:
                        performDeleteProductFromCart(inActiveDataItem.variantId);
                        break;
                    default:
                        showAlert(getString(R.string.cart_inactive_item_alert_message));
                        break;
                }
                break;

            case ViewTypes.CartViewType.CART_APPLIED_COUPON_CODES_LIST_ITEM_VIEW_TYPE:
                handleCouponCodeRemove();
                break;
        }
    }

    /**
     * Method that handles the removal of coupon code
     */
    private void handleCouponCodeRemove() {
        //Toast.makeText(getActivity().getApplicationContext(), "Remove", Toast.LENGTH_SHORT).show();
    }

    /**
     * Method that handles the Pharma or Non Pharma PDP launch
     *
     * @param active the flag that determines if the product is available
     * @param isPharma the flag that determines if the product is a pharma/non pharma
     * @param variantId the product assigned unique id
     */
    private void handleProductItemClick(boolean active, boolean isPharma, long variantId) {
        String fragmentId = "";
        if (active) {
            if (isPharma) {
                fragmentId = ProductDetailActivity.PHARMA_PRODUCT_DETAIL_FRAGMENT_ID;
            } else {
                fragmentId = ProductDetailActivity.NON_PHARMA_PRODUCT_DETAIL_FRAGMENT_ID;
            }
            startActivity(ProductDetailActivity.getActivityIntent(getActivity().getApplicationContext(),
                    fragmentId, variantId));
            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        } else {
            showAlert(getString(R.string.no_variant_information));
        }
    }

    /**
     * Method displays the dialog with allows the user to update the product quantity
     *
     * @param quantity        the current quantity of the product in the cart
     * @param maxOrderableQty the max orderable quantity of the product
     * @param stripInfo       the strip information to be displayed in the dialog
     */
    private void handleProductQuantityBtnClick(int quantity, int maxOrderableQty, String stripInfo) {
        CartQuantityPickerDialogFragment cartQuantityPickerDialogFragment = new CartQuantityPickerDialogFragment();
        cartQuantityPickerDialogFragment.create(this, quantity, maxOrderableQty, stripInfo);
        cartQuantityPickerDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);
    }

    private void handleAvailabilityCheckBtnClick() {
        Toast.makeText(getActivity().getApplicationContext(), getString(R.string.cart_invalid_pincode), Toast.LENGTH_SHORT).show();
    }

    /**
     * Method to handle the cases for Apply button click in Cart Coupon code section
     *
     * @param cartCouponCodeDataItem the Coupon code data item
     */
    private void handleCouponCodeApplyBtnClick(CartRecyclerAdapter.CartCouponCodeDataItem cartCouponCodeDataItem) {
        if (TextUtils.isEmpty(cartCouponCodeDataItem.enteredCouponCode)) {
            showAlert(getString(R.string.cart_coupon_code_please_enter_msg));
        } else {
            if (Utils.isLoggedIn(getActivity().getApplicationContext())) {
                if (cartCouponCodeDataItem.isApplied) {
                    removeAppliedCouponCode(cartCouponCodeDataItem.enteredCouponCode);
                } else {
                    applyCouponCode(cartCouponCodeDataItem.enteredCouponCode);
                }
            } else {
                /*
                User not logged in case : Get the entered coupon code and cache it to apply it once he successfully logs in
                 */
                verifyCouponCodeApplied();
                mFragmentInteractionListener.showAlert(null, getString(R.string.cart_login_coupon_code_apply_msg), getString(R.string.ok),
                        null, new AlertDialogFragment.AlertPositiveActionListener() {
                            @Override
                            public void onPositiveAction() {
                                startActivityForResult(LogInActivity.getActivityIntent(getActivity().getApplicationContext(), true,
                                        LogInActivity.LOG_IN_FRAGMENT), REQUEST_CODE_LOGIN_COUPON_APPLY);
                            }
                        }, null, false);
            }
        }
    }

    /**
     * Method that gets the dynamically changing Coupon code filed value
     */
    private void verifyCouponCodeApplied() {
        for (BaseRecyclerAdapter.IViewType view : mCartScreenData) {
            if (view.getViewType() == ViewTypes.CartViewType.CART_COUPON_CODE_VIEW_TYPE) {
                CartRecyclerAdapter.CartCouponCodeDataItem dataItem = (CartRecyclerAdapter.CartCouponCodeDataItem) view;
                if (!dataItem.isApplied && !TextUtils.isEmpty(dataItem.enteredCouponCode)) {
                    //mCouponCodeApplied = false;
                    mCachedCouponCode = dataItem.enteredCouponCode;
                }
            }
        }
    }

    /**
     * Method requests for apply the coupon
     *
     * @param couponCode the coupon code to be applied
     */
    private void applyCouponCode(String couponCode) {
        mCachedCouponCode = "";
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performApplyCouponCodeRequest(couponCode, new ApiRequestManager.ICartResultNotifier() {
            @Override
            public void onCartResult(List<BaseRecyclerAdapter.IViewType> cartDataList) {
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.COUPON_CODE_APPLIED_EVENT);
                Vibrator vb = (Vibrator) getActivity().getSystemService(Context.VIBRATOR_SERVICE);
                vb.vibrate(VIBRATE_MILLISECONDS);
                populateCartData(cartDataList);
            }
        }, this, this);
    }

    /**
     * Method requests for removing the coupon
     *
     * @param couponCode the coupon code to be removed
     */
    private void removeAppliedCouponCode(String couponCode) {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performDeleteCouponCodeRequest(couponCode, new ApiRequestManager.ICartResultNotifier() {
            @Override
            public void onCartResult(List<BaseRecyclerAdapter.IViewType> cartDataList) {
                populateCartData(cartDataList);
            }
        }, this, this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.cart_place_order_btn:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PLACE_ORDER_TAP_EVENT);
                if (NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
                    performPlaceOrder();
                } else {
                    showAlert(getString(R.string.please_check_your_network_connection));
                }
                break;
            case R.id.cart_empty_view_tv:
                startActivity(HomeActivity.getActivityIntentBackToHome(getActivity(), HomeActivity.HOME_FRAGMENT_TAG, true));
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                break;
        }
    }

    /**
     * Method validates cases on Place Order click and performs the specified actions
     */
    public void performPlaceOrder() {
        if (mIsInsufficientInventory) {
            mFragmentInteractionListener.showAlert(getString(R.string.cart_insufficient_inventory_title), getString(R.string.cart_insufficient_inventory_msg),
                    getString(R.string.ok), null, null, null, false);
        }/* else if (!mCouponCodeApplied) {
            mFragmentInteractionListener.showAlert(getString(R.string.cart_apply_coupon_code_login_title),
            getString(R.string.cart_apply_coupon_code_login_msg), getString(R.string.ok), null,
            new AlertDialogFragment.AlertPositiveActionListener() {
                @Override
                public void onPositiveAction() {

                }
            }, null, false);
        }*/ else {
            verifyIsOrderWithoutPrescription();
            if (!Utils.isLoggedIn(getActivity().getApplicationContext())) {
                startActivityForResult(LogInActivity.getActivityIntent(getActivity().getApplicationContext(), true,
                                LogInActivity.LOG_IN_FRAGMENT),
                        REQUEST_CODE_LOGIN);
            } else {
                 if (mIsUploadPrescription) {
                    if (mIsOrderWithoutPrescription) {
                        PlaceOrderDialogFragment placeOrderDialogFragment = PlaceOrderDialogFragment
                                .create(mDoctorName, mPatientName, mOrderId, -1, -1, CheckOutDeliveryAddressFragment.CartFlow.CART);
                        placeOrderDialogFragment.show(getChildFragmentManager(), TAG);
                    } else {
                        mFragmentInteractionListener.loadFragment(getId(), CartUploadPrescriptionFragment.create(mDoctorName, mPatientName,
                                        mOrderId, -1, -1, CheckOutDeliveryAddressFragment.CartFlow.CART),
                                null, R.anim.push_left_in, R.anim.fade_out,
                                BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                    }
                } else {
                    mFragmentInteractionListener.loadFragment(getId(), CheckOutDeliveryAddressFragment.create(
                                    mDoctorName, mPatientName, mOrderId, -1, -1, -1, CheckOutDeliveryAddressFragment.CartFlow.CART),
                            CheckOutDeliveryAddressFragment.TAG, R.anim.push_left_in, R.anim.fade_out,
                            BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                }
            }
        }
    }

    /**
     * Method to check order without prescription
     */
    private void verifyIsOrderWithoutPrescription() {
        for (BaseRecyclerAdapter.IViewType view : mCartScreenData) {
            if (view.getViewType() == ViewTypes.CartViewType.CART_ORDER_SUMMARY_VIEW_TYPE) {
                CartRecyclerAdapter.CartOrderSummaryDataItem dataItem = (CartRecyclerAdapter.CartOrderSummaryDataItem) view;
                mIsOrderWithoutPrescription = dataItem.isOrderWithoutPrescription;
                mOrderId = dataItem.orderId;
            }
        }
    }

    /**
     * Method requests for refreshing the cart items
     */
    private void performGetCartRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetCartItemsRequest(new ApiRequestManager.ICartResultNotifier() {
            @Override
            public void onCartResult(List<BaseRecyclerAdapter.IViewType> cartDataList) {
                if (getActivity() != null && getView() != null)
                    populateCartData(cartDataList);
            }
        }, this, this);
    }

    /**
     * Method requests for updating the cart;If success, refresh the cart items
     *
     * @param variantId    the unique id for each product
     * @param cartQuantity the quantity of the product to be added to the cart
     */
    private void performUpdateCartRequest(long variantId, int cartQuantity) {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performUpdateCartRequest(variantId, cartQuantity, new ApiRequestManager.ICartUpdateResultNotifier() {
            @Override
            public void onCartUpdated() {
                mFragmentInteractionListener.hideBlockingProgressBar();
                performGetCartRequest();
            }

            @Override
            public void onCartResult(List<BaseRecyclerAdapter.IViewType> cartDataList) {
                populateCartData(cartDataList);
            }
        }, this, this);
    }

    /**
     * Method requests for delete a product from cart;If success, refresh the cart items
     *
     * @param variantId the unique id for each product
     */
    private void performDeleteProductFromCart(long variantId) {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performDeleteCartItemsRequest(variantId, new ApiRequestManager.ICartItemDeleteResultNotifier() {
            @Override
            public void onCartItemDeleted() {
                mFragmentInteractionListener.hideBlockingProgressBar();
                performGetCartRequest();
            }

            @Override
            public void onCartResult(List<BaseRecyclerAdapter.IViewType> cartDataList) {
                populateCartData(cartDataList);
            }
        }, this, this);
    }

    /**
     * Method that receives the callback on updating the product to cart
     *
     * @param cartQuantity the quantity of the product
     */
    @Override
    public void onAddToCartClick(int cartQuantity) {
        if (NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
            performUpdateCartRequest(mVariantId, cartQuantity);
        } else {
            showAlert(getString(R.string.please_check_your_network_connection));
        }
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_cart);
    }

    @Override
    public int getToolbarMenuId() {
        return R.menu.menu_cart;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_search:
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_FROM_TOOLBAR_EVENT);
                        startActivity(new Intent(getActivity(), SearchActivity.class));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;
                }
                return false;
            }
        };
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        //FrankRossAnalytics.getFrankRossTracker().logTimedEvent(FrankRossEvents.TIME_SPENT_CART_SCREEN_EVENT, null);
        performRequest();
    }

    @Override
    public void onStop() {
        super.onStop();
        //FrankRossAnalytics.getFrankRossTracker().endTimedEvent(FrankRossEvents.TIME_SPENT_CART_SCREEN_EVENT, null);
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_CODE_LOGIN) {
                /*Refresh the cart items when pressed back after Log In through CheckOut*/
                mFragmentInteractionListener.showBlockingProgressBar();
                mApiRequestManager.performGetCartItemsRequest(new ApiRequestManager.ICartResultNotifier() {
                    @Override
                    public void onCartResult(List<BaseRecyclerAdapter.IViewType> cartDataList) {
                        populateCartData(cartDataList);
                        performPlaceOrder();
                    }
                }, this, this);
            } else if (requestCode == REQUEST_CODE_LOGIN_COUPON_APPLY) {
                mFragmentInteractionListener.showBlockingProgressBar();
                mIsCartLoginFlow = true;
            }
        }
    }
}

