/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.support.annotation.NonNull;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.DigitisedPrescription;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.CirclePageIndicator;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 15/7/15.
 * <p> Adapter class for Prescription Section</p>
 * <p>Supports the Four View Types </p>
 * <p> 1 : PRESCRIPTION UNDIGITISED PRESCRIPTIONS VIEW TYPE </p>
 * <p> 2 : PRESCRIPTION UPLOAD PRESCRIPTION VIEW TYPE </p>
 * <p> 3 : PRESCRIPTION INFO VIEW TYPE </p>
 * <p> 3 : PRESCRIPTION FILTER VIEW TYPE </p>
 */
public class PrescriptionAdapter extends BaseRecyclerAdapter {

    public PrescriptionAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewDataBinderList = new ArrayList<>(1);
        viewDataBinderList.add(new UnDigitisedPrescriptionsViewDataBinder());
        viewDataBinderList.add(new PrescriptionsUploadViewDataBinder());
        viewDataBinderList.add(new PrescriptionInfoViewDataBinder());
        viewDataBinderList.add(new PrescriptionsFilterViewDataBinder());

        return viewDataBinderList;
    }

    /**
     * PRESCRIPTION UNDIGITISED PRESCRIPTIONS VIEW TYPE
     */

    public static class UnDigitisedPrescriptionPagerDataItem implements IViewType {
        public List<String> mUnDigitisedPrescriptionsUrlList;

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_PAGER;
        }
    }

    private static class PrescriptionPagerViewHolder extends RecyclerView.ViewHolder {
        private ViewPager mPrescriptionViewPager;
        private CirclePageIndicator mPrescriptionPagerIndicator;

        public PrescriptionPagerViewHolder(View itemView) {
            super(itemView);

            mPrescriptionViewPager = (ViewPager) itemView.findViewById(R.id.prescription_pager);
            mPrescriptionPagerIndicator = (CirclePageIndicator) itemView.findViewById(R.id.prescription_pager_indicator);
        }
    }

    private static class UnDigitisedPrescriptionsViewDataBinder implements
            RecyclerViewDataBinder<PrescriptionPagerViewHolder, UnDigitisedPrescriptionPagerDataItem> {

        @Override
        public PrescriptionPagerViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.prescription_pager_item, parent, false);

            return new PrescriptionPagerViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final PrescriptionPagerViewHolder viewHolder,
                                         UnDigitisedPrescriptionPagerDataItem data, int position,
                                         RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mPrescriptionViewPager.setAdapter(new TopOffersAdapter(data.mUnDigitisedPrescriptionsUrlList));
            viewHolder.mPrescriptionPagerIndicator.getBackground().setAlpha((int) (0.7F * 255));
            viewHolder.mPrescriptionPagerIndicator.setViewPager(viewHolder.mPrescriptionViewPager);

            viewHolder.mPrescriptionViewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
                @Override
                public void onPageSelected(int position) {
                    viewHolder.mPrescriptionPagerIndicator.setCurrentItem(position);
                }
            });
        }

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_PAGER;
        }
    }


    /**
     * PRESCRIPTION UPLOAD PRESCRIPTION VIEW TYPE
     */

    public static class PrescriptionUploadItem implements IViewType {

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_UPLOAD;
        }
    }

    private static class PrescriptionUploadViewHolder extends RecyclerView.ViewHolder {

        public Button prescriptionUploadButton;

        public PrescriptionUploadViewHolder(View itemView) {
            super(itemView);

            prescriptionUploadButton = (Button) itemView.findViewById(R.id.prescription_upload_button);
        }
    }

    private static class PrescriptionsUploadViewDataBinder implements
            RecyclerViewDataBinder<PrescriptionUploadViewHolder, PrescriptionUploadItem> {

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_UPLOAD;
        }

        @Override
        public PrescriptionUploadViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.prescription_upload_item, parent, false);
            return new PrescriptionUploadViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(PrescriptionUploadViewHolder viewHolder, final PrescriptionUploadItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            if (recyclerViewClickListener != null) {
                viewHolder.prescriptionUploadButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }
    }

    /**
     * PRESCRIPTION INFO VIEW TYPE
     */
    public static class PrescriptionInfoDataItem implements IViewType {

        public DigitisedPrescription digitisedPrescription;

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_INFO;
        }
    }

    private static class PrescriptionInfoViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mPrescriptionReferenceNumberTitle;
        private RobotoTextView mPrescriptionReferenceNumber;
        private RobotoTextView mPrescriptionDate;
        private RobotoTextView mPrescriptionExpiryDate;
        private RobotoTextView mPatientName;
        private RobotoTextView mDoctorName;
        private RobotoTextView mDosageInfo1;
        private RobotoTextView mDosageInfo2;
        private RobotoTextView mMoreCount;
        private RobotoTextView mPrescriptionRefNo;

        private ImageView mDoctorMoreIcon;
        private ImageView mPatientMoreIcon;

        private LinearLayout mPrescriptionDosageLayout;
        private LinearLayout mPrescriptionPatientView;
        private LinearLayout mPrescriptionDoctorView;
        private LinearLayout mPrescriptionDosageProductsLinLyt;
        private LinearLayout mPrescriptionDrugMoreLayout;

        public PrescriptionInfoViewHolder(View itemView) {
            super(itemView);
            mPrescriptionReferenceNumberTitle = (RobotoTextView) itemView.findViewById(R.id.prescription_reference_title_tv);
            mPrescriptionReferenceNumber = (RobotoTextView) itemView.findViewById(R.id.prescription_reference_number_tv);
            mPrescriptionDate = (RobotoTextView) itemView.findViewById(R.id.prescription_date_tv);
            mPatientName = (RobotoTextView) itemView.findViewById(R.id.prescriptions_patient_name_tv);
            mDoctorName = (RobotoTextView) itemView.findViewById(R.id.prescriptions_doctor_name_tv);
            mDosageInfo1 = (RobotoTextView) itemView.findViewById(R.id.prescriptions_dosage_info1_tv);
            mDosageInfo2 = (RobotoTextView) itemView.findViewById(R.id.prescriptions_dosage_info2_tv);
            mMoreCount = (RobotoTextView) itemView.findViewById(R.id.prescription_dosage_info_more_tv);
            mPrescriptionRefNo = (RobotoTextView) itemView.findViewById(R.id.prescription_ref_no_tv);

            mPrescriptionPatientView = (LinearLayout) itemView.findViewById(R.id.prescription_patient_view);
            mPrescriptionDoctorView = (LinearLayout) itemView.findViewById(R.id.prescription_doctor_view);

            mPrescriptionDrugMoreLayout = (LinearLayout) itemView.findViewById(R.id.prescriptions_dosage_more_linLyt);
            mPrescriptionDosageLayout = (LinearLayout) itemView.findViewById(R.id.prescription_dosage_linLy);
            mPrescriptionDosageProductsLinLyt = (LinearLayout) itemView.findViewById(R.id.prescriptions_dosage_products_linLyt);
        }
    }

    private static class PrescriptionInfoViewDataBinder implements
            RecyclerViewDataBinder<PrescriptionInfoViewHolder, PrescriptionInfoDataItem> {

        @Override
        public PrescriptionInfoViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.prescription_info_item, parent, false);

            return new PrescriptionInfoViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(PrescriptionInfoViewHolder viewHolder,
                                         final PrescriptionInfoDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mPrescriptionReferenceNumber.setText(TextUtils.isEmpty(String.valueOf(data.digitisedPrescription.getId())) ?
                    "Not available" : String.valueOf(data.digitisedPrescription.getId()));
            viewHolder.mPrescriptionRefNo.setText(TextUtils.isEmpty(data.digitisedPrescription.getPresRefNo())
                    ? "NA" : data.digitisedPrescription.getPresRefNo());

            viewHolder.mPrescriptionDate.setText(data.digitisedPrescription.getFormattedDate());
            viewHolder.mPatientName.setText(data.digitisedPrescription.getPatientName());
            viewHolder.mDoctorName.setText(Utils.getDoctorPrefixedName(data.digitisedPrescription.getDoctorName()));
            viewHolder.mPrescriptionDate.setText(data.digitisedPrescription.getFormattedDate());

            if (!TextUtils.isEmpty(data.digitisedPrescription.getMoreCount()) && Integer.parseInt(data.digitisedPrescription.getMoreCount()) > 0) {
                viewHolder.mPrescriptionDosageProductsLinLyt.setVisibility(View.VISIBLE);
                viewHolder.mPrescriptionDrugMoreLayout.setVisibility(View.VISIBLE);
                viewHolder.mDosageInfo1.setVisibility(View.VISIBLE);
                viewHolder.mDosageInfo2.setVisibility(View.VISIBLE);
                viewHolder.mDosageInfo1.setText(data.digitisedPrescription.getDosage().get(0));
                viewHolder.mDosageInfo2.setText(data.digitisedPrescription.getDosage().get(1));
                viewHolder.mMoreCount.setText(String.valueOf(data.digitisedPrescription.getMoreCount()));
            } else {
                viewHolder.mPrescriptionDrugMoreLayout.setVisibility(View.GONE);
                switch (data.digitisedPrescription.getDosage().size()) {
                    case 0:
                        viewHolder.mPrescriptionDosageProductsLinLyt.setVisibility(View.GONE);
                        break;
                    case 1:
                        viewHolder.mPrescriptionDosageProductsLinLyt.setVisibility(View.VISIBLE);
                        viewHolder.mDosageInfo1.setVisibility(View.VISIBLE);
                        viewHolder.mDosageInfo1.setText(data.digitisedPrescription.getDosage().get(0));
                        viewHolder.mDosageInfo2.setVisibility(View.GONE);
                        break;
                    case 2:
                        viewHolder.mPrescriptionDosageProductsLinLyt.setVisibility(View.VISIBLE);
                        viewHolder.mDosageInfo1.setVisibility(View.VISIBLE);
                        viewHolder.mDosageInfo2.setVisibility(View.VISIBLE);
                        viewHolder.mDosageInfo1.setText(data.digitisedPrescription.getDosage().get(0));
                        viewHolder.mDosageInfo2.setText(data.digitisedPrescription.getDosage().get(1));
                        break;
                    default:
                        break;
                }
            }

            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_INFO;
        }
    }

    /**
     * PRESCRIPTION FILTER VIEW TYPE
     */

    public static class PrescriptionFilterDataItem implements IViewType {

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_FILTER_HEADER;
        }
    }

    private static class PrescriptionFilterViewHolder extends RecyclerView.ViewHolder {

        public PrescriptionFilterViewHolder(View itemView) {
            super(itemView);
        }
    }

    private static class PrescriptionsFilterViewDataBinder implements
            RecyclerViewDataBinder<PrescriptionFilterViewHolder, PrescriptionFilterDataItem> {

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionViewType.PRESCRIPTION_FILTER_HEADER;
        }

        @Override
        public PrescriptionFilterViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.prescription_view_filters_item, parent, false);
            return new PrescriptionFilterViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(PrescriptionFilterViewHolder viewHolder, final PrescriptionFilterDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }
    }

}

