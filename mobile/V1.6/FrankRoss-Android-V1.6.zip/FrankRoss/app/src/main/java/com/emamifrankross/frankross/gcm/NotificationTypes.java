/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.gcm;

/**
 * Created by gowtham on 30/10/15.
 */
public interface NotificationTypes {

    /**
     * COMMON PUSH NOTIFICATIONS
     */
    int DIGITISATION_FAILURE = 1;
    int CART_PREPARED = 2;
    int ORDER_REVISION = 3;
    int ORDER_STATUS_UPDATE = 4;
    int GENERAL_PROMOTION_SPECIFIC_USER = 5;
    int GENERAL_PROMOTION_ALL_USER = 6;

    /**
     * IMAGE BASED PUSH NOTIFICATIONS
     */
    int HOME = 10;
    int CATEGORY = 11;
    int PROMOTION_PRODUCT_LISTING = 12;
    int HOME_COPY_CODE = 13;
    int CATEGORY_COPY_CODE = 14;
    int HTML_PAGE = 15;
    int REFER_A_FRIEND = 16;
    int PRODUCT_DETAIL = 17;
    int HEALTH_ARTICLES = 18;
}
