/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.home;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.FrankRossApplication;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.aloglia.AlgoliaManager;
import com.emamifrankross.frankross.core.aloglia.datamodel.AlgoliaProductsFilterInfo;
import com.emamifrankross.frankross.core.apimodels.ApiHomeBanner;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.ApptentiveManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.HomeFeaturedCategoriesAdapter;
import com.emamifrankross.frankross.ui.adapters.HomeRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.NewFeaturedProductsAdapter;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.common.WebViewFragment;
import com.emamifrankross.frankross.ui.notification.NotificationCenterFragment;
import com.emamifrankross.frankross.ui.pharmacy.PharmacyActivity;
import com.emamifrankross.frankross.ui.pharmacy.PharmacyFragment;
import com.emamifrankross.frankross.ui.pharmacy.ProductListingActivity;
import com.emamifrankross.frankross.ui.prescription.prescriptionmedicines.PrescriptionMedicineActivity;
import com.emamifrankross.frankross.ui.prescription.uploadprescription.UploadPrescriptionActivity;
import com.emamifrankross.frankross.ui.products.ProductDetailActivity;
import com.emamifrankross.frankross.ui.search.SearchActivity;
import com.emamifrankross.frankross.ui.viewmodels.CommonRecyclerHeaderItem;
import com.emamifrankross.frankross.ui.viewmodels.HorizontalRecyclerViewItem;
import com.emamifrankross.frankross.ui.viewmodels.HorizontalScrollerViewMoreDataItem;
import com.emamifrankross.frankross.ui.viewmodels.ProductDataModel;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderItem;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Log;
import com.emamifrankross.frankross.utils.NetworkUtils;
import com.emamifrankross.frankross.utils.PreferenceUtils;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by gauthami on 29/6/15.
 */

/**
 * This class represents the UI for Home screen that consists of Upload prescription,
 * auto scrolled banner views and horizontal scroll views for featured categories and featured products
 */
public class HomeFragment extends ApiRequestBaseFragment implements BaseRecyclerAdapter.RecyclerItemClickListener, IToolbar {

    private static final String TAG = HomeFragment.class.getSimpleName();
    private static final int PRODUCT_LIMIT = 6;
    private static final int REQUEST_CODE_UPLOAD_PRESCRIPTION = 111;
    private static final int REQUEST_CODE_CART = 222;
    private static final int REQUEST_CODE_PDP = 333;

    private List<BaseRecyclerAdapter.IViewType> mHomeScreenData = new ArrayList<>();
    private HomeRecyclerAdapter mHomeRecyclerAdapter;
    private HomeRecyclerAdapter.TopOffersAutoScrollDataItem mOfferBannerItem;
    private HomeRecyclerAdapter.TopOffersAutoScrollDataItem mStoresBannerItem;

    private ApiRequestManager.INotificationsCountChangeNotifier mINotificationsCountChangeNotifier;

    private boolean mIsBinded = false;
    private int mNotificationCount = 0;

    private ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            Log.d(TAG, "on Service Connected");
            if (service != null && service instanceof LooperService.LooperBinder) {
                final LooperService.LooperBinder looperBinder = (LooperService.LooperBinder) service;
                mHomeRecyclerAdapter.setLooperBinder(looperBinder);

                looperBinder.startLooping(new LooperService.ILoopNotifier() {
                    @Override
                    public void onLoop() {
                        Log.d(TAG, " on loop Please notify the view pager");

                        if (mHomeRecyclerAdapter != null) {
                            mHomeRecyclerAdapter.onScrollNext();
                        }
                    }
                });
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            Log.d(TAG, "on Service Disconnected");
        }
    };

    public static HomeFragment create() {
        return new HomeFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mHomeRecyclerAdapter = new HomeRecyclerAdapter(mHomeScreenData);
        mOfferBannerItem = null;
        mStoresBannerItem = null;
        getHomeAdapterData();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initHomeRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            mINotificationsCountChangeNotifier = (ApiRequestManager.INotificationsCountChangeNotifier) context;
        } catch (Exception e) {
            throw new ClassCastException(context
                    + " must implement INotificationsCountChangeNotifier");
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        //FrankRossAnalytics.getFrankRossTracker().logTimedEvent(FrankRossEvents.TIME_SPENT_HOME_SCREEN_EVENT, null);
        if (mOfferBannerItem != null || mStoresBannerItem != null) {
            bindLooperService();
        }
    }

    private void bindLooperService() {
        mIsBinded = true;
        Intent intent = new Intent(this.getActivity(), LooperService.class);
        getActivity().bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    public void onPause() {
        super.onPause();
        //FrankRossAnalytics.getFrankRossTracker().endTimedEvent(FrankRossEvents.TIME_SPENT_HOME_SCREEN_EVENT, null);
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
        if (mIsBinded) {
            unbindService();
        }
    }

    private void unbindService() {
        getActivity().unbindService(mServiceConnection);
        mIsBinded = false;
    }

    private void initHomeRecyclerView(View view) {
        RecyclerView homeRecyclerView = (RecyclerView) view.findViewById(R.id.home_container);
        homeRecyclerView.setHasFixedSize(false);
        homeRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mHomeRecyclerAdapter.setRecyclerItemClickListener(this);
        homeRecyclerView.setAdapter(mHomeRecyclerAdapter);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.HOME_SCREEN_VISIT_EVENT);
        ApptentiveManager.registerHomeScreenVisitEvent(getActivity());
    }

    /**
     * Method requests for notifications count
     */
    private void performNotificationsCountRequest() {
        if (!TextUtils.isEmpty(PreferenceUtils.getStringFromSharedPreference(
                FrankRossApplication.getFrankrossApplicationContext(), PreferenceUtils.PREFERENCE_KEY_GCM_TOKEN))) {
            mFragmentInteractionListener.showBlockingProgressBar();
            mApiRequestManager.performNotificationCountRequest(new ApiRequestManager.INotificationCountRequestResultNotifier() {
                @Override
                public void onNotificationCountRequestFetched(int notificationCount) {
                    mINotificationsCountChangeNotifier.onNotificationCountChanged(notificationCount);
                    mNotificationCount = notificationCount;
                }
            }, this, this);
        }
    }

    /**
     * Method to populate Home screen data
     */
    private void getHomeAdapterData() {
        performNotificationsCountRequest();
        mHomeScreenData.clear();
        HomeRecyclerAdapter.UploadPrescriptionDataItem uploadPrescriptionDataItem = new HomeRecyclerAdapter.UploadPrescriptionDataItem();
        uploadPrescriptionDataItem.searchLinLytTitle = getString(R.string.search_medicines_and_other_products);
        mHomeScreenData.add(uploadPrescriptionDataItem);
        getBanners();
    }

    /**
     * Method that gets the banner image urls
     */
    private void getBanners() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performGetBannersRequest(new ApiRequestManager.IBannerResultNotifier() {
            @Override
            public void onBannersFetched(List<ApiHomeBanner.Banner> homeBannerList, List<ApiHomeBanner.Banner> storeBannerList) {
                if (homeBannerList != null && homeBannerList.size() > 0) {
                    HomeRecyclerAdapter.TopOffersAutoScrollDataItem offerBannerItem =
                            new HomeRecyclerAdapter.TopOffersAutoScrollDataItem();
                    offerBannerItem.mBanner = homeBannerList;
                    mOfferBannerItem = offerBannerItem;
                }

                if (storeBannerList != null && storeBannerList.size() > 0) {
                    HomeRecyclerAdapter.TopOffersAutoScrollDataItem storesBannerItem =
                            new HomeRecyclerAdapter.TopOffersAutoScrollDataItem();
                    storesBannerItem.mBanner = storeBannerList;
                    storesBannerItem.isStoreBanner = true;
                    mStoresBannerItem = storesBannerItem;
                }

                getHomeCategories();
            }

            @Override
            public void onBannersFetchingFailed() {
                getHomeCategories();
            }
        }, null, this);
    }

    /**
     * Method that gets the popular categories
     */
    private void getHomeCategories() {
        if (NetworkUtils.isNetworkConnected(getActivity())) {
            mApiRequestManager.performGetHomeFeaturedCategoriesRequest(new ApiRequestManager.IGetHomeFeaturedCategoriesResultNotifier() {
                @Override
                public void onHomeFeatureCategoriesFetched(List<BaseRecyclerAdapter.IViewType> homeFeaturedCategoryDataList) {

                    if (homeFeaturedCategoryDataList != null && homeFeaturedCategoryDataList.size() > 0) {
                        if (mOfferBannerItem != null) {
                            mHomeScreenData.add(mOfferBannerItem);
                            bindLooperService();
                        }

                        mHomeScreenData.add(new CommonRecyclerHeaderItem(getString(R.string.home_top_categories)));
                        mHomeScreenData.add(new RecyclerBorderItem(2));

                        HorizontalRecyclerViewItem horizontalRecyclerViewItem = new HorizontalRecyclerViewItem();
                        horizontalRecyclerViewItem.viewHeight = 160;
                        horizontalRecyclerViewItem.mHorizontalRecyclerViewAdapter =
                                new HomeFeaturedCategoriesAdapter(homeFeaturedCategoryDataList);

                        mHomeScreenData.add(horizontalRecyclerViewItem);

                        if (mStoresBannerItem != null) {
                            mHomeScreenData.add(mStoresBannerItem);
                        }

                    } else {
                        if (mOfferBannerItem != null) {
                            mHomeScreenData.add(mOfferBannerItem);
                            bindLooperService();
                        }
                        if (mStoresBannerItem != null) {
                            mHomeScreenData.add(mStoresBannerItem);
                        }
                    }

                    mFragmentInteractionListener.hideBlockingProgressBar();
                    //mHomeRecyclerAdapter.notifyDataSetChanged();
                    getFeaturedProducts();
                }

                @Override
                public void onHomeFeatureCategoriesFailed() {
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mFragmentInteractionListener.hideBlockingProgressBar();
                            mHomeRecyclerAdapter.notifyDataSetChanged();
                        }
                    });
                }
            }, this, this);
        } else {
            getActivity().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    showAlert(getResources().getString(R.string.no_connection_error));
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    mHomeRecyclerAdapter.notifyDataSetChanged();
                }
            });
        }
    }

    /**
     * Method to add the Featured products to the UI list
     */
    private void getFeaturedProducts() {
        mFragmentInteractionListener.showBlockingProgressBar();
        AlgoliaManager.getInstance().performGetFeaturedProducts(getActivity().getApplicationContext(), PRODUCT_LIMIT, 0, false,
                new AlgoliaManager.IProductInfoWithFilterResultNotifier() {
                    @Override
                    public void onProductInfoFetched(final List<ProductDataModel> productList, AlgoliaProductsFilterInfo productsFilterInfo) {
                        if (getActivity() == null || getView() == null) return;
                        if (productList == null || productList.size() < 0) {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    mHomeRecyclerAdapter.notifyDataSetChanged();
                                }
                            });
                            return;
                        }

                        if (productList != null || productList.size() > 0) {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    generateFeaturedProductsMappedData(productList);
                                    mFragmentInteractionListener.hideBlockingProgressBar();
                                }
                            });
                        }
                    }

                    @Override
                    public void onSearchError() {

                        if (getActivity() != null && getView() != null) {
                            getActivity().runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    mFragmentInteractionListener.hideBlockingProgressBar();
                                    mHomeRecyclerAdapter.notifyDataSetChanged();
                                    showAlert(getString(R.string.no_connection_error));
                                }
                            });
                        }
                    }
                });
    }

    /**
     * Method that Maps the Algolia Featured Products
     *
     * @param productList the algolia featured products to be mapped to the UI list
     */
    private void generateFeaturedProductsMappedData(List<ProductDataModel> productList) {
        boolean isViewMore = false;
        if (productList != null && productList.size() != 0 && getActivity() != null) {
            mHomeScreenData.add(new RecyclerBorderItem(1));
            mHomeScreenData.add(new CommonRecyclerHeaderItem(getString(R.string.home_featured_products)));
            mHomeScreenData.add(new RecyclerBorderItem(2));

            List<BaseRecyclerAdapter.IViewType> featuredProductDataModel = new ArrayList<>();
            if (productList.size() > PRODUCT_LIMIT - 1) {
                productList.remove(productList.size() - 1);
                isViewMore = true;
            }

            for (ProductDataModel model : productList) {
                NewFeaturedProductsAdapter.HomeFeaturedProductsDataItem featuredProductsDataItem
                        = new NewFeaturedProductsAdapter.HomeFeaturedProductsDataItem();
                featuredProductsDataItem.productId = model.productId;
                featuredProductsDataItem.productBrandOrManufacturerName = model.productBrandOrManufacturerName;
                featuredProductsDataItem.productIconImageUrl = model.productIconImageUrl;
                featuredProductsDataItem.isAddToCartVisible = model.isAddToCartVisible;
                featuredProductsDataItem.productSellingPrice = model.productSellingPrice;
                featuredProductsDataItem.productActualPrice = model.productActualPrice;
                featuredProductsDataItem.productName = model.productName;
                featuredProductsDataItem.productDiscountPercent = model.productDiscountPercent;
                featuredProductsDataItem.productImageUrl = model.productImageUrl;
                featuredProductsDataItem.isPharma = model.isPharma;
                featuredProductDataModel.add(featuredProductsDataItem);
            }

            if (isViewMore) {
                HorizontalScrollerViewMoreDataItem viewMoreDataItem = new HorizontalScrollerViewMoreDataItem();
                viewMoreDataItem.viewHeight = 120;
                viewMoreDataItem.isCategory = false;
                featuredProductDataModel.add(viewMoreDataItem);
            }

            HorizontalRecyclerViewItem featuredProductsDataItem = new HorizontalRecyclerViewItem();
            featuredProductsDataItem.mHorizontalRecyclerViewAdapter =
                    new NewFeaturedProductsAdapter(featuredProductDataModel);
            featuredProductsDataItem.viewHeight = 193;

            mHomeScreenData.add(featuredProductsDataItem);
            mHomeScreenData.add(new RecyclerBorderItem(1));
        }

        mHomeRecyclerAdapter.notifyDataSetChanged();
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {
            case ViewTypes.HomeViewType.UPLOAD_PRESCRIPTION:
                handleUploadPrescriptionClick(view);
                break;
            //Auto scroll View Pager
            case ViewTypes.CommonViewType.TOP_OFFERS_VIEW_PAGER:
                HomeRecyclerAdapter.TopOffersAutoScrollDataItem topOffersAutoScrollDataItem =
                        (HomeRecyclerAdapter.TopOffersAutoScrollDataItem) object;

                if (topOffersAutoScrollDataItem != null) {

                    FrankRossAnalytics.getFrankRossTracker().logEvent(topOffersAutoScrollDataItem.isStoreBanner ?
                            FrankRossEvents.HOME_STORE_BANNER_TAP_EVENT : FrankRossEvents.HOME_BANNER_TAP_EVENT);
                    handleBannerItemClick(topOffersAutoScrollDataItem.mBanner.get(position).getWebUrl(),
                            topOffersAutoScrollDataItem.mBanner.get(position).getPromotionId());
                }
                break;

            //Horizontal view - Item category
            case ViewTypes.HomeViewType.HOME_HORIZONTAL_SCROLL_LIST_ITEM_VIEW_TYPE:
                handleCategoryClick(object);
                break;
            case ViewTypes.CommonViewType.HORIZONTAL_SCROLL_LIST_VIEW_MORE_ITEM_VIEW_TYPE:
                handleHorizontalScrollClick(object);
                break;
            //Horizontal view - Item featured products
            case ViewTypes.HomeViewType.HOME_HORIZONTAL_SCROLL_FEATURED_LIST_ITEM_VIEW_TYPE:
                handleProductItemClick(((NewFeaturedProductsAdapter.HomeFeaturedProductsDataItem) object).productId,
                        ((NewFeaturedProductsAdapter.HomeFeaturedProductsDataItem) object).isPharma);
                break;
            default:
                break;
        }
    }

    private void handleHorizontalScrollClick(Object object) {
        if (((HorizontalScrollerViewMoreDataItem) object).isCategory) {
            handleViewAllCategoriesClick();
        } else {
            handleViewMoreFeaturedProducts();
        }
    }

    /**
     * Method to handle the Banner image click
     *
     * @param webUrl      the web page url to be loaded associated with the banner
     * @param promotionId the promotion id associated with the banner
     */
    private void handleBannerItemClick(String webUrl, long promotionId) {
        if (promotionId != 0) {
            startActivity(ProductListingActivity.getActivityIntentForHomePromotionalProducts(getActivity().getApplicationContext(),
                    ProductListingActivity.PROMOTIONAL_PRODUCTS_FRAGMENT_ID, promotionId));
            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);

        } else if (!TextUtils.isEmpty(webUrl)) {
            mFragmentInteractionListener.loadFragment(getId(),
                    WebViewFragment.create(webUrl,
                            getString(R.string.home_promotion_details)),
                    null, R.anim.push_left_in, R.anim.fade_out,
                    BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
        }
    }

    /**
     * Method to handle Featured products view more click
     */
    private void handleViewMoreFeaturedProducts() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_MORE_HOME_FEATURED_PRODUCTS_TAP_EVENT);
        startActivity(ProductListingActivity.getActivityIntentForFeaturedProducts(getActivity().getApplicationContext(),
                ProductListingActivity.FEATURED_PRODUCTS_LISTING_FRAGMENT_ID, -1));
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    private void handleCategoryClick(Object object) {
        if (object instanceof HomeFeaturedCategoriesAdapter.HomeFeaturedCategoryDataItem) {
            HomeFeaturedCategoriesAdapter.HomeFeaturedCategoryDataItem categoryDataItem =
                    (HomeFeaturedCategoriesAdapter.HomeFeaturedCategoryDataItem) object;
            if (categoryDataItem.topCategoryName.equals(getString(R.string.pharmacy_category_name))
                    || categoryDataItem.categoryId == Constants.CATEGORY_PHARMACY_ID) {
                startActivityForResult(PrescriptionMedicineActivity.getActivityIntent(getActivity().getApplicationContext(),
                        PrescriptionMedicineActivity.PRESCRIPTION_MEDICINE_FRAGMENT_ID), REQUEST_CODE_CART);
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
            } else {
                startActivityForResult(PharmacyActivity.getActivityIntent(getActivity(), PharmacyActivity.PHARMACY_SUB_CATEGORY_FRAGMENT_ID,
                        null, categoryDataItem.categoryId), REQUEST_CODE_CART);
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
            }

            Map<String, String> categoriesClickData = Utils.categoriesClickDataForAnalytics(categoryDataItem.topCategoryName,
                    FrankRossEvents.PHARMACY_CATEGORY_NAME);
            FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.CATEGORIES_FROM_HOME_TAP_EVENT, categoriesClickData);
        }
    }

    private void handleViewAllCategoriesClick() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_MORE_CATEGORIES_TAP_EVENT);
        mFragmentInteractionListener.loadFragment(getId(), PharmacyFragment.create(), null, R.anim.push_left_in, R.anim.fade_out,
                BaseFragment.FragmentTransactionType.CLEAR_BACK_STACK_AND_REPLACE);
    }

    private void handleProductItemClick(long variantId, boolean isPharma) {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.HOME_FEATURED_PRODUCTS_TAP_EVENT);
        startActivityForResult(ProductDetailActivity.getActivityIntent(getActivity().getApplicationContext(),
                isPharma ? ProductDetailActivity.PHARMA_PRODUCT_DETAIL_FRAGMENT_ID : ProductDetailActivity.NON_PHARMA_PRODUCT_DETAIL_FRAGMENT_ID,
                variantId), REQUEST_CODE_PDP);
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    private void handleUploadPrescriptionClick(View view) {
        switch (view.getId()) {
            case R.id.home_search_linLay:
                Map<String, String> searchBarClickData = Utils.categoriesClickDataForAnalytics(Constants.HOME_SCREEN_NAME,
                        FrankRossEvents.SEARCH_BAR_SCREEN_NAME_EVENT);
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_BAR_TAP_EVENT, searchBarClickData);

                startActivity(SearchActivity.getActivityIntent(getActivity()));
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                break;

            case R.id.home_upload_button:
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.UPLOAD_PRESCRIPTION_FROM_HOME_EVENT);
                startActivityForResult(UploadPrescriptionActivity.getActivityIntent(getActivity(), false, false), REQUEST_CODE_UPLOAD_PRESCRIPTION);
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                break;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        mApiRequestManager.registerCartCountChangeNotifier((BaseActivity) getActivity());
        mApiRequestManager.registerNotificationsCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        mApiRequestManager.unregisterCartCountChangeNotifier((BaseActivity) getActivity());
        mApiRequestManager.unregisterNotificationsCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.menu;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        //Its handled in Drawer Activity. So don't set the listener here.
        return null;
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_home);
    }

    @Override
    public int getToolbarMenuId() {
        return R.menu.menu_home;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_cart:
                        if (!mFragmentInteractionListener.isProgressBarShowing()) {
                            Map<String, String> cartClickData = Utils.cartToolbarClickDataForAnalytics(Constants.HOME_SCREEN_NAME,
                                    FrankRossEvents.VIEW_CART_FROM_TOOLBAR_SCREEN_NAME);
                            FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_CART_FROM_TOOLBAR_EVENT, cartClickData);
                            startActivityForResult(CartActivity.getActivityIntent(getActivity().getApplicationContext(),
                                    CartActivity.CART_FRAGMENT_ID), REQUEST_CODE_CART);
                            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        }
                        break;
                    case R.id.action_notifications:
                        if (!mFragmentInteractionListener.isProgressBarShowing()) {
                            //FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.STORE_LOCATOR_DRAWER_TAP_EVENT);
                            mFragmentInteractionListener.loadFragment(getId(), NotificationCenterFragment.create(mNotificationCount),
                                    null, R.anim.push_left_in, R.anim.fade_out,
                                    BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                            mNotificationCount = 0;
                        }
                        break;
                }
                return false;
            }
        };
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_UPLOAD_PRESCRIPTION || requestCode == REQUEST_CODE_CART || requestCode == REQUEST_CODE_PDP) {
            getHomeAdapterData();
        }
    }
}