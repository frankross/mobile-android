/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 12/8/15.
 */
public class ApiCityDetails {

    public static class Response {
        @SerializedName("city")
        private CityDetails cityDetails = new CityDetails();

        public CityDetails getCityDetails() {
            return cityDetails;
        }
    }

    public static class CityDetails {

        @SerializedName("id")
        private int id;

        @SerializedName("customer_care_closes_at")
        private String customer_care_closes_at;

        @SerializedName("customer_care_starts_at")
        private String customer_care_starts_at;

        @SerializedName("name")
        private String name = "";

        @SerializedName("state")
        private String state = "";

        @SerializedName("warehouse_code")
        private String warehouse_code = "";

        @SerializedName("customer_care_number")
        private String customer_care_number = "";

        @SerializedName("country")
        private String country = "";

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getCustomer_care_closes_at() {
            return customer_care_closes_at;
        }

        public void setCustomer_care_closes_at(String customer_care_closes_at) {
            this.customer_care_closes_at = customer_care_closes_at;
        }

        public String getCustomer_care_starts_at() {
            return customer_care_starts_at;
        }

        public void setCustomer_care_starts_at(String customer_care_starts_at) {
            this.customer_care_starts_at = customer_care_starts_at;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public String getWarehouse_code() {
            return warehouse_code;
        }

        public void setWarehouse_code(String warehouse_code) {
            this.warehouse_code = warehouse_code;
        }

        public String getCustomerCareNumber() {
            return customer_care_number;
        }

        public void setCustomer_care_number(String customer_care_number) {
            this.customer_care_number = customer_care_number;
        }

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }
    }
}
