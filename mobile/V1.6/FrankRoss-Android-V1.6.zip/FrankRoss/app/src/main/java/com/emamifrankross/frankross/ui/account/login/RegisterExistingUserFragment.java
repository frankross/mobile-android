/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.account.login;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gauthami on 19/8/15.
 */

/**
 * This class represents the UI for registering existing user by verifying the registered mobile number
 */
public class RegisterExistingUserFragment extends ApiRequestBaseFragment implements View.OnClickListener, IToolbar {

    private static final String IS_ALREADY_PLACED = "isAlreadyPlacedOrder";

    private EditText mRegistrationUserMobileNumber;
    private RobotoTextView mThatsGreat;
    private RobotoTextView mThatsGreatSubTitle;
    private RobotoTextView mClearBtn;

    private boolean mIsOrderPlaced = false;

    public static RegisterExistingUserFragment create(boolean isAlreadyPlacedOrder) {
        RegisterExistingUserFragment fragment = new RegisterExistingUserFragment();
        Bundle bundle = new Bundle();
        bundle.putBoolean(IS_ALREADY_PLACED, isAlreadyPlacedOrder);
        fragment.setArguments(bundle);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (getArguments() != null) {
            mIsOrderPlaced = getArguments().getBoolean(IS_ALREADY_PLACED);
        }

        return inflater.inflate(R.layout.fragment_register_existing_user, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that initializes the views
     *
     * @param view the root view
     */
    private void initViews(View view) {
        mRegistrationUserMobileNumber = (EditText) view.findViewById(R.id.register_existing_user_mobile_number_et);
        Button registerBtn = (Button) view.findViewById(R.id.register_existing_user_register_btn);
        mThatsGreat = (RobotoTextView) view.findViewById(R.id.register_existing_user_thats_great_tv);
        mThatsGreatSubTitle = (RobotoTextView) view.findViewById(R.id.register_existing_user_thats_great_sub_title_tv);
        mClearBtn = (RobotoTextView) view.findViewById(R.id.register_existing_user_clear_txt_btn);

        registerBtn.setOnClickListener(this);
        mClearBtn.setOnClickListener(this);
        mRegistrationUserMobileNumber.addTextChangedListener(mTextChangeListener);
        setVisibility();

        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ENTER_MOBILE_NUMBER_VISIT_EVENT);
    }

    /**
     * Text watcher for mobile number that helps in setting the clear button visibility
     */
    private TextWatcher mTextChangeListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            setClearButtonVisibility(charSequence);
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    };

    private void setClearButtonVisibility(CharSequence charSequence) {
        mClearBtn.setVisibility((!TextUtils.isEmpty(charSequence) && charSequence.length() > 0) ? View.VISIBLE : View.INVISIBLE);
    }

    /**
     * Method that initializes the default text and visibility based on the flow
     */
    private void setVisibility() {
        mThatsGreat.setVisibility(mIsOrderPlaced ? View.VISIBLE : View.GONE);
        mThatsGreatSubTitle.setText(mIsOrderPlaced ? getString(R.string.register_existing_user_sub_title2) :
                getString(R.string.register_existing_user_sub_title));
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.register_existing_user_register_btn:
                performCreateOTP();
                break;
            case R.id.register_existing_user_clear_txt_btn:
                mRegistrationUserMobileNumber.getText().clear();
                break;
        }
    }

    /**
     * Method requests for Creating OTP;If success, move to Enter OTP screen
     */
    private void performCreateOTP() {
        if (validateRegistration()) {
            hide_keyboard(mThatsGreat.getContext(), mThatsGreat);
            mFragmentInteractionListener.showBlockingProgressBar();
            mApiRequestManager.performCreateOTPRequest(getUserMobileNumber(), new ApiRequestManager.ICreateOTPResultNotifier() {
                @Override
                public void onOtpSent(String message) {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    mFragmentInteractionListener.loadFragment(getId(), EnterOTPFragment.create(mIsOrderPlaced, false, "", getUserMobileNumber(), "", null),
                            null, R.anim.push_left_in, R.anim.fade_out,
                            BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                    if (mIsOrderPlaced) {
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.USER_REGISTRATION_ORDER_FLOW_EVENT);
                    }
                }
            }, this, this);
        }
    }

    /**
     * @return If false,displays the input error dialog with appropriate message;else true.
     */
    private boolean validateRegistration() {
        boolean isValid = false;

        if (!Utils.isValidPhoneNumber(getUserMobileNumber())) {
            showAlert(getString(R.string.please_enter_a_valid_number));
        } else {
            isValid = true;
        }

        return isValid;
    }

    /**
     * @return returns user mobile number if not empty or null,else returns empty string
     */
    private String getUserMobileNumber() {
        String userMobileNumber = mRegistrationUserMobileNumber.getText().toString();
        if (TextUtils.isEmpty(userMobileNumber)) return "";
        return userMobileNumber;
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        //FrankRossAnalytics.getFrankRossTracker().logTimedEvent(FrankRossEvents.TIME_SPENT_ENTER_MOBILE_NUMBER_SCREEN_EVENT, null);
    }

    @Override
    public void onStop() {
        super.onStop();
        //FrankRossAnalytics.getFrankRossTracker().endTimedEvent(FrankRossEvents.TIME_SPENT_ENTER_MOBILE_NUMBER_SCREEN_EVENT, null);
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return "";
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

}
