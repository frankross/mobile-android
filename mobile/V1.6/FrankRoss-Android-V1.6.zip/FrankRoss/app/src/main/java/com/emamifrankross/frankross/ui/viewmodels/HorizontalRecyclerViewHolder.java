/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.content.Context;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.emamifrankross.frankross.R;

/**
 * Created by gowtham on 17/12/15.
 */

/**
 * Horizontal Recycler item view holder
 */
public class HorizontalRecyclerViewHolder extends RecyclerView.ViewHolder {

    public RecyclerView mHorizontalRecyclerView;

    public HorizontalRecyclerViewHolder(View itemView, Context context) {
        super(itemView);

        mHorizontalRecyclerView = (RecyclerView) itemView.findViewById(R.id.home_top_categories_horizontal_view);
        mHorizontalRecyclerView.setHasFixedSize(false);
        LinearLayoutManager layoutManager
                = new LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false);
        mHorizontalRecyclerView.setLayoutManager(layoutManager);
    }
}
