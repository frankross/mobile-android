/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;

/**
 * Created by gowtham on 22/7/15.
 */

/**
 * Common header data item
 */
public class CommonRecyclerHeaderItem implements BaseRecyclerAdapter.IViewType {

    public String addressHeader;

    public CommonRecyclerHeaderItem(String headerText) {
        addressHeader = headerText;
    }

    @Override
    public int getViewType() {
        return ViewTypes.CommonViewType.COMMON_HEADER_TEXT;
    }
}
