/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by gauthami on 2/5/16.
 */
public class ApiNewTag {

    public static class Request {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("features")
        private List<String> features = new ArrayList<>(1);

        public List<String> getFeatures() {
            return features;
        }

        public void setFeatures(List<String> features) {
            this.features = features;
        }
    }

    public static class Response {

        @SerializedName("features")
        private Features features;

        public Features getFeatures() {
            return features;
        }

        public void setFeatures(Features features) {
            this.features = features;
        }

        public static class Features {

            @SerializedName("home")
            private String home;

            @SerializedName("shop_by_category")
            private String shop_by_category;

            @SerializedName("my_orders")
            private String my_orders;

            @SerializedName("my_prescriptions")
            private String my_prescriptions;

            @SerializedName("frank_ross_wallet")
            private String frank_ross_wallet;

            @SerializedName("offers")
            private String offers;

            @SerializedName("refer_a_friend")
            private String refer_a_friend;

            @SerializedName("emergency_services")
            private String emergency;

            @SerializedName("health_articles")
            private String health_articles;

            @SerializedName("support")
            private String support;

            @SerializedName("store_locator")
            private String store_locator;

            @SerializedName("privacy_policy")
            private String privacy_policy;

            @SerializedName("faqs")
            private String faqs;

            public HashMap<String, String> singleKeyValueToJson() {

                HashMap<String, String> map = new HashMap();
                map.put("home", getHome());
                map.put("shop_by_category", getShop_by_category());
                map.put("my_orders", getMy_orders());
                map.put("my_prescriptions", getMy_prescriptions());
                map.put("frank_ross_wallet", getFrank_ross_wallet());
                map.put("offers", getOffers());
                map.put("health_articles", getHealth_articles());
                map.put("refer_a_friend", getRefer_a_friend());
                map.put("emergency_services", getEmergency());

                map.put("support", getSupport());
                map.put("store_locator", getStore_locator());
                map.put("privacy_policy", getPrivacy_policy());
                map.put("faqs", getFaqs());
                return map;
            }

            private String getHealth_articles() {
                return health_articles;
            }

            private String getRefer_a_friend() {
                return refer_a_friend;
            }

            private String getFaqs() {
                return faqs;
            }

            private String getPrivacy_policy() {
                return privacy_policy;
            }

            private String getStore_locator() {
                return store_locator;
            }

            private String getSupport() {
                return support;
            }

            private String getOffers() {
                return offers;
            }

            private String getFrank_ross_wallet() {
                return frank_ross_wallet;
            }

            private String getMy_prescriptions() {
                return my_prescriptions;
            }

            private String getMy_orders() {
                return my_orders;
            }

            private String getShop_by_category() {
                return shop_by_category;
            }

            private String getHome() {
                return home;
            }

            public String getEmergency() {
                return emergency;
            }
        }
    }
}
