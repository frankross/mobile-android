/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.os.Parcel;
import android.os.Parcelable;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;

/**
 * Created by gowtham on 22/7/15.
 */

/**
 * User information from User API
 */
public class UserInformation implements Parcelable, BaseRecyclerAdapter.IViewType {

    public String userId;
    public String userName;
    public String userMailId;
    public String userMobileNumber;

    public UserInformation() {
    }

    public UserInformation(Parcel source) {
        userId = source.readString();
        userName = source.readString();
        userMailId = source.readString();
        userMobileNumber = source.readString();
    }

    @Override
    public int getViewType() {
        return ViewTypes.AccountViewType.ACCOUNT_VIEW_TYPE_USER_INFO;
    }


    public static Creator<UserInformation> CREATOR = new Creator<UserInformation>() {
        @Override
        public UserInformation createFromParcel(Parcel source) {

            return new UserInformation(source);
        }

        @Override
        public UserInformation[] newArray(int size) {
            return new UserInformation[0];
        }
    };


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(userId);
        dest.writeString(userName);
        dest.writeString(userMailId);
        dest.writeString(userMobileNumber);
    }
}
