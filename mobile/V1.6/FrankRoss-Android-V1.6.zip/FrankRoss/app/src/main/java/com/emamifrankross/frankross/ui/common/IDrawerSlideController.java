/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

/**
 * Created by gowtham on 22/7/15.
 */
public interface IDrawerSlideController {
    void lockDrawer();

    void unlockDrawer();
}
