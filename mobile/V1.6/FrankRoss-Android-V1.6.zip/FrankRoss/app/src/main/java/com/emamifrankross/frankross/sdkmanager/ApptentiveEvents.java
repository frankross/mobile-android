/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.sdkmanager;

/**
 * Created by gauthami on 6/9/16.
 */

/**
 * This class represents the Apptentive SDK events that are recorded in the app from App version 1.5
 */
public class ApptentiveEvents {

    static final String APPTENTIVE_APP_LAUNCH_EVENT = "App_Launched";
    static final String APPTENTIVE_PRESCRIPTIONS_SCREEN_VISIT_EVENT = "Prescriptions_Screen_Visited";
    static final String APPTENTIVE_WALLET_SCREEN_VISIT_EVENT = "FR_Wallet_Screen_Visited";
    static final String APPTENTIVE_ORDER_CONFIRM_EVENT = "Order_Completion";
    static final String APPTENTIVE_HOME_VISITED_EVENT = "Home_Screen_Visited";
    static final String APPTENTIVE_ORDER_CONFIRM_METHOD = "payment_method";
}
