/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.gcm;

import android.content.Intent;

import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.utils.Utils;
import com.google.android.gms.iid.InstanceIDListenerService;

public class FRInstanceIDListenerService extends InstanceIDListenerService {

    private static final String TAG = FRInstanceIDListenerService.class.getSimpleName();

    /**
     * Called if InstanceID token is updated. This may occur if the security of
     * the previous token had been compromised. This call is initiated by the
     * InstanceID provider.
     */
    // [START refresh_token]
    @Override
    public void onTokenRefresh() {
        // Fetch updated Instance ID token and notify our app's server of any changes (if applicable).
        Intent intent = new Intent(this, RegistrationIntentService.class);
        startService(intent);

        callLogout();
    }

    private void callLogout() {
        Utils.clearAccessToken(getApplicationContext());
        ApiRequestManager.getInstance(getApplicationContext()).clearCartItemsCount();
        ApiRequestManager.getInstance(getApplicationContext()).clearNotificationsCount();
    }
    // [END refresh_token]
}
