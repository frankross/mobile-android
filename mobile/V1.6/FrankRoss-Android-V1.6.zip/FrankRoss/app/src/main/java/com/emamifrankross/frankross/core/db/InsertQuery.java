/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.db;

public class InsertQuery<T> extends DBQuery {

	private T mValues;

	public T getValues() {
		return mValues;
	}

	public void setValues(T values) {
		this.mValues = values;
	}

}
