/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.annotations.SerializedName;

/**
 * Created by gauthami on 24/10/16.
 */
public class ApiNotificationCount {

    public static class Request {

    }

    public static class Response {

        @SerializedName("device_notification_count")
        private int notificationsCount;

        public int getNotificationsCount() {
            return notificationsCount;
        }
    }
}
