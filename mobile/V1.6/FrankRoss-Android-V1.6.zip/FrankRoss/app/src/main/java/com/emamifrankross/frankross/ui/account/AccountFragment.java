/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.account;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.PopupMenu;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.Address;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.AccountAdapter;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.home.HomeFragment;
import com.emamifrankross.frankross.ui.viewmodels.CommonRecyclerHeaderItem;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderItem;
import com.emamifrankross.frankross.ui.viewmodels.UserInformation;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by gauthami on 2/7/15.
 */

/**
 * This class represents the UI for Account screen of a logged in user
 */
public class AccountFragment extends ApiRequestBaseFragment implements IToolbar, BaseRecyclerAdapter.RecyclerItemClickListener,
        PopupMenu.OnMenuItemClickListener {

    private static final int REQUEST_CODE_EDIT_PROFILE = 11;
    private static final int REQUEST_CODE_ADD_ADDRESS = 12;
    private static final int REQUEST_CODE_UPDATE_ADDRESS = 13;

    private AccountAdapter mAccountAdapter;
    private ArrayList<BaseRecyclerAdapter.IViewType> mAccountInfoList;
    private UserInformation mUserInfo;
    private List<Address> mAddressList = new ArrayList<>();
    private IUserUpdateNotifier mUserUpdateListener;

    private int mOverFlowClickPosition = 0;

    /**
     * Interface to communicate the user updates
     */
    public interface IUserUpdateNotifier {
        /**
         * Callback to be invoked on fetching the user details
         *
         * @param userName the user full name
         */
        void onUserInfoUpdated(String userName);
    }

    public static AccountFragment create() {
        return new AccountFragment();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            mUserUpdateListener = (IUserUpdateNotifier) getActivity();
        } catch (ClassCastException exception) {
            throw new ClassCastException(context.toString()
                    + " must implement IUserUpdateNotifier");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getAccountAdapterData();
    }

    /**
     * Method that constructs the Account screen data list
     */
    private void getAccountAdapterData() {
        mAccountInfoList = new ArrayList<>();
        mAccountAdapter = new AccountAdapter(mAccountInfoList);

        addUserInfo(mAccountInfoList, false);
        //addOrderInfo(mAccountInfoList);
        addAddressInfo(mAccountInfoList);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_account, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        initAccountRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method to initialize the view associated to the Account screen
     *
     * @param view the root view
     */
    private void initAccountRecyclerView(View view) {
        RecyclerView homeRecyclerView = (RecyclerView) view.findViewById(R.id.account_container);
        homeRecyclerView.setHasFixedSize(false);
        homeRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        mAccountAdapter.setRecyclerItemClickListener(this);
        homeRecyclerView.setAdapter(mAccountAdapter);

        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ACCOUNT_SCREEN_VISIT_EVENT);
    }

    /**
     * Method that adds the Address footer to the UI data list
     *
     * @param accountInfoList the UI data list that has to be adapted
     */
    private void addAddressFooter(ArrayList<BaseRecyclerAdapter.IViewType> accountInfoList) {
        AccountAdapter.AccountAddressFooterItem categoryItem = new AccountAdapter.AccountAddressFooterItem();
        categoryItem.addressFooter = getString(R.string.account_add_new_delivery_address);
        accountInfoList.add(categoryItem);
    }

    /**
     * Method that adds the Address header to the UI data list
     *
     * @param accountInfoList the UI data list that has to be adapted
     */
    private void addAddressHeader(ArrayList<BaseRecyclerAdapter.IViewType> accountInfoList) {
        accountInfoList.add(new RecyclerBorderItem(1));
        CommonRecyclerHeaderItem categoryItem = new CommonRecyclerHeaderItem(getString(R.string.account_address_list_header));
        accountInfoList.add(categoryItem);
    }

    /**
     * Method that adds the User details to the UI data list
     *
     * @param accountInfoList the UI data list that has to be adapted
     * @param isRefresh       the flag to update the user details data item
     */
    private void addUserInfo(final ArrayList<BaseRecyclerAdapter.IViewType> accountInfoList, final boolean isRefresh) {
        mFragmentInteractionListener.showBlockingProgressBar();

        mApiRequestManager.performUserInfoRequest(new ApiRequestManager.IGetUserInfoResultNotifier() {
            @Override
            public void onUserInfoFetched(UserInformation userInfo) {
                mFragmentInteractionListener.hideBlockingProgressBar();
                if (userInfo != null) {
                    mUserInfo = userInfo;

                    if (isRefresh) accountInfoList.remove(0);
                    accountInfoList.add(0, mUserInfo);
                    Utils.saveUserName(getActivity(), mUserInfo.userName);
                    Utils.saveUserMobileNUmber(getActivity(), mUserInfo.userMobileNumber);
                    mAccountAdapter.notifyDataSetChanged();

                    mUserUpdateListener.onUserInfoUpdated(mUserInfo.userName);
                }
            }
        }, this, this);
    }

    /**
     * Method that adds the User addresses to the UI data list
     *
     * @param accountInfoList the UI data list that has to be adapted
     */
    private void addAddressInfo(final ArrayList<BaseRecyclerAdapter.IViewType> accountInfoList) {
        mApiRequestManager.performGetAddressRequest(new ApiRequestManager.IGetAddressResultNotifier() {

            @Override
            public void onAddressFetched(List<AccountAdapter.AccountAddressItem> addressList, List<Address> list) {
                mFragmentInteractionListener.hideBlockingProgressBar();

                if (addressList != null && addressList.size() > 0) {
                    mAddressList.clear();
                    addAddressHeader(accountInfoList);
                    Collections.reverse(addressList);
                    accountInfoList.addAll(addressList);
                    Collections.reverse(list);
                    mAddressList.addAll(list);
                }
                addAddressFooter(accountInfoList);
                mAccountAdapter.notifyDataSetChanged();
            }
        }, this, this);
    }

    /**
     * Method requests for clearing the access token
     */
    private void performLogout() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performLogoutRequest(new ApiRequestManager.ILogoutResultNotifier() {
            @Override
            public void onLogoutCompleted() {
                Utils.clearAccessToken(getActivity().getApplicationContext());
                Utils.saveUserName(getActivity().getApplicationContext(), "");
                Utils.clearUserID(getActivity().getApplicationContext());
                mUserUpdateListener.onUserInfoUpdated("");
                mApiRequestManager.clearCartItemsCount();
                mApiRequestManager.clearNotificationsCount();
                mFragmentInteractionListener.loadFragment(getId(), HomeFragment.create(), null, R.anim.push_left_in, R.anim.push_left_out,
                        FragmentTransactionType.CLEAR_BACK_STACK_AND_REPLACE);
                mFragmentInteractionListener.hideBlockingProgressBar();
            }
        }, this, this);
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {

        if (object == null) return;
        switch (((AccountAdapter.IViewType) object).getViewType()) {
            case ViewTypes.AccountViewType.ACCOUNT_VIEW_TYPE_USER_INFO:
                handleEditProfileClick();
                break;

            case ViewTypes.AccountViewType.ACCOUNT_VIEW_TYPE_ADDRESS:
                handleOverflowIconClick(view, position);
                break;

            case ViewTypes.AccountViewType.ACCOUNT_VIEW_TYPE_FOOTER:
                handleAddNewDeliveryAddressClick();
                break;
        }
    }

    /**
     * Method that handles the address item overflow click
     *
     * @param view     the address item to which the overflow click is associated
     * @param position the index of the item that was tapped in the overflow menu
     */
    private void handleOverflowIconClick(View view, int position) {
        switch (view.getId()) {
            case R.id.account_overflow_icon_iv:
                showPopUp(view, position);
                break;
        }
    }

    /**
     * Method displays a pop up menu on clicking overflow icon of each address
     *
     * @param view     view that was clicked
     * @param position position in the recycler view that corresponds to the each address
     */
    private void showPopUp(View view, int position) {
        mOverFlowClickPosition = position - 3;//no of views above address list
        PopupMenu popup = new PopupMenu(getActivity(), view);
        MenuInflater inflater = popup.getMenuInflater();
        popup.setOnMenuItemClickListener(this);
        inflater.inflate(R.menu.menu_account_address_popup, popup.getMenu());
        popup.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.address_menu_delete:
                showDeleteAddressDialog();
                return true;
            case R.id.address_menu_default:
                performSetAsDefaultAddress();
                return true;
            case R.id.address_menu_edit:
                startActivityForResult(AccountActivity.getActivityIntentForUpdateAddress(getActivity().getApplicationContext(),
                        mAddressList.get(mOverFlowClickPosition)),
                        REQUEST_CODE_UPDATE_ADDRESS);
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                return true;
            default:
                return false;
        }
    }

    /**
     * Method displays alert dialog for deleting address;If Yes,requests for deleting the address
     */
    private void showDeleteAddressDialog() {
        mFragmentInteractionListener.showAlert(getString(R.string.account_delete_address_dialog_title),
                getString(R.string.account_delete_address_dialog_msg), getString(R.string.no), getString(R.string.yes),
                null, new AlertDialogFragment.AlertNegativeActionListener() {
                    @Override
                    public void onNegativeAction() {
                        performDeleteAddress();
                    }
                }, true);
    }

    /**
     * Method requests for delete address;If success, refresh the addresses
     */
    private void performDeleteAddress() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performDeleteAddressRequest(mAddressList.get(mOverFlowClickPosition).getId(),
                new ApiRequestManager.IDeleteAddressResultNotifier() {
                    @Override
                    public void onAddressDeleted() {
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.DELETE_DELIVERY_ADDRESS_EVENT);
                        refreshAddresses();
                    }
                }, this, this);
    }

    /**
     * Method requests for set as default address;If success, refresh the addresses
     */
    private void performSetAsDefaultAddress() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performDefaultAddressRequest(String.valueOf(mAddressList.get(mOverFlowClickPosition).getId()),
                true, new ApiRequestManager.IDefaultAddressResultNotifier() {

                    @Override
                    public void onDefaultAddressSet() {
                        mFragmentInteractionListener.hideBlockingProgressBar();
                        showAlert(getString(R.string.set_default_address_success), new AlertDialogFragment.AlertPositiveActionListener() {
                            @Override
                            public void onPositiveAction() {
                                refreshAddresses();
                            }
                        }, false);
                    }
                }, this, this);
    }

    /**
     * Method that refreshes the Address list
     */
    private void refreshAddresses() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mAccountInfoList.clear();
        mAccountInfoList.add(mUserInfo);
        //addOrderInfo(mAccountInfoList);
        addAddressInfo(mAccountInfoList);
    }

    /**
     * Method that refreshes the User information
     */
    private void refreshAccountInfo() {
        addUserInfo(mAccountInfoList, true);
    }

    /**
     * Method that handles the Edit Profile click by loading the new screen
     */
    private void handleEditProfileClick() {
        startActivityForResult(AccountActivity.getActivityIntentForEditProfile(getActivity().getApplicationContext(), mUserInfo),
                REQUEST_CODE_EDIT_PROFILE);
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    /**
     * Method that handles the Add new Delivery address from the overflow menu
     * associated with each address in the Addresses section
     */
    private void handleAddNewDeliveryAddressClick() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ADD_NEW_DELIVERY_ADDRESS_EVENT);
        startActivityForResult(AccountActivity.getActivityIntentForAddAddress(getActivity().getApplicationContext()),
                REQUEST_CODE_ADD_ADDRESS);
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_CODE_EDIT_PROFILE) {
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.EDIT_DELIVERY_ADDRESS_EVENT);
                refreshAccountInfo();
            } else if (requestCode == REQUEST_CODE_ADD_ADDRESS || requestCode == REQUEST_CODE_UPDATE_ADDRESS) {
                refreshAddresses();
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.menu;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return null;
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_my_account);
    }

    @Override
    public int getToolbarMenuId() {
        return R.menu.menu_login;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_logout:
                        performLogout();
                        return true;
                }
                return false;
            }
        };
    }
}
