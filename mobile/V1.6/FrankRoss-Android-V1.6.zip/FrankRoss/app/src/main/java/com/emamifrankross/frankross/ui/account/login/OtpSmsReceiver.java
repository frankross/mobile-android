/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.account.login;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.text.TextUtils;

import com.emamifrankross.frankross.core.apimodels.ApiSettings;
import com.emamifrankross.frankross.utils.Log;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gauthami on 1/3/16.
 */

/**
 * This class represents the OTP retrieval from the received message
 */
public class OtpSmsReceiver extends BroadcastReceiver {

    private static final String TAG = OtpSmsReceiver.class.getSimpleName();
    private static final String MESSAGE_PDUS_FORMAT = "pdus";//PDU is a “protocol data unit”, which is the industry format for an SMS message

    private final ApiSettings.Response.SettingsInfo mOtpSettings;//The OTP settings that are received from Settings API
    private IOtpReceivedListener mIOtpReceivedListener;//The listener that corresponds to OTP auto-read

    public OtpSmsReceiver() {
        mOtpSettings = null;
    }

    public OtpSmsReceiver(ApiSettings.Response.SettingsInfo otpSettings) {
        mOtpSettings = otpSettings;
    }

    /**
     * Interface to communicate OTP read success/failure
     */
    interface IOtpReceivedListener {
        /**
         * Callback to be invoked on successful reading of OTP
         *
         * @param otpCode the otp code that is read from the authorized message
         */
        void onOtpReceived(String otpCode);

        /**
         * Callback to be invoked on failure cases of reading of OTP
         */
        void onOtpReadError();
    }

    public void setOtpReceivedListener(IOtpReceivedListener mIOtpReceivedListener) {
        this.mIOtpReceivedListener = mIOtpReceivedListener;
    }

    @Override
    @Deprecated
    public void onReceive(Context context, Intent intent) {
        final Bundle bundle = intent.getExtras();
        try {
            if (bundle != null) {
                Object[] pdusObj = (Object[]) bundle.get(MESSAGE_PDUS_FORMAT);

                if (pdusObj != null) {
                    for (Object pduObj : pdusObj) {

                        SmsMessage currentMessage = SmsMessage.createFromPdu((byte[]) pduObj);
                        String senderAddress = currentMessage.getDisplayOriginatingAddress();
                        String message = currentMessage.getDisplayMessageBody();
                        Log.d(TAG, "Received SMS: " + message + ", Sender: " + senderAddress);

                        if (!senderAddress.toLowerCase().contains(mOtpSettings.getOtpSender().toLowerCase()) &&
                                !message.contains(mOtpSettings.getOtpPrefixMessage())) {
                            return;
                        }
                        //Get the otp code from message
                        String otpCode = Utils.getOtpFromMessage(message, mOtpSettings.getOtpPrefixMessage());

                        //Check for listeners based on success/failure
                        if (mIOtpReceivedListener != null && !TextUtils.isEmpty(otpCode)) {
                            mIOtpReceivedListener.onOtpReceived(otpCode);
                        } else if (mIOtpReceivedListener != null) {
                            mIOtpReceivedListener.onOtpReadError();
                        }
                        Log.d(TAG, "OTP received: " + otpCode);
                    }
                }
            }
        } catch (Exception e) {
            Log.d(TAG, "Exception: " + e.getMessage());
        }
    }
}