/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.account;

import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.ui.account.login.EnterOTPFragment;
import com.emamifrankross.frankross.ui.account.login.AccountOTPFragment;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.viewmodels.UserInformation;
import com.emamifrankross.frankross.utils.NetworkUtils;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gauthami on 7/7/15.
 */

/**
 * This class represents the UI for Edit profile screen of a logged in user
 */
public class EditProfileFragment extends ApiRequestBaseFragment implements IToolbar, View.OnClickListener {

    private static final String TAG = EditProfileFragment.class.getSimpleName();
    private static final String BUNDLE_KEY_USER_INFO = "userInfo";

    private EditText mUserName;
    private EditText mUserMobileNumber;
    private RobotoTextView mUserMailId;
    private View mView;

    private UserInformation mUserInformation;

    public static EditProfileFragment create(UserInformation userInformation) {
        EditProfileFragment editProfileFragment = new EditProfileFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelable(BUNDLE_KEY_USER_INFO, userInformation);
        editProfileFragment.setArguments(bundle);

        return editProfileFragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mUserInformation = getArguments().getParcelable(BUNDLE_KEY_USER_INFO);
        }
        //Since the first editable field gets focused and opens the keyboard by default -To avoid the scenario
        getActivity().getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_edit_profile, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
        setData();
    }

    /**
     * Method that initializes the views
     *
     * @param view the root view
     */
    private void initViews(View view) {
        mUserName = (EditText) view.findViewById(R.id.edit_profile_user_name_tv);
        mUserMailId = (RobotoTextView) view.findViewById(R.id.edit_profile_user_mail_id_tv);
        mUserMobileNumber = (EditText) view.findViewById(R.id.edit_profile_user_mobile_number_tv);
        RobotoTextView changePassword = (RobotoTextView) view.findViewById(R.id.edit_profile_change_password_txt_tv);
        Button editProfileSubmit = (Button) view.findViewById(R.id.edit_profile_submit_btn);
        mView = view.findViewById(R.id.edit_profile_user_mail_id_view);

        changePassword.setOnClickListener(this);
        editProfileSubmit.setOnClickListener(this);
    }

    /**
     * Method that sets the default data to the views
     */
    private void setData() {
        if (mUserInformation != null) {
            mUserName.setText(mUserInformation.userName);
            mUserName.setSelection(mUserInformation.userName.length());
            if (TextUtils.isEmpty(mUserInformation.userMailId)) {
                mView.setVisibility(View.GONE);
                mUserMailId.setVisibility(View.GONE);
            } else {
                mUserMailId.setText(mUserInformation.userMailId);
            }
            mUserMobileNumber.setText(mUserInformation.userMobileNumber);
            mUserMobileNumber.setSelection(mUserInformation.userMobileNumber.length());
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.edit_profile_change_password_txt_tv:
                loadChangePasswordFragment();
                break;

            case R.id.edit_profile_submit_btn:
                String userName = (mUserName.getText() != null) ? mUserName.getText().toString() : "";
                String phoneNumber = (mUserMobileNumber.getText() != null) ? mUserMobileNumber.getText().toString() : "";

                if (validateData(userName, phoneNumber)) {
                    /*EditProfilePasswordDialogFragment editProfilePasswordDialogFragment =
                            EditProfilePasswordDialogFragment.create(mUserInformation.userMobileNumber);
                    editProfilePasswordDialogFragment.show(getActivity().getSupportFragmentManager(), TAG);*/
                    onVerifyViaOTPClick();
                } else if (mUserInformation.userMobileNumber.equals(phoneNumber) && mUserInformation.userName.equals(userName)) {
                    getActivity().finish();
                }
                break;
        }
    }

    /**
     * Method requests for Updating user information;If success,
     * checks whether the mobile number is changed then display the Enter OTP screen,
     * otherwise displays the success dialog
     */
    private void performUpdateUserInfo(String userName, String phoneNumber, final String password) {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performUpdateUserInfoRequest(userName, phoneNumber, new ApiRequestManager.IUpdateUserInfoResultNotifier() {
            @Override
            public void onUserInfoUpdated() {
                mFragmentInteractionListener.hideBlockingProgressBar();

                if (mUserInformation.userMobileNumber.equals(mUserMobileNumber.getText().toString())) {
                    showUpdateProfileAlert();
                } else {
                    mFragmentInteractionListener.loadFragment(getId(), EnterOTPFragment.create(false, false, "",
                            mUserMobileNumber.getText().toString(), password, null), null, R.anim.push_left_in, R.anim.fade_out,
                            BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                }

            }
        }, this, this);
    }

    /**
     * Method that pops out the Update profile success dialog also defines the positive action
     */
    private void showUpdateProfileAlert() {
        showAlert(getString(R.string.profile_updated_successfully), new AlertDialogFragment.AlertPositiveActionListener() {
            @Override
            public void onPositiveAction() {
                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
            }
        }, false);
    }

    /**
     * @return If false,displays the input or network error dialog with appropriate message;else true.
     */
    private boolean validateData(String userName, String phoneNumber) {
        if (TextUtils.isEmpty(userName)) {
            showAlert(getString(R.string.please_enter_your_name));
        } else if (TextUtils.isEmpty(phoneNumber)) {
            showAlert(getString(R.string.please_enter_your_number));
        } else if (Utils.isValidPhoneNumber(phoneNumber) && phoneNumber.length() < 10) {
            showAlert(getString(R.string.please_enter_a_valid_number));
        } else if (!NetworkUtils.isNetworkConnected(getActivity().getApplicationContext())) {
            showAlert(getString(R.string.please_check_your_network_connection));
        } else
            return !(mUserInformation.userMobileNumber.equals(phoneNumber) && mUserInformation.userName.equals(userName));
        return false;
    }

    /**
     * Method that launches the Change Password screen
     */
    private void loadChangePasswordFragment() {
        mFragmentInteractionListener.loadFragment(getId(), ChangePasswordFragment.create(), null, R.anim.push_left_in, R.anim.fade_out,
                BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    /**
     * Callback received from paren on password validation successful
     *
     * @param password the password that was validated
     */
    public void onPasswordValidated(String password) {
        hide_keyboard(getActivity(), mUserMobileNumber);
        performUpdateUserInfo(mUserName.getText().toString(), mUserMobileNumber.getText().toString(), password);
    }

    /**
     * Callback received from paren on password validation successful
     */
    public void onVerifyViaOTPClick() {
        hide_keyboard(getActivity(), mUserMobileNumber);
        mFragmentInteractionListener.loadFragment(getId(), AccountOTPFragment.create(false, false, false, false, "",
                mUserInformation.userMobileNumber, mUserMobileNumber.getText().toString(),
                null, mUserName.getText().toString(), null), null, R.anim.push_left_in, R.anim.fade_out,
                BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().setResult(Activity.RESULT_OK);
                getActivity().finish();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_edit);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }
}
