/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;

import com.android.volley.toolbox.NetworkImageView;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiReturnReasons;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.NumberPickerWidget;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.customviews.VolleySingleton;
import com.emamifrankross.frankross.ui.viewmodels.CommonRecyclerHeaderViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderDataBinder;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 4/8/16.
 * <p/>
 * <p> Adapter class for Return Management Section</p>
 * <p> Supports the Six View Types </p>
 * <p> 1 : RETURNABLE PRODUCTS ITEM VIEW TYPE </p>
 * <p> 2 : NON RETURNABLE PRODUCTS ITEM VIEW TYPE </p>
 * <p> 3 : RETURN PRODUCTS PICKUP SLOT VIEW TYPE </p>
 * <p> 4 : RETURN PRODUCTS REASON/COMMENT VIEW TYPE </p>
 * <p> 5 : COMMON HEADER VIEW TYPE </p>
 * <p> 6 : COMMON BORDER VIEW TYPE </p>
 */
public class ReturnProductsAdapter extends BaseRecyclerAdapter {

    public ReturnProductsAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        ArrayList<RecyclerViewDataBinder> viewHolderTypes = new ArrayList<>(1);
        viewHolderTypes.add(new ReturnableProductsItemViewHolderType());
        viewHolderTypes.add(new NonReturnableProductsItemViewHolderType());
        viewHolderTypes.add(new ReturnProductsPickUpSlotViewHolderType());
        viewHolderTypes.add(new ReturnProductsReasonCommentViewHolderType());
        viewHolderTypes.add(new RecyclerBorderDataBinder());
        viewHolderTypes.add(new CommonRecyclerHeaderViewDataBinder());
        return viewHolderTypes;
    }

    /**
     * RETURNABLE PRODUCTS ITEM VIEW TYPE
     */
    public static class ReturnableProductsItemDataModel implements IViewType {

        public long productId = 0;
        public String productName = "";
        public String productImageUrl = "";
        public int orderQuantity = 0;

        @Override
        public int getViewType() {
            return ViewTypes.ReturnManagementViewType.RETURNABLE_PRODUCT_VIEW_TYPE;
        }
    }

    public class ReturnableProductsItemViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mProductName;
        private NetworkImageView mProductImage;
        private RobotoTextView mProductOrderedQuantity;
        private NumberPickerWidget mProductQuantityPicker;

        public ReturnableProductsItemViewHolder(View itemView) {
            super(itemView);

            mProductImage = (NetworkImageView) itemView.findViewById(R.id.return_product_icon_iv);
            mProductName = (RobotoTextView) itemView.findViewById(R.id.return_product_title_tv);
            mProductOrderedQuantity = (RobotoTextView) itemView.findViewById(R.id.return_product_max_quantity_tv);
            mProductQuantityPicker = (NumberPickerWidget) itemView.findViewById(R.id.return_product_number_picker);

            mProductImage.setDefaultImageResId(R.drawable.product_logo);
            mProductImage.setErrorImageResId(R.drawable.product_logo);
            mProductQuantityPicker.setValue(1);
        }
    }

    public class ReturnableProductsItemViewHolderType implements
            RecyclerViewDataBinder<ReturnableProductsItemViewHolder, ReturnableProductsItemDataModel> {

        @Override
        public ReturnableProductsItemViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.return_product_list_item,
                    parent, false);
            return new ReturnableProductsItemViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(ReturnableProductsItemViewHolder viewHolder,
                                         final ReturnableProductsItemDataModel data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mProductName.setText(data.productName);
            Animation fadeInAnimation = AnimationUtils.loadAnimation(viewHolder.
                    mProductImage.getContext(), R.anim.fade_in);
            viewHolder.mProductImage.startAnimation(fadeInAnimation);
            viewHolder.mProductImage.setImageUrl(data.productImageUrl, VolleySingleton.
                    getInstance(viewHolder.mProductImage.getContext()).getImageLoader());
            viewHolder.mProductOrderedQuantity.setText(data.orderQuantity + "");
            viewHolder.mProductQuantityPicker.setMaxValue(data.orderQuantity);
        }

        @Override
        public int getViewType() {
            return ViewTypes.ReturnManagementViewType.RETURNABLE_PRODUCT_VIEW_TYPE;
        }
    }

    /**
     * NON RETURNABLE PRODUCTS ITEM VIEW TYPE
     */
    public static class NonReturnableProductsItemDataModel implements IViewType {

        public long productId = 0;
        public String productName = "";
        public String productImageUrl = "";
        public String returnErrorMessage = "";

        @Override
        public int getViewType() {
            return ViewTypes.ReturnManagementViewType.NON_RETURNABLE_PRODUCT_VIEW_TYPE;
        }
    }

    public class NonReturnableProductsItemViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mProductName;
        private NetworkImageView mProductImage;
        private RobotoTextView mProductErrorMessage;

        public NonReturnableProductsItemViewHolder(View itemView) {
            super(itemView);

            mProductImage = (NetworkImageView) itemView.findViewById(R.id.non_returnable_product_icon_iv);
            mProductName = (RobotoTextView) itemView.findViewById(R.id.non_returnable_product_title_tv);
            mProductErrorMessage = (RobotoTextView) itemView.findViewById(R.id.non_returnable_product_error_message_tv);

            mProductImage.setDefaultImageResId(R.drawable.product_logo);
            mProductImage.setErrorImageResId(R.drawable.product_logo);
        }
    }

    public class NonReturnableProductsItemViewHolderType implements
            RecyclerViewDataBinder<NonReturnableProductsItemViewHolder, NonReturnableProductsItemDataModel> {

        @Override
        public NonReturnableProductsItemViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.non_returnable_product_list_item,
                    parent, false);
            return new NonReturnableProductsItemViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(NonReturnableProductsItemViewHolder viewHolder,
                                         final NonReturnableProductsItemDataModel data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mProductName.setText(data.productName);
            Animation fadeInAnimation = AnimationUtils.loadAnimation(viewHolder.
                    mProductImage.getContext(), R.anim.fade_in);
            viewHolder.mProductImage.startAnimation(fadeInAnimation);
            viewHolder.mProductImage.setImageUrl(data.productImageUrl, VolleySingleton.
                    getInstance(viewHolder.mProductImage.getContext()).getImageLoader());
            viewHolder.mProductErrorMessage.setText(data.returnErrorMessage);
        }

        @Override
        public int getViewType() {
            return ViewTypes.ReturnManagementViewType.NON_RETURNABLE_PRODUCT_VIEW_TYPE;
        }
    }

    /**
     * RETURN PRODUCTS REASON/COMMENT VIEW TYPE
     */
    public static class ReturnProductsReasonCommentDataItem implements IViewType {

        public String returnSelectedReason = "";
        public String returnSelectedComment = "";
        public List<ApiReturnReasons> returnReasonsData;

        public ReturnProductsReasonCommentDataItem(List<ApiReturnReasons> returnReasonsData) {
            this.returnReasonsData = returnReasonsData;
        }

        @Override
        public int getViewType() {
            return ViewTypes.ReturnManagementViewType.RETURN_REASON_COMMENT_VIEW_TYPE;
        }
    }

    public static class ReturnProductsReasonCommentViewHolder extends RecyclerView.ViewHolder {

        private Spinner mReturnReason;
        private EditText mReturnComment;

        public ReturnProductsReasonCommentViewHolder(View view) {
            super(view);

            mReturnComment = (EditText) itemView.findViewById(R.id.return_order_comments_et);
            mReturnReason = (Spinner) itemView.findViewById(R.id.return_order_reason_spinner);

        }
    }

    private class ReturnProductsReasonCommentViewHolderType implements RecyclerViewDataBinder<ReturnProductsReasonCommentViewHolder,
            ReturnProductsReasonCommentDataItem> {
        @Override
        public ReturnProductsReasonCommentViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.return_product_reason_comment_item, parent, false);
            return new ReturnProductsReasonCommentViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final ReturnProductsReasonCommentViewHolder viewHolder, final ReturnProductsReasonCommentDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {

            final Context context = viewHolder.mReturnReason.getContext();
            final SpinnerHintAdapter spinnerHintAdapter = new SpinnerHintAdapter(context,
                    data.returnReasonsData, R.layout.return_products_custom_spinner_item);
            viewHolder.mReturnReason.setAdapter(spinnerHintAdapter);
            if (Utils.getSpinnerSelectedItemPosition(context) == -1) {
                viewHolder.mReturnReason.post(new Runnable() {
                    public void run() {
                        viewHolder.mReturnReason.setSelection(spinnerHintAdapter.getCount(), false);
                    }
                });
            } else {
                viewHolder.mReturnReason.post(new Runnable() {
                    public void run() {
                        viewHolder.mReturnReason.setSelection(Utils.getSpinnerSelectedItemPosition(context), false);
                    }
                });
            }

            viewHolder.mReturnReason.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int selectedPosition, long id) {

                    RobotoTextView spinnerLabel = (RobotoTextView) view.findViewById(R.id.return_products_spinner_reason_tv);
                    ImageView spinnerSelectIcon = (ImageView) view.findViewById(R.id.return_products_spinner_reason_select_iv);
                    String returnReason = spinnerLabel.getText().toString();

                    spinnerLabel.setTextColor(ContextCompat.getColor(context,
                            returnReason.equals(context.getString(R.string.return_product_select_reason_hint)) ?
                                    R.color.sign_in_screen_edit_text_color :
                                    R.color.common_sub_header_text_color));

                    data.returnSelectedReason = returnReason;
                    for (ApiReturnReasons apiReturnReasons : data.returnReasonsData) {
                        apiReturnReasons.setSelected(apiReturnReasons.getReturnReason().equals(returnReason));
                    }

                    Utils.saveSpinnerSelectedItemPosition(context,
                            returnReason.equals(context.getString(R.string.return_product_select_reason_hint)) ? -1 : selectedPosition);

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });

            viewHolder.mReturnComment.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                    data.returnSelectedComment = TextUtils.isEmpty(charSequence) ? "" : charSequence.toString();
                }

                @Override
                public void afterTextChanged(Editable s) {
                }
            });

        }

        @Override
        public int getViewType() {
            return ViewTypes.ReturnManagementViewType.RETURN_REASON_COMMENT_VIEW_TYPE;
        }
    }

    /**
     * RETURN PRODUCTS PICKUP SLOT VIEW TYPE
     */
    public static class ReturnProductsPickUpSlotDataItem implements IViewType {

        public String deliverySlotHeader = "";
        public String deliverySlotTime = "";

        @Override
        public int getViewType() {
            return ViewTypes.ReturnManagementViewType.RETURN_PICK_UP_SLOT_VIEW_TYPE;
        }
    }

    public static class ReturnProductsPickUpSlotViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mCheckOutAddressHeader;
        private RobotoTextView mCheckOutChangeAddress;
        private RobotoTextView mCheckOutUserName;
        private RobotoTextView mCheckOutAddress;
        private RobotoTextView mCheckOutMobileNumber;
        private ImageView mCheckOutNextIcon;

        public ReturnProductsPickUpSlotViewHolder(View view, Context context) {
            super(view);
            mCheckOutAddressHeader = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_header_tv);
            mCheckOutChangeAddress = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_change_tv);
            mCheckOutUserName = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_user_name_tv);
            mCheckOutAddress = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_full_address_tv);
            mCheckOutMobileNumber = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_mobile_number_tv);
            mCheckOutNextIcon = (ImageView) view.findViewById(R.id.check_out_deliver_to_next_icon_iv);

            mCheckOutMobileNumber.setVisibility(View.GONE);
            mCheckOutChangeAddress.setVisibility(View.GONE);
            mCheckOutNextIcon.setVisibility(View.VISIBLE);
            mCheckOutNextIcon.setEnabled(false);
            view.findViewById(R.id.card_view_linLyt).setBackgroundColor(ContextCompat.getColor(view.getContext(),
                    R.color.white_background));
        }
    }

    private class ReturnProductsPickUpSlotViewHolderType implements RecyclerViewDataBinder<ReturnProductsPickUpSlotViewHolder,
            ReturnProductsPickUpSlotDataItem> {
        @Override
        public ReturnProductsPickUpSlotViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.check_out_deliver_to, parent, false);

            return new ReturnProductsPickUpSlotViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(ReturnProductsPickUpSlotViewHolder viewHolder, final ReturnProductsPickUpSlotDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            if (!TextUtils.isEmpty(data.deliverySlotHeader)) {
                viewHolder.mCheckOutAddressHeader.setText(viewHolder.mCheckOutAddressHeader.getResources().getString(R.string.return_products_pickup_slot));
                viewHolder.mCheckOutUserName.setVisibility(View.VISIBLE);
                viewHolder.mCheckOutUserName.setText(data.deliverySlotHeader);
            } else {
                viewHolder.mCheckOutAddressHeader.setText(viewHolder.mCheckOutAddressHeader.getResources().getString(R.string.return_products_pick_up_header));
                viewHolder.mCheckOutUserName.setVisibility(View.GONE);
            }

            if (!TextUtils.isEmpty(data.deliverySlotTime)) {
               /* viewHolder.mCheckOutAddressHeader.setText(viewHolder.mCheckOutAddressHeader.getContext().getResources().
                        getString(R.string.check_out_delivery_slot));*/
                viewHolder.mCheckOutAddress.setVisibility(View.VISIBLE);
                viewHolder.mCheckOutAddress.setText(data.deliverySlotTime);
            } else {
                viewHolder.mCheckOutAddress.setVisibility(View.GONE);
            }
            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.ReturnManagementViewType.RETURN_PICK_UP_SLOT_VIEW_TYPE;
        }
    }
}
