/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.notification;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.core.network.UrlConstants;
import com.emamifrankross.frankross.gcm.NotificationTypes;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.ui.account.login.LogInActivity;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.NotificationCenterAdapter;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.common.WebViewActivity;
import com.emamifrankross.frankross.ui.common.WebViewFragment;
import com.emamifrankross.frankross.ui.order.OrderHistoryActivity;
import com.emamifrankross.frankross.ui.pharmacy.PharmacyActivity;
import com.emamifrankross.frankross.ui.pharmacy.ProductListingActivity;
import com.emamifrankross.frankross.ui.products.ProductDetailActivity;
import com.emamifrankross.frankross.ui.referral.ReferFriendActivity;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Log;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 17/10/16.
 */

/**
 * This class represents the UI for Notification centre screen
 */
public class NotificationCenterFragment extends ApiRequestBaseFragment implements
        BaseRecyclerAdapter.RecyclerItemClickListener, IToolbar, NotificationTypes {

    private static final String TAG = NotificationCenterFragment.class.getSimpleName();

    private static final String EXTRA_NOTIFICATION_COUNT_KEY = "notificationCount";
    private ArrayList<BaseRecyclerAdapter.IViewType> mNotificationCenterScreenData = new ArrayList<>();
    private NotificationCenterAdapter mNotificationCenterRecyclerAdapter;

    private int mNotificationsCount = 0;

    public static NotificationCenterFragment create(int notificationCount) {
        NotificationCenterFragment notificationCenterFragment = new NotificationCenterFragment();

        Bundle bundle = new Bundle();
        bundle.putInt(EXTRA_NOTIFICATION_COUNT_KEY, notificationCount);
        notificationCenterFragment.setArguments(bundle);

        return notificationCenterFragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mNotificationsCount = getArguments().getInt(EXTRA_NOTIFICATION_COUNT_KEY);
        }

        mNotificationCenterRecyclerAdapter = new NotificationCenterAdapter(mNotificationCenterScreenData);
        performNotificationCenterRequest();
        //FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.STORE_LOCATOR_LAUNCH_EVENT);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_notifications, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initNotificationCenterRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method requests for notifications list
     */
    private void performNotificationCenterRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        mApiRequestManager.performNotificationCentreRequest(mNotificationsCount, new ApiRequestManager.INotificationCenterResultNotifier() {
            @Override
            public void onNotificationCenterRequestResultFetched(List<BaseRecyclerAdapter.IViewType> notificationsList) {
                mFragmentInteractionListener.hideBlockingProgressBar();
                mNotificationCenterScreenData.clear();
                mNotificationCenterScreenData.addAll(notificationsList);
                mNotificationCenterRecyclerAdapter.notifyDataSetChanged();
                performNotificationsReadRequest();
            }
        }, this, this);
    }

    /**
     * Method requests for notifications list to be marked as read
     */
    private void performNotificationsReadRequest() {
        if (mNotificationsCount != 0) {
            mApiRequestManager.performNotificationsReadRequest(this, this);
            mApiRequestManager.clearNotificationsCount();
            mNotificationsCount = 0;
        }
    }

    /**
     * Method that initializes the Fragment's view
     *
     * @param view the view associated to the Store Locator fragment
     */
    private void initNotificationCenterRecyclerView(View view) {
        RecyclerView notificationCenterRecyclerView = (RecyclerView) view.findViewById(R.id.notifications_container);
        notificationCenterRecyclerView.setHasFixedSize(false);
        notificationCenterRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mNotificationCenterRecyclerAdapter.setRecyclerItemClickListener(this);
        notificationCenterRecyclerView.setAdapter(mNotificationCenterRecyclerAdapter);
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {
            case ViewTypes.NotificationCenterViewType.NOTIFICATION_OFFER_ITEM_VIEW_TYPE:
                NotificationCenterAdapter.NotificationsOfferDataItem notificationOffersDataItem =
                        (NotificationCenterAdapter.NotificationsOfferDataItem) object;
                offersCopyToClipboard(notificationOffersDataItem.notificationPromoCode);

                notificationOffersDataItem.isRead = true;
                mNotificationCenterRecyclerAdapter.notifyItemChanged(position);

                handleItemClick(notificationOffersDataItem.notificationType, notificationOffersDataItem.notificationWebUrl,
                        notificationOffersDataItem.promotionId);
                break;
            case ViewTypes.NotificationCenterViewType.NOTIFICATION_BACK_IN_STOCK_ITEM_VIEW_TYPE:
                NotificationCenterAdapter.NotificationsBackInStockDataItem notificationBackInStockDataItem =
                        (NotificationCenterAdapter.NotificationsBackInStockDataItem) object;

                notificationBackInStockDataItem.isRead = true;
                mNotificationCenterRecyclerAdapter.notifyItemChanged(position);

                handleProductDetailLaunch(notificationBackInStockDataItem.variantId,
                        notificationBackInStockDataItem.isPharma);
                break;
            case ViewTypes.NotificationCenterViewType.NOTIFICATION_DEFAULT_ITEM_VIEW_TYPE:
                NotificationCenterAdapter.NotificationsDefaultDataItem notificationsDefaultDataItem =
                        (NotificationCenterAdapter.NotificationsDefaultDataItem) object;

                notificationsDefaultDataItem.isRead = true;
                mNotificationCenterRecyclerAdapter.notifyItemChanged(position);

                handleNotificationsDefaultItemClick(notificationsDefaultDataItem);
                break;
            case ViewTypes.NotificationCenterViewType.NOTIFICATION_PDP_ITEM_VIEW_TYPE:
                NotificationCenterAdapter.NotificationsProductDetailDataItem notificationsProductDetailDataItem =
                        (NotificationCenterAdapter.NotificationsProductDetailDataItem) object;

                notificationsProductDetailDataItem.isRead = true;
                mNotificationCenterRecyclerAdapter.notifyItemChanged(position);

                handleNotificationsPDPItemClick(notificationsProductDetailDataItem);
                break;
            case ViewTypes.NotificationCenterViewType.NOTIFICATION_EMPTY_ITEM_VIEW_TYPE:
                closeNotificationScreen();
                break;
        }
    }

    private void closeNotificationScreen() {
        getActivity().onBackPressed();
    }

    private void handleNotificationsPDPItemClick(NotificationCenterAdapter.NotificationsProductDetailDataItem
                                                         notificationsProductDetailDataItem) {
        //Type 17
        loadProductDetailActivity(notificationsProductDetailDataItem.variantId, notificationsProductDetailDataItem.isPharma);
    }

    private void handleNotificationsDefaultItemClick(NotificationCenterAdapter.NotificationsDefaultDataItem
                                                             notificationsDefaultDataItem) {

        switch (notificationsDefaultDataItem.notificationType) {
            case DIGITISATION_FAILURE:
                //Type 1
                loadPrescriptionDetailsActivity(notificationsDefaultDataItem.prescriptionId);
                return;

            case CART_PREPARED:
                //Type 2
                loadCartActivity();
                return;

            case ORDER_REVISION:
            case ORDER_STATUS_UPDATE:
                //Type 3 & 4
                loadOrderDetailsActivity(notificationsDefaultDataItem.orderId);
                return;

            case CATEGORY:
                //Type 11
                loadCategoryActivity(notificationsDefaultDataItem.categoryId, "");
                return;

            case PROMOTION_PRODUCT_LISTING:
                //Type 12
                loadProductListingFragment(notificationsDefaultDataItem.promotionId);
                return;

            case HOME_COPY_CODE:
                //Type 13 - alert
                loadHomeFragmentFromNotificationFlow(notificationsDefaultDataItem.notificationPromoCode);
                return;

            case CATEGORY_COPY_CODE:
                //Type 14 - alert
                loadCategoryActivity(notificationsDefaultDataItem.categoryId, notificationsDefaultDataItem.notificationPromoCode);
                return;

            case HTML_PAGE:
                //Type 15
                loadPromotionalDetail(notificationsDefaultDataItem.notificationWebUrl, getString(R.string.category_promotion_details));
                return;

            case REFER_A_FRIEND:
                //Type 16
                loadReferFriendActivity();
                return;

            case HEALTH_ARTICLES:
                //Type 18
                loadPromotionalDetail(notificationsDefaultDataItem.notificationWebUrl, getString(R.string.drawer_menu_health_articles));
                return;

            case GENERAL_PROMOTION_SPECIFIC_USER:
            case GENERAL_PROMOTION_ALL_USER:
            case HOME:
            default:
                //Type 5,6 & 10
                closeNotificationScreen();
                break;
        }
    }

    /**
     * Method launches Product Detail Activity
     */
    private void loadProductDetailActivity(long variantId, boolean isPharma) {
        if (variantId != 0) {
            startActivityForResult(ProductDetailActivity.getActivityIntent(getActivity(),
                    isPharma ? ProductDetailActivity.PHARMA_PRODUCT_DETAIL_FRAGMENT_ID :
                            ProductDetailActivity.NON_PHARMA_PRODUCT_DETAIL_FRAGMENT_ID,
                    variantId), Constants.REQUEST_CODE_BRANCH_DEEPLINKING);
            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    /**
     * Method loads the Refer a Friend screen if the user is already logged in
     */
    private void loadReferFriendActivity() {
        int installedAppVersion = Integer.parseInt(UrlConstants.API_VERSION.replaceAll("\\D+", ""));
        if (installedAppVersion > 5) {
            if (Utils.isLoggedIn(getActivity().getApplicationContext())) {
                startActivity(ReferFriendActivity.getActivityIntent(getActivity().getApplicationContext(), ReferFriendActivity.INVITE_FRIENDS_FRAGMENT));
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
            } else {
                startActivityForResult(LogInActivity.getActivityIntent(getActivity().getApplicationContext(), false,
                        LogInActivity.LOG_IN_FRAGMENT), Constants.REQUEST_CODE_INVITE_FRIENDS);
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
            }
        }
    }

    /**
     * Method to load the specific link in app's web view
     *
     * @param pageLink     the web url associated with the offer
     * @param toolbarTitle the web page title
     */
    private void loadPromotionalDetail(String pageLink, String toolbarTitle) {
        if (!TextUtils.isEmpty(pageLink)) {
            startActivityForResult(WebViewActivity.getActivityIntentForWebViewFragment(getActivity().getApplicationContext(),
                    WebViewActivity.WEB_VIEW_FRAGMENT_ID, pageLink, toolbarTitle),
                    Constants.REQUEST_CODE_WEB_VIEW);
            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    /**
     * Method to load the Home screen in notification flow
     *
     * @param couponCode the coupon code associated with the offer
     */
    private void loadHomeFragmentFromNotificationFlow(String couponCode) {
        if (!TextUtils.isEmpty(couponCode)) {
            Utils.copyToClipboard(couponCode, getActivity());
            Toast.makeText(getActivity().getApplicationContext(), "Coupon code " + couponCode + " is copied to clipboard",
                    Toast.LENGTH_LONG).show();
            closeNotificationScreen();
        }
    }

    /**
     * Method mto load the Product Listing screen
     *
     * @param promotionId the promotion id associated with the offer
     */
    private void loadProductListingFragment(long promotionId) {
        if (promotionId != 0) {
            startActivityForResult(ProductListingActivity.getActivityIntentForHomePromotionalProducts(getActivity().getApplicationContext(),
                    ProductListingActivity.PROMOTIONAL_PRODUCTS_FRAGMENT_ID, promotionId), Constants.REQUEST_CODE_PRODUCT_LISTING);
            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    /**
     * Method to load the category page
     *
     * @param categoryId the category id
     * @param couponCode the coupon code associated with the offer
     */
    private void loadCategoryActivity(long categoryId, String couponCode) {
        if (!TextUtils.isEmpty(couponCode)) {
            Utils.copyToClipboard(couponCode, getActivity());
            Toast.makeText(getActivity().getApplicationContext(), "Coupon code " + couponCode + " is copied to clipboard",
                    Toast.LENGTH_SHORT).show();
        }
        if (categoryId != 0) {
            startActivity(PharmacyActivity.getActivityIntent(getActivity().getApplicationContext(),
                    PharmacyActivity.PHARMACY_SUB_CATEGORY_FRAGMENT_ID, null, categoryId));
            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    /**
     * Method to load the prescription detail page
     *
     * @param prescriptionId the prescription id
     */
    private void loadPrescriptionDetailsActivity(long prescriptionId) {
        if (prescriptionId != 0) {
            startActivityForResult(
                    OrderHistoryActivity.getActivityIntent(getActivity().getApplicationContext(),
                            OrderHistoryActivity.PRESCRIPTION_DETAILS_FRAGMENT_ID, prescriptionId), Constants.REQUEST_CODE_PRESCRIPTION_DETAIL);
            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    /**
     * Method to load Cart screen
     */
    private void loadCartActivity() {
        startActivityForResult(CartActivity.getActivityIntent(getActivity().getApplicationContext(),
                CartActivity.CART_FRAGMENT_ID), Constants.REQUEST_CODE_CART);
    }

    /**
     * Method to load the Order details screen
     *
     * @param orderId the order id
     */
    private void loadOrderDetailsActivity(long orderId) {
        if (orderId != 0) {
            startActivityForResult(OrderHistoryActivity.getActivityIntent(getActivity().getApplicationContext(),
                    OrderHistoryActivity.ORDER_HISTORY_DETAILS_FRAGMENT_ID, orderId), Constants.REQUEST_CODE_ORDER_HISTORY);
            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    /**
     * Method to handle the Back in stock notification data item
     *
     * @param variantId the product variant id
     * @param isPharma  pharma or non pharma product
     */
    private void handleProductDetailLaunch(long variantId, boolean isPharma) {
        if (variantId != 0) {
            startActivityForResult(ProductDetailActivity.getActivityIntent(getActivity(),
                    isPharma ?
                            ProductDetailActivity.PHARMA_PRODUCT_DETAIL_FRAGMENT_ID :
                            ProductDetailActivity.NON_PHARMA_PRODUCT_DETAIL_FRAGMENT_ID,
                    variantId), Constants.REQUEST_CODE_BRANCH_DEEPLINKING);
            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    /**
     * Method to handle the Banner image click
     *
     * @param notificationType the notification type; id that identifies each type of notification
     * @param webUrl           the web page url for promotional details
     * @param promotionId      the promotional ID for each offer
     */
    private void handleItemClick(int notificationType, String webUrl, long promotionId) {
        if (promotionId != 0) {
            startActivity(ProductListingActivity.getActivityIntentForHomePromotionalProducts(getActivity().getApplicationContext(),
                    ProductListingActivity.PROMOTIONAL_PRODUCTS_FRAGMENT_ID, promotionId));
            getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);

        } else if (!TextUtils.isEmpty(webUrl)) {

            switch (notificationType) {

                case HTML_PAGE:
                    //Type 15
                    mFragmentInteractionListener.loadFragment(getId(),
                            WebViewFragment.create(webUrl,
                                    getString(R.string.category_promotion_details)),
                            null, R.anim.push_left_in, R.anim.fade_out,
                            FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                    return;

                case HEALTH_ARTICLES:
                    //Type 18
                    mFragmentInteractionListener.loadFragment(getId(),
                            WebViewFragment.create(webUrl,
                                    getString(R.string.drawer_menu_health_articles)),
                            null, R.anim.push_left_in, R.anim.fade_out,
                            FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                    return;

                default:
                    closeNotificationScreen();
                    break;
            }
        }
    }

    /**
     * Method to handle the promo code click
     *
     * @param promoCode the promo code that has to be copied to clipboard
     */
    private void offersCopyToClipboard(String promoCode) {
        if (!TextUtils.isEmpty(promoCode)) {
            Utils.copyToClipboard(promoCode, getActivity());
            Toast.makeText(getActivity(), "Coupon code " + promoCode + " is copied to clipboard",
                    Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());

        mApiRequestManager.registerCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());

        mApiRequestManager.unregisterCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeNotificationScreen();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_notifications);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.d(TAG, "onActivityResult");

        switch (requestCode) {
            case Constants.REQUEST_CODE_INVITE_FRIENDS:
                if (Utils.isLoggedIn(getActivity().getApplicationContext())) {
                    startActivity(ReferFriendActivity.getActivityIntent(getActivity().getApplicationContext(),
                            ReferFriendActivity.INVITE_FRIENDS_FRAGMENT));
                    getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                }
                break;
        }
    }
}
