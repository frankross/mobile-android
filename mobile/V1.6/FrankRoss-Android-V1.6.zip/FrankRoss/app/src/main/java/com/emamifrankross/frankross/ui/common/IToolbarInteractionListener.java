/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

/**
 * Created by gowtham on 5/7/15.
 */
public interface IToolbarInteractionListener {
    void updateToolbar(IToolbar toolbar);
}
