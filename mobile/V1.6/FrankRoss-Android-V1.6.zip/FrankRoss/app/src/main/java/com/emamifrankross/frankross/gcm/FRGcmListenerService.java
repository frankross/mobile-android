/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.gcm;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.NotificationCompat;
import android.text.TextUtils;
import android.util.Log;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.sdkmanager.ApptentiveManager;
import com.emamifrankross.frankross.ui.home.HomeActivity;
import com.emamifrankross.frankross.utils.Utils;
import com.google.android.gms.gcm.GcmListenerService;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

public class FRGcmListenerService extends GcmListenerService {

    private static final String TAG = FRGcmListenerService.class.getSimpleName();

    /**
     * ANDROID SPECIFIC KEYS
     */
    private static final String NOTIFICATION_MESSAGE_KEY = "message";//No idea
    private static final String NOTIFICATION_IMAGE_URL_KEY = "url";//Only for Image based push notification
    private static final String NOTIFICATION_SUBJECT_KEY = "sub";//Android notification subject

    /**
     * COMMON TO ANDROID & IOS
     */
    private static final String NOTIFICATION_FAILED_IMAGE_URL_KEY = "furl";//Prescriptions - Failed prescription
    private static final String NOTIFICATION_HTML_PAGE_KEY = "page_link";//Html page link
    private static final String NOTIFICATION_COUPON_ID_KEY = "cid";//Offer coupon code
    private static final String NOTIFICATION_TYPE_KEY = "nt";//Notification type
    private static final String NOTIFICATION_ID_KEY = "id";//This is notification type specific:Can be order id,prescription id etc.
    private static final String NOTIFICATION_IS_PHARMA_KEY = "is_pharma";//Product type - pharma or non-pharma

    /**
     * IOS SPECIFIC KEYS
     */
    private static final String NOTIFICATION_IOS_MESSAGE_KEY = "alert";//iOS notification subject
    private static final String NOTIFICATION_IOS_MESSAGE_BODY_KEY = "aps";//iOS notification subject body

    @Override
    public void onMessageReceived(String from, Bundle data) {

        Log.d(TAG, "data: " + data);

        String apptentiveSubject = "";
        if (ApptentiveManager.setApptentivePushNotificationData(data)) {
            //Notification is from Apptentive
            apptentiveSubject = data.getString(ApptentiveManager.APPTENTIVE_NOTIFICATION_BODY_KEY);
        }

        String message = data.getString(NOTIFICATION_MESSAGE_KEY);
        String imageUrl = data.getString(NOTIFICATION_IMAGE_URL_KEY);
        String failedUrl = data.getString(NOTIFICATION_FAILED_IMAGE_URL_KEY);
        String pageLink = data.getString(NOTIFICATION_HTML_PAGE_KEY);
        String couponCode = data.getString(NOTIFICATION_COUPON_ID_KEY);
        String subject = TextUtils.isEmpty(apptentiveSubject) ?
                data.getString(NOTIFICATION_SUBJECT_KEY) :
                apptentiveSubject;
        boolean isPharma = data.getBoolean(NOTIFICATION_IS_PHARMA_KEY);

        long id = 0;
        int type = 0;
        try {
            type = Integer.parseInt(data.getString(NOTIFICATION_TYPE_KEY));
            id = Long.parseLong(data.getString(NOTIFICATION_ID_KEY));
        } catch (NumberFormatException numberFormatException) {

        }

        /**
         * For iOS
         */
        String json = data.getString(NOTIFICATION_IOS_MESSAGE_BODY_KEY);
        String alertMessage = "";
        if (!TextUtils.isEmpty(json)) {
            try {
                JSONObject jObject = new JSONObject(json);
                if (jObject != null && jObject.has(NOTIFICATION_IOS_MESSAGE_KEY))
                    alertMessage = jObject.getString(NOTIFICATION_IOS_MESSAGE_KEY);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        Log.d(TAG, "From: " + from);
        Log.d(TAG, "Message: " + message);
        Log.d(TAG, "Type: " + type);
        Log.d(TAG, "id: " + id);
        Log.d(TAG, "url: " + imageUrl);
        Log.d(TAG, "failed url: " + failedUrl);
        Log.d(TAG, "pageLink: " + pageLink);
        Log.d(TAG, "coupon code: " + couponCode);
        Log.d(TAG, "subject: " + subject);
        Log.d(TAG, "alert: " + alertMessage);
        Log.d(TAG, "apptentive subject: " + apptentiveSubject);
        Log.d(TAG, "isPharma: " + isPharma);

        EFNotification efNotification = new EFNotification();
        efNotification.setId(id);
        efNotification.setMessage(message);
        efNotification.setNotificationType(type);
        efNotification.setFurl(failedUrl);
        efNotification.setImageUrl(imageUrl);
        efNotification.setCouponCode(couponCode);
        efNotification.setPageLink(pageLink);
        efNotification.setSubject(subject);
        efNotification.setAlertMessage(alertMessage);
        efNotification.setApptentiveNotification(apptentiveSubject);
        efNotification.setIsPharma(isPharma);

        sendNotification(efNotification);
    }

    private void sendNotification(EFNotification efNotification) {
        Intent intent = HomeActivity.getActivityIntentForNotification(getApplicationContext(),
                HomeActivity.HOME_FRAGMENT_TAG, efNotification);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, Utils.getRandomNumForPushNotificationStacking(), intent,
                PendingIntent.FLAG_UPDATE_CURRENT);

        Bitmap bm = BitmapFactory.decodeResource(getResources(), R.mipmap.app_icon);
        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.mipmap.push_notif_app_icon)//R.mipmap.calender
                .setLargeIcon(bm)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(efNotification.getSubject())
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setVibrate(new long[0])
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setContentIntent(pendingIntent);

        String url = efNotification.getImageUrl();

        if (url != null && !TextUtils.isEmpty(url)) {
            NotificationCompat.BigPictureStyle bigPicNotificationStyle = new NotificationCompat.BigPictureStyle();
            bigPicNotificationStyle.setBigContentTitle(getString(R.string.app_name));
            bigPicNotificationStyle.setSummaryText(efNotification.getSubject());
            Bitmap remote_picture = null;
            //String sample_url = "https://s3-ap-southeast-1.amazonaws.com/emami-images/HomePageBanner/trust.png";
            try {
                remote_picture = BitmapFactory.decodeStream((InputStream) new URL(url).getContent());
            } catch (IOException e) {
                e.printStackTrace();
            }
            bigPicNotificationStyle.bigPicture(remote_picture);
            //bigPicNotificationStyle.bigPicture(BitmapFactory.decodeResource(this.getResources(), R.drawable.notification));
            notificationBuilder.setStyle(bigPicNotificationStyle);
        } else {
            // only message
            NotificationCompat.BigTextStyle bigTextNotificationStyle = new NotificationCompat.BigTextStyle();
            bigTextNotificationStyle.bigText(efNotification.getSubject());
            notificationBuilder.setStyle(bigTextNotificationStyle);
        }

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(Utils.getRandomNumForPushNotificationStacking(), notificationBuilder.build());
    }
}
