/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by gowtham on 3/8/15.
 */
public class ApiCart {

    public static class Request {
        @SerializedName("line_items")
        private List<RequestCartItem> requestCartItems;

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        public List<RequestCartItem> getRequestCartItems() {
            return requestCartItems;
        }

        public void setRequestCartItems(List<RequestCartItem> requestCartItems) {
            this.requestCartItems = requestCartItems;
        }
    }

    public static class CouponRequest {
        @SerializedName("coupon_code")
        private String couponCode = "";

        public CouponRequest(String couponCode) {
            this.couponCode = couponCode;
        }

        public String toJsonString() {
            return new Gson().toJson(this);
        }
    }

    public static class Response {

        private List<BaseRecyclerAdapter.IViewType> uiDataList;
        @SerializedName("cart")
        private Cart cart;

        public List<BaseRecyclerAdapter.IViewType> getUiDataList() {
            return uiDataList;
        }

        public void setUiDataList(List<BaseRecyclerAdapter.IViewType> uiDataList) {
            this.uiDataList = uiDataList;
        }

        public Cart getCart() {
            return cart;
        }

        public void setCart(Cart cart) {
            this.cart = cart;
        }
    }

    public static class UpdateWalletRequest {

        @SerializedName("debit")
        private int mDebit;

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        public boolean isDebit() {
            return mDebit == 1;
            //return mDebit;
        }

        public void setDebit(boolean debit) {
            this.mDebit = debit ? 1 : 0;
            //this.mDebit = debit;
        }
    }

}
