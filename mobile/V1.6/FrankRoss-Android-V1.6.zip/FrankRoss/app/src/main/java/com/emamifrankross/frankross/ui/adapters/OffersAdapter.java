/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;

import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.NetworkImageView;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.VolleySingleton;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderDataBinder;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 24/9/15.
 * <p> Adapter class for Offers Section</p>
 * <p>Supports the One View Types </p>
 * <p> 1 : OFFER ITEM VIEW TYPE </p>
 * <p> 2 : COMMON BORDER VIEW TYPE </p>
 */
public class OffersAdapter extends BaseRecyclerAdapter {

    public OffersAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewHolderTypeList = new ArrayList<>(1);
        viewHolderTypeList.add(new OffersItemViewHolderType());
        viewHolderTypeList.add(new RecyclerBorderDataBinder());

        return viewHolderTypeList;
    }

    /**
     * OFFER ITEM VIEW TYPE
     */
    public static class OffersDataItem implements IViewType {

        public String offerImageUrl = "";
        public String offerPromoCode = "";
        public String offerWebUrl = "";
        public long offerPromotionId = 0;
        public boolean isLongTap = false;
        public boolean listable = true;

        @Override
        public int getViewType() {
            return ViewTypes.OffersViewType.OFFER_ITEM_VIEW_TYPE;
        }
    }

    private static class OffersItemViewHolder extends RecyclerView.ViewHolder {

        private LinearLayout mOfferItemLinLyt;
        private NetworkImageView mOfferImage;

        public OffersItemViewHolder(View itemView) {
            super(itemView);
            mOfferItemLinLyt = (LinearLayout) itemView.findViewById(R.id.offers_item_background_linLyt);
            mOfferImage = (NetworkImageView) itemView.findViewById(R.id.offer_image_iv);

            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (int) (0.23 * Utils.getDisplayHeight((Activity) mOfferImage.getContext())));
            mOfferImage.setLayoutParams(layoutParams);
        }
    }

    private static class OffersItemViewHolderType implements
            RecyclerViewDataBinder<OffersItemViewHolder, OffersDataItem> {

        @Override
        public OffersItemViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.offers_list_item, parent, false);

            return new OffersItemViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(OffersItemViewHolder viewHolder,
                                         final OffersDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {

            ImageLoader imageLoader = VolleySingleton.getInstance(viewHolder.mOfferImage.getContext()).getImageLoader();
            viewHolder.mOfferImage.setImageUrl(data.offerImageUrl, imageLoader);
            viewHolder.mOfferImage.setDefaultImageResId(R.drawable.pdp_placeholder);
            viewHolder.mOfferImage.setErrorImageResId(R.drawable.pdp_placeholder);
            Animation fadeInAnimation = AnimationUtils.loadAnimation(viewHolder.mOfferImage.getContext(), R.anim.fade_in);
            viewHolder.mOfferImage.startAnimation(fadeInAnimation);

            if (recyclerViewClickListener != null) {

                viewHolder.mOfferItemLinLyt.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        data.isLongTap = true;
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                        return true;
                    }
                });

                viewHolder.mOfferItemLinLyt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        data.isLongTap = false;
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.OffersViewType.OFFER_ITEM_VIEW_TYPE;
        }
    }
}
