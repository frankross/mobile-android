/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.utils.Log;

import java.util.HashMap;
import java.util.List;

/**
 * Created by gowtham on 30/6/15.
 * <p> Base Adapter class </p>
 * <p> Adds all the View Types,creates the view holder and sets the page end and click listeners </p>
 */
public abstract class BaseRecyclerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public interface IViewType {
        int getViewType();
    }

    public interface RecyclerViewDataBinder<G extends RecyclerView.ViewHolder, T extends IViewType> extends IViewType {
        G getViewHolder(ViewGroup parent);

        void bindDataToViewHolder(G viewHolder, T data, int position, RecyclerItemClickListener recyclerViewClickListener);
    }

    public interface OnPageEndListener {
        void onPageEnd(int position);
    }

    public interface RecyclerItemClickListener {
        void onRecyclerItemClick(int position, View view, Object object);
    }

    protected abstract
    @NonNull
    List<RecyclerViewDataBinder> getViewDataBinders();

    private HashMap<Integer, RecyclerViewDataBinder> mRecyclerViewTypes;
    private List<IViewType> mDataList;
    private RecyclerItemClickListener mRecyclerItemClickListener;
    private OnPageEndListener mOnPageEndListener;

    public BaseRecyclerAdapter(@NonNull List<IViewType> dataList) {
        mDataList = dataList;
        List<RecyclerViewDataBinder> recyclerViewHolderTypes = getViewDataBinders();
        mRecyclerViewTypes = new HashMap<>(recyclerViewHolderTypes.size());

        for (RecyclerViewDataBinder recyclerViewHolderType : recyclerViewHolderTypes) {
            mRecyclerViewTypes.put(recyclerViewHolderType.getViewType(), recyclerViewHolderType);
        }
    }

    public void setRecyclerItemClickListener(RecyclerItemClickListener recyclerItemClickListener) {
        mRecyclerItemClickListener = recyclerItemClickListener;
    }

    public void setRecyclerOnPageEndListener(OnPageEndListener onPageEndListener) {
        mOnPageEndListener = onPageEndListener;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerViewDataBinder recyclerViewType = mRecyclerViewTypes.get(viewType);

        if (recyclerViewType == null) {
            Log.d("RECYCLER", "View type not added = " + viewType);
        }

        return recyclerViewType.getViewHolder(parent);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (position == getItemCount() - 1 && mOnPageEndListener != null) {
            mOnPageEndListener.onPageEnd(position + 1);
        }
        RecyclerViewDataBinder recyclerViewType = mRecyclerViewTypes.get(getItemViewType(position));
        recyclerViewType.bindDataToViewHolder(holder, mDataList.get(position), position, mRecyclerItemClickListener);
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }


    @Override
    public int getItemViewType(int position) {
        return mDataList.get(position).getViewType();
    }
}
