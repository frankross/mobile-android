/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.app.Activity;
import android.graphics.Paint;
import android.support.annotation.NonNull;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiNonPharmaProduct;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.CirclePageIndicator;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.viewmodels.CommonRecyclerHeaderViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.ProductViewDataBinder;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderDataBinder;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 14/7/15.
 * <p> Adapter class for Non Pharma Product Detail Section</p>
 * <p>Supports the Nine View Types </p>
 * <p> 1 : PRODUCT DETAILS VIEW TYPE </p>
 * <p> 2 : TOP OFFERS VIEW PAGER VIEW TYPE  </p>
 * <p> 3 : KEY FEATURES VIEW TYPE </p>
 * <p> 4 : PRODUCT DESCRIPTION VIEW TYPE </p>
 * <p> 5 : CUSTOMER REVIEWS VIEW TYPE </p>
 * <p> 6 : REVIEW INFO VIEW TYPE </p>
 * <p> 7 : TOP SELLING PRODUCT HEADER </p>
 * <p> 8 : COMMON HERDER VIEW TYPE </p>
 * <p> 9 : COMMON BORDER VIEW TYPE </p>
 */
public class NonPharmaProductDetailAdapter extends BaseRecyclerAdapter {

    public NonPharmaProductDetailAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewDataBinderList = new ArrayList<>(1);
        viewDataBinderList.add(new ProductDetailsViewDataBinder());
        viewDataBinderList.add(new NonPharmaProductImageViewPagerViewDataBinder());
        viewDataBinderList.add(new KeyFeaturesViewDataBinder());
        viewDataBinderList.add(new ProductVariantViewDataBinder());
        viewDataBinderList.add(new ProductViewDataBinder());
        viewDataBinderList.add(new RecyclerBorderDataBinder());
        viewDataBinderList.add(new CommonRecyclerHeaderViewDataBinder());
        viewDataBinderList.add(new ViewMoreProductViewDataBinder());
        viewDataBinderList.add(new KeyFeaturesHeaderViewDataBinder());
        viewDataBinderList.add(new PharmaProductDetailAdapter.QuestionAnswerViewDataBinder());

        return viewDataBinderList;
    }

    /**
     * PRODUCT DETAILS VIEW TYPE
     */
    public static class ProductDetailsDataItem implements IViewType {

        public ApiNonPharmaProduct mNonPharmaProduct;

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.PRODUCT_DETAILS;
        }
    }

    private static class ProductDetailsViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mPharmacyProductName;
        private RobotoTextView mPharmacyProductCompanyName;
        private RobotoTextView mPharmacyProductOfferPrice;
        private RobotoTextView mPharmacyProductActualPrice;
        private RobotoTextView mPharmacyProductDiscount;
        private RobotoTextView mPharmacyProductAvailability;
        private RobotoTextView mPharmacyProductCashBackMessage;
        private LinearLayout mPharmacyProductCashBackLinLyt;

        public ProductDetailsViewHolder(View itemView) {
            super(itemView);

            mPharmacyProductName = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_name_tv);
            mPharmacyProductCompanyName = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_medicine_company_tv);
            mPharmacyProductOfferPrice = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_offer_price_tv);
            mPharmacyProductActualPrice = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_actual_price_tv);
            mPharmacyProductDiscount = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_discount_tv);
            mPharmacyProductAvailability = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_availabilty_txt_tv);

            mPharmacyProductCashBackLinLyt = (LinearLayout) itemView.findViewById(R.id.pharmacy_product_detail_cashback_message_linLyt);
            mPharmacyProductCashBackMessage = (RobotoTextView) itemView.findViewById(R.id.pharmacy_product_detail_cashback_message_tv);

            mPharmacyProductActualPrice.setPaintFlags(mPharmacyProductActualPrice.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
        }
    }

    private static class ProductDetailsViewDataBinder implements
            RecyclerViewDataBinder<ProductDetailsViewHolder, ProductDetailsDataItem> {

        @Override
        public ProductDetailsViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.non_pharmacy_product_info, parent, false);

            return new ProductDetailsViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(ProductDetailsViewHolder viewHolder,
                                         final ProductDetailsDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mPharmacyProductName.setText(data.mNonPharmaProduct.getProductName());
            viewHolder.mPharmacyProductCompanyName.setText("By " + data.mNonPharmaProduct.getBrandName());
            viewHolder.mPharmacyProductAvailability.setText(data.mNonPharmaProduct.getProductInventoryLabel());

            if (data.mNonPharmaProduct.isCashBack()) {
                viewHolder.mPharmacyProductCashBackLinLyt.setVisibility(View.VISIBLE);
                viewHolder.mPharmacyProductCashBackMessage.setText(data.mNonPharmaProduct.getProductCashBackMessage());
            } else {
                viewHolder.mPharmacyProductCashBackLinLyt.setVisibility(View.GONE);
            }

            if (data.mNonPharmaProduct.getDiscount() > 0) {
                viewHolder.mPharmacyProductDiscount.setVisibility(View.VISIBLE);
                viewHolder.mPharmacyProductActualPrice.setVisibility(View.VISIBLE);
                viewHolder.mPharmacyProductDiscount.setText(Utils.getDiscountFormattedDouble(data.mNonPharmaProduct.getDiscount()) + "% off");
                viewHolder.mPharmacyProductActualPrice.setText(Utils.addRupeeSymbol(viewHolder.mPharmacyProductActualPrice.getContext(), "",
                        Utils.getFormattedDouble(data.mNonPharmaProduct.getMrpPrice())));
                viewHolder.mPharmacyProductOfferPrice.setText(Utils.addRupeeSymbol(viewHolder.mPharmacyProductOfferPrice.getContext(), "",
                        Utils.getFormattedDouble(data.mNonPharmaProduct.getPromotionalPrice())));
            } else {
                viewHolder.mPharmacyProductDiscount.setVisibility(View.GONE);
                viewHolder.mPharmacyProductActualPrice.setVisibility(View.GONE);
                viewHolder.mPharmacyProductOfferPrice.setText(Utils.addRupeeSymbol(viewHolder.mPharmacyProductOfferPrice.getContext(), "",
                        Utils.getFormattedDouble(data.mNonPharmaProduct.getSellingPrice())));
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.PRODUCT_DETAILS;
        }
    }

    /**
     * PRODUCT IMAGES VIEW PAGER VIEW TYPE
     */

    public static class NonPharmaProductImageViewPagerDataItem implements IViewType {
        public List<String> mNonPharmaProductImagePagerDataList;

        @Override
        public int getViewType() {
            return ViewTypes.CommonViewType.TOP_OFFERS_VIEW_PAGER;
        }
    }

    private static class NonPharmaProductImageViewPagerViewHolder extends RecyclerView.ViewHolder {
        private ViewPager mNonPharmaProductImageViewPager;
        private CirclePageIndicator mNonPharmaProductImagePagerIndicator;

        public NonPharmaProductImageViewPagerViewHolder(View itemView) {
            super(itemView);
            mNonPharmaProductImageViewPager = (ViewPager) itemView.findViewById(R.id.home_top_offers_pager);
            FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, (int) (0.35 * Utils.getDisplayHeight((Activity) mNonPharmaProductImageViewPager.getContext())));
            mNonPharmaProductImageViewPager.setLayoutParams(layoutParams);
            mNonPharmaProductImagePagerIndicator = (CirclePageIndicator) itemView.findViewById(R.id.top_offers_pager_indicator);
        }
    }

    private static class NonPharmaProductImageViewPagerViewDataBinder implements
            RecyclerViewDataBinder<NonPharmaProductImageViewPagerViewHolder, NonPharmaProductImageViewPagerDataItem> {

        @Override
        public NonPharmaProductImageViewPagerViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.home_top_offers, parent, false);

            return new NonPharmaProductImageViewPagerViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final NonPharmaProductImageViewPagerViewHolder viewHolder,
                                         NonPharmaProductImageViewPagerDataItem data, int position,
                                         RecyclerItemClickListener recyclerViewClickListener) {

            viewHolder.mNonPharmaProductImageViewPager.setAdapter(new TopOffersAdapter(data.mNonPharmaProductImagePagerDataList));
            if (data.mNonPharmaProductImagePagerDataList.size() > 1) {
                viewHolder.mNonPharmaProductImagePagerIndicator.getBackground().setAlpha((int) (0.7F * 255));
                viewHolder.mNonPharmaProductImagePagerIndicator.setViewPager(viewHolder.mNonPharmaProductImageViewPager);
            }
            viewHolder.mNonPharmaProductImageViewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
                @Override
                public void onPageSelected(int position) {
                    viewHolder.mNonPharmaProductImagePagerIndicator.setCurrentItem(position);
                }
            });
        }

        @Override
        public int getViewType() {
            return ViewTypes.CommonViewType.TOP_OFFERS_VIEW_PAGER;
        }
    }

    /**
     * KEY FEATURES HEADER VIEW TYPE
     */
    public static class KeyFeaturesHeaderDataItem implements IViewType {

        public String headerTitle;

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.KEY_FEATURES_HEADER;
        }
    }

    private static class KeyFeaturesHeaderViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mKeyFeaturesTitle;

        public KeyFeaturesHeaderViewHolder(View itemView) {
            super(itemView);
            mKeyFeaturesTitle = (RobotoTextView) itemView.findViewById(R.id.non_pharma_key_features_title_tv);
        }
    }

    public static class KeyFeaturesHeaderViewDataBinder implements
            RecyclerViewDataBinder<KeyFeaturesHeaderViewHolder, KeyFeaturesHeaderDataItem> {

        @Override
        public KeyFeaturesHeaderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.non_pharma_key_features_header, parent, false);
            return new KeyFeaturesHeaderViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(KeyFeaturesHeaderViewHolder viewHolder,
                                         final KeyFeaturesHeaderDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mKeyFeaturesTitle.setText(data.headerTitle);
        }

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.KEY_FEATURES_HEADER;
        }
    }

    /**
     * KEY FEATURES VIEW TYPE
     */
    public static class KeyFeaturesDataItem implements IViewType {

        public String keyFeature;
        public static final String BULLET_SYMBOL = "&#8226";

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.KEY_FEATURES;
        }
    }

    private static class KeyFeaturesViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mKeyFeature;

        public KeyFeaturesViewHolder(View itemView) {
            super(itemView);
            mKeyFeature = (RobotoTextView) itemView.findViewById(R.id.non_pharma_product_detail_key_feature_tv);
        }
    }

    private static class KeyFeaturesViewDataBinder implements
            RecyclerViewDataBinder<KeyFeaturesViewHolder, KeyFeaturesDataItem> {

        @Override
        public KeyFeaturesViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.non_pharma_key_features, parent, false);

            return new KeyFeaturesViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(KeyFeaturesViewHolder viewHolder,
                                         final KeyFeaturesDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mKeyFeature.setText(Html.fromHtml(data.keyFeature));
        }

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.KEY_FEATURES;
        }
    }

    /**
     * PRODUCT DESCRIPTION HEADER VIEW TYPE
     *//*
    public static class ProductDescriptionHeaderDataItem implements IViewType {

        public String headerTitle;

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.PRODUCT_SPECS_HEADER;
        }
    }

    private static class ProductDescriptionHeaderViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mDescriptionTitle;

        public ProductDescriptionHeaderViewHolder(View itemView) {
            super(itemView);
            mDescriptionTitle = (RobotoTextView) itemView.findViewById(R.id.non_pharma_product_description_header_tv);
        }
    }

    private static class ProductDescriptionHeaderViewDataBinder implements
            RecyclerViewDataBinder<ProductDescriptionHeaderViewHolder, ProductDescriptionHeaderDataItem> {

        @Override
        public ProductDescriptionHeaderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.non_pharma_product_specs_header, parent, false);

            return new ProductDescriptionHeaderViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(ProductDescriptionHeaderViewHolder viewHolder,
                                         final ProductDescriptionHeaderDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mDescriptionTitle.setText(data.headerTitle);
        }

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.PRODUCT_SPECS_HEADER;
        }
    }
*/

    /**
     * PRODUCT VARIANT VIEW TYPE
     */
    public static class ProductVariantDataItem implements IViewType {
        public boolean isPrimaryVariant;
        public String variantName;
        public String variantValue;
        public List<BaseRecyclerAdapter.IViewType> mVariantSupportedValues;

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.PRODUCT_VARIANTS;
        }
    }

    private static class ProductVariantViewHolder extends RecyclerView.ViewHolder {

        public RobotoTextView mVariantName;
        public RobotoTextView mVariantValue;
        public LinearLayout mVariantLayout;
        public ImageView mImageView;

        public ProductVariantViewHolder(View itemView) {
            super(itemView);

            mVariantName = (RobotoTextView) itemView.findViewById(R.id.non_pharma_variant_name_tv);
            mVariantValue = (RobotoTextView) itemView.findViewById(R.id.non_pharma_variant_value_tv);
            mImageView = (ImageView) itemView.findViewById(R.id.non_pharma_variant_next_iv);
            mVariantLayout = (LinearLayout) itemView.findViewById(R.id.non_pharma_variant_linLay);
        }
    }

    private static class ProductVariantViewDataBinder implements
            RecyclerViewDataBinder<ProductVariantViewHolder, ProductVariantDataItem> {

        @Override
        public ProductVariantViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.non_pharma_product_variant, parent, false);

            return new ProductVariantViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(ProductVariantViewHolder viewHolder,
                                         final ProductVariantDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mVariantName.setText(data.variantName);
            viewHolder.mVariantValue.setText(data.variantValue);

            if (data.mVariantSupportedValues.size() > 1) {
                viewHolder.mImageView.setVisibility(View.VISIBLE);
            } else {
                viewHolder.mImageView.setVisibility(View.GONE);
            }

            if (recyclerViewClickListener != null) {
                viewHolder.mVariantLayout.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.ProductDetailViewType.PRODUCT_VARIANTS;
        }
    }

    /**
     * TOP SELLING PRODUCT HEADER
     */
    public static class TopSellingProductsHeaderDataItem implements IViewType {
        public String listHeader;

        public TopSellingProductsHeaderDataItem(String listHeader) {
            this.listHeader = listHeader;
        }

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.TOP_SELLING_PRODUCTS_HEADER;
        }
    }

    private static class TopSellingProductsHeaderViewHolder extends RecyclerView.ViewHolder {
        private RobotoTextView mListHeader;

        public TopSellingProductsHeaderViewHolder(View itemView) {
            super(itemView);

            mListHeader = (RobotoTextView) itemView.findViewById(R.id.top_selling_products_list_header_tv);
        }
    }

    private static class TopSellingProductsHeaderViewDataBinder implements
            RecyclerViewDataBinder<TopSellingProductsHeaderViewHolder, TopSellingProductsHeaderDataItem> {

        @Override
        public TopSellingProductsHeaderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.top_selling_products_list_header, parent, false);
            return new TopSellingProductsHeaderViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(TopSellingProductsHeaderViewHolder viewHolder,
                                         TopSellingProductsHeaderDataItem data,
                                         int position, RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mListHeader.setText(data.listHeader);
        }

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.TOP_SELLING_PRODUCTS_HEADER;
        }
    }


    /**
     * VIEW MORE VIEW TYPE
     */

    public static class ViewMoreDataItem implements IViewType {
        public boolean showProgressBar = false;

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.VIEW_MORE_PRODUCTS;
        }
    }

    public static class ViewMoreViewHolder extends RecyclerView.ViewHolder {

        public ProgressBar mViewMoreProgressBar;

        public ViewMoreViewHolder(View itemView) {
            super(itemView);
            mViewMoreProgressBar = (ProgressBar) itemView.findViewById(R.id.view_more_progressBar);
        }
    }

    private static class ViewMoreProductViewDataBinder implements
            RecyclerViewDataBinder<ViewMoreViewHolder, ViewMoreDataItem> {

        @Override
        public ViewMoreViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.top_selling_product_list_load_more, parent, false);
            return new ViewMoreViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(ViewMoreViewHolder viewHolder, final ViewMoreDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mViewMoreProgressBar.setVisibility((data.showProgressBar) ? View.VISIBLE : View.GONE);

            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                        data.showProgressBar = true;
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.HomeViewType.VIEW_MORE_PRODUCTS;
        }
    }
}
