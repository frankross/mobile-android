/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.annotations.SerializedName;

/**
 * Created by gauthami on 2/5/16.
 */
public class ApiReferFriend {

    public static class Response {

        @SerializedName("referral_details")
        private InviteInfo inviteInfo;

        @SerializedName("social_sharing_details")
        private SocialSharingDetails socialSharingDetails;

        public InviteInfo getInviteInfo() {
            return inviteInfo;
        }

        public void setInviteInfo(InviteInfo inviteInfo) {
            this.inviteInfo = inviteInfo;
        }

        public SocialSharingDetails getSocialSharingDetails() {
            return socialSharingDetails;
        }

        public void setSocialSharingDetails(SocialSharingDetails socialSharingDetails) {
            this.socialSharingDetails = socialSharingDetails;
        }

        public static class InviteInfo {

            @SerializedName("code")
            private String code = "";

            @SerializedName("active")
            private boolean active = false;

            @SerializedName("user_id")
            private int user_id = 0;

            @SerializedName("points_accrued")
            private int points_accrued = 0;

            @SerializedName("successful_referral_count")
            private int successful_referral_count = 0;

            @SerializedName("status_message")
            private String status_message = "";

            @SerializedName("faq_topic_id")
            private long faq_topic_id = 0;

            @SerializedName("image_url")
            private String image_url = "";

            @SerializedName("message")
            private String message = "";

            public String getCode() {
                return code;
            }

            public void setCode(String code) {
                this.code = code;
            }

            public boolean isActive() {
                return active;
            }

            public void setActive(boolean active) {
                this.active = active;
            }

            public int getUser_id() {
                return user_id;
            }

            public void setUser_id(int user_id) {
                this.user_id = user_id;
            }

            public int getPoints_accrued() {
                return points_accrued;
            }

            public void setPoints_accrued(int points_accrued) {
                this.points_accrued = points_accrued;
            }

            public int getSuccessful_referral_count() {
                return successful_referral_count;
            }

            public void setSuccessful_referral_count(int successful_referral_count) {
                this.successful_referral_count = successful_referral_count;
            }

            public String getStatus_message() {
                return status_message;
            }

            public void setStatus_message(String status_message) {
                this.status_message = status_message;
            }

            public long getFaq_topic_id() {
                return faq_topic_id;
            }

            public void setFaq_topic_id(long faq_topic_id) {
                this.faq_topic_id = faq_topic_id;
            }

            public String getImage_url() {
                return image_url;
            }

            public void setImage_url(String image_url) {
                this.image_url = image_url;
            }

            public String getMessage() {
                return message;
            }

            public void setMessage(String message) {
                this.message = message;
            }
        }

        public static class SocialSharingDetails {

            @SerializedName("email_body")
            private String email_body = "";

            @SerializedName("email_subject")
            private String email_subject = "";

            @SerializedName("promotional_message")
            private String promotional_message = "";

            public String getEmail_body() {
                return email_body;
            }

            public void setEmail_body(String email_body) {
                this.email_body = email_body;
            }

            public String getPromotional_message() {
                return promotional_message;
            }

            public void setPromotional_message(String promotional_message) {
                this.promotional_message = promotional_message;
            }

            public String getEmail_subject() {
                return email_subject;
            }

            public void setEmail_subject(String email_subject) {
                this.email_subject = email_subject;
            }
        }
    }
}
