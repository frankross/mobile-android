/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

/**
 * Created by gowtham on 2/8/15.
 */
public class ApiPharmaProduct extends ApiProduct {

    private String innerPackageQuantity = "";

    private String outerPackageQuantity = "";

    private BasicInfo basicInfo = new BasicInfo();

    private MoreInfo moreInfo = new MoreInfo();

    public BasicInfo getBasicInfo() {
        return basicInfo;
    }

    public void setBasicInfo(BasicInfo basicInfo) {
        this.basicInfo = basicInfo;
    }

    public MoreInfo getMoreInfo() {
        return moreInfo;
    }

    public void setMoreInfo(MoreInfo moreInfo) {
        this.moreInfo = moreInfo;
    }

    public String getInnerPackageQuantity() {
        return innerPackageQuantity;
    }

    public void setInnerPackageQuantity(String innerPackageQuantity) {
        this.innerPackageQuantity = innerPackageQuantity;
    }

    public String getOuterPackageQuantity() {
        return outerPackageQuantity;
    }

    public void setOuterPackageQuantity(String outerPackageQuantity) {
        this.outerPackageQuantity = outerPackageQuantity;
    }

    public static class BasicInfo {

        private String activeIngredients = "";

        private String activeIngredient = "";

        private String form = "";

        private String routeOfAdmin = "";

        private String whyPrescribe = "";

        private String howItShouldBeTaken = "";

        private String recommendedDosage = "";

        private boolean hasMultipleActiveIngredient = false;

        public String getActiveIngredients() {
            return activeIngredients;
        }

        public void setActiveIngredients(String activeIngredient) {
            this.activeIngredients = activeIngredient;
        }

        public String getForm() {
            return form;
        }

        public void setForm(String form) {
            this.form = form;
        }

        public String getRouteOfAdmin() {
            return routeOfAdmin;
        }

        public void setRouteOfAdmin(String routeOfAdmin) {
            this.routeOfAdmin = routeOfAdmin;
        }


        public String getWhyPrescribe() {
            return whyPrescribe;
        }

        public void setWhyPrescribe(String whyPrescribe) {
            this.whyPrescribe = whyPrescribe;
        }

        public String getHowItShouldBeTaken() {
            return howItShouldBeTaken;
        }

        public void setHowItShouldBeTaken(String howItShouldBeTaken) {
            this.howItShouldBeTaken = howItShouldBeTaken;
        }

        public String getRecommendedDosage() {
            return recommendedDosage;
        }

        public void setRecommendedDosage(String recommendedDosage) {
            this.recommendedDosage = recommendedDosage;
        }

        public String getActiveIngredient() {
            return activeIngredient;
        }

        public void setActiveIngredient(String activeIngredient) {
            this.activeIngredient = activeIngredient;
        }

        public boolean isHasMultipleActiveIngredient() {
            return hasMultipleActiveIngredient;
        }

        public void setHasMultipleActiveIngredient(boolean hasMultipleActiveIngredient) {
            this.hasMultipleActiveIngredient = hasMultipleActiveIngredient;
        }
    }

    public static class MoreInfo {

        private String whenItIsNotToBeTaken = "";

        private String warningAndPrecautions = "";

        private String sideEffects = "";

        private String otherPrecautions = "";

        public String getWarningAndPrecautions() {
            return warningAndPrecautions;
        }

        public void setWarningAndPrecautions(String warningAndPrecautions) {
            this.warningAndPrecautions = warningAndPrecautions;
        }

        public String getSideEffects() {
            return sideEffects;
        }

        public void setSideEffects(String sideEffects) {
            this.sideEffects = sideEffects;
        }

        public String getOtherPrecautions() {
            return otherPrecautions;
        }

        public void setOtherPrecautions(String otherPrecautions) {
            this.otherPrecautions = otherPrecautions;
        }

        public String getWhenItIsNotToBeTaken() {
            return whenItIsNotToBeTaken;
        }

        public void setWhenItIsNotToBeTaken(String whenItIsNotToBeTaken) {
            this.whenItIsNotToBeTaken = whenItIsNotToBeTaken;
        }
    }
}
