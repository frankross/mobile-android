/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.prescription.uploadprescription;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.core.network.IApiRequestCancel;
import com.emamifrankross.frankross.ui.account.login.LogInActivity;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;
import com.emamifrankross.frankross.ui.common.AlertError;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IErrorHandler;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Log;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gowtham on 5/7/15.
 */

/**
 * This class manages the fragment transactions for Upload prescriptions based on the intents and its data
 */
public class UploadPrescriptionActivity extends BaseActivity implements PrescriptionSubmitFragment.
        IUploadPrescriptionListener, IErrorHandler, IApiRequestCancel {

    private static final String TAG = UploadPrescriptionActivity.class.getSimpleName();

    private static final String CHECKOUT_UPLOAD_PRESCRIPTION = "isCheckOut";
    private static final String IS_FROM_CART = "isFromCart";
    protected ApiRequestManager mApiRequestManager;
    private long mPrescriptionId = -1;
    private boolean isCheckOut = false;
    private boolean mIsFromCart = false;

    public static Intent getActivityIntent(Context context, boolean isCheckOut, boolean isFromCart) {
        Intent intent = new Intent(context, UploadPrescriptionActivity.class);
        intent.putExtra(CHECKOUT_UPLOAD_PRESCRIPTION, isCheckOut);
        intent.putExtra(IS_FROM_CART, isFromCart);

        return intent;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mApiRequestManager = ApiRequestManager.getInstance(getApplicationContext());
        mApiRequestManager.registerRequest(this);

        isCheckOut = getIntent().getBooleanExtra(CHECKOUT_UPLOAD_PRESCRIPTION, false);
        mIsFromCart = getIntent().getBooleanExtra(IS_FROM_CART, false);

        if (Utils.isLoggedIn(getApplicationContext())) {
            loadFragment(getFragmentContainerId(), UploadPrescriptionFragment.create(mPrescriptionId, isCheckOut, mIsFromCart),
                    UploadPrescriptionFragment.TAG, R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.ADD);
        } else {
            startActivityForResult(LogInActivity.getActivityIntent(getApplicationContext(), false,
                    LogInActivity.LOG_IN_FRAGMENT), Constants.REQUEST_CODE_FOR_LOGIN);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == Constants.REQUEST_CODE_FOR_LOGIN) {
            if (resultCode == RESULT_OK) {
                setResult(RESULT_OK);
                loadFragment(getFragmentContainerId(), UploadPrescriptionFragment.create(mPrescriptionId, isCheckOut, mIsFromCart),
                        UploadPrescriptionFragment.TAG, R.anim.push_left_in, R.anim.push_left_out, BaseFragment.FragmentTransactionType.ADD);
            } else {
                finish();
            }
        }
    }

    /**
     * Method that receives the call back on successful prescription upload
     *
     * @param prescriptionId the prescription id of successfully uploaded prescription
     */
    @Override
    public void prescriptionUploaded(long prescriptionId) {
        mPrescriptionId = prescriptionId;
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(UploadPrescriptionFragment.TAG);

        if (fragment instanceof UploadPrescriptionFragment) {
            UploadPrescriptionFragment uploadPrescriptionFragment = (UploadPrescriptionFragment) fragment;
            uploadPrescriptionFragment.setPrescriptionId(prescriptionId);
        }
    }

    @Override
    public void onBackPressed() {
        Log.d(TAG, "PrescriptionId = " + mPrescriptionId);
        /*
          Displays the alert dialog so that user will not lose track of uploaded prescriptions
        */
        Fragment fragment = getSupportFragmentManager().findFragmentById(getFragmentContainerId());
        if (fragment != null && fragment instanceof UploadPrescriptionFragment) {
            if (mPrescriptionId != -1) {
                showAlert(getString(R.string.upload_prescription_dialog_title),
                        getString(R.string.upload_prescription_dialog_msg),
                        getString(R.string.done),
                        getString(R.string.cancel), new AlertDialogFragment.AlertPositiveActionListener() {
                            @Override
                            public void onPositiveAction() {
                                completePrescriptionUpload();
                            }
                        }, new AlertDialogFragment.AlertNegativeActionListener() {
                            @Override
                            public void onNegativeAction() {
                                //DO Nothing
                            }
                        }, false);
            } else {
                super.onBackPressed();
            }
        } else {
            super.onBackPressed();
        }
    }

    private void completePrescriptionUpload() {
        showBlockingProgressBar();
        mApiRequestManager.performPrescriptionUploadComplete(mPrescriptionId, new ApiRequestManager.IPrescriptionCompleteListener() {

            @Override
            public void onPrescriptionUploadCompleted() {
                Intent data = new Intent();
                data.putExtra(Constants.INTENT_EXTRA_PRESCRIPTION_ID, mPrescriptionId);

                setResult(Activity.RESULT_OK, data);
                finish();
            }
        }, this, this);
    }

    @Override
    public String getRequestTag() {
        return getClass().getName();
    }

    @Override
    public <T> void handleError(AlertError<T> alertError, int statusCode) {
        hideBlockingProgressBar();

        if (alertError == null) return;
        showAlert(alertError.getErrorTitle(), alertError.getErrorMessage(),
                alertError.getPositiveButtonText(), alertError.getNegativeButtonText(), new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                    }
                }, new AlertDialogFragment.AlertNegativeActionListener() {
                    @Override
                    public void onNegativeAction() {
                    }
                }, true);
    }

    @Override
    public void handleCommonError(int errorResourceId) {
        hideBlockingProgressBar();
        String errorMessage = getString(errorResourceId);

        showAlert(null, errorMessage,
                getString(R.string.ok), null, new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                    }
                }, null, true);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mApiRequestManager.unregisterRequest(this);
    }
}
