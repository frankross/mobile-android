/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.db;


import com.emamifrankross.frankross.core.apimodels.RequestCartItem;
import com.emamifrankross.frankross.core.db.tables.CartCacheTable;
import com.emamifrankross.frankross.core.db.tables.DataBaseTableConstants;
import com.emamifrankross.frankross.core.db.dbmodels.SearchSuggestion;

/**
 * This class is responsible for creating the database operation queries based on provided table name.
 *
 * Provides methods for particular database operations like insertSearchSuggestion, deleteAllCartCache etc..
 * Note: Please create any of your newly added database operation query in this class rather in other for single responsibility.
 */
public class QueryProvider implements IDataBaseOperation.DBOperationsID, DataBaseTableConstants.TableID {

    /**
     * Common method creates and returns query for deleting all the entries in the given table
     * @param dbResultNotifier call back for notifying the result.
     * @param tableId table id of the entries to be deleted.
     * @return Delete query
     */
	public static DeleteQuery getDeleteAllQuery(IDataBaseResultNotifier dbResultNotifier, byte tableId) {
		DeleteQuery deleteQuery = new DeleteQuery();
		deleteQuery.setDataBaseResultNotifier(dbResultNotifier);
		deleteQuery.setOperationId(DELETE);
		deleteQuery.setTableId(tableId);

		return deleteQuery;
	}

    /**
     * method creates and returns query for inserting search suggestion.
     * @return insert query
     */
    public static InsertQuery<SearchSuggestion> getInsertSearchSuggestionQuery(SearchSuggestion searchSuggestion) {
        InsertQuery<SearchSuggestion> insertQuery = new InsertQuery<SearchSuggestion>();
        insertQuery.setDataBaseResultNotifier(null);
        insertQuery.setOperationId(INSERT);
        insertQuery.setTableId(ID_SEARCH_SUGGESTIONS_TABLE);
        insertQuery.setValues(searchSuggestion);

        return insertQuery;
    }

    /**
     * Method which creates and returns query for selecting all the stored search suggestion.
     * @param dbResultNotifier call back for notifying the result.
     * @return the select query
     */
    public static SelectQuery getAllSearchSuggestionsQuery(IDataBaseResultNotifier dbResultNotifier) {
        SelectQuery selectQuery = new SelectQuery();
        selectQuery.setDataBaseResultNotifier(dbResultNotifier);
        selectQuery.setOperationId(SELECT);
        selectQuery.setTableId(ID_SEARCH_SUGGESTIONS_TABLE);

        return selectQuery;
    }

    /**
     * Method creates and returns query for inserting cart item in offline  mode
     * @param dbResultNotifier call back for notifying the result.
     * @param cartItem cart item to be inserted
     * @return insert query
     */
    public static InsertQuery<RequestCartItem> getInsertCartItemQuery(IDataBaseResultNotifier dbResultNotifier, RequestCartItem cartItem) {
        InsertQuery<RequestCartItem> insertQuery = new InsertQuery<RequestCartItem>();
        insertQuery.setDataBaseResultNotifier(dbResultNotifier);
        insertQuery.setOperationId(INSERT);
        insertQuery.setTableId(ID_CART_CACHE_TABLE);
        insertQuery.setValues(cartItem);

        return insertQuery;
    }

    /**
     * Method creates and returns query for getting the cart items.
     * @param dbResultNotifier  call back for notifying the result.
     * @return Select query.
     */
    public static SelectQuery getAllCartItemsQuery(IDataBaseResultNotifier dbResultNotifier) {
        SelectQuery selectQuery = new SelectQuery();
        selectQuery.setDataBaseResultNotifier(dbResultNotifier);
        selectQuery.setOperationId(SELECT);
        selectQuery.setTableId(ID_CART_CACHE_TABLE);

        return selectQuery;
    }

    /**
     * Method creates and returns query for getting cart item quantity for the given variant id of the cart item.
     * @param dbResultNotifier call back for notifying the result.
     * @param variantId variant id of the cart item to fetch the quantity of it.
     * @return Raw query
     */
    public static RawQuery getCartItemQuantityQuery(IDataBaseResultNotifier dbResultNotifier, long variantId) {
        RawQuery rawQuery = new RawQuery();
        rawQuery.setDataBaseResultNotifier(dbResultNotifier);
        rawQuery.setOperationId(RAW);
        rawQuery.setTableId(ID_CART_CACHE_TABLE);
        rawQuery.setRawOperationId(CartCacheTable.OPERATION_ID_VARIANT_QUANTITY);
        rawQuery.setSqlStatement(CartCacheTable.RAW_QUERY_CART_ITEM_QUANTITY);
        rawQuery.setSelectionArgs(new String[]{variantId+""});

        return rawQuery;
    }

    /**
     * Method creates and returns query for deleting cart item.
     * @param dataBaseResultNotifier call back for notifying the result.
     * @param variantId variant id of the cart item to be deleted.
     * @return Delete Query
     */
    public static DBQuery getDeleteCartItemQuery (IDataBaseResultNotifier dataBaseResultNotifier, long variantId) {
        DeleteQuery deleteQuery = new DeleteQuery();
        deleteQuery.setDataBaseResultNotifier(dataBaseResultNotifier);
        deleteQuery.setOperationId(DELETE);
        deleteQuery.setTableId(ID_CART_CACHE_TABLE);

        String whereClause = CartCacheTable.COLUMN_KEY_VARIANT_ID + "=?";
        deleteQuery.setWhereClause(whereClause);

        String[] whereArgs = {variantId + ""};
        deleteQuery.setWhereArgs(whereArgs);

        return deleteQuery;
    }

}
