/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.sdkmanager;

import android.content.Context;
import android.os.Bundle;

import com.apptentive.android.sdk.Apptentive;
import com.emamifrankross.frankross.core.network.UrlConstants;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by gauthami on 6/9/16.
 */

/**
 * This class manages the Apptentive event logging, instance switching, message centre and push notifications
 */
public class ApptentiveManager {

    public static final String TAG = ApptentiveManager.class.getSimpleName();
    public static final String APPTENTIVE_TOKEN = UrlConstants.DEV_MODE ?
            "e4daf90d940af08a36eadbe5c21442f58ad77a4c5610c9390d3fc0fafc9e3dfe" :
            "02f3b58f03dfebb2341c79c32b1ba33a5ac34e5625f6fe31c62732c04f7bb8a7";

    /**
     * APPTENTIVE KEYS
     */
    public static final String APPTENTIVE_NOTIFICATION_BODY_KEY = "gcm.notification.body";//message
    public static final String APPTENTIVE_NOTIFICATION_TITLE_KEY = "gcm.notification.title";//title

    private ApptentiveManager() {
    }

    /**
     * APPTENTIVE EVENT LOGGING
     */
    public static void registerAppAppLaunchEvent(Context context) {
        Apptentive.engage(context, ApptentiveEvents.APPTENTIVE_APP_LAUNCH_EVENT);
    }

    public static void registerPrescriptionScreenVisitEvent(Context context) {
        Apptentive.engage(context, ApptentiveEvents.APPTENTIVE_PRESCRIPTIONS_SCREEN_VISIT_EVENT);
    }

    public static void registerWalletScreenVisitEvent(Context context) {
        Apptentive.engage(context, ApptentiveEvents.APPTENTIVE_WALLET_SCREEN_VISIT_EVENT);
    }

    public static void registerOrderConfirmEvent(Context context, String orderMethod) {
        Map<String, Object> confirmOrderData = new HashMap<>();
        confirmOrderData.put(ApptentiveEvents.APPTENTIVE_ORDER_CONFIRM_METHOD, orderMethod);
        Apptentive.engage(context, ApptentiveEvents.APPTENTIVE_ORDER_CONFIRM_EVENT, confirmOrderData);
    }

    public static void registerHomeScreenVisitEvent(Context context) {
        Apptentive.engage(context, ApptentiveEvents.APPTENTIVE_HOME_VISITED_EVENT);
    }

    /**
     * APPTENTIVE PUSH NOTIFICATIONS
     */
    public static void registerApptentivePushNotification(String token) {
        Apptentive.setPushNotificationIntegration(Apptentive.PUSH_PROVIDER_APPTENTIVE, token);
    }

    public static boolean setApptentivePushNotificationData(Bundle pushNotificationData) {
        return Apptentive.setPendingPushNotification(pushNotificationData);
    }

    public static boolean isApptentiveNotificationHandled(Context context) {
        // Returns true if the push notification was for Apptentive, and we handled it.
        return Apptentive.handleOpenedPushNotification(context);
    }

    /**
     * APPTENTIVE MESSAGE CENTER
     */
    public static void showApptentiveMessageCenter(Context context) {
        if (Apptentive.canShowMessageCenter())
            Apptentive.showMessageCenter(context);
    }
}
