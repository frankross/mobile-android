/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.utils.Utils;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 3/8/15.
 */
public class Cart {

    @SerializedName("order_id")
    private long orderId = 0;

    @SerializedName("line_items")
    private List<ResponseCartItem> cartItems = new ArrayList<>(1);

    @SerializedName("line_items_total")
    private String cartItemsTotal = "";

    @SerializedName("cart_total")
    private String cartTotal = "";

    @SerializedName("net_payable_amount")
    private String netPayableAmount = "";

    @SerializedName("shipping_total")
    private String shippingTotal = "";

    @SerializedName("discount_total")
    private String discountTotal = "0.0";

    @SerializedName("promotion_discount_total")
    private String offerDiscountTotal = "0.0";

    @SerializedName("shipping_description")
    private String shippingDescription = "";

    @SerializedName("patient_details_required")
    private String isMandatory = "";

    @SerializedName("order_without_prescription")
    private boolean isOrderWithoutPrescription = false;

    @SerializedName("payment_retryable")
    private boolean paymentRetryable = false;

    @SerializedName("fully_paid_by_wallet")
    private boolean fullyPaidByWallet = false;

    @SerializedName("apply_wallet")
    private boolean applyWallet = false;

    @SerializedName("wallet_amount")
    private double walletAmount = 0.0d;

    @SerializedName("cash_back_desc")
    private String cashBackSummary = "";

    @SerializedName("cash_back")
    private boolean isCashBack = false;

    @SerializedName("payment_methods")
    private List<PaymentMethods> paymentMethods = new ArrayList<>(1);

    @SerializedName("promotions")
    private List<CartPromotion> cartPromotionList = new ArrayList<>(1);

    @SerializedName("payments")
    private List<Payments> payments = new ArrayList<>(1);

    public List<ResponseCartItem> getCartItems() {
        return cartItems;
    }

    public void setCartItems(List<ResponseCartItem> cartItems) {
        this.cartItems = cartItems;
    }

    public double getCartItemsTotal() {
        return Utils.getDoubleValue(cartItemsTotal);
    }

    public void setCartItemsTotal(String cartItemsTotal) {
        this.cartItemsTotal = cartItemsTotal;
    }

    public double getCartTotal() {
        return Utils.getDoubleValue(cartTotal);
    }

    public void setCartTotal(String cartTotal) {
        this.cartTotal = cartTotal;
    }

    public double getShippingTotal() {
        return Utils.getDoubleValue(shippingTotal);
    }

    public void setShippingTotal(String shippingTotal) {
        this.shippingTotal = shippingTotal;
    }

    public double getDiscountTotal() {
        return Utils.getDoubleValue(discountTotal);
    }

    public void setDiscountTotal(String discountTotal) {
        this.discountTotal = discountTotal;
    }

    public String getShippingDescription() {
        return shippingDescription;
    }

    public void setShippingDescription(String shippingDescription) {
        this.shippingDescription = shippingDescription;
    }

    public String getIsMandatory() {
        return isMandatory;
    }

    public void setIsMandatory(String isMandatory) {
        this.isMandatory = isMandatory;
    }

    public double getOfferDiscountTotal() {

        return Utils.getDoubleValue(offerDiscountTotal);
    }

    public List<CartPromotion> getCartPromotionList() {
        return cartPromotionList;
    }

    public boolean isOrderWithoutPrescription() {
        return isOrderWithoutPrescription;
    }

    public void setIsOrderWithoutPrescription(boolean isOrderWithoutPrescription) {
        this.isOrderWithoutPrescription = isOrderWithoutPrescription;
    }

    public long getOrderId() {
        return orderId;
    }

    public void setOrderId(long orderId) {
        this.orderId = orderId;
    }

    public List<PaymentMethods> getPaymentMethods() {
        return paymentMethods;
    }

    public void setPaymentMethods(List<PaymentMethods> paymentMethods) {
        this.paymentMethods = paymentMethods;
    }

    public double getWalletAmount() {
        return walletAmount;
    }

    public void setWalletAmount(double walletAmount) {
        this.walletAmount = walletAmount;
    }

    public boolean isApplyWallet() {
        return applyWallet;
    }

    public void setApplyWallet(boolean applyWallet) {
        this.applyWallet = applyWallet;
    }

    public double getNetPayableAmount() {
        return Utils.getDoubleValue(netPayableAmount);
    }

    public boolean isPaymentRetryable() {
        return !paymentRetryable;
    }

    public void setPaymentRetryable(boolean paymentRetryable) {
        this.paymentRetryable = paymentRetryable;
    }

    public boolean isFullyPaidByWallet() {
        return fullyPaidByWallet;
    }

    public void setFullyPaidByWallet(boolean fullyPaidByWallet) {
        this.fullyPaidByWallet = fullyPaidByWallet;
    }

    public List<Payments> getPayments() {
        return payments;
    }

    public void setPayments(List<Payments> payments) {
        this.payments = payments;
    }

    public String getCashBackSummary() {
        return cashBackSummary;
    }

    public boolean isCashBack() {
        return isCashBack;
    }

    public static class CartPromotion {
        @SerializedName("name")
        private String mainText = "";

        @SerializedName("description")
        private String subText = "";

        @SerializedName("image_url")
        private String offerImageUrl = "";

        @SerializedName("coupon")
        private Coupon coupon = new Coupon();

        public String getMainText() {
            return mainText;
        }

        public String getSubText() {
            return subText;
        }

        public String getOfferImageUrl() {
            return offerImageUrl;
        }

        public Coupon getCoupon() {
            return coupon;
        }
    }

    public static class Coupon {
        @SerializedName("coupon_id")
        private long couponId;

        @SerializedName("code")
        private String code = "";

        @SerializedName("status")
        private String status = "";

        @SerializedName("message")
        private String message = "";

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getStatus() {
            return status;
        }

        public String getCode() {
            return code;
        }

        public long getCouponId() {
            return couponId;
        }
    }

    public static class ResponseCartItem {

        @SerializedName("variant_id")
        private long variantId;

        @SerializedName("variant_name")
        private String variantName;

        @SerializedName("quantity")
        private int quantity;

        @SerializedName("prescription_required")
        private boolean prescriptionRequired;

        @SerializedName("inner_package_unit")
        private String innerPackageUnit;

        @SerializedName("inner_package_quantity")
        private String innerPackageQuantity;

        @SerializedName("outer_package_unit")
        private String outerPackageUnit;

        @SerializedName("outer_package_quantity")
        private String outerPackageQuantity;

        @SerializedName("prescription_message")
        private String prescriptionMessage;

        @SerializedName("prescription_available")
        private boolean prescriptionAvailable;

        @SerializedName("unit_of_sale")
        private String unitOfSale;

        @SerializedName("max_orderable_quantity")
        private int maxOrderableQuantity = 0;

        @SerializedName("mrp")
        private String mrp = "";

        @SerializedName("sales_price")
        private String salesPrice = "";

        @SerializedName("promotional_price")
        private String promotionalPrice = "";

        @SerializedName("total")
        private String total = "";

        @SerializedName("discount_amount")
        private String discountAmount = "";

        @SerializedName("discount_percent")
        private String discountPercent = "";

        @SerializedName("cash_back_desc")
        private String cashBackSummary = "";

        @SerializedName("active")
        private boolean isActive = false;

        @SerializedName("pharma")
        private boolean isPharma = false;

        @SerializedName("cash_back")
        private boolean isCashBack = false;

        public String getOuterPackageUnit() {
            return outerPackageUnit;
        }

        public void setOuterPackageUnit(String outerPackageUnit) {
            this.outerPackageUnit = outerPackageUnit;
        }

        public long getVariantId() {
            return variantId;
        }

        public void setVariantId(int variantId) {
            this.variantId = variantId;
        }

        public String getInnerPackageUnit() {
            return innerPackageUnit;
        }

        public void setInnerPackageUnit(String innerPackageUnit) {
            this.innerPackageUnit = innerPackageUnit;
        }

        public double getMrp() {
            return Utils.getDoubleValue(mrp);
        }

        public double getDiscountAmount() {
            return Utils.getDoubleValue(discountAmount);
        }

        public void setOuterPackageQuantity(String outerPackageQuantity) {
            this.outerPackageQuantity = outerPackageQuantity;
        }

        public String getVariantName() {
            return variantName;
        }

        public void setVariantName(String variantName) {
            this.variantName = variantName;
        }

        public double getSalesPrice() {
            return Utils.getDoubleValue(salesPrice);
        }

        public boolean getPrescriptionRequired() {
            return prescriptionRequired;
        }

        public void setPrescriptionRequired(boolean prescriptionRequired) {
            this.prescriptionRequired = prescriptionRequired;
        }

        public double getTotal() {
            return Utils.getDoubleValue(total);
        }

        public boolean getPrescriptionAvailable() {
            return prescriptionAvailable;
        }

        public void setPrescriptionAvailable(boolean prescriptionAvailable) {
            this.prescriptionAvailable = prescriptionAvailable;
        }

        public String getInnerPackageQuantity() {
            return innerPackageQuantity;
        }

        public void setInnerPackageQuantity(String innerPackageQuantity) {
            this.innerPackageQuantity = innerPackageQuantity;
        }

        public int getMaxOrderableQuantity() {
            return maxOrderableQuantity;
        }

        public void setMaxOrderableQuantity(int maxOrderableQuantity) {
            this.maxOrderableQuantity = maxOrderableQuantity;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        public String getUnitOfSale() {
            return unitOfSale;
        }

        public void setUnitOfSale(String unitOfSale) {
            this.unitOfSale = unitOfSale;
        }

        public double getPromotionalPrice() {
            return Utils.getDoubleValue(promotionalPrice);
        }

        public double getDiscountPercent() {
            return Utils.getDoubleValue(discountPercent);
        }

        public boolean isActive() {
            return isActive;
        }

        public String getOuterPackageQuantity() {
            return outerPackageQuantity;
        }

        public boolean isPharma() {
            return isPharma;
        }

        public String getPrescriptionMessage() {
            return prescriptionMessage;
        }

        public void setPrescriptionMessage(String prescriptionMessage) {
            this.prescriptionMessage = prescriptionMessage;
        }

        public String getCashBackSummary() {
            return cashBackSummary;
        }

        public void setCashBackSummary(String cashBackSummary) {
            this.cashBackSummary = cashBackSummary;
        }

        public boolean isCashBack() {
            return isCashBack;
        }

        public void setCashBack(boolean cashBack) {
            isCashBack = cashBack;
        }
    }

    public static class Payments {

        @SerializedName("payment_method")
        private String payment_method = "";

        @SerializedName("payment_instrument")
        private String payment_instrument = "";

        @SerializedName("amount")
        private String amount = "";

        @SerializedName("status")
        private String status = "";

        public String getPayment_method() {
            return payment_method;
        }

        public void setPayment_method(String payment_method) {
            this.payment_method = payment_method;
        }

        public String getPayment_instrument() {
            return payment_instrument;
        }

        public void setPayment_instrument(String payment_instrument) {
            this.payment_instrument = payment_instrument;
        }

        public String getAmount() {
            return amount;
        }

        public void setAmount(String amount) {
            this.amount = amount;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }
    }
}
