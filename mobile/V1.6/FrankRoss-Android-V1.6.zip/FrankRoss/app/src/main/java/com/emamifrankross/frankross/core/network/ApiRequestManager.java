/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.network;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Build;
import android.support.annotation.NonNull;
import android.text.TextUtils;
import android.util.Base64;
import android.webkit.CookieManager;

import com.emamifrankross.frankross.FrankRossApplication;
import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.Address;
import com.emamifrankross.frankross.core.apimodels.ApiAddress;
import com.emamifrankross.frankross.core.apimodels.ApiCart;
import com.emamifrankross.frankross.core.apimodels.ApiCartCheckout;
import com.emamifrankross.frankross.core.apimodels.ApiCategories;
import com.emamifrankross.frankross.core.apimodels.ApiChangeNumber;
import com.emamifrankross.frankross.core.apimodels.ApiCityDetails;
import com.emamifrankross.frankross.core.apimodels.ApiCommonError;
import com.emamifrankross.frankross.core.apimodels.ApiDeliverySlot;
import com.emamifrankross.frankross.core.apimodels.ApiDeviceRegister;
import com.emamifrankross.frankross.core.apimodels.ApiFAQ;
import com.emamifrankross.frankross.core.apimodels.ApiFulfillmentCenter;
import com.emamifrankross.frankross.core.apimodels.ApiGetAddress;
import com.emamifrankross.frankross.core.apimodels.ApiHomeBanner;
import com.emamifrankross.frankross.core.apimodels.ApiInitializePayment;
import com.emamifrankross.frankross.core.apimodels.ApiLocation;
import com.emamifrankross.frankross.core.apimodels.ApiLogin;
import com.emamifrankross.frankross.core.apimodels.ApiLogout;
import com.emamifrankross.frankross.core.apimodels.ApiNewTag;
import com.emamifrankross.frankross.core.apimodels.ApiNonPharmaProduct;
import com.emamifrankross.frankross.core.apimodels.ApiNotificationCentre;
import com.emamifrankross.frankross.core.apimodels.ApiNotificationCount;
import com.emamifrankross.frankross.core.apimodels.ApiNotifyMe;
import com.emamifrankross.frankross.core.apimodels.ApiOffer;
import com.emamifrankross.frankross.core.apimodels.ApiOrder;
import com.emamifrankross.frankross.core.apimodels.ApiOrderCancel;
import com.emamifrankross.frankross.core.apimodels.ApiOrderDetail;
import com.emamifrankross.frankross.core.apimodels.ApiOrderReminder;
import com.emamifrankross.frankross.core.apimodels.ApiOrdersList;
import com.emamifrankross.frankross.core.apimodels.ApiPaymentFailure;
import com.emamifrankross.frankross.core.apimodels.ApiPharmaProduct;
import com.emamifrankross.frankross.core.apimodels.ApiPrescriptionDescription;
import com.emamifrankross.frankross.core.apimodels.ApiPrescriptionList;
import com.emamifrankross.frankross.core.apimodels.ApiRecentPharmaOrdersList;
import com.emamifrankross.frankross.core.apimodels.ApiReferFriend;
import com.emamifrankross.frankross.core.apimodels.ApiRegister;
import com.emamifrankross.frankross.core.apimodels.ApiResendOtp;
import com.emamifrankross.frankross.core.apimodels.ApiRewardPoints;
import com.emamifrankross.frankross.core.apimodels.ApiSetPassword;
import com.emamifrankross.frankross.core.apimodels.ApiSettings;
import com.emamifrankross.frankross.core.apimodels.ApiSocialLogin;
import com.emamifrankross.frankross.core.apimodels.ApiSocialRegister;
import com.emamifrankross.frankross.core.apimodels.ApiStatus;
import com.emamifrankross.frankross.core.apimodels.ApiStoreLocator;
import com.emamifrankross.frankross.core.apimodels.ApiUpdateUserInformation;
import com.emamifrankross.frankross.core.apimodels.ApiUpdateUserPassword;
import com.emamifrankross.frankross.core.apimodels.ApiUploadPrescription;
import com.emamifrankross.frankross.core.apimodels.ApiUploadPrescriptionComplete;
import com.emamifrankross.frankross.core.apimodels.ApiUserInformation;
import com.emamifrankross.frankross.core.apimodels.ApiVerifyOtp;
import com.emamifrankross.frankross.core.apimodels.Cart;
import com.emamifrankross.frankross.core.apimodels.FAQ;
import com.emamifrankross.frankross.core.apimodels.OrderDetails;
import com.emamifrankross.frankross.core.apimodels.PaymentMethods;
import com.emamifrankross.frankross.core.apimodels.RequestCartItem;
import com.emamifrankross.frankross.core.db.IDataBaseResultNotifier;
import com.emamifrankross.frankross.core.db.QueryExecutor;
import com.emamifrankross.frankross.core.db.QueryProvider;
import com.emamifrankross.frankross.core.db.tables.DataBaseTableConstants;
import com.emamifrankross.frankross.sdkmanager.BranchManager;
import com.emamifrankross.frankross.ui.adapters.AccountAdapter;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.CartUploadPrescriptionAdapter;
import com.emamifrankross.frankross.ui.adapters.CheckOutSummaryAdapter;
import com.emamifrankross.frankross.ui.adapters.LocationChooserAdapter;
import com.emamifrankross.frankross.ui.adapters.PrescriptionFilterAdapter;
import com.emamifrankross.frankross.ui.checkout.CheckOutDeliveryAddressFragment;
import com.emamifrankross.frankross.ui.common.AlertError;
import com.emamifrankross.frankross.ui.common.IErrorHandler;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryProductInfoHeaderItem;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryProductInfoItem;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryShippingChargesItem;
import com.emamifrankross.frankross.ui.viewmodels.OrderHistoryTotalAmountItem;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderItem;
import com.emamifrankross.frankross.ui.viewmodels.UserInformation;
import com.emamifrankross.frankross.utils.BitmapUtils;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Log;
import com.emamifrankross.frankross.utils.PreferenceUtils;
import com.emamifrankross.frankross.utils.Utils;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by gowtham on 14/7/15.
 */

/**
 * This class manages the API requests by constructing the request data model,
 * adding the success & error response listeners,
 * adding the cancel handler and provides the Gson request to API request executor
 */
public class ApiRequestManager implements FRGsonRequest.IAPIRequestCancelHandler {

    private static final String TAG = ApiRequestManager.class.getSimpleName();
    private static Context mAppContext;
    public ApiHomeBanner.Response mBannerResponse;
    private ApiCategories.Category mOtcMedicineCategory;
    private ApiCategories.Category mMedicalAidsCategory;
    private ApiCart.Response mCartResponse;
    private ApiOrderDetail.Response mRevisedOrderResponse;
    private ApiSettings.Response mSettingsResponse;
    private ApiNewTag.Response mNewFeaturesResponse;

    //public boolean isFirstCycleComplete = false;
    private long loopingDelay = Constants.AUTO_SCROLL_PRIMARY_DELAY;

    private List<ICartCountChangeNotifier> mCartCountChangeNotifiers = new ArrayList<>(1);
    private int mCartItemsCount = 0;

    private List<INotificationsCountChangeNotifier> mNotificationsCountChangeNotifiers = new ArrayList<>(1);
    private int mNotificationsCount = 0;
    private List<String> mRequestTagList;

    private ApiRequestManager() {
        mRequestTagList = new ArrayList<>();
    }

    public static ApiRequestManager getInstance(Context appContext) {
        // Application Context is also a single instance across application.
        mAppContext = appContext.getApplicationContext();

        return ManagerInstanceHolder.INSTANCE;
    }

    private static FRGsonRequest.ErrorResponseListener<ApiCommonError> getCommonErrResponseListener(
            final IErrorHandler errorHandler) {
        return new FRGsonRequest.ErrorResponseListener<ApiCommonError>() {
            @Override
            public void onErrorResponse(ApiCommonError errorResponse, int statusCode) {
                if (errorHandler != null) {
                    errorHandler.handleError(getAlertError(errorResponse), statusCode);
                }
            }

            @Override
            public void onError(int messageId) {
                if (errorHandler != null) {
                    errorHandler.handleCommonError(messageId);
                }
            }
        };
    }

    private static <T> AlertError<T> getAlertError(ApiCommonError commonError) {
        AlertError<T> alertError = new AlertError<>();
        alertError.setErrorMessage((commonError != null)
                ? commonError.getErrorMessage() : "Unknown error, please try again");
        alertError.setPositiveButtonText("OK");

        return alertError;
    }

    private static <T> AlertError<T> getAlertError(String errorMessage) {
        AlertError<T> alertError = new AlertError<>();
        alertError.setErrorMessage((errorMessage != null)
                ? errorMessage : "Unknown error, please try again");
        alertError.setPositiveButtonText("OK");

        return alertError;
    }

    public void clearResponseCacheOnLocationUpdate() {
        mBannerResponse = null;
    }

    public int getCartItemsCount() {
        return mCartItemsCount;
    }

    public String getCartItemsCountInString() {
        return (mCartItemsCount == 0) ? "" : mCartItemsCount + "";
    }

    public String getNotificationsCountInString() {
        return (mNotificationsCount == 0) ? "" : mNotificationsCount + "";
    }

    public void updateCartItemsCount(int cartCount) {
        mCartItemsCount = cartCount;
        refreshCartCount();
    }

    public void refreshCartCount() {
        for (ICartCountChangeNotifier cartCountChangeNotifier : mCartCountChangeNotifiers) {
            cartCountChangeNotifier.onCartCountChanged(mCartItemsCount);
        }
    }

    public void clearCartItemsCount() {
        mCartItemsCount = 0;
        mCartResponse = null;
        refreshCartCount();
    }

    public void refreshNotificationsCount() {
        for (INotificationsCountChangeNotifier cartCountChangeNotifier : mNotificationsCountChangeNotifiers) {
            cartCountChangeNotifier.onNotificationCountChanged(mCartItemsCount);
        }
    }

    public void clearNotificationsCount() {
        mNotificationsCount = 0;
        refreshNotificationsCount();
    }

    public long getLoopingDelay() {
        return loopingDelay;
    }

    public void setLoopingDelay(long loopingDelay) {
        this.loopingDelay = loopingDelay;
    }

    public ApiSettings.Response.SettingsInfo getSettingsResponse() {
        if (mSettingsResponse == null || mSettingsResponse.getSettingsInfo() == null) {
            mSettingsResponse = new ApiSettings.Response();
            ApiSettings.Response.SettingsInfo settingsInfo = new ApiSettings.Response.SettingsInfo();
            settingsInfo.setOtpSender(mAppContext.getString(R.string.otp_sms_vendor_id));
            settingsInfo.setOtpPrefixMessage(mAppContext.getString(R.string.otp_receiver_message) + " ");
            settingsInfo.setOtpTimeInterval(30);
            settingsInfo.setShowRedeem(false);
            settingsInfo.setAppShareLinkTitle(mAppContext.getString(R.string.share_link_title));
            settingsInfo.setAppShareLinkDescription(mAppContext.getString(R.string.share_link_description));
            settingsInfo.setAppShareLinkImageUrl(BranchManager.BRANCH_APP_SHARE_CONTENT_IMAGE_URL);
            settingsInfo.setReferralLinkTitle(mAppContext.getString(R.string.share_link_title));
            settingsInfo.setReferralLinkDescription(mAppContext.getString(R.string.share_link_description));
            settingsInfo.setReferralLinkImageUrl(BranchManager.BRANCH_APP_SHARE_CONTENT_IMAGE_URL);
            mSettingsResponse.setSettingsInfo(settingsInfo);
        }
        return mSettingsResponse.getSettingsInfo();
    }

    public void setSettingsResponse(ApiSettings.Response apiSettings) {
        mSettingsResponse = apiSettings;
    }

    public ApiNewTag.Response getNewFeaturesResponse() {
        return mNewFeaturesResponse;
    }

    public void setNewFeaturesResponse(ApiNewTag.Response mNewFeaturesResponse) {
        this.mNewFeaturesResponse = mNewFeaturesResponse;
    }

    /**
     * Runs in invocation thread
     */
    public int getCartItemQuantityForReOrder(long variantId, int quantityToAdd) {
        if (mCartResponse != null && mCartResponse.getCart() != null
                && mCartResponse.getCart().getCartItems() != null) {
            for (Cart.ResponseCartItem cartItem : mCartResponse.getCart().getCartItems()) {
                if (cartItem.getVariantId() == variantId) {
                    int quantity = cartItem.getQuantity() + quantityToAdd;

                    return (cartItem.getMaxOrderableQuantity() > quantity) ? quantity : cartItem.getMaxOrderableQuantity();
                }
            }
        }

        return quantityToAdd;
    }

    public void getCartItemQuantity(long variantId, IGetCartItemQuantityListener cartItemQuantityListener) {
        if (Utils.isLoggedIn(mAppContext)) {
            getCartItemQuantityFromCache(variantId, cartItemQuantityListener);
        } else {
            getCartItemQuantityFromDB(variantId, cartItemQuantityListener);
        }
    }

    private void getCartItemQuantityFromCache(final long variantId, final IGetCartItemQuantityListener cartItemQuantityListener) {
        new AsyncTask<Void, Void, Integer>() {

            @Override
            protected Integer doInBackground(Void... params) {
                if (mCartResponse != null && mCartResponse.getCart() != null
                        && mCartResponse.getCart().getCartItems() != null) {
                    for (Cart.ResponseCartItem cartItem : mCartResponse.getCart().getCartItems()) {
                        if (cartItem.getVariantId() == variantId) {
                            return cartItem.getQuantity();
                        }
                    }
                }

                return 0;
            }

            @Override
            protected void onPostExecute(Integer quantity) {
                super.onPostExecute(quantity);
                cartItemQuantityListener.cartItemQuantity(quantity);
            }
        }.execute();
    }

    private void getCartItemQuantityFromDB(long variantId, final IGetCartItemQuantityListener cartItemQuantityListener) {
        new QueryExecutor(mAppContext, QueryProvider.getCartItemQuantityQuery(new IDataBaseResultNotifier() {
            @Override
            public <T> void OnDataBaseDataUpdated(T data) {
                int quantity = 0;
                if (data != null) {
                    try {
                        quantity = (Integer) data;
                    } catch (ClassCastException exception) {
                        exception.printStackTrace();
                    }
                }

                cartItemQuantityListener.cartItemQuantity(quantity);
            }
        }, variantId)).execute();
    }

    public void registerNotificationsCountChangeNotifier(INotificationsCountChangeNotifier notificationsCountChangeNotifier) {
        mNotificationsCountChangeNotifiers.add(notificationsCountChangeNotifier);
    }

    public void unregisterNotificationsCountChangeNotifier(INotificationsCountChangeNotifier notificationsCountChangeNotifier) {
        mNotificationsCountChangeNotifiers.remove(notificationsCountChangeNotifier);
    }

    public void registerCartCountChangeNotifier(ICartCountChangeNotifier cartCountChangeNotifier) {
        mCartCountChangeNotifiers.add(cartCountChangeNotifier);
    }

    public void unregisterCartCountChangeNotifier(ICartCountChangeNotifier cartCheckoutResultNotifier) {
        mCartCountChangeNotifiers.remove(cartCheckoutResultNotifier);
    }

    public ApiCategories.Category getOtcMedicineCategory() {
        return mOtcMedicineCategory;
    }

    public ApiCategories.Category getMedicalAidsCategory() {
        return mMedicalAidsCategory;
    }

    public void getCartPrescriptionRequiredItems(final ICartUploadPrescriptionRequiredResultNotifier cartUploadPrescriptionRequiredResultNotifier) {
        new AsyncTask<Void, Void, ArrayList<BaseRecyclerAdapter.IViewType>>() {
            @Override
            protected ArrayList<BaseRecyclerAdapter.IViewType> doInBackground(Void... params) {
                ArrayList<BaseRecyclerAdapter.IViewType> cartUploadPrescriptionDataList = new ArrayList<>();
                if (mCartResponse != null && mCartResponse.getCart() != null
                        && mCartResponse.getCart().getCartItems() != null
                        && mCartResponse.getCart().getCartItems().size() > 0) {

                    CartUploadPrescriptionAdapter.CartUploadPrescriptionHeaderDataItem headerItem = new CartUploadPrescriptionAdapter.
                            CartUploadPrescriptionHeaderDataItem();
                    headerItem.cartItemHeader = mAppContext.getString(R.string.cart_upload_prescription_header_txt);
                    cartUploadPrescriptionDataList.add(headerItem);

                    for (Cart.ResponseCartItem cartItem : mCartResponse.getCart().getCartItems()) {
                        if (cartItem.getPrescriptionRequired() && !cartItem.getPrescriptionAvailable()) {
                            CartUploadPrescriptionAdapter.CartUploadPrescriptionDataItem cartUploadPrescriptionDataItem =
                                    new CartUploadPrescriptionAdapter.CartUploadPrescriptionDataItem();
                            cartUploadPrescriptionDataItem.productName = cartItem.getVariantName();
                            cartUploadPrescriptionDataItem.productStripInfo = ApiRequestProvider
                                    .getStripInfo(cartItem.getInnerPackageQuantity(), cartItem.getOuterPackageQuantity());

                            cartUploadPrescriptionDataList.add(cartUploadPrescriptionDataItem);
                        }
                    }
                }

                return cartUploadPrescriptionDataList;
            }

            @Override
            protected void onPostExecute(ArrayList<BaseRecyclerAdapter.IViewType> cartUploadPrescriptionScreenData) {
                super.onPostExecute(cartUploadPrescriptionScreenData);
                cartUploadPrescriptionRequiredResultNotifier.onCartPrescriptionRequiredListFetched(cartUploadPrescriptionScreenData);
            }
        }.execute();
    }

    public void getRevisedOrderPrescriptionRequiredItems(final ICartUploadPrescriptionRequiredResultNotifier cartUploadPrescriptionRequiredResultNotifier) {
        new AsyncTask<Void, Void, ArrayList<BaseRecyclerAdapter.IViewType>>() {
            @Override
            protected ArrayList<BaseRecyclerAdapter.IViewType> doInBackground(Void... params) {
                ArrayList<BaseRecyclerAdapter.IViewType> cartUploadPrescriptionDataList = new ArrayList<>();

                if (mRevisedOrderResponse != null && mRevisedOrderResponse.getOrderDetails() != null
                        && mRevisedOrderResponse.getOrderDetails().getOrderProductItems() != null
                        && mRevisedOrderResponse.getOrderDetails().getOrderProductItems().size() > 0) {

                    CartUploadPrescriptionAdapter.CartUploadPrescriptionHeaderDataItem headerItem = new CartUploadPrescriptionAdapter.
                            CartUploadPrescriptionHeaderDataItem();
                    headerItem.cartItemHeader = mAppContext.getString(R.string.cart_upload_prescription_header_txt);
                    cartUploadPrescriptionDataList.add(headerItem);

                    for (OrderDetails.OrderProductItem cartItem : mRevisedOrderResponse.getOrderDetails().getOrderProductItems()) {
                        if (cartItem.isPrescriptionRequired() && !cartItem.isPrescriptionAvailable()) {

                            CartUploadPrescriptionAdapter.CartUploadPrescriptionDataItem cartUploadPrescriptionDataItem =
                                    new CartUploadPrescriptionAdapter.CartUploadPrescriptionDataItem();
                            cartUploadPrescriptionDataItem.productName = cartItem.getVariantName();
                            cartUploadPrescriptionDataItem.productStripInfo = ApiRequestProvider
                                    .getStripInfo(cartItem.getInnerPackageQuantity(), cartItem.getOuterPackageQuantity());

                            cartUploadPrescriptionDataList.add(cartUploadPrescriptionDataItem);
                        }
                    }
                }

                return cartUploadPrescriptionDataList;
            }

            @Override
            protected void onPostExecute(ArrayList<BaseRecyclerAdapter.IViewType> cartUploadPrescriptionScreenData) {
                super.onPostExecute(cartUploadPrescriptionScreenData);
                cartUploadPrescriptionRequiredResultNotifier.onCartPrescriptionRequiredListFetched(cartUploadPrescriptionScreenData);
            }
        }.execute();
    }

    public void getCartSummaryItems(final ICartSummaryResultNotifier cartSummaryResultNotifier) {
        new AsyncTask<Void, Void, ArrayList<BaseRecyclerAdapter.IViewType>>() {
            @Override
            protected ArrayList<BaseRecyclerAdapter.IViewType> doInBackground(Void... params) {
                ArrayList<BaseRecyclerAdapter.IViewType> checkoutSummaryScreenData = new ArrayList<>();
                if (mCartResponse != null && mCartResponse.getCart() != null
                        && mCartResponse.getCart().getCartItems() != null
                        && mCartResponse.getCart().getCartItems().size() > 0) {

                    checkoutSummaryScreenData.add(new OrderHistoryProductInfoHeaderItem());

                    for (Cart.ResponseCartItem cartItem : mCartResponse.getCart().getCartItems()) {
                        OrderHistoryProductInfoItem orderItem = new OrderHistoryProductInfoItem();
                        orderItem.productName = cartItem.getVariantName();
                        if (cartItem.getDiscountAmount() > 0) {
                            orderItem.productPrice = (cartItem.getQuantity() * cartItem.getPromotionalPrice());
                        } else {
                            orderItem.productPrice = (cartItem.getQuantity() * cartItem.getSalesPrice());
                        }
                        orderItem.productQuantity = cartItem.getQuantity();
                        orderItem.maxOrderableQty = cartItem.getMaxOrderableQuantity();
                        orderItem.numberOfItems = mCartResponse.getCart().getCartItems().size();

                        checkoutSummaryScreenData.add(orderItem);
                    }

                    OrderHistoryShippingChargesItem shippingChargesItem = new OrderHistoryShippingChargesItem();
                    shippingChargesItem.shippingCharge = mCartResponse.getCart().getShippingTotal();
                    shippingChargesItem.shippingChargesTxt = "Shipping charges";
                    shippingChargesItem.shippingChargeDescription = mCartResponse.getCart().getShippingDescription();
                    shippingChargesItem.discountTotalTitle = "Additional discount";
                    shippingChargesItem.discountTotal = mCartResponse.getCart().getOfferDiscountTotal();
                    shippingChargesItem.rewardPoints = mCartResponse.getCart().getWalletAmount();
                    shippingChargesItem.isChecked = mCartResponse.getCart().isApplyWallet();
                    shippingChargesItem.isFullyPaidByWallet = mCartResponse.getCart().isFullyPaidByWallet();
                    if (mCartResponse.getCart().isFullyPaidByWallet()) {
                        shippingChargesItem.paymentInstrument = mCartResponse.getCart().getPayments().get(0).getPayment_instrument();
                        shippingChargesItem.paymentMethod = mCartResponse.getCart().getPayments().get(0).getPayment_method();
                    }
                    checkoutSummaryScreenData.add(shippingChargesItem);

                    OrderHistoryTotalAmountItem totalAmountItem = new OrderHistoryTotalAmountItem();
                    totalAmountItem.totalAmtTitle = "Order total";
                    totalAmountItem.totalAmt = mCartResponse.getCart().getNetPayableAmount();
                    checkoutSummaryScreenData.add(totalAmountItem);

                    if (mCartResponse.getCart().getWalletAmount() != 0.0d) {
                        checkoutSummaryScreenData.add(new RecyclerBorderItem(1));

                        CheckOutSummaryAdapter.CheckOutRewardPointsItem checkOutRewardPointsItem =
                                new CheckOutSummaryAdapter.CheckOutRewardPointsItem();
                        checkOutRewardPointsItem.checkBoxText = mCartResponse.getCart().getWalletAmount();
                        checkOutRewardPointsItem.checkBoxState = mCartResponse.getCart().isApplyWallet();
                        checkoutSummaryScreenData.add(checkOutRewardPointsItem);
                    }

                    checkoutSummaryScreenData.add(new RecyclerBorderItem(1));

                    if (mCartResponse.getCart().getPaymentMethods().size() > 0) {
                        boolean allUnChecked = false;
                        for (PaymentMethods paymentMethods : mCartResponse.getCart().getPaymentMethods()) {
                            if (paymentMethods.isChecked()) allUnChecked = true;
                        }
                        if (!allUnChecked)
                            mCartResponse.getCart().getPaymentMethods().get(0).setIsChecked(true);

                        if (mCartResponse.getCart().getPaymentMethods().size() > 0) {
                            checkoutSummaryScreenData.add(new CheckOutSummaryAdapter.CheckOutPayUsingItem());
                            for (PaymentMethods paymentMethods : mCartResponse.getCart().getPaymentMethods()) {

                                CheckOutSummaryAdapter.CheckOutSummaryRadioButtonDataItem radioDataItem =
                                        new CheckOutSummaryAdapter.CheckOutSummaryRadioButtonDataItem();
                                radioDataItem.paymentType = paymentMethods.getPaymentType();
                                radioDataItem.paymentMethod = paymentMethods;
                                radioDataItem.isSelected = paymentMethods.isChecked();
                                radioDataItem.paymentMethods = mCartResponse.getCart().getPaymentMethods();
                                checkoutSummaryScreenData.add(radioDataItem);
                            }
                        }
                    }
                }
                return checkoutSummaryScreenData;
            }

            @Override
            protected void onPostExecute(ArrayList<BaseRecyclerAdapter.IViewType> checkoutSummaryScreenData) {
                super.onPostExecute(checkoutSummaryScreenData);
                cartSummaryResultNotifier.onCarSummaryFetched(checkoutSummaryScreenData);
            }
        }.execute();
    }

    public void getRevisedOrderSummaryItems(final ICartSummaryResultNotifier cartSummaryResultNotifier) {
        new AsyncTask<Void, Void, ArrayList<BaseRecyclerAdapter.IViewType>>() {
            @Override
            protected ArrayList<BaseRecyclerAdapter.IViewType> doInBackground(Void... params) {
                ArrayList<BaseRecyclerAdapter.IViewType> checkoutSummaryScreenData = new ArrayList<BaseRecyclerAdapter.IViewType>();
                if (mRevisedOrderResponse != null && mRevisedOrderResponse.getOrderDetails() != null
                        && mRevisedOrderResponse.getOrderDetails().getOrderProductItems() != null
                        && mRevisedOrderResponse.getOrderDetails().getOrderProductItems().size() > 0) {

                    checkoutSummaryScreenData.add(new OrderHistoryProductInfoHeaderItem());

                    for (OrderDetails.OrderProductItem cartItem : mRevisedOrderResponse.getOrderDetails().getOrderProductItems()) {
                        OrderHistoryProductInfoItem orderItem = new OrderHistoryProductInfoItem();
                        orderItem.productName = cartItem.getVariantName();
                        if (cartItem.getDiscountAmount() > 0) {
                            orderItem.productPrice = (cartItem.getQuantity() * cartItem.getPromotionalPrice());
                        } else {
                            orderItem.productPrice = (cartItem.getQuantity() * cartItem.getSalesPrice());
                        }
                        orderItem.productQuantity = cartItem.getQuantity();
                        orderItem.maxOrderableQty = cartItem.getMaxOrderableQuantity();
                        orderItem.numberOfItems = mRevisedOrderResponse.getOrderDetails().
                                getOrderProductItems().size();

                        checkoutSummaryScreenData.add(orderItem);
                    }

                    OrderHistoryShippingChargesItem shippingChargesItem = new OrderHistoryShippingChargesItem();
                    shippingChargesItem.shippingCharge = mRevisedOrderResponse.getOrderDetails().getShippingTotal();
                    shippingChargesItem.shippingChargesTxt = "Shipping charges";
                    shippingChargesItem.shippingChargeDescription = mRevisedOrderResponse.getOrderDetails().getShippingDescription();
                    shippingChargesItem.discountTotalTitle = "Additional discount";
                    shippingChargesItem.discountTotal = mRevisedOrderResponse.getOrderDetails().getPromotionalDiscountTotal();
                    shippingChargesItem.rewardPoints = mCartResponse.getCart().getWalletAmount();
                    shippingChargesItem.isChecked = mCartResponse.getCart().isApplyWallet();
                    shippingChargesItem.isFullyPaidByWallet = mCartResponse.getCart().isFullyPaidByWallet();
                    if (mCartResponse.getCart().isFullyPaidByWallet()) {
                        shippingChargesItem.paymentInstrument = mCartResponse.getCart().getPayments().get(0).getPayment_instrument();
                        shippingChargesItem.paymentMethod = mCartResponse.getCart().getPayments().get(0).getPayment_method();
                    }
                    checkoutSummaryScreenData.add(shippingChargesItem);

                    OrderHistoryTotalAmountItem totalAmountItem = new OrderHistoryTotalAmountItem();
                    totalAmountItem.totalAmtTitle = "Order total";
                    totalAmountItem.totalAmt = mRevisedOrderResponse.getOrderDetails().getTotal();
                    checkoutSummaryScreenData.add(totalAmountItem);


                /*    if (mRevisedOrderResponse.getOrderDetails().getWalletAmount() != 0.0d) {
                        checkoutSummaryScreenData.add(new RecyclerBorderItem(1));

                        CheckOutSummaryAdapter.CheckOutRewardPointsItem checkOutRewardPointsItem =
                                new CheckOutSummaryAdapter.CheckOutRewardPointsItem();
                        checkOutRewardPointsItem.checkBoxText = mRevisedOrderResponse.getOrderDetails().getWalletAmount();
                        checkOutRewardPointsItem.checkBoxState = mRevisedOrderResponse.getOrderDetails().isApplyWallet();
                        checkoutSummaryScreenData.add(checkOutRewardPointsItem);
                    }*/

                    checkoutSummaryScreenData.add(new RecyclerBorderItem(1));

                    if (mRevisedOrderResponse.getOrderDetails().getPaymentMethods().size() > 0) {
                        boolean allUnChecked = false;
                        for (PaymentMethods paymentMethods : mRevisedOrderResponse.getOrderDetails().getPaymentMethods()) {
                            if (paymentMethods.isChecked()) allUnChecked = true;
                        }
                        if (!allUnChecked)
                            mCartResponse.getCart().getPaymentMethods().get(0).setIsChecked(true);

                        if (mRevisedOrderResponse.getOrderDetails().getPaymentMethods().size() > 0) {
                            checkoutSummaryScreenData.add(new CheckOutSummaryAdapter.CheckOutPayUsingItem());
                            for (PaymentMethods paymentMethods : mRevisedOrderResponse.getOrderDetails().getPaymentMethods()) {

                                CheckOutSummaryAdapter.CheckOutSummaryRadioButtonDataItem radioDataItem =
                                        new CheckOutSummaryAdapter.CheckOutSummaryRadioButtonDataItem();
                                radioDataItem.paymentType = paymentMethods.getPaymentType();
                                radioDataItem.paymentMethod = paymentMethods;
                                radioDataItem.isSelected = paymentMethods.isChecked();
                                radioDataItem.paymentMethods = mRevisedOrderResponse.getOrderDetails().getPaymentMethods();
                                checkoutSummaryScreenData.add(radioDataItem);
                            }
                        }
                    }
                }
                return checkoutSummaryScreenData;
            }

            @Override
            protected void onPostExecute(ArrayList<BaseRecyclerAdapter.IViewType> checkoutSummaryScreenData) {
                super.onPostExecute(checkoutSummaryScreenData);
                cartSummaryResultNotifier.onCarSummaryFetched(checkoutSummaryScreenData);
            }
        }.execute();
    }

    public void getCheckOutAddressData(final ICartCheckOutPatientDetailsResultNotifier cartCheckOutResultNotifier) {
        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... params) {
                String isMandatory = "";
                if (mCartResponse != null && mCartResponse.getCart() != null) {
                    isMandatory = mCartResponse.getCart().getIsMandatory();
                }
                return isMandatory;
            }

            @Override
            protected void onPostExecute(String isMandatory) {
                super.onPostExecute(isMandatory);
                cartCheckOutResultNotifier.onCheckOutResultFetched(isMandatory);
            }
        }.execute();
    }

    /**
     * Method to register the request to handle the response Call backs.
     * <p><b>NOTE: </b>Use this method to handle the response callback together with
     * setAPIRequestCancelHandler(IRequestCancelHandler handler) method in FRGsonRequest.</p>
     */
    public void registerRequest(IApiRequestCancel requestHandler) {
        mRequestTagList.add(requestHandler.getRequestTag());
    }

    /**
     * Method to unregister the request,
     * <p>EmailRequest response will not return response if you had set the EmailRequest Cancel Handler to your created request.</p>
     */
    public void unregisterRequest(IApiRequestCancel requestHandler) {
        ApiRequestExecutor.getInstance(mAppContext).cancelRequestsWithTag(requestHandler.getRequestTag());
        mRequestTagList.remove(requestHandler.getRequestTag());
    }

    @Override
    public boolean isRequestCancelled(String requestTag) {

        return mRequestTagList.contains(requestTag);
    }

    private void addAccessTokenHeader(@NonNull HashMap<String, String> requestHeader) {
        String accessToken = PreferenceUtils.getStringFromSharedPreference(mAppContext, PreferenceUtils.PREFERENCE_KEY_ACCESS_TOKEN);
        requestHeader.put("X-Auth-Token", accessToken);
        addAccessHeader(requestHeader);
    }

    private void addAccessHeader(@NonNull HashMap<String, String> requestHeader) {
        requestHeader.put("Access", "application/json");
    }

    private int getCurrentCityId() {
        return PreferenceUtils.getIntegerFromSharedPreference(mAppContext, PreferenceUtils.PREFERENCE_KEY_LOCATION_ID);
    }

    public void performApiStatusRequest(IApiStatusResultNotifier apiStatusResultNotifier,
                                        IErrorHandler errorHandler, IApiRequestCancel requestCancel) {

        FRGsonRequest.SuccessResponseListener<ApiStatus.Response>
                successResponseListener = getAPIStatusSuccessResponseListener(apiStatusResultNotifier);

        FRGsonRequest<ApiStatus.Response, ApiCommonError> loginRequest = ApiRequestProvider
                .getApiStatusRequest(successResponseListener,
                        getCommonErrResponseListener(errorHandler), requestCancel.getRequestTag());
        loginRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(loginRequest);

    }

    private FRGsonRequest.SuccessResponseListener<ApiStatus.Response> getAPIStatusSuccessResponseListener(
            final IApiStatusResultNotifier apiStatusResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiStatus.Response>() {
            @Override
            public void onResponse(ApiStatus.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    switch (response.mStatus) {
                        case ApiStatus.STATUS_DEPRECATED:
                            apiStatusResultNotifier.onApiDeprecated();
                            break;

                        case ApiStatus.STATUS_DISCONTINUED:
                            apiStatusResultNotifier.onApiDiscontinued();
                            break;

                        case ApiStatus.STATUS_LIVE:
                            apiStatusResultNotifier.onApiLive();
                            break;

                        default:
                            apiStatusResultNotifier.onApiLive();
                            break;
                    }
                }
            }
        };
    }

    public void performDeviceRegistration(IDeviceRegisterResultNotifier deviceRegisterResultNotifier, String gcmToken,
                                          IApiRequestCancel requestCancel) {
        FRGsonRequest.SuccessResponseListener<ApiDeviceRegister.Response>
                successResponseListener = getDeviceRegisterSuccessResponseListener(deviceRegisterResultNotifier);
        FRGsonRequest.ErrorResponseListener<ApiCommonError>
                errorResponseListener = getDeviceRegisterErrorResponseListener(deviceRegisterResultNotifier);

        ApiDeviceRegister.Request deviceRegisterRequest = new ApiDeviceRegister.Request(gcmToken);

        FRGsonRequest<ApiDeviceRegister.Response, ApiCommonError> deviceRegister = ApiRequestProvider
                .getDeviceRegisterRequest(deviceRegisterRequest, successResponseListener, errorResponseListener,
                        requestCancel.getRequestTag());
        deviceRegister.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(deviceRegister);
    }

    private FRGsonRequest.ErrorResponseListener<ApiCommonError> getDeviceRegisterErrorResponseListener(
            final IDeviceRegisterResultNotifier deviceRegisterResultNotifier) {
        return new FRGsonRequest.ErrorResponseListener<ApiCommonError>() {
            @Override
            public void onErrorResponse(ApiCommonError errorResponse, int statusCode) {
                deviceRegisterResultNotifier.onDeviceRegistrationFailed();
            }

            @Override
            public void onError(int messageId) {
                deviceRegisterResultNotifier.onDeviceRegistrationFailed();
            }
        };
    }

    private FRGsonRequest.SuccessResponseListener<ApiDeviceRegister.Response> getDeviceRegisterSuccessResponseListener(
            final IDeviceRegisterResultNotifier deviceRegisterResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiDeviceRegister.Response>() {
            @Override
            public void onResponse(ApiDeviceRegister.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getDevice() != null &&
                        !TextUtils.isEmpty(response.getDevice().getToken())) {
                    deviceRegisterResultNotifier.onDeviceRegistered(response.getDevice().getToken());
                } else {
                    deviceRegisterResultNotifier.onDeviceRegistrationFailed();
                }
            }
        };
    }

    public void performLoginRequest(@NonNull String emailOrPhoneNUmber, @NonNull String password,
                                    ILoginResultNotifier loginResultNotifier,
                                    IErrorHandler errorHandler, IApiRequestCancel requestCancel) {

        ApiLogin.Request requestData = getApiLoginRequestData(emailOrPhoneNUmber, password);
        Log.d(TAG, "gcm Token in login request Data = " + requestData.getUser().getToken());

        FRGsonRequest.SuccessResponseListener<ApiLogin.Response>
                successResponseListener = getLoginAPISuccessResponseListener(loginResultNotifier,
                errorHandler, requestCancel.getRequestTag());

        FRGsonRequest<ApiLogin.Response, ApiCommonError> loginRequest = ApiRequestProvider
                .getLoginRequest(requestData, successResponseListener,
                        getCommonErrResponseListener(errorHandler), requestCancel.getRequestTag());
        loginRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(loginRequest);
    }

    private ApiLogin.Request getApiLoginRequestData(String emailOrPhoneNumber, String password) {
        ApiLogin.Request request = new ApiLogin.Request();

        if (Utils.isValidEmail(emailOrPhoneNumber)) {
            ApiLogin.UserWithEmail loginRequestUser = new ApiLogin.UserWithEmail();
            loginRequestUser.setEmail(emailOrPhoneNumber);
            loginRequestUser.setPassword(password);
            loginRequestUser.setToken(PreferenceUtils.getStringFromSharedPreference(
                    FrankRossApplication.getFrankrossApplicationContext(), PreferenceUtils.PREFERENCE_KEY_GCM_TOKEN));
            request.setUser(loginRequestUser);
        } else {
            ApiLogin.UserWithPhoneNumber loginRequestUser = new ApiLogin.UserWithPhoneNumber();
            loginRequestUser.setPhoneNumber(emailOrPhoneNumber);
            loginRequestUser.setPassword(password);
            loginRequestUser.setToken(PreferenceUtils.getStringFromSharedPreference(
                    FrankRossApplication.getFrankrossApplicationContext(), PreferenceUtils.PREFERENCE_KEY_GCM_TOKEN));
            request.setUser(loginRequestUser);
        }

        return request;
    }

    private FRGsonRequest.SuccessResponseListener<ApiLogin.Response> getLoginAPISuccessResponseListener(
            final ILoginResultNotifier loginResultNotifier, final IErrorHandler errorHandler, final String requestTag) {
        return new FRGsonRequest.SuccessResponseListener<ApiLogin.Response>() {
            @Override
            public void onResponse(ApiLogin.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getUser() != null) {
                    PreferenceUtils.saveStringIntoSharedPreference(mAppContext,
                            PreferenceUtils.PREFERENCE_KEY_ACCESS_TOKEN, response.getUser().getAuth_token());
                    pushLocalCartItemsToSever(loginResultNotifier, response.getUser().getAuth_token());
                    clearWebVIewCookies();

                    FRGsonRequest.SuccessResponseListener<ApiUserInformation.Response>
                            successResponseListener = getUserInfoAPISuccessResponseListener(
                            new IGetUserInfoResultNotifier() {
                                @Override
                                public void onUserInfoFetched(UserInformation userInfo) {
                                    Utils.saveUserName(mAppContext, userInfo.userName);
                                    Utils.saveUserMobileNUmber(mAppContext, userInfo.userMobileNumber);
                                    Utils.saveUserID(mAppContext, userInfo.userId);
                                    BranchManager.getBranchInstance(mAppContext).setIdentity(userInfo.userId);

                                    if (Utils.getBooleanIsRegistered(mAppContext) && Utils.getBooleanIsWelcomeDialogShown(mAppContext)) {
                                        BranchManager.logBranchUserRegistrationEvent(mAppContext);
                                        Utils.clearIsRegistered(mAppContext);
                                        Utils.clearIsWelcomeDialogShown(mAppContext);
                                    }
                                }
                            }, errorHandler);

                    HashMap<String, String> requestHeader = new HashMap<>();
                    addAccessTokenHeader(requestHeader);

                    FRGsonRequest<ApiUserInformation.Response, ApiCommonError> getLocationGsonRequest = ApiRequestProvider
                            .getUserInformationRequest(requestHeader, successResponseListener, getCommonErrResponseListener(errorHandler),
                                    requestTag);

                    ApiRequestExecutor.getInstance(mAppContext).executeRequest(getLocationGsonRequest);
                }
            }
        };
    }

    private void clearWebVIewCookies() {
        CookieManager cookieManager = CookieManager.getInstance();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            cookieManager.removeAllCookies(null);
        } /*else if (cookieManager.hasCookies()) {
            cookieManager.removeAllCookie();
        }*/
    }

    private void pushLocalCartItemsToSever(final ILoginResultNotifier loginResultNotifier, final String auth_token) {
        new QueryExecutor(mAppContext, QueryProvider.getAllCartItemsQuery(new IDataBaseResultNotifier() {
            @Override
            public <T> void OnDataBaseDataUpdated(T data) {
                try {
                    List<RequestCartItem> requestCartItems = (List<RequestCartItem>) data;

                    if (requestCartItems.size() > 0) {
                        final IApiRequestCancel apiRequestCancel = new IApiRequestCancel() {
                            @Override
                            public String getRequestTag() {
                                return "cart Cache";
                            }
                        };
                        registerRequest(apiRequestCancel);

                        performAddCartRequest(requestCartItems, new IAddCartResultNotifier() {
                            @Override
                            public void onProductAdded() {
                                clearCartCache();
                                unregisterRequest(apiRequestCancel);
                                loginResultNotifier.onLoginCompleted(auth_token);
                            }

                            @Override
                            public void onProductAddFailed() {
                                unregisterRequest(apiRequestCancel);
                                loginResultNotifier.onLoginCompleted(auth_token);
                            }
                        }, new IErrorHandler() {
                            @Override
                            public <T> void handleError(AlertError<T> alertError, int statusCode) {
                                unregisterRequest(apiRequestCancel);
                                loginResultNotifier.onLoginCompleted(auth_token);
                            }

                            @Override
                            public void handleCommonError(int errorResourceId) {
                                unregisterRequest(apiRequestCancel);
                                loginResultNotifier.onLoginCompleted(auth_token);
                            }
                        }, apiRequestCancel);
                    } else {
                        loginResultNotifier.onLoginCompleted(auth_token);
                    }
                } catch (ClassCastException e) {
                    e.printStackTrace();
                }
            }
        })).execute();
    }

    private void clearCartCache() {
        new QueryExecutor(mAppContext, QueryProvider.getDeleteAllQuery(new IDataBaseResultNotifier() {
            @Override
            public <T> void OnDataBaseDataUpdated(T data) {
            }
        }, DataBaseTableConstants.TableID.ID_CART_CACHE_TABLE)).execute();
    }

    public void performLogoutRequest(ILogoutResultNotifier logoutResultNotifier,
                                     IErrorHandler errorHandler,
                                     IApiRequestCancel requestCancel) {

        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessHeader(requestHeader);
        addAccessTokenHeader(requestHeader);

        String gcmToken = PreferenceUtils.getStringFromSharedPreference(
                FrankRossApplication.getFrankrossApplicationContext(), PreferenceUtils.PREFERENCE_KEY_GCM_TOKEN);

        FRGsonRequest.SuccessResponseListener<ApiLogout.Response>
                successResponseListener = getLogoutAPISuccessResponseListener(logoutResultNotifier);

        FRGsonRequest<ApiLogout.Response, ApiCommonError> registerGsonRequest = ApiRequestProvider
                .getLogoutRequest(gcmToken, requestHeader, successResponseListener,
                        getCommonErrResponseListener(errorHandler), requestCancel.getRequestTag());
        registerGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(registerGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiLogout.Response> getLogoutAPISuccessResponseListener(
            final ILogoutResultNotifier logoutResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiLogout.Response>() {
            @Override
            public void onResponse(ApiLogout.Response response, Map<String, String> responseHeaders) {
                clearCartItemsCount();
                BranchManager.getBranchInstance(mAppContext).logout();
                logoutResultNotifier.onLogoutCompleted();
            }
        };
    }

    public void performRegisterRequest(@NonNull String name, String email, String password,
                                       String phoneNumber, String phoneNumberType,
                                       IRegisterResultNotifier registerResultNotifier,
                                       IErrorHandler errorHandler,
                                       IApiRequestCancel requestCancel) {

        ApiRegister.Request requestData = getRegisterApiRequestData(name, email, password,
                phoneNumber, phoneNumberType);
        FRGsonRequest.SuccessResponseListener<ApiRegister.Response>
                successResponseListener = getRegisterAPISuccessResponseListener(registerResultNotifier);
        FRGsonRequest.ErrorResponseListener<ApiRegister.Response>
                errorResponseListener = getRegisterAPIErrorResponseListener(registerResultNotifier);

        FRGsonRequest<ApiRegister.Response, ApiRegister.Response> registerGsonRequest = ApiRequestProvider
                .getRegisterRequest(requestData, successResponseListener,
                        /*getCommonErrResponseListener(errorHandler)*/errorResponseListener,
                        requestCancel.getRequestTag());
        registerGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(registerGsonRequest);
    }

    private ApiRegister.Request getRegisterApiRequestData(String name, String email,
                                                          String password, String phoneNumber,
                                                          String phoneNumberType) {
        ApiRegister.Request registerBodyRequest = new ApiRegister.Request();
        ApiRegister.Request.User registerUser = new ApiRegister.Request.User();

        registerUser.setName(name);
        registerUser.setEmail(email);
        registerUser.setPassword(password);
        registerUser.setPrimaryPhone(phoneNumber);
        registerUser.setPrimaryPhoneType(phoneNumberType);

        registerBodyRequest.setUser(registerUser);

        return registerBodyRequest;
    }

    private FRGsonRequest.ErrorResponseListener<ApiRegister.Response> getRegisterAPIErrorResponseListener(
            final IRegisterResultNotifier registerResultNotifier) {
        return new FRGsonRequest.ErrorResponseListener<ApiRegister.Response>() {
            @Override
            public void onErrorResponse(ApiRegister.Response errorResponse, int statusCode) {
                registerResultNotifier.onRegisterError(errorResponse);
            }

            @Override
            public void onError(int messageId) {

            }
        };
    }

    private FRGsonRequest.SuccessResponseListener<ApiRegister.Response> getRegisterAPISuccessResponseListener(
            final IRegisterResultNotifier registerResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiRegister.Response>() {
            @Override
            public void onResponse(ApiRegister.Response response, Map<String, String> responseHeaders) {
                if (response != null)
                    registerResultNotifier.onRegisterCompleted(response);
            }
        };
    }

    public void performVerifyOtpRequest(String otp, @NonNull String emailOrPhoneNumber,
                                        IVerifyOtpResultNotifier verifyOtpResultNotifier,
                                        IApiRequestCancel requestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiVerifyOtp.Response>
                successResponseListener = getVerifyOtpAPISuccessResponseListener(verifyOtpResultNotifier);
        FRGsonRequest.ErrorResponseListener<ApiVerifyOtp.ErrorResponse>
                errorResponseListener = getVerifyOtpErrorResponseListener(verifyOtpResultNotifier);

        ApiVerifyOtp.Request requestData;

        if (Utils.isValidEmail(emailOrPhoneNumber)) {
            requestData = new ApiVerifyOtp.EmailRequest(emailOrPhoneNumber);
        } else {
            requestData = new ApiVerifyOtp.NumberRequest(emailOrPhoneNumber);
        }
        FRGsonRequest<ApiVerifyOtp.Response, ApiVerifyOtp.ErrorResponse> registerGsonRequest = ApiRequestProvider
                .getVerifyOtpForEmailRequest(otp, requestData, requestHeader, successResponseListener, errorResponseListener,
                        requestCancel.getRequestTag());
        registerGsonRequest.setAPIRequestCancelHandler(this);
        ApiRequestExecutor.getInstance(mAppContext).executeRequest(registerGsonRequest);
    }

    private FRGsonRequest.ErrorResponseListener<ApiVerifyOtp.ErrorResponse> getVerifyOtpErrorResponseListener(
            final IVerifyOtpResultNotifier verifyOtpResultNotifier) {
        return new FRGsonRequest.ErrorResponseListener<ApiVerifyOtp.ErrorResponse>() {
            @Override
            public void onErrorResponse(ApiVerifyOtp.ErrorResponse errorResponse, int statusCode) {
                if (errorResponse != null && !TextUtils.isEmpty(errorResponse.getFailureReason())) {
                    verifyOtpResultNotifier.onOtpApiError(errorResponse.getFailureReason());
                } else {
                    verifyOtpResultNotifier.onCommonError(R.string.server_error);
                }
            }

            @Override
            public void onError(int messageId) {
                verifyOtpResultNotifier.onCommonError(messageId);
            }
        };
    }

    private FRGsonRequest.SuccessResponseListener<ApiVerifyOtp.Response> getVerifyOtpAPISuccessResponseListener(
            final IVerifyOtpResultNotifier verifyOtpResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiVerifyOtp.Response>() {
            @Override
            public void onResponse(ApiVerifyOtp.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    verifyOtpResultNotifier.onOtpVerified();
                }
            }
        };
    }

    public void performCreateOTPRequest(String emailOrPhoneNumber, ICreateOTPResultNotifier resendOTPResultNotifier,
                                        IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiResendOtp.Response>
                successResponseListener = getResendOTPAPISuccessResponseListener(resendOTPResultNotifier, errorHandler);

        ApiResendOtp.Request requestData;

        if (Utils.isValidEmail(emailOrPhoneNumber)) {
            requestData = new ApiResendOtp.EmailRequest(emailOrPhoneNumber);
        } else {
            requestData = new ApiResendOtp.NumberRequest(emailOrPhoneNumber);
        }
        FRGsonRequest<ApiResendOtp.Response, ApiCommonError> getLocationGsonRequest = ApiRequestProvider
                .getCreateOtpForEmailRequest(requestData, requestHeader, successResponseListener, getCommonErrResponseListener(errorHandler),
                        apiRequestCancel.getRequestTag());
        getLocationGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(getLocationGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiResendOtp.Response> getResendOTPAPISuccessResponseListener(
            final ICreateOTPResultNotifier resendOTPResultNotifier, final IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiResendOtp.Response>() {
            @Override
            public void onResponse(ApiResendOtp.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    resendOTPResultNotifier.onOtpSent(response.getSuccessMessage());
                } else {
                    errorHandler.handleCommonError(R.string.server_error);
                }
            }
        };
    }

    public void performSetPasswordRequest(String password, String otp, String emailOrPhoneNumber,
                                          ISetPasswordResultNotifier updatePasswordResultNotifier,
                                          IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        FRGsonRequest.SuccessResponseListener<ApiSetPassword.Response>
                successResponseListener = getSetPasswordAPISuccessResponseListener(updatePasswordResultNotifier, errorHandler);

        ApiSetPassword.Request requestData;

        if (Utils.isValidEmail(emailOrPhoneNumber)) {
            requestData = new ApiSetPassword.EmailRequest(emailOrPhoneNumber);
        } else {
            requestData = new ApiSetPassword.NumberRequest(emailOrPhoneNumber);
        }

        requestData.setOtp(otp);
        ApiSetPassword.Request.User user = new ApiSetPassword.Request.User();
        user.setNewPassword(password);
        requestData.setUser(user);

        FRGsonRequest<ApiSetPassword.Response, ApiCommonError> setPasswordGsonRequest = ApiRequestProvider
                .getSetPasswordRequest(requestData, successResponseListener, getCommonErrResponseListener(errorHandler),
                        apiRequestCancel.getRequestTag());
        setPasswordGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(setPasswordGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiSetPassword.Response> getSetPasswordAPISuccessResponseListener(
            final ISetPasswordResultNotifier setPasswordResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiSetPassword.Response>() {
            @Override
            public void onResponse(ApiSetPassword.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    setPasswordResultNotifier.onPasswordSet();
                }
            }
        };
    }

    public void performChangeNumberRequest(String email, String password, String newNumber,
                                           IChangeNumberResultNotifier changeNumberResultNotifier,
                                           IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        FRGsonRequest.SuccessResponseListener<ApiChangeNumber.Response>
                successResponseListener = getChangeNumberApiSuccessResponseListener(changeNumberResultNotifier);

        ApiChangeNumber.Request changeNumberRequest = new ApiChangeNumber.Request();
        changeNumberRequest.setEmail(email);
        changeNumberRequest.setPassword(password);
        changeNumberRequest.getUser().setPrimary_phone(newNumber);

        FRGsonRequest<ApiChangeNumber.Response, ApiCommonError> setPasswordGsonRequest = ApiRequestProvider
                .getChangeNumberRequest(changeNumberRequest, successResponseListener, getCommonErrResponseListener(errorHandler),
                        apiRequestCancel.getRequestTag());
        setPasswordGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(setPasswordGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiChangeNumber.Response> getChangeNumberApiSuccessResponseListener(
            final IChangeNumberResultNotifier changeNumberResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiChangeNumber.Response>() {
            @Override
            public void onResponse(ApiChangeNumber.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    changeNumberResultNotifier.onNumberChanged();
                }
            }
        };
    }

    public void performGetLocationRequest(IGetLocationResultNotifier locationResultNotifier,
                                          @NonNull IErrorHandler errorHandler,
                                          IApiRequestCancel apiRequestCancel) {
        FRGsonRequest.SuccessResponseListener<ApiLocation.Response>
                successResponseListener = getLocationAPISuccessResponseListener(
                locationResultNotifier, errorHandler);

        FRGsonRequest<ApiLocation.Response, ApiCommonError> getLocationGsonRequest = ApiRequestProvider
                .getLocationRequest(successResponseListener, getCommonErrResponseListener(errorHandler),
                        apiRequestCancel.getRequestTag());
        getLocationGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(getLocationGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiLocation.Response> getLocationAPISuccessResponseListener(
            final IGetLocationResultNotifier locationResultNotifier, final IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiLocation.Response>() {
            @Override
            public void onResponse(ApiLocation.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getUiData() != null && response.getUiData().size() > 0) {
                    locationResultNotifier.onLocationFetched(response.getUiData(), response.getCities());
                } else {
                    errorHandler.handleCommonError(R.string.no_data_found_in_server);
                }
            }
        };
    }

    public void performCustomerCareNumberRequest(ICustomerCareNumberResultNotifier customerCareNumberResultNotifier,
                                                 @NonNull IErrorHandler errorHandler,
                                                 IApiRequestCancel apiRequestCancel) {
        FRGsonRequest.SuccessResponseListener<ApiCityDetails.Response>
                successResponseListener = getCustomerCareAPISuccessResponseListener(
                customerCareNumberResultNotifier);

        FRGsonRequest<ApiCityDetails.Response, ApiCommonError> getLocationGsonRequest = ApiRequestProvider
                .getCityDetailsRequest(getCurrentCityId(), successResponseListener, getCommonErrResponseListener(errorHandler),
                        apiRequestCancel.getRequestTag());
        getLocationGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(getLocationGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiCityDetails.Response> getCustomerCareAPISuccessResponseListener(
            final ICustomerCareNumberResultNotifier customerCareNumberResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiCityDetails.Response>() {
            @Override
            public void onResponse(ApiCityDetails.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getCityDetails() != null) {
                    customerCareNumberResultNotifier.onCustomerCareNumberFetched(response.getCityDetails().getCustomerCareNumber());
                } else {
                    customerCareNumberResultNotifier.onCustomerCareNumberFetched("");
                }
            }
        };
    }

    public void performUserInfoRequest(IGetUserInfoResultNotifier userInfoResultNotifier,
                                       IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        FRGsonRequest.SuccessResponseListener<ApiUserInformation.Response>
                successResponseListener = getUserInfoAPISuccessResponseListener(
                userInfoResultNotifier, errorHandler);

        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest<ApiUserInformation.Response, ApiCommonError> getLocationGsonRequest = ApiRequestProvider
                .getUserInformationRequest(requestHeader, successResponseListener, getCommonErrResponseListener(errorHandler),
                        apiRequestCancel.getRequestTag());
        getLocationGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(getLocationGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiUserInformation.Response> getUserInfoAPISuccessResponseListener(
            final IGetUserInfoResultNotifier userInfoResultNotifier, final IErrorHandler errorHandler) {

        return new FRGsonRequest.SuccessResponseListener<ApiUserInformation.Response>() {
            @Override
            public void onResponse(ApiUserInformation.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getUser() != null) {
                    userInfoResultNotifier.onUserInfoFetched(response.getUiData());
                } else {
                    errorHandler.handleCommonError(R.string.no_data_found_in_server);
                }
            }
        };
    }

    public void performUpdateUserInfoRequest(String userName, String phoneNumber,
                                             IUpdateUserInfoResultNotifier updateUserInfoResultNotifier,
                                             IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        ApiUpdateUserInformation.Request request = new ApiUpdateUserInformation.Request(userName, phoneNumber);

        FRGsonRequest.SuccessResponseListener<ApiUpdateUserInformation.Response>
                successResponseListener = getUpdateUserInfoAPISuccessResponseListener(
                updateUserInfoResultNotifier);

        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest<ApiUpdateUserInformation.Response, ApiCommonError> getLocationGsonRequest = ApiRequestProvider
                .getUpdateUserInformationRequest(request, requestHeader, successResponseListener, getCommonErrResponseListener(errorHandler),
                        apiRequestCancel.getRequestTag());
        getLocationGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(getLocationGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiUpdateUserInformation.Response> getUpdateUserInfoAPISuccessResponseListener(
            final IUpdateUserInfoResultNotifier updateUserInfoResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiUpdateUserInformation.Response>() {
            @Override
            public void onResponse(ApiUpdateUserInformation.Response response, Map<String, String> responseHeaders) {
                updateUserInfoResultNotifier.onUserInfoUpdated();
            }
        };
    }

    public void performUpdateUserPassword(String oldPassword, String newPassword,
                                          IUpdateUserPasswordResultNotifier updateUserPasswordResultNotifier,
                                          IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        ApiUpdateUserPassword.Request updatePasswordRequestData = new ApiUpdateUserPassword.Request(oldPassword, newPassword);

        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiUpdateUserPassword.Response>
                successResponseListener = getUpdateUserPasswordAPISuccessResponseListener(updateUserPasswordResultNotifier);

        FRGsonRequest<ApiUpdateUserPassword.Response, ApiCommonError> getLocationGsonRequest = ApiRequestProvider
                .getUpdateUserPasswordRequest(updatePasswordRequestData, requestHeader, successResponseListener,
                        getCommonErrResponseListener(errorHandler),
                        apiRequestCancel.getRequestTag());
        getLocationGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(getLocationGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiUpdateUserPassword.Response> getUpdateUserPasswordAPISuccessResponseListener(
            final IUpdateUserPasswordResultNotifier updateUserPasswordResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiUpdateUserPassword.Response>() {
            @Override
            public void onResponse(ApiUpdateUserPassword.Response response, Map<String, String> responseHeaders) {
                updateUserPasswordResultNotifier.onUserPasswordUpdated();
            }
        };
    }

    public void performGetAddressRequest(IGetAddressResultNotifier getAddressResultNotifier,
                                         IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiGetAddress.Response>
                successResponseListener = getAddressAPISuccessResponseListener(getAddressResultNotifier);

        FRGsonRequest<ApiGetAddress.Response, ApiCommonError> getLocationGsonRequest = ApiRequestProvider
                .getDeliveryAddressRequest(getCurrentCityId(), requestHeader, successResponseListener,
                        getAddressErrResponseListener(errorHandler, getAddressResultNotifier), apiRequestCancel.getRequestTag());
        getLocationGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(getLocationGsonRequest);
    }

    private FRGsonRequest.ErrorResponseListener<ApiCommonError> getAddressErrResponseListener(
            final IErrorHandler errorHandler, final IGetAddressResultNotifier getAddressResultNotifier) {
        return new FRGsonRequest.ErrorResponseListener<ApiCommonError>() {
            @Override
            public void onErrorResponse(ApiCommonError errorResponse, int statusCode) {
                if (errorHandler != null) {
                    errorHandler.handleError(getAlertError(errorResponse), statusCode);
                    getAddressResultNotifier.onAddressFetched(null, null);
                }
            }

            @Override
            public void onError(int messageId) {
                if (errorHandler != null) {
                    errorHandler.handleCommonError(messageId);
                    getAddressResultNotifier.onAddressFetched(null, null);
                }
            }
        };
    }

    private FRGsonRequest.SuccessResponseListener<ApiGetAddress.Response> getAddressAPISuccessResponseListener(
            final IGetAddressResultNotifier getAddressResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiGetAddress.Response>() {
            @Override
            public void onResponse(ApiGetAddress.Response response, Map<String, String> responseHeaders) {
                getAddressResultNotifier.onAddressFetched(response.getUiData(), response.getAddressList());
            }
        };
    }

    public void performAddAddressRequest(ApiAddress.Request addAddress, IAddAddressResultNotifier addAddressResultNotifier,
                                         IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiAddress.Response>
                successResponseListener = getAddAddressAPISuccessResponseListener(addAddressResultNotifier);

        FRGsonRequest<ApiAddress.Response, ApiCommonError> getLocationGsonRequest = ApiRequestProvider
                .addDeliveryAddressRequest(getCurrentCityId(), addAddress, requestHeader, successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        getLocationGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(getLocationGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiAddress.Response> getAddAddressAPISuccessResponseListener(
            final IAddAddressResultNotifier addAddressResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiAddress.Response>() {
            @Override
            public void onResponse(ApiAddress.Response response, Map<String, String> responseHeaders) {
                addAddressResultNotifier.onAddressAdded();
            }
        };
    }

    public void performDefaultAddressRequest(String addressId, boolean isDefault,
                                             IDefaultAddressResultNotifier defaultAddressResultNotifier,
                                             IErrorHandler errorHandler,
                                             IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        ApiAddress.DefaultRequest defaultRequest = new ApiAddress.DefaultRequest();
        defaultRequest.setAddress(new ApiAddress.DefaultRequest.PutAddress(isDefault));

        FRGsonRequest.SuccessResponseListener<ApiAddress.DefaultResponse>
                successResponseListener = getDefaultAddressAPISuccessResponseListener(defaultAddressResultNotifier);

        FRGsonRequest<ApiAddress.DefaultResponse, ApiCommonError> setDefaultAddressGsonRequest = ApiRequestProvider
                .defaultAddressRequest(addressId, getCurrentCityId(), defaultRequest,
                        requestHeader, successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        setDefaultAddressGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(setDefaultAddressGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiAddress.DefaultResponse> getDefaultAddressAPISuccessResponseListener(
            final IDefaultAddressResultNotifier defaultAddressResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiAddress.DefaultResponse>() {
            @Override
            public void onResponse(ApiAddress.DefaultResponse response, Map<String, String> responseHeaders) {
                defaultAddressResultNotifier.onDefaultAddressSet();
            }
        };
    }

    public void performDeleteAddressRequest(long addressId, IDeleteAddressResultNotifier deleteAddressResultNotifier,
                                            IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiAddress.DefaultResponse>
                successResponseListener = getDeleteAddressAPISuccessResponseListener(deleteAddressResultNotifier);

        FRGsonRequest<ApiAddress.DefaultResponse, ApiCommonError> updateAddressGsonRequest = ApiRequestProvider
                .getDeleteDeliveryAddressRequest(getCurrentCityId(), addressId, requestHeader, successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        updateAddressGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(updateAddressGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiAddress.DefaultResponse> getDeleteAddressAPISuccessResponseListener(
            final IDeleteAddressResultNotifier deleteAddressResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiAddress.DefaultResponse>() {
            @Override
            public void onResponse(ApiAddress.DefaultResponse response, Map<String, String> responseHeaders) {
                deleteAddressResultNotifier.onAddressDeleted();
            }
        };
    }

    public void performUpdateAddressRequest(ApiAddress.Request addAddress, IUpdateAddressResultNotifier updateAddressResultNotifier,
                                            IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiAddress.Response>
                successResponseListener = getUpdateAddressAPISuccessResponseListener(updateAddressResultNotifier);

        FRGsonRequest<ApiAddress.Response, ApiCommonError> updateAddressGsonRequest = ApiRequestProvider
                .updateDeliveryAddressRequest(getCurrentCityId(), addAddress, requestHeader, successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        updateAddressGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(updateAddressGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiAddress.Response> getUpdateAddressAPISuccessResponseListener(
            final IUpdateAddressResultNotifier iUpdateAddressResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiAddress.Response>() {
            @Override
            public void onResponse(ApiAddress.Response response, Map<String, String> responseHeaders) {
                iUpdateAddressResultNotifier.onAddressUpdated();
            }
        };
    }

    public void performGetDeliverySlotRequest(int areaId, long prescriptionId, int fulFillmentCenterId,
                                              IGetDeliverySlotsResultNotifier deliverySlotsResultNotifier,
                                              IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiDeliverySlot.Response>
                successResponseListener = getDeliverySlotsPISuccessResponseListener(deliverySlotsResultNotifier);

        FRGsonRequest<ApiDeliverySlot.Response, ApiCommonError> updateAddressGsonRequest = ApiRequestProvider
                .getDeliverySlotRequest(areaId, getCurrentCityId(), prescriptionId, fulFillmentCenterId,
                        requestHeader, successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        updateAddressGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(updateAddressGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiDeliverySlot.Response> getDeliverySlotsPISuccessResponseListener(
            final IGetDeliverySlotsResultNotifier deliverySlotsResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiDeliverySlot.Response>() {
            @Override
            public void onResponse(ApiDeliverySlot.Response response, Map<String, String> responseHeaders) {
                deliverySlotsResultNotifier.onDeliverySlotsFetched(response.getUiDataList());
            }
        };
    }

    public void performGetCategoriesRequest(IGetCategoriesResultNotifier categoriesResultNotifier,
                                            IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        FRGsonRequest.SuccessResponseListener<ApiCategories.Response>
                successResponseListener = getCategoriesAPISuccessResponseListener(categoriesResultNotifier, errorHandler);

        FRGsonRequest<ApiCategories.Response, ApiCommonError> categoryGsonRequest = ApiRequestProvider
                .getCategoriesRequest(getCurrentCityId(), successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        categoryGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(categoryGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiCategories.Response> getCategoriesAPISuccessResponseListener(
            final IGetCategoriesResultNotifier categoriesResultNotifier, final IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiCategories.Response>() {
            @Override
            public void onResponse(ApiCategories.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    if (response.getUiDataList() != null)
                        categoriesResultNotifier.onCategoriesFetched(response.getUiDataList());

                    if (response.getOtcMedicine() != null) {
                        mOtcMedicineCategory = response.getOtcMedicine();
                    }

                    if (response.getMedicalAidsMedicine() != null) {
                        mMedicalAidsCategory = response.getMedicalAidsMedicine();
                    }
                } else {
                    errorHandler.handleCommonError(R.string.server_error);
                }
            }
        };
    }

    public void performGetHomeFeaturedCategoriesRequest(IGetHomeFeaturedCategoriesResultNotifier homeCategoriesResultNotifier,
                                                        IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        FRGsonRequest.SuccessResponseListener<ApiCategories.HomeCategoryResponse>
                successResponseListener = getBaseCategoriesAPISuccessResponseListener(homeCategoriesResultNotifier, errorHandler);

        FRGsonRequest<ApiCategories.HomeCategoryResponse, ApiCommonError> homeCategoryGsonRequest = ApiRequestProvider
                .getHomeFeaturedCategoriesRequest(getCurrentCityId(), successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        homeCategoryGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(homeCategoryGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiCategories.HomeCategoryResponse>
    getBaseCategoriesAPISuccessResponseListener(final IGetHomeFeaturedCategoriesResultNotifier homeCategoriesResultNotifier,
                                                IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiCategories.HomeCategoryResponse>() {
            @Override
            public void onResponse(ApiCategories.HomeCategoryResponse response, Map<String, String> responseHeaders) {
                if (response != null) {
                    homeCategoriesResultNotifier.onHomeFeatureCategoriesFetched(response.getUiDataList());
                } else {
                    homeCategoriesResultNotifier.onHomeFeatureCategoriesFailed();
                }
            }
        };
    }

    public void performGetPrimaryCategoriesRequest(long categoryId, IGetPrimaryCategoriesResultNotifier primaryCategoriesResultNotifier,
                                                   IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        FRGsonRequest.SuccessResponseListener<ApiCategories.PrimaryCategoryResponse>
                successResponseListener = getPrimaryCategoriesAPISuccessResponseListener(primaryCategoriesResultNotifier, errorHandler);

        FRGsonRequest<ApiCategories.PrimaryCategoryResponse, ApiCommonError> homeCategoryGsonRequest = ApiRequestProvider
                .getPrimaryCategoriesRequest(categoryId, getCurrentCityId(), successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        homeCategoryGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(homeCategoryGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiCategories.PrimaryCategoryResponse>
    getPrimaryCategoriesAPISuccessResponseListener(final IGetPrimaryCategoriesResultNotifier primaryCategoriesResultNotifier,
                                                   IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiCategories.PrimaryCategoryResponse>() {
            @Override
            public void onResponse(ApiCategories.PrimaryCategoryResponse response, Map<String, String> responseHeaders) {
                if (response != null) {
                    primaryCategoriesResultNotifier.onPrimaryCategoriesAndPromotionFetched(response);
                }
            }
        };
    }

    public void performGetPharmaProductDetailsRequest(
            long variantId,
            IGetPharmaProductDetailResultNotifier pharmaProductDetailResultNotifier,
            IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        FRGsonRequest.SuccessResponseListener<ApiPharmaProduct>
                successResponseListener = getPharmaDetailsAPISuccessResponseListener(pharmaProductDetailResultNotifier, errorHandler);

        FRGsonRequest<ApiPharmaProduct, ApiCommonError> getLocationGsonRequest = ApiRequestProvider
                .getPharmaProductDetails(variantId, getCurrentCityId(), successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        getLocationGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(getLocationGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiPharmaProduct> getPharmaDetailsAPISuccessResponseListener(
            final IGetPharmaProductDetailResultNotifier pharmaProductDetailResultNotifier, final IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiPharmaProduct>() {
            @Override
            public void onResponse(ApiPharmaProduct response, Map<String, String> responseHeaders) {
                if (response != null) {
                    pharmaProductDetailResultNotifier.onPharmaProductDetailFetched(response);
                } else {
                    errorHandler.handleCommonError(R.string.server_error);
                }
            }
        };
    }

    public void performGetNonPharmaProductDetailsRequest(
            long variantId,
            IGetNonPharmaProductDetailResultNotifier nonPharmaProductDetailResultNotifier,
            IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        FRGsonRequest.SuccessResponseListener<ApiNonPharmaProduct>
                successResponseListener = getNonPharmaDetailsAPISuccessResponseListener(nonPharmaProductDetailResultNotifier, errorHandler);

        FRGsonRequest<ApiNonPharmaProduct, ApiCommonError> getLocationGsonRequest = ApiRequestProvider
                .getNonPharmaProductDetails(variantId, getCurrentCityId(), successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        getLocationGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(getLocationGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiNonPharmaProduct> getNonPharmaDetailsAPISuccessResponseListener(
            final IGetNonPharmaProductDetailResultNotifier nonPharmaProductDetailResultNotifier, final IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiNonPharmaProduct>() {
            @Override
            public void onResponse(ApiNonPharmaProduct response, Map<String, String> responseHeaders) {
                if (response != null) {
                    nonPharmaProductDetailResultNotifier.onNonPharmaProductDetailFetched(response);
                } else {
                    errorHandler.handleCommonError(R.string.server_error);
                }
            }
        };
    }

    public void performAddCartRequest(long variantId, int quantity, final IAddCartResultNotifier addCartResultNotifier,
                                      IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {

        if (Utils.isLoggedIn(mAppContext.getApplicationContext())) {
            performAddCartRequest(getRequestCartItems(variantId, quantity),
                    addCartResultNotifier, errorHandler, apiRequestCancel);
        } else {
            RequestCartItem requestCartItem = new RequestCartItem();
            requestCartItem.setVariantId(variantId);
            requestCartItem.setQuantity(quantity);

            new QueryExecutor(mAppContext, QueryProvider.getInsertCartItemQuery(new IDataBaseResultNotifier() {
                @Override
                public <T> void OnDataBaseDataUpdated(T data) {
                    getCartItemsFromDb(addCartResultNotifier);
                }
            }, requestCartItem)).execute();
        }
    }

    private void getCartItemsFromDb(final IAddCartResultNotifier addCartResultNotifier) {
        new QueryExecutor(mAppContext, QueryProvider.getAllCartItemsQuery(new IDataBaseResultNotifier() {
            @Override
            public <T> void OnDataBaseDataUpdated(T data) {
                try {
                    List<RequestCartItem> requestCartItems = (List<RequestCartItem>) data;

                    if (requestCartItems.size() > 0) {
                        updateCartItemsCount(requestCartItems.size());
                    } else {
                        updateCartItemsCount(0);
                    }
                } catch (ClassCastException e) {
                    e.printStackTrace();
                }

                addCartResultNotifier.onProductAdded();
            }
        })).execute();
    }

    public void performAddCartRequest(List<RequestCartItem> requestCartItems, IAddCartResultNotifier addCartResultNotifier,
                                      IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        ApiCart.Request cartRequest = new ApiCart.Request();
        cartRequest.setRequestCartItems(requestCartItems);

        FRGsonRequest.SuccessResponseListener<ApiCart.Response>
                successResponseListener = getAddCartAPISuccessResponseListener(addCartResultNotifier, errorHandler);

        FRGsonRequest<ApiCart.Response, ApiCommonError> addCartGsonRequest = ApiRequestProvider.getAddOrUpdateCartRequest(
                getCurrentCityId(), cartRequest, requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        addCartGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(addCartGsonRequest);
    }

    private List<RequestCartItem> getRequestCartItems(long variantId, int quantity) {
        List<RequestCartItem> requestCartItems = new ArrayList<>(1);
        RequestCartItem cartItem = new RequestCartItem();
        cartItem.setVariantId(variantId);
        cartItem.setQuantity(quantity);
        requestCartItems.add(cartItem);

        return requestCartItems;
    }

    private FRGsonRequest.SuccessResponseListener<ApiCart.Response> getAddCartAPISuccessResponseListener(
            final IAddCartResultNotifier addCartResultNotifier, IErrorHandler errorHandler) {

        return new FRGsonRequest.SuccessResponseListener<ApiCart.Response>() {
            @Override
            public void onResponse(ApiCart.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getCart() != null) {
                    mCartResponse = response;
                    updateCartItemsCount(response.getCart().getCartItems().size());
                    addCartResultNotifier.onProductAdded();
                } else {
                    addCartResultNotifier.onProductAddFailed();
                }
            }
        };
    }

    /**
     * Get Cart
     */
    private FRGsonRequest.SuccessResponseListener<ApiCart.Response> getCartSuccessResponseListener(
            final ICartResultNotifier updateCartResultNotifier, final IErrorHandler errorHandler) {

        return new FRGsonRequest.SuccessResponseListener<ApiCart.Response>() {
            @Override
            public void onResponse(ApiCart.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getUiDataList() != null) {
                    mCartResponse = response;
                    updateCartItemsCount(response.getCart().getCartItems().size());
                    updateCartResultNotifier.onCartResult(response.getUiDataList());
                } else {
                    mCartResponse = null;
                    updateCartItemsCount(0);
                    errorHandler.handleCommonError(R.string.no_data_found_in_server);
                }
            }
        };
    }

    public void performGetCartItemsRequest(ICartResultNotifier cartItemsResultNotifier,
                                           IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        if (Utils.isLoggedIn(mAppContext.getApplicationContext())) {
            getCartItemsFromAuthToken(cartItemsResultNotifier, errorHandler, apiRequestCancel);
        } else {
            getCartItemsFromCartCalculations(cartItemsResultNotifier, errorHandler, apiRequestCancel);
        }
    }

    private void getCartItemsFromCartCalculations(final ICartResultNotifier cartItemsResultNotifier,
                                                  final IErrorHandler errorHandler, final IApiRequestCancel apiRequestCancel) {
        new QueryExecutor(mAppContext, QueryProvider.getAllCartItemsQuery(new IDataBaseResultNotifier() {
            @Override
            public <T> void OnDataBaseDataUpdated(T data) {
                try {
                    List<RequestCartItem> requestCartItems = (List<RequestCartItem>) data;

                    if (requestCartItems.size() > 0) {
                        FRGsonRequest.SuccessResponseListener<ApiCart.Response>
                                successResponseListener = getCartSuccessResponseListener(cartItemsResultNotifier, errorHandler);

                        FRGsonRequest<ApiCart.Response, ApiCommonError> addCartGsonRequest = ApiRequestProvider.getCartCalculationRequest(
                                getCurrentCityId(), requestCartItems, successResponseListener,
                                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
                        addCartGsonRequest.setAPIRequestCancelHandler(ApiRequestManager.this);

                        ApiRequestExecutor.getInstance(mAppContext).executeRequest(addCartGsonRequest);
                    } else {
                        updateCartItemsCount(0);
                        cartItemsResultNotifier.onCartResult(new ArrayList<BaseRecyclerAdapter.IViewType>(1));
                    }
                } catch (ClassCastException e) {
                    e.printStackTrace();
                }
            }
        })).execute();
    }

    private void getCartItemsFromAuthToken(ICartResultNotifier cartItemsResultNotifier,
                                           IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiCart.Response>
                successResponseListener = getCartSuccessResponseListener(cartItemsResultNotifier, errorHandler);

        FRGsonRequest<ApiCart.Response, ApiCommonError> addCartGsonRequest = ApiRequestProvider.getCartItemsRequest(
                getCurrentCityId(), requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        addCartGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(addCartGsonRequest);
    }

    public void performUpdateCartRequest(long variantId, int quantity, final ICartUpdateResultNotifier updateCartResultNotifier,
                                         IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        if (Utils.isLoggedIn(mAppContext)) {
            HashMap<String, String> requestHeader = new HashMap<>();
            addAccessTokenHeader(requestHeader);

            ApiCart.Request cartRequest = new ApiCart.Request();
            cartRequest.setRequestCartItems(getRequestCartItems(variantId, quantity));

            FRGsonRequest.SuccessResponseListener<ApiCart.Response>
                    successResponseListener = getCartSuccessResponseListener(updateCartResultNotifier, errorHandler);

            FRGsonRequest<ApiCart.Response, ApiCommonError> addCartGsonRequest = ApiRequestProvider.getAddOrUpdateCartRequest(
                    getCurrentCityId(), cartRequest, requestHeader, successResponseListener,
                    getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
            addCartGsonRequest.setAPIRequestCancelHandler(this);

            ApiRequestExecutor.getInstance(mAppContext).executeRequest(addCartGsonRequest);
        } else {
            RequestCartItem requestCartItem = new RequestCartItem();
            requestCartItem.setVariantId(variantId);
            requestCartItem.setQuantity(quantity);

            new QueryExecutor(mAppContext, QueryProvider.getInsertCartItemQuery(new IDataBaseResultNotifier() {
                @Override
                public <T> void OnDataBaseDataUpdated(T data) {
                    updateCartResultNotifier.onCartUpdated();
                }
            }, requestCartItem)).execute();
        }
    }

    public void performDeleteCartItemsRequest(long variantId, final ICartItemDeleteResultNotifier cartItemsResultNotifier,
                                              IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        if (Utils.isLoggedIn(mAppContext.getApplicationContext())) {
            HashMap<String, String> requestHeader = new HashMap<>();
            addAccessTokenHeader(requestHeader);

            FRGsonRequest.SuccessResponseListener<ApiCart.Response>
                    successResponseListener = getCartSuccessResponseListener(cartItemsResultNotifier, errorHandler);

            FRGsonRequest<ApiCart.Response, ApiCommonError> addCartGsonRequest = ApiRequestProvider.getDeleteCartItemRequest(
                    variantId, getCurrentCityId(), requestHeader, successResponseListener,
                    getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
            addCartGsonRequest.setAPIRequestCancelHandler(this);

            ApiRequestExecutor.getInstance(mAppContext).executeRequest(addCartGsonRequest);
        } else {
            new QueryExecutor(mAppContext, QueryProvider.getDeleteCartItemQuery(new IDataBaseResultNotifier() {
                @Override
                public <T> void OnDataBaseDataUpdated(T data) {
                    cartItemsResultNotifier.onCartItemDeleted();
                    updateCartItemsCount(mCartItemsCount++);
                }
            }, variantId)).execute();
        }
    }

    /**
     * Apply Coupon Code
     */
    public void performApplyCouponCodeRequest(String couponCode, ICartResultNotifier cartItemsResultNotifier,
                                              IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiCart.Response>
                successResponseListener = getCartSuccessResponseListener(cartItemsResultNotifier, errorHandler);

        FRGsonRequest<ApiCart.Response, ApiCommonError> applyCouponCodeGsonRequest = ApiRequestProvider.getApplyCouponCodeRequest(
                couponCode, getCurrentCityId(), requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        applyCouponCodeGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(applyCouponCodeGsonRequest);
    }

    /**
     * Delete Coupon Code
     */
    public void performDeleteCouponCodeRequest(String couponCode, ICartResultNotifier cartItemsResultNotifier,
                                               IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiCart.Response>
                successResponseListener = getCartSuccessResponseListener(cartItemsResultNotifier, errorHandler);

        FRGsonRequest<ApiCart.Response, ApiCommonError> deleteCouponCodeGsonRequest = ApiRequestProvider.getDeleteCouponCodeRequest(
                couponCode, getCurrentCityId(), requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        deleteCouponCodeGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(deleteCouponCodeGsonRequest);
    }

    public void performCartCheckOutRequest(ApiCartCheckout.Request apiCartCheckOut, ICartCheckoutResultNotifier cartCheckoutResultNotifier,
                                           IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiCartCheckout.Response>
                successResponseListener = getCartCheckoutSuccessResponseListener(cartCheckoutResultNotifier, errorHandler);
        FRGsonRequest.ErrorResponseListener<ApiCartCheckout.ErrorResponse>
                errorResponseListener = getCartCheckoutErrorResponseListener(errorHandler, cartCheckoutResultNotifier);

        FRGsonRequest<ApiCartCheckout.Response, ApiCartCheckout.ErrorResponse> addCartGsonRequest = ApiRequestProvider.getCartCheckoutRequest(
                getCurrentCityId(), apiCartCheckOut, requestHeader, successResponseListener, errorResponseListener, apiRequestCancel.getRequestTag());
        addCartGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(addCartGsonRequest);
    }

    private FRGsonRequest.ErrorResponseListener<ApiCartCheckout.ErrorResponse>
    getCartCheckoutErrorResponseListener(final IErrorHandler errorHandler,
                                         final ICartCheckoutResultNotifier cartCheckoutResultNotifier) {
        return new FRGsonRequest.ErrorResponseListener<ApiCartCheckout.ErrorResponse>() {
            @Override
            public void onErrorResponse(ApiCartCheckout.ErrorResponse errorResponse, int statusCode) {
                if (statusCode == 422) {
                    if ((errorResponse != null && errorResponse.getOrder() != null && errorResponse.getOrder().getErrors().size() > 0)) {
                        cartCheckoutResultNotifier.onOrderFailed(true, errorResponse.getOrder().getErrors().get(0), 0);
                    } else {
                        cartCheckoutResultNotifier.onOrderFailed(true, "", 0);
                    }
                } else {
                    cartCheckoutResultNotifier.onOrderFailed(false, "Unable to checkout the order", 0);
                }

                // errorHandler.handleError(getAlertError("Server Error"), statusCode);
            }

            @Override
            public void onError(int messageId) {
                cartCheckoutResultNotifier.onOrderFailed(false, "", messageId);
                //errorHandler.handleCommonError(messageId);
            }
        };
    }

    private FRGsonRequest.SuccessResponseListener<ApiCartCheckout.Response> getCartCheckoutSuccessResponseListener(
            final ICartCheckoutResultNotifier cartCheckoutResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiCartCheckout.Response>() {
            @Override
            public void onResponse(ApiCartCheckout.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getCartOrder() != null) {
                    mCartResponse.getCart().setCartItems(null);
                    mCartItemsCount = 0;
                    cartCheckoutResultNotifier.onOrderIdCreated(response.getCartOrder().getId());
                }
            }
        };
    }

    private void getUploadPrescriptionRequest(
            final String imagePath, final IGetUploadPrescriptionRequestModel uploadPrescriptionRequestModel) {
        new AsyncTask<Void, Void, String>() {

            @Override
            protected String doInBackground(Void... params) {
                try {
                    //Bitmap bm = BitmapFactory.decodeFile(imagePath);
                    Bitmap bm = BitmapUtils.getScaledPrescriptionBitmap(imagePath);
                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    bm.compress(Bitmap.CompressFormat.JPEG, 100, baos); //bm is the bitmap object
                    byte[] byteArrayImage = baos.toByteArray();

                    String encodedImage = "data:image/jpeg;base64," + Base64.encodeToString(byteArrayImage, Base64.DEFAULT);
                    bm.recycle();

                    return encodedImage;
                } catch (Exception e) {
                    return null;
                }
            }

            @Override
            protected void onPostExecute(String encodedImage) {
                super.onPostExecute(encodedImage);
                Log.d(TAG, "Request  generated");
                uploadPrescriptionRequestModel.onUploadPrescriptionRequest(encodedImage);
            }
        }.execute();
    }

    public void performUploadPrescriptionRequest(final long prescriptionId, final String imagePath, final boolean isFromCart,
                                                 final IUploadPrescriptionNotifier uploadPrescriptionNotifier,
                                                 final IErrorHandler errorHandler, final IApiRequestCancel apiRequestCancel) {

        getUploadPrescriptionRequest(imagePath, new IGetUploadPrescriptionRequestModel() {
            @Override
            public void onUploadPrescriptionRequest(String encodedImage) {
                HashMap<String, String> requestHeader = new HashMap<>();
                addAccessTokenHeader(requestHeader);

                if (prescriptionId < 0) {
                    ApiUploadPrescription.PostRequest postRequest = new ApiUploadPrescription.PostRequest();
                    postRequest.getPrescription().setImageUploadBase64String(encodedImage);
                    postRequest.getPrescription().setPrepareCart(!isFromCart);

                    uploadPrescription(requestHeader, postRequest, uploadPrescriptionNotifier, errorHandler, apiRequestCancel);
                } else {
                    ApiUploadPrescription.PutRequest putRequest = new ApiUploadPrescription.PutRequest();
                    putRequest.getPrescription().setImageUploadBase64String(encodedImage);

                    uploadPrescription(prescriptionId, requestHeader, putRequest, uploadPrescriptionNotifier, errorHandler, apiRequestCancel);
                }
            }
        });
    }

    private void uploadPrescription(
            HashMap<String, String> requestHeader, ApiUploadPrescription.PostRequest uploadPrescriptionRequest,
            IUploadPrescriptionNotifier uploadPrescriptionNotifier, IErrorHandler errorHandler,
            IApiRequestCancel apiRequestCancel) {
        FRGsonRequest.SuccessResponseListener<ApiUploadPrescription.PostResponse>
                successResponseListener = getUploadPrescriptionSuccessResponseListener(uploadPrescriptionNotifier, errorHandler);

        FRGsonRequest<ApiUploadPrescription.PostResponse, ApiCommonError> uploadPrescriptionGsonRequest = ApiRequestProvider
                .getUploadPrescriptionRequest(getCurrentCityId(), uploadPrescriptionRequest,
                        requestHeader, successResponseListener, getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        uploadPrescriptionGsonRequest.setAPIRequestCancelHandler(ApiRequestManager.this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(uploadPrescriptionGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiUploadPrescription.PostResponse> getUploadPrescriptionSuccessResponseListener(
            final IUploadPrescriptionNotifier uploadPrescriptionNotifier, final IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiUploadPrescription.PostResponse>() {
            @Override
            public void onResponse(ApiUploadPrescription.PostResponse response, Map<String, String> responseHeaders) {
                if (response != null && response.getPrescription() != null) {
                    uploadPrescriptionNotifier.onPrescriptionUploaded(response.getPrescription().getImageUploadId());
                } else {
                    errorHandler.handleCommonError(R.string.server_error);
                }
            }
        };
    }

    private void uploadPrescription(long prescriptionId, HashMap<String, String> requestHeader,
                                    ApiUploadPrescription.PutRequest uploadPrescriptionRequest,
                                    IUploadPrescriptionNotifier uploadPrescriptionNotifier,
                                    IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        FRGsonRequest.SuccessResponseListener<ApiUploadPrescription.PutResponse>
                successResponseListener = getUploadPrescriptionSuccessResponseListener(prescriptionId, uploadPrescriptionNotifier, errorHandler);

        FRGsonRequest<ApiUploadPrescription.PutResponse, ApiCommonError> uploadPrescriptionPutRequest = ApiRequestProvider
                .getUploadPrescriptionRequest(getCurrentCityId(), prescriptionId, uploadPrescriptionRequest,
                        requestHeader, successResponseListener, getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        uploadPrescriptionPutRequest.setAPIRequestCancelHandler(ApiRequestManager.this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(uploadPrescriptionPutRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiUploadPrescription.PutResponse> getUploadPrescriptionSuccessResponseListener(
            final long prescriptionId, final IUploadPrescriptionNotifier uploadPrescriptionNotifier, final IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiUploadPrescription.PutResponse>() {
            @Override
            public void onResponse(ApiUploadPrescription.PutResponse response, Map<String, String> responseHeaders) {
                if (response != null) {
                    uploadPrescriptionNotifier.onPrescriptionUploaded(prescriptionId);
                } else {
                    errorHandler.handleCommonError(R.string.server_error);
                }
            }
        };
    }

    public void performPrescriptionUploadComplete(
            long prescriptionId, IPrescriptionCompleteListener prescriptionCompleteListener,
            IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiUploadPrescriptionComplete.Response>
                successResponseListener = getPrescriptionUploadCompleteSuccessResponseListener(prescriptionCompleteListener, errorHandler);

        FRGsonRequest<ApiUploadPrescriptionComplete.Response, ApiCommonError> prescriptionUploadCompleteGsonRequest = ApiRequestProvider
                .getUploadPrescriptionCompleteRequest(getCurrentCityId(), prescriptionId, requestHeader, successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        prescriptionUploadCompleteGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(prescriptionUploadCompleteGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiUploadPrescriptionComplete.Response> getPrescriptionUploadCompleteSuccessResponseListener(
            final IPrescriptionCompleteListener prescriptionCompleteListener, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiUploadPrescriptionComplete.Response>() {
            @Override
            public void onResponse(ApiUploadPrescriptionComplete.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    prescriptionCompleteListener.onPrescriptionUploadCompleted();
                }
            }
        };
    }

    /**
     * Method to perform the get prescription list EmailRequest and notify the result back to view.
     *
     * @param prescriptionListResultNotifier the callback for notifying the result of the request
     * @param errorHandler                   the callback for notifying the error of the request
     * @param apiRequestCancel               the callback for notifying the cancel of the request
     */
    public void performGetPrescriptionListRequest(IPrescriptionListResultNotifier prescriptionListResultNotifier,
                                                  IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiPrescriptionList.Response>
                successResponseListener = getPrescriptionListSuccessResponseListener(prescriptionListResultNotifier, errorHandler);

        FRGsonRequest<ApiPrescriptionList.Response, ApiCommonError> prescriptionListGsonRequest = ApiRequestProvider.getPrescriptionListRequest(
                requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        prescriptionListGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(prescriptionListGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiPrescriptionList.Response> getPrescriptionListSuccessResponseListener(
            final IPrescriptionListResultNotifier prescriptionListResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiPrescriptionList.Response>() {
            @Override
            public void onResponse(ApiPrescriptionList.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getUiDataList() != null) {
                    prescriptionListResultNotifier.onPrescriptionListFetched(response.getUiDataList(),
                            response.getDoctorNamesList(), response.getPatientNamesList());
                }
            }
        };
    }

    /**
     * Method to perform get Prescription description request and notify the result back to requester.
     *
     * @param prescriptionId                        the prescription id of the Prescription detail request
     * @param prescriptionDescriptionResultNotifier the callback for notifying the result of the request
     * @param errorHandler                          the callback for notifying the error of the request
     * @param apiRequestCancel                      the callback for notifying the cancel of the request
     */
    public void performGetPrescriptionDetailRequest(
            long prescriptionId, IPrescriptionDescriptionResultNotifier prescriptionDescriptionResultNotifier,
            IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiPrescriptionDescription.Response>
                successResponseListener = getPrescriptionDescriptionSuccessResponseListener(prescriptionDescriptionResultNotifier, errorHandler);

        FRGsonRequest<ApiPrescriptionDescription.Response, ApiCommonError> prescriptionListGsonRequest = ApiRequestProvider.getPrescriptionDetailsRequest(
                prescriptionId, requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        prescriptionListGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(prescriptionListGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiPrescriptionDescription.Response> getPrescriptionDescriptionSuccessResponseListener(
            final IPrescriptionDescriptionResultNotifier prescriptionDescriptionResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiPrescriptionDescription.Response>() {
            @Override
            public void onResponse(ApiPrescriptionDescription.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getUiDataList() != null && response.getDoctor() != null && response.getPatient() != null) {
                    prescriptionDescriptionResultNotifier.onPrescriptionDetailFetched(response.getUiDataList(),
                            response.getDoctor().getName(), response.getPatient().getName());
                }
            }
        };
    }

    /**
     * Method to perform the get order list request and notify the result back to fragment.
     *
     * @param currentPage             the current page number
     * @param recordsPerPage          the records per page
     * @param orderListResultNotifier result notifier callback
     * @param errorHandler            ; error handler
     * @param apiRequestCancel        the callback for notifying the cancel of the request
     */
    public void performGetOrderListRequest(int currentPage, int recordsPerPage, IGetOderListResultNotifier orderListResultNotifier,
                                           IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiOrdersList.Response>
                successResponseListener = getOrderListSuccessResponseListener(orderListResultNotifier, errorHandler);

        FRGsonRequest<ApiOrdersList.Response, ApiCommonError> addCartGsonRequest = ApiRequestProvider.getPaginatedOrderListRequest(
                currentPage, recordsPerPage,
                requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        addCartGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(addCartGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiOrdersList.Response> getOrderListSuccessResponseListener(
            final IGetOderListResultNotifier orderListResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiOrdersList.Response>() {
            @Override
            public void onResponse(ApiOrdersList.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getUiDataList() != null) {
                    orderListResultNotifier.onOrderListFetched(response.getUiDataList(), response.getPageInfo());
                }
            }
        };
    }

    /**
     * Method to perform the get order list request and notify the result back to fragment.
     *
     * @param orderDetailsResultNotifier result notifier callback
     * @param errorHandler               ; error handler
     * @param apiRequestCancel           the callback for notifying the cancel of the request
     */
    public void performOrderDetailsRequest(long orderId, IOderDetailsResultNotifier orderDetailsResultNotifier,
                                           IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiOrderDetail.Response>
                successResponseListener = getOrderDetailSuccessResponseListener(orderDetailsResultNotifier, errorHandler);

        FRGsonRequest<ApiOrderDetail.Response, ApiCommonError> addCartGsonRequest = ApiRequestProvider.getOrderDetailsRequest(
                orderId, requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        addCartGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(addCartGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiOrderDetail.Response> getOrderDetailSuccessResponseListener(
            final IOderDetailsResultNotifier oderDetailsResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiOrderDetail.Response>() {
            @Override
            public void onResponse(ApiOrderDetail.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getUiDataList() != null) {
                    oderDetailsResultNotifier.onOrderDetailsFetched(response.getUiDataList(), response.getProductList(),
                            response.getDoctorName(), response.getPatientName());
                }
            }
        };
    }

    /**
     * Method to perform the get order list request and notify the result back to fragment.
     *
     * @param orderDetailsResultNotifier result notifier callback
     * @param errorHandler               ; error handler
     * @param apiRequestCancel           the callback for notifying the cancel of the request
     */
    public void performRevisedOrderDetailsRequest(long orderId, IRevisedOderDetailsResultNotifier orderDetailsResultNotifier,
                                                  IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiOrderDetail.Response>
                successResponseListener = getRevisedOrderDetailSuccessResponseListener(orderDetailsResultNotifier, errorHandler);

        FRGsonRequest<ApiOrderDetail.Response, ApiCommonError> addCartGsonRequest = ApiRequestProvider.getRevisedOrderDetailsRequest(
                orderId, requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        addCartGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(addCartGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiOrderDetail.Response> getRevisedOrderDetailSuccessResponseListener(
            final IRevisedOderDetailsResultNotifier oderDetailsResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiOrderDetail.Response>() {
            @Override
            public void onResponse(ApiOrderDetail.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getUiDataList() != null) {
                    mRevisedOrderResponse = response;
                    oderDetailsResultNotifier.onRevisedOrderDetailsFetched(response);
                } else {
                    mRevisedOrderResponse = null;
                }
            }
        };
    }

    /**
     * Method to perform cancel order request and notify the result back to fragment.
     *
     * @param cancelOrderResultNotifier result notifier callback
     * @param errorHandler              ; error handler
     * @param apiRequestCancel          the callback for notifying the cancel of the request
     */
    public void performCancelOrderRequest(long orderId, ApiOrderCancel.Request apiOrderCancel, ICancelOrderResultNotifier cancelOrderResultNotifier,
                                          IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiOrderCancel.Response>
                successResponseListener = getOrderDetailSuccessResponseListener(cancelOrderResultNotifier, errorHandler);

        FRGsonRequest<ApiOrderCancel.Response, ApiCommonError> cancelOrderGsonRequest = ApiRequestProvider.getOrderCancelRequest(
                orderId, apiOrderCancel, requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        cancelOrderGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(cancelOrderGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiOrderCancel.Response> getOrderDetailSuccessResponseListener(
            final ICancelOrderResultNotifier cancelOrderResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiOrderCancel.Response>() {
            @Override
            public void onResponse(ApiOrderCancel.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    cancelOrderResultNotifier.onOrderCancelled(response.getMessage());
                }
            }
        };
    }

    public void performGetRecentOrdersListRequest(int count, IRecentPharmaOrdersResultNotifier recentPharmaOrdersResultNotifier,
                                                  IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiRecentPharmaOrdersList.Response>
                successResponseListener = getRecentPharmaOrdersSuccessResponseListener(recentPharmaOrdersResultNotifier, errorHandler);

        FRGsonRequest<ApiRecentPharmaOrdersList.Response, ApiCommonError> recentPharmaOrdersGsonRequest = ApiRequestProvider.getRecentPharmaProducts(
                getCurrentCityId(), count, requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        recentPharmaOrdersGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(recentPharmaOrdersGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiRecentPharmaOrdersList.Response> getRecentPharmaOrdersSuccessResponseListener(
            final IRecentPharmaOrdersResultNotifier recentPharmaOrdersResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiRecentPharmaOrdersList.Response>() {
            @Override
            public void onResponse(ApiRecentPharmaOrdersList.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getUiDataList() != null) {
                    recentPharmaOrdersResultNotifier.onRecentOrdersFetched(response.getUiDataList());
                }
            }
        };
    }

    public void performOrderPlaceRequest(final long orderId, ApiOrder.Request orderRequest,
                                         IPlaceOrderResultNotifier placeOrderResultNotifier,
                                         IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiOrder.Response>
                successResponseListener = performGetPlaceOrderSuccessResponseListener(placeOrderResultNotifier, errorHandler);

        FRGsonRequest.ErrorResponseListener<ApiOrder.ErrorResponse>
                errorResponseListener = performGetPlaceOrderErrorResponseListener(placeOrderResultNotifier, errorHandler);

        FRGsonRequest<ApiOrder.Response, ApiOrder.ErrorResponse> recentPharmaOrdersGsonRequest = ApiRequestProvider.getOrderPlaceRequest(
                orderId, orderRequest, requestHeader, successResponseListener,
                errorResponseListener, apiRequestCancel.getRequestTag());
        recentPharmaOrdersGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(recentPharmaOrdersGsonRequest);
    }

    private FRGsonRequest.ErrorResponseListener<ApiOrder.ErrorResponse> performGetPlaceOrderErrorResponseListener(
            IPlaceOrderResultNotifier placeOrderResultNotifier, final IErrorHandler errorHandler) {
        return new FRGsonRequest.ErrorResponseListener<ApiOrder.ErrorResponse>() {
            @Override
            public void onErrorResponse(ApiOrder.ErrorResponse errorResponse, int statusCode) {
                if (statusCode == 422) {
                    errorHandler.handleError(getAlertError("Server Error"), statusCode);
                } else {
                    errorHandler.handleError(getAlertError("Server Error"), statusCode);
                }
            }

            @Override
            public void onError(int messageId) {
                errorHandler.handleCommonError(messageId);
            }
        };
    }

    private FRGsonRequest.SuccessResponseListener<ApiOrder.Response> performGetPlaceOrderSuccessResponseListener(
            final IPlaceOrderResultNotifier placeOrderResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiOrder.Response>() {
            @Override
            public void onResponse(ApiOrder.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    placeOrderResultNotifier.onOrderConfirmed();
                }
            }
        };
    }

    public void performReviseOrderPlaceRequest(final long orderId, ApiOrder.Request orderRequest,
                                               IReviseOrderResultNotifier reviseOrderResultNotifier,
                                               IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiOrder.Response>
                successResponseListener = performGetReviseOrderSuccessResponseListener(reviseOrderResultNotifier, errorHandler);

        FRGsonRequest.ErrorResponseListener<ApiOrder.ErrorResponse>
                errorResponseListener = performGetReviseOrderErrorResponseListener(reviseOrderResultNotifier, errorHandler);

        FRGsonRequest<ApiOrder.Response, ApiOrder.ErrorResponse> recentPharmaOrdersGsonRequest = ApiRequestProvider.getReviseOrderRequest(
                orderId, orderRequest, requestHeader, successResponseListener,
                errorResponseListener, apiRequestCancel.getRequestTag());
        recentPharmaOrdersGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(recentPharmaOrdersGsonRequest);
    }

    private FRGsonRequest.ErrorResponseListener<ApiOrder.ErrorResponse> performGetReviseOrderErrorResponseListener(
            IReviseOrderResultNotifier reviseOrderResultNotifier, final IErrorHandler errorHandler) {
        return new FRGsonRequest.ErrorResponseListener<ApiOrder.ErrorResponse>() {
            @Override
            public void onErrorResponse(ApiOrder.ErrorResponse errorResponse, int statusCode) {
                errorHandler.handleError(getAlertError("Server Error"), statusCode);
            }

            @Override
            public void onError(int messageId) {
                errorHandler.handleCommonError(messageId);
            }
        };
    }

    private FRGsonRequest.SuccessResponseListener<ApiOrder.Response> performGetReviseOrderSuccessResponseListener(
            final IReviseOrderResultNotifier reviseOrderResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiOrder.Response>() {
            @Override
            public void onResponse(ApiOrder.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    reviseOrderResultNotifier.onOrderRevised();
                }
            }
        };
    }

    public void performGetStoreLocatorListRequest(double longitude, double latitude,
                                                  IStoreLocatorResultNotifier storeLocatorResultNotifier,
                                                  IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>
                successResponseListener = getStoreLocatorSuccessResponseListener(storeLocatorResultNotifier, errorHandler);

        FRGsonRequest<ApiStoreLocator.Response, ApiCommonError> storeLocatorGsonRequest = ApiRequestProvider.getStoreLocatorRequest(
                longitude, latitude, requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        storeLocatorGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(storeLocatorGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response> getStoreLocatorSuccessResponseListener(
            final IStoreLocatorResultNotifier storeLocatorResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiStoreLocator.Response>() {
            @Override
            public void onResponse(ApiStoreLocator.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    storeLocatorResultNotifier.onStoreLocatorFetched(response.getUiData());
                }
            }
        };
    }

    public void performReOrderReminderListRequest(long orderId, ApiOrderReminder.Request apiRequest,
                                                  IReOrderReminderResultNotifier reOrderReminderResultNotifier,
                                                  IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiOrderReminder.Response>
                successResponseListener = getReOrderReminderSuccessResponseListener(reOrderReminderResultNotifier, errorHandler);

        FRGsonRequest<ApiOrderReminder.Response, ApiCommonError> reOrderReminderGsonRequest = ApiRequestProvider.getOrderReminderRequest(
                orderId, requestHeader, apiRequest, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        reOrderReminderGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(reOrderReminderGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiOrderReminder.Response> getReOrderReminderSuccessResponseListener(
            final IReOrderReminderResultNotifier reOrderReminderResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiOrderReminder.Response>() {
            @Override
            public void onResponse(ApiOrderReminder.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    reOrderReminderResultNotifier.onReminderSet();
                }
            }
        };
    }

    public void performGetBannersRequest(IBannerResultNotifier bannerResultNotifier, IErrorHandler errorHandler,
                                         IApiRequestCancel apiRequestCancel) {
        if (mBannerResponse != null) {
            bannerResultNotifier.onBannersFetched(mBannerResponse.getHomeBannerList(), mBannerResponse.getHomeStoreList());
        } else {
            FRGsonRequest.SuccessResponseListener<ApiHomeBanner.Response>
                    successResponseListener = getBannerSuccessResponseListener(bannerResultNotifier);

            FRGsonRequest<ApiHomeBanner.Response, ApiCommonError> homeBannerRequest = ApiRequestProvider.getHomeBannersRequest(
                    getCurrentCityId(), successResponseListener,
                    getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
            homeBannerRequest.setAPIRequestCancelHandler(this);

            ApiRequestExecutor.getInstance(mAppContext).executeRequest(homeBannerRequest);
        }
    }

    private FRGsonRequest.ErrorResponseListener<ApiCommonError> getBannerErrorResponseListener(final IBannerResultNotifier bannerResultNotifier) {
        return new FRGsonRequest.ErrorResponseListener<ApiCommonError>() {
            @Override
            public void onErrorResponse(ApiCommonError errorResponse, int statusCode) {
                bannerResultNotifier.onBannersFetchingFailed();
            }

            @Override
            public void onError(int messageId) {
                bannerResultNotifier.onBannersFetchingFailed();
            }
        };
    }

    private FRGsonRequest.SuccessResponseListener<ApiHomeBanner.Response> getBannerSuccessResponseListener(final IBannerResultNotifier bannerResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiHomeBanner.Response>() {

            @Override
            public void onResponse(ApiHomeBanner.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getUiDataList() != null) {
                    mBannerResponse = response;
                    bannerResultNotifier.onBannersFetched(response.getHomeBannerList(), response.getHomeStoreList());
                }
            }
        };
    }

    public void performReOrderReminderDeleteRequest(long orderId,
                                                    IReOrderReminderDeleteResultNotifier reminderDeleteResultNotifier,
                                                    IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiOrderReminder.Response>
                successResponseListener = getReOrderReminderSuccessResponseListener(reminderDeleteResultNotifier, errorHandler);

        FRGsonRequest<ApiOrderReminder.Response, ApiCommonError> reOrderReminderGsonRequest = ApiRequestProvider.getOrderReminderDeleteRequest(
                orderId, requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        reOrderReminderGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(reOrderReminderGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiOrderReminder.Response> getReOrderReminderSuccessResponseListener(
            final IReOrderReminderDeleteResultNotifier reminderDeleteResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiOrderReminder.Response>() {
            @Override
            public void onResponse(ApiOrderReminder.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    reminderDeleteResultNotifier.onReminderDelete();
                }
            }
        };
    }

    /* UPLOAD PRESCRIPTION */

    public void performOrderCancellationReasonRequest(IOrderCancellationReasonResultNotifier orderCancellationReasonResultNotifier,
                                                      IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<List<String>>
                successResponseListener = getReOrderReminderSuccessResponseListener(orderCancellationReasonResultNotifier, errorHandler);

        FRGsonRequest<List<String>, ApiCommonError> orderCancellationReasonRequest = ApiRequestProvider.
                getOrderCancellationReasonsRequest(requestHeader, successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        orderCancellationReasonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(orderCancellationReasonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<List<String>> getReOrderReminderSuccessResponseListener(
            final IOrderCancellationReasonResultNotifier orderCancellationReasonResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<List<String>>() {
            @Override
            public void onResponse(List<String> response, Map<String, String> responseHeaders) {
                if (response != null) {
                    orderCancellationReasonResultNotifier.onCancellationReasons(response);
                }
            }
        };
    }

    public void performGetOffersListRequest(IOffersResultNotifier offersResultNotifier,
                                            IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiOffer.Response>
                successResponseListener = getOffersSuccessResponseListener(offersResultNotifier, errorHandler);

        FRGsonRequest<ApiOffer.Response, ApiCommonError> offersGsonRequest = ApiRequestProvider.getOffersRequest(
                getCurrentCityId(),
                requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        offersGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(offersGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiOffer.Response> getOffersSuccessResponseListener(
            final IOffersResultNotifier offersResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiOffer.Response>() {
            @Override
            public void onResponse(ApiOffer.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    offersResultNotifier.onOffersFetched(response.getUiData());
                }
            }
        };
    }

    public void performGetFAQListRequest(long faqTopicId, IFAQResultNotifier faqResultNotifier,
                                         IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiFAQ.Response>
                successResponseListener = getFAQSuccessResponseListener(faqResultNotifier, errorHandler);

        FRGsonRequest<ApiFAQ.Response, ApiCommonError> faqGsonRequest = ApiRequestProvider.getFAQRequest(faqTopicId,
                requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        faqGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(faqGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiFAQ.Response> getFAQSuccessResponseListener(
            final IFAQResultNotifier faqResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiFAQ.Response>() {
            @Override
            public void onResponse(ApiFAQ.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    faqResultNotifier.onFAQFetched(response.getFaqList());
                }
            }
        };
    }

    public void performGetFAQHomeListRequest(IFAQHomeResultNotifier faqHomeResultNotifier,
                                             IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiFAQ.Response>
                successResponseListener = getFAQHomeSuccessResponseListener(faqHomeResultNotifier, errorHandler);

        FRGsonRequest<ApiFAQ.Response, ApiCommonError> faqGsonRequest = ApiRequestProvider.getFAQHomeRequest(
                requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        faqGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(faqGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiFAQ.Response> getFAQHomeSuccessResponseListener(
            final IFAQHomeResultNotifier faqHomeResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiFAQ.Response>() {
            @Override
            public void onResponse(ApiFAQ.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    faqHomeResultNotifier.onFAQHomeFetched(response.getUiData());
                }
            }
        };
    }

    /* UPLOAD PRESCRIPTION COMPLETE */

    public void performGetRewardPointsListRequest(IRewardPointsResultNotifier rewardPointsResultNotifier,
                                                  IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiRewardPoints.Response>
                successResponseListener = getOffersSuccessResponseListener(rewardPointsResultNotifier, errorHandler);

        FRGsonRequest<ApiRewardPoints.Response, ApiCommonError> rewardPointsGsonRequest = ApiRequestProvider.getRewardPointsRequest(
                requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        rewardPointsGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(rewardPointsGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiRewardPoints.Response> getOffersSuccessResponseListener(
            final IRewardPointsResultNotifier rewardPointsResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiRewardPoints.Response>() {
            @Override
            public void onResponse(ApiRewardPoints.Response response, Map<String, String> responseHeaders) {
                if (TextUtils.isEmpty(response.getFailureMessage())) {
                    rewardPointsResultNotifier.onRewardPointsFetched(response.getUiData());
                } else {
                    rewardPointsResultNotifier.onRewardPointsFailed(response.getFailureMessage());
                }
            }
        };
    }

    public void performUpdateWalletRequest(CheckOutDeliveryAddressFragment.CartFlow cartFlow, long orderId,
                                           ApiCart.UpdateWalletRequest updateWalletRequest,
                                           IUpdateWalletResultNotifier updateWalletResultNotifier,
                                           IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiCart.Response>
                successResponseListener = getUpdateWalletSuccessResponseListener(cartFlow, updateWalletResultNotifier, errorHandler);

        FRGsonRequest<ApiCart.Response, ApiCommonError> updateWalletGsonRequest = ApiRequestProvider.getUpdateWalletRequest(
                orderId,
                updateWalletRequest,
                requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        updateWalletGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(updateWalletGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiCart.Response> getUpdateWalletSuccessResponseListener(
            final CheckOutDeliveryAddressFragment.CartFlow cartFlow,
            final IUpdateWalletResultNotifier updateWalletResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiCart.Response>() {
            @Override
            public void onResponse(ApiCart.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    updateWalletResultNotifier.onWalletUpdated(response.getUiDataList());
                }
            }
        };
    }

    public void performInitializePaymentRequest(long orderId, ApiInitializePayment.Request initializePaymentRequest,
                                                IInitializePaymentResultNotifier initializePaymentResultNotifier,
                                                IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiInitializePayment.Response>
                successResponseListener = getInitializePaymentSuccessResponseListener(initializePaymentResultNotifier, errorHandler);

        FRGsonRequest.ErrorResponseListener<ApiInitializePayment.ErrorResponse>
                errorResponseListener = getInitiatePaymentErrorResponseListener(errorHandler, initializePaymentResultNotifier);

        FRGsonRequest<ApiInitializePayment.Response, ApiInitializePayment.ErrorResponse> initializePaymentGsonRequest =
                ApiRequestProvider.getInitializePaymentRequest(
                        orderId,
                        initializePaymentRequest,
                        requestHeader, successResponseListener,
                        errorResponseListener, apiRequestCancel.getRequestTag());
        initializePaymentGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(initializePaymentGsonRequest);
    }

    private FRGsonRequest.ErrorResponseListener<ApiInitializePayment.ErrorResponse>
    getInitiatePaymentErrorResponseListener(final IErrorHandler errorHandler,
                                            final IInitializePaymentResultNotifier initializePaymentResultNotifier) {
        return new FRGsonRequest.ErrorResponseListener<ApiInitializePayment.ErrorResponse>() {
            @Override
            public void onErrorResponse(ApiInitializePayment.ErrorResponse errorResponse, int statusCode) {
                if (statusCode == 422) {
                    if ((errorResponse != null && errorResponse.getOrder() != null && errorResponse.getOrder().getErrors().size() > 0)) {
                        initializePaymentResultNotifier.onPaymentInitializeFailed(true, errorResponse.getOrder().getErrors().get(0), 0);
                    } else {
                        initializePaymentResultNotifier.onPaymentInitializeFailed(true, "", 0);
                    }
                } else {
                    initializePaymentResultNotifier.onPaymentInitializeFailed(false, "Unable to checkout the order", 0);
                }

                // errorHandler.handleError(getAlertError("Server Error"), statusCode);
            }

            @Override
            public void onError(int messageId) {
                initializePaymentResultNotifier.onPaymentInitializeFailed(false, "", messageId);
                //errorHandler.handleCommonError(messageId);
            }
        };
    }

    private FRGsonRequest.SuccessResponseListener<ApiInitializePayment.Response> getInitializePaymentSuccessResponseListener(
            final IInitializePaymentResultNotifier updateWalletResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiInitializePayment.Response>() {
            @Override
            public void onResponse(ApiInitializePayment.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    updateWalletResultNotifier.onPaymentInitializeSuccess(response);
                }
            }
        };
    }

    public void performReferFriendRequest(IReferFriendResultNotifier referFriendResultNotifier,
                                          IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiReferFriend.Response>
                successResponseListener = getReferFriendSuccessResponseListener(referFriendResultNotifier, errorHandler);

        FRGsonRequest<ApiReferFriend.Response, ApiCommonError> updateWalletGsonRequest = ApiRequestProvider.getReferFriendRequest(
                requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        updateWalletGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(updateWalletGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiReferFriend.Response> getReferFriendSuccessResponseListener(
            final IReferFriendResultNotifier referFriendResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiReferFriend.Response>() {
            @Override
            public void onResponse(ApiReferFriend.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    referFriendResultNotifier.onReferFriendFetched(response);
                }
            }
        };
    }

     /* OrderDetails */

    public void performSettingsRequest(ISettingsResultNotifier settingsResultNotifier,
                                       IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiSettings.Response>
                successResponseListener = getReferFriendSuccessResponseListener(settingsResultNotifier, errorHandler);

        FRGsonRequest<ApiSettings.Response, ApiCommonError> updateWalletGsonRequest = ApiRequestProvider.getSettingsRequest(
                requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        updateWalletGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(updateWalletGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiSettings.Response> getReferFriendSuccessResponseListener(
            final ISettingsResultNotifier settingsResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiSettings.Response>() {
            @Override
            public void onResponse(ApiSettings.Response response, Map<String, String> responseHeaders) {
                mSettingsResponse = response;
                settingsResultNotifier.onSettingsFetched(response);
            }
        };
    }

    public void performNewFeaturesListRequest(ApiNewTag.Request apiNewTagRequest, INewFeaturesResultNotifier newFeaturesResultNotifier,
                                              IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiNewTag.Response>
                successResponseListener = getNewFeaturesListSuccessResponseListener(newFeaturesResultNotifier, errorHandler);

        FRGsonRequest<ApiNewTag.Response, ApiCommonError> updateWalletGsonRequest = ApiRequestProvider.getNewFeaturesListRequest(
                apiNewTagRequest, requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        updateWalletGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(updateWalletGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiNewTag.Response> getNewFeaturesListSuccessResponseListener(
            final INewFeaturesResultNotifier newFeaturesResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiNewTag.Response>() {
            @Override
            public void onResponse(ApiNewTag.Response response, Map<String, String> responseHeaders) {
                mNewFeaturesResponse = response;
                newFeaturesResultNotifier.onNewFeatureListFetched(response);
            }
        };
    }

    public void performPaymentFailureRequest(long orderId, ApiPaymentFailure.Request apiPaymentFailureRequest,
                                             IPaymentFailureResultNotifier paymentFailureResultNotifier,
                                             IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiCart.Response>
                successResponseListener = getPaymentFailureRequestSuccessResponseListener(paymentFailureResultNotifier, errorHandler);

        FRGsonRequest<ApiCart.Response, ApiCommonError> updateWalletGsonRequest = ApiRequestProvider.getPaymentFailureRequest(
                orderId, apiPaymentFailureRequest, requestHeader, successResponseListener,
                getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        updateWalletGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(updateWalletGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiCart.Response> getPaymentFailureRequestSuccessResponseListener(
            final IPaymentFailureResultNotifier paymentFailureResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiCart.Response>() {
            @Override
            public void onResponse(ApiCart.Response response, Map<String, String> responseHeaders) {
                paymentFailureResultNotifier.onPaymentFailureResultFetched(response);
            }
        };
    }

    public void performSocialLoginRequest(ApiSocialLogin.Request apiSocialLoginRequest,
                                          ISocialLoginResultNotifier socialLoginResultNotifier,
                                          IErrorHandler errorHandler, IApiRequestCancel requestCancel) {

        FRGsonRequest.SuccessResponseListener<ApiLogin.Response>
                successResponseListener = getSocialLoginAPISuccessResponseListener(socialLoginResultNotifier,
                errorHandler, requestCancel.getRequestTag());

        FRGsonRequest.ErrorResponseListener<ApiSocialLogin.ErrorResponse>
                errorResponseListener = getSocialLoginErrorResponseListener(errorHandler, socialLoginResultNotifier);

        FRGsonRequest<ApiLogin.Response, ApiSocialLogin.ErrorResponse> loginRequest = ApiRequestProvider
                .getSocialLoginRequest(apiSocialLoginRequest, successResponseListener,
                        errorResponseListener, requestCancel.getRequestTag());
        loginRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(loginRequest);
    }

    private FRGsonRequest.ErrorResponseListener<ApiSocialLogin.ErrorResponse>
    getSocialLoginErrorResponseListener(final IErrorHandler errorHandler, final ISocialLoginResultNotifier socialLoginResultNotifier) {
        return new FRGsonRequest.ErrorResponseListener<ApiSocialLogin.ErrorResponse>() {
            @Override
            public void onErrorResponse(ApiSocialLogin.ErrorResponse errorResponse, int statusCode) {
                if (statusCode == 401) {
                    if (errorResponse != null && !TextUtils.isEmpty(errorResponse.getError_code()) &&
                            errorResponse.getError_code().equalsIgnoreCase("EFR:Err:SocialLogin:USER_NOT_REGISTERED")) {
                        socialLoginResultNotifier.onSocialNewUserLoginError(errorResponse.getMessage());
                    } else {
                        socialLoginResultNotifier.onSocialLoginError(errorResponse.getMessage());
                    }
                } else if (statusCode == 403) {
                    if (errorResponse != null && !TextUtils.isEmpty(errorResponse.getError_code()) &&
                            errorResponse.getError_code().equalsIgnoreCase("EFR:Err:Login:UNVERIFIED_PHONE")) {
                        socialLoginResultNotifier.onSocialNewUserOtpError(errorResponse.getPhone_number());
                    }
                } else {
                    socialLoginResultNotifier.onSocialLoginError(errorResponse.getMessage());
                }
            }

            @Override
            public void onError(int messageId) {
                errorHandler.handleCommonError(messageId);
            }
        };
    }

    private FRGsonRequest.SuccessResponseListener<ApiLogin.Response> getSocialLoginAPISuccessResponseListener(
            final ISocialLoginResultNotifier socialLoginResultNotifier, final IErrorHandler errorHandler, final String requestTag) {
        return new FRGsonRequest.SuccessResponseListener<ApiLogin.Response>() {
            @Override
            public void onResponse(ApiLogin.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getUser() != null) {
                    PreferenceUtils.saveStringIntoSharedPreference(mAppContext,
                            PreferenceUtils.PREFERENCE_KEY_ACCESS_TOKEN, response.getUser().getAuth_token());
                    pushLocalCartItemsToSeverUsingSocialLogin(socialLoginResultNotifier, response.getUser().getAuth_token());

                    clearWebVIewCookies();

                    FRGsonRequest.SuccessResponseListener<ApiUserInformation.Response>
                            successResponseListener = getUserInfoAPISuccessResponseListener(
                            new IGetUserInfoResultNotifier() {
                                @Override
                                public void onUserInfoFetched(UserInformation userInfo) {
                                    Utils.saveUserName(mAppContext, userInfo.userName);
                                    Utils.saveUserMobileNUmber(mAppContext, userInfo.userMobileNumber);
                                    Utils.saveUserID(mAppContext, userInfo.userId);
                                    BranchManager.getBranchInstance(mAppContext).setIdentity(userInfo.userId);
                                    if (Utils.getBooleanIsRegistered(mAppContext) && Utils.getBooleanIsWelcomeDialogShown(mAppContext)) {
                                        BranchManager.logBranchUserRegistrationEvent(mAppContext);
                                        Utils.clearIsRegistered(mAppContext);
                                    }
                                }
                            }, errorHandler);

                    HashMap<String, String> requestHeader = new HashMap<>();
                    addAccessTokenHeader(requestHeader);

                    FRGsonRequest<ApiUserInformation.Response, ApiCommonError> getLocationGsonRequest = ApiRequestProvider
                            .getUserInformationRequest(requestHeader, successResponseListener, getCommonErrResponseListener(errorHandler),
                                    requestTag);

                    ApiRequestExecutor.getInstance(mAppContext).executeRequest(getLocationGsonRequest);
                }
            }
        };
    }

    private void pushLocalCartItemsToSeverUsingSocialLogin(final ISocialLoginResultNotifier loginResultNotifier, final String auth_token) {
        new QueryExecutor(mAppContext, QueryProvider.getAllCartItemsQuery(new IDataBaseResultNotifier() {
            @Override
            public <T> void OnDataBaseDataUpdated(T data) {
                try {
                    List<RequestCartItem> requestCartItems = (List<RequestCartItem>) data;

                    if (requestCartItems.size() > 0) {
                        final IApiRequestCancel apiRequestCancel = new IApiRequestCancel() {
                            @Override
                            public String getRequestTag() {
                                return "cart Cache";
                            }
                        };
                        registerRequest(apiRequestCancel);

                        performAddCartRequest(requestCartItems, new IAddCartResultNotifier() {
                            @Override
                            public void onProductAdded() {
                                clearCartCache();
                                unregisterRequest(apiRequestCancel);
                                loginResultNotifier.onSocialLoginSuccess(auth_token);
                            }

                            @Override
                            public void onProductAddFailed() {
                                unregisterRequest(apiRequestCancel);
                                loginResultNotifier.onSocialLoginSuccess(auth_token);
                            }
                        }, new IErrorHandler() {
                            @Override
                            public <T> void handleError(AlertError<T> alertError, int statusCode) {
                                unregisterRequest(apiRequestCancel);
                                loginResultNotifier.onSocialLoginSuccess(auth_token);
                            }

                            @Override
                            public void handleCommonError(int errorResourceId) {
                                unregisterRequest(apiRequestCancel);
                                loginResultNotifier.onSocialLoginSuccess(auth_token);
                            }
                        }, apiRequestCancel);
                    } else {
                        loginResultNotifier.onSocialLoginSuccess(auth_token);
                    }
                } catch (ClassCastException e) {
                    e.printStackTrace();
                }
            }
        })).execute();
    }

    /**
     * Social Register
     */
    public void performSocialRegisterRequest(ApiSocialRegister.Request apiSocialRegisterData,
                                             IRegisterResultNotifier registerResultNotifier,
                                             IErrorHandler errorHandler,
                                             IApiRequestCancel requestCancel) {

        FRGsonRequest.SuccessResponseListener<ApiRegister.Response>
                successResponseListener = getRegisterAPISuccessResponseListener(registerResultNotifier);
        FRGsonRequest.ErrorResponseListener<ApiRegister.Response>
                errorResponseListener = getRegisterAPIErrorResponseListener(registerResultNotifier);

        FRGsonRequest<ApiRegister.Response, ApiRegister.Response> registerGsonRequest = ApiRequestProvider
                .getSocialRegisterRequest(apiSocialRegisterData, successResponseListener,
                        /*getCommonErrResponseListener(errorHandler)*/errorResponseListener,
                        requestCancel.getRequestTag());
        registerGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(registerGsonRequest);
    }

    /**
     * Change Social User Number
     */
    public void performChangeNumberForSocialUserRequest(String userId, String userAuthToken, String socialProvider,
                                                        String newNumber, IChangeNumberResultNotifier changeNumberResultNotifier,
                                                        IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        FRGsonRequest.SuccessResponseListener<ApiChangeNumber.Response>
                successResponseListener = getChangeNumberApiSuccessResponseListener(changeNumberResultNotifier);

        ApiChangeNumber.SocialUserRequest socialUserChangeNumberRequest = new ApiChangeNumber.SocialUserRequest();
        socialUserChangeNumberRequest.setAuthToken(userAuthToken);
        socialUserChangeNumberRequest.setUserId(userId);
        socialUserChangeNumberRequest.setUserSocialProvider(socialProvider);
        socialUserChangeNumberRequest.getUser().setPrimary_phone(newNumber);

        FRGsonRequest<ApiChangeNumber.Response, ApiCommonError> setPasswordGsonRequest = ApiRequestProvider
                .getSocialUserChangeNumberRequest(socialUserChangeNumberRequest,
                        successResponseListener, getCommonErrResponseListener(errorHandler),
                        apiRequestCancel.getRequestTag());
        setPasswordGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(setPasswordGsonRequest);
    }

    public void performNotifyMeSignedInUserRequest(long variantId, INotifyMeSignedInUserResultNotifier notifyMeSignedInUserResultNotifier,
                                                   IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        ApiNotifyMe.NotifyMeSignedInUserRequest apiNotifyMeSignedInUser = new ApiNotifyMe.NotifyMeSignedInUserRequest();
        apiNotifyMeSignedInUser.setVariantId(variantId);
        apiNotifyMeSignedInUser.setUserId(Utils.getUserID(mAppContext));

        FRGsonRequest.SuccessResponseListener<ApiNotifyMe.Response>
                successResponseListener = getNotifyMeSignedInUserRequestSuccessResponseListener(
                notifyMeSignedInUserResultNotifier, errorHandler);

        FRGsonRequest<ApiNotifyMe.Response, ApiCommonError> notifyMeSignedInUserGsonRequest =
                ApiRequestProvider.getNotifyMeSignedInUserRequest(getCurrentCityId(), apiNotifyMeSignedInUser,
                        requestHeader, successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        notifyMeSignedInUserGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(notifyMeSignedInUserGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiNotifyMe.Response> getNotifyMeSignedInUserRequestSuccessResponseListener(
            final INotifyMeSignedInUserResultNotifier notifyMeSignedInUserResultNotifier, IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiNotifyMe.Response>() {
            @Override
            public void onResponse(ApiNotifyMe.Response response, Map<String, String> responseHeaders) {
                if (response != null && TextUtils.isEmpty(response.getMessage())) {
                    notifyMeSignedInUserResultNotifier.onNotifyMeSignedInUserRequestResultFetched(response);
                } else if (!TextUtils.isEmpty(response.getMessage())) {
                    notifyMeSignedInUserResultNotifier.onNotifyMeSignedInUserError(response.getMessage());
                }
            }
        };
    }

    public void performNotifyMeNonSignedInUserRequest(long variantId, String mobileNumber,
                                                      INotifyMeNonSignedInUserResultNotifier notifyMeNonSignedInUserResultNotifier,
                                                      IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        ApiNotifyMe.NotifyMeNonSignedInUserRequest apiNotifyMeNonSignedInUser = new ApiNotifyMe.NotifyMeNonSignedInUserRequest();
        apiNotifyMeNonSignedInUser.setVariantId(variantId);
        apiNotifyMeNonSignedInUser.setPhoneNumber(mobileNumber);

        FRGsonRequest.SuccessResponseListener<ApiNotifyMe.Response>
                successResponseListener = getNotifyMeNonSignedInUserRequestSuccessResponseListener(
                notifyMeNonSignedInUserResultNotifier, errorHandler);

        FRGsonRequest<ApiNotifyMe.Response, ApiCommonError> notifyMeNonSignedInUserGsonRequest =
                ApiRequestProvider.getNotifyMeNonSignedInUserRequest(getCurrentCityId(), apiNotifyMeNonSignedInUser,
                        requestHeader, successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        notifyMeNonSignedInUserGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(notifyMeNonSignedInUserGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiNotifyMe.Response> getNotifyMeNonSignedInUserRequestSuccessResponseListener(
            final INotifyMeNonSignedInUserResultNotifier notifyMeNonSignedInUserResultNotifier, final IErrorHandler errorHandler) {
        return new FRGsonRequest.SuccessResponseListener<ApiNotifyMe.Response>() {
            @Override
            public void onResponse(ApiNotifyMe.Response response, Map<String, String> responseHeaders) {
                if (response != null && TextUtils.isEmpty(response.getMessage())) {
                    notifyMeNonSignedInUserResultNotifier.onNotifyMeNonSignedInUserRequestResultFetched(response);
                } else if (!TextUtils.isEmpty(response.getMessage())) {
                    notifyMeNonSignedInUserResultNotifier.onNotifyMeNonSignedInUserError(response.getMessage());
                }
            }
        };
    }

    public void performNotificationCentreRequest(int notificationCount, INotificationCenterResultNotifier notificationCenterResultNotifier,
                                                 IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiNotificationCentre.Response>
                successResponseListener = getNotificationCenterRequestSuccessResponseListener(
                notificationCenterResultNotifier);

        FRGsonRequest<ApiNotificationCentre.Response, ApiCommonError> notificationCentreGsonRequest =
                ApiRequestProvider.getNotificationCentreRequest(getCurrentCityId(), notificationCount,
                        requestHeader, successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        notificationCentreGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(notificationCentreGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiNotificationCentre.Response> getNotificationCenterRequestSuccessResponseListener(
            final INotificationCenterResultNotifier notificationCenterResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiNotificationCentre.Response>() {
            @Override
            public void onResponse(ApiNotificationCentre.Response response, Map<String, String> responseHeaders) {
                if (response != null && response.getUiData() != null) {
                    notificationCenterResultNotifier.onNotificationCenterRequestResultFetched(response.getUiData());
                }
            }
        };
    }

    public void performNotificationsReadRequest(IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiNotificationCount.Response>
                successResponseListener = new FRGsonRequest.SuccessResponseListener<ApiNotificationCount.Response>() {
            @Override
            public void onResponse(ApiNotificationCount.Response response, Map<String, String> responseHeaders) {

            }
        };

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(
                ApiRequestProvider.getNotificationsReadRequest(getCurrentCityId(),
                        PreferenceUtils.getStringFromSharedPreference(
                                FrankRossApplication.getFrankrossApplicationContext(), PreferenceUtils.PREFERENCE_KEY_GCM_TOKEN), requestHeader,
                        successResponseListener, getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag()));
    }

    public void performNotificationCountRequest(INotificationCountRequestResultNotifier notificationCountRequestResultNotifier,
                                                IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiNotificationCount.Response>
                successResponseListener = getNotificationCenterRequestSuccessResponseListener(
                notificationCountRequestResultNotifier);

        FRGsonRequest<ApiNotificationCount.Response, ApiCommonError> notificationCountGsonRequest =
                ApiRequestProvider.getNotificationsCountRequest(getCurrentCityId(),
                        PreferenceUtils.getStringFromSharedPreference(
                                FrankRossApplication.getFrankrossApplicationContext(), PreferenceUtils.PREFERENCE_KEY_GCM_TOKEN),
                        requestHeader, successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        notificationCountGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(notificationCountGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiNotificationCount.Response> getNotificationCenterRequestSuccessResponseListener(
            final INotificationCountRequestResultNotifier notificationCountRequestResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiNotificationCount.Response>() {
            @Override
            public void onResponse(ApiNotificationCount.Response response, Map<String, String> responseHeaders) {
                if (response != null) {
                    mNotificationsCount = response.getNotificationsCount();
                    notificationCountRequestResultNotifier.onNotificationCountRequestFetched(response.getNotificationsCount());
                }
            }
        };
    }

    public void performGetFulfillmentCenterRequest(ApiFulfillmentCenter.Request fulfillmentCenterRequest,
                                                   IGetFulfillmentCenterResultNotifier fulfillmentCenterResultNotifier,
                                                   IErrorHandler errorHandler, IApiRequestCancel apiRequestCancel) {
        HashMap<String, String> requestHeader = new HashMap<>();
        addAccessTokenHeader(requestHeader);

        FRGsonRequest.SuccessResponseListener<ApiFulfillmentCenter.Response>
                successResponseListener = getGetFulfillmentCenterAPISuccessResponseListener(fulfillmentCenterResultNotifier);

        FRGsonRequest<ApiFulfillmentCenter.Response, ApiCommonError> fulfillmentCenterGsonRequest = ApiRequestProvider
                .getFulfillmentCenterRequest(fulfillmentCenterRequest, getCurrentCityId(), requestHeader, successResponseListener,
                        getCommonErrResponseListener(errorHandler), apiRequestCancel.getRequestTag());
        fulfillmentCenterGsonRequest.setAPIRequestCancelHandler(this);

        ApiRequestExecutor.getInstance(mAppContext).executeRequest(fulfillmentCenterGsonRequest);
    }

    private FRGsonRequest.SuccessResponseListener<ApiFulfillmentCenter.Response> getGetFulfillmentCenterAPISuccessResponseListener(
            final IGetFulfillmentCenterResultNotifier getFulfillmentCenterResultNotifier) {
        return new FRGsonRequest.SuccessResponseListener<ApiFulfillmentCenter.Response>() {
            @Override
            public void onResponse(ApiFulfillmentCenter.Response response, Map<String, String> responseHeaders) {
                getFulfillmentCenterResultNotifier.onFulfillmentCenterFetched(response.getFulfillmentCenterId());
            }
        };
    }

    public interface IGetCartItemQuantityListener {
        void cartItemQuantity(int quantity);
    }

    public interface ICartCountChangeNotifier {
        void onCartCountChanged(int cartCount);
    }

    public interface INotificationsCountChangeNotifier {
        void onNotificationCountChanged(int notificationCount);
    }

    public interface ICartUploadPrescriptionRequiredResultNotifier {
        void onCartPrescriptionRequiredListFetched(List<BaseRecyclerAdapter.IViewType> uploadPrescriptionData);
    }

    public interface ICartSummaryResultNotifier {
        void onCarSummaryFetched(List<BaseRecyclerAdapter.IViewType> checkSummaryData);
    }

    public interface ICartCheckOutPatientDetailsResultNotifier {
        void onCheckOutResultFetched(String isMandatory);
    }

    /**
     * Api Status
     */
    public interface IApiStatusResultNotifier {
        void onApiDeprecated();

        void onApiDiscontinued();

        void onApiLive();
    }

    /**
     * Device register for Push notification
     */
    public interface IDeviceRegisterResultNotifier {
        void onDeviceRegistered(String gcmToken);

        void onDeviceRegistrationFailed();
    }

    /**
     * Login
     */
    public interface ILoginResultNotifier {
        void onLoginCompleted(String accessToken);
    }

    /**
     * Logout
     */

    public interface ILogoutResultNotifier {
        void onLogoutCompleted();
    }

    /**
     * Register
     */
    public interface IRegisterResultNotifier {
        void onRegisterCompleted(ApiRegister.Response successResponse);

        void onRegisterError(ApiRegister.Response errorResponse);
    }

    /**
     * Verify Otp
     */
    public interface IVerifyOtpResultNotifier {
        void onOtpVerified();

        void onOtpApiError(String message);

        void onCommonError(int messageId);
    }

    /**
     * Create OTP
     */
    public interface ICreateOTPResultNotifier {
        void onOtpSent(String message);
    }

    /**
     * Set Password API For Forgot pass word and Set Password for already register customer
     */
    public interface ISetPasswordResultNotifier {
        void onPasswordSet();
    }

    /**
     * Change User Number
     */
    public interface IChangeNumberResultNotifier {
        void onNumberChanged();
    }

    /**
     * Get Locations
     */
    public interface IGetLocationResultNotifier {
        void onLocationFetched(List<LocationChooserAdapter.LocationChooserListItem> availableLocations, List<ApiLocation.Cities> cities);
    }

    /**
     * Get Customer Care Number
     */
    public interface ICustomerCareNumberResultNotifier {
        void onCustomerCareNumberFetched(String customerCareNumber);
    }

    /**
     * Get User Information
     */
    public interface IGetUserInfoResultNotifier {
        void onUserInfoFetched(UserInformation userInfo);
    }

    /**
     * Update User Info
     */

    public interface IUpdateUserInfoResultNotifier {
        void onUserInfoUpdated();
    }

    /**
     * Update user Password
     */
    public interface IUpdateUserPasswordResultNotifier {
        void onUserPasswordUpdated();
    }

    /**
     * Get delivery Address
     */

    public interface IGetAddressResultNotifier {
        void onAddressFetched(List<AccountAdapter.AccountAddressItem> addressList, List<Address> list);
    }

    /**
     * Add delivery Address
     */
    public interface IAddAddressResultNotifier {
        void onAddressAdded();
    }

    /**
     * Set Default Address
     */
    public interface IDefaultAddressResultNotifier {
        void onDefaultAddressSet();
    }

    /**
     * delete delivery Address
     */
    public interface IDeleteAddressResultNotifier {
        void onAddressDeleted();
    }

    /**
     * update delivery Address
     */
    public interface IUpdateAddressResultNotifier {
        void onAddressUpdated();
    }

    /**
     * Get Delivery slots
     */
    public interface IGetDeliverySlotsResultNotifier {
        void onDeliverySlotsFetched(List<BaseRecyclerAdapter.IViewType> deliverySlots);
    }

    /**
     * Get Categories
     */
    public interface IGetCategoriesResultNotifier {
        void onCategoriesFetched(List<BaseRecyclerAdapter.IViewType> categoriesList);
    }

    /**
     * Get Home Categories and Promotion
     */
    public interface IGetHomeFeaturedCategoriesResultNotifier {
        void onHomeFeatureCategoriesFetched(List<BaseRecyclerAdapter.IViewType> homeFeaturedCategoryDataList);

        void onHomeFeatureCategoriesFailed();
    }

    /**
     * Get primary Categories, Promotion and Banners
     */
    public interface IGetPrimaryCategoriesResultNotifier {
        void onPrimaryCategoriesAndPromotionFetched(ApiCategories.PrimaryCategoryResponse primaryCategoryResponse);
    }

    /**
     * Pharma product detail
     */
    public interface IGetPharmaProductDetailResultNotifier {
        void onPharmaProductDetailFetched(ApiPharmaProduct pharmaProductDetail);
    }

    /**
     * Non Pharma product detail
     */
    public interface IGetNonPharmaProductDetailResultNotifier {
        void onNonPharmaProductDetailFetched(ApiNonPharmaProduct nonPharmaProductDetail);
    }

    /**
     * Add Cart
     */
    public interface IAddCartResultNotifier {
        void onProductAdded();

        void onProductAddFailed();
    }

    /**
     * Update Cart
     */
    public interface ICartResultNotifier {
        void onCartResult(List<BaseRecyclerAdapter.IViewType> cartDataList);
    }

    public interface ICartUpdateResultNotifier extends ICartResultNotifier {
        void onCartUpdated();
    }

    /**
     * Delete Cart
     */

    public interface ICartItemDeleteResultNotifier extends ICartResultNotifier {
        void onCartItemDeleted();
    }

    /**
     * Cart Checkout
     */
    public interface ICartCheckoutResultNotifier {
        void onOrderIdCreated(long orderId);

        void onOrderFailed(boolean isInventoryError, String errorMessage, int errorId);
    }

    public interface IUploadPrescriptionNotifier {
        void onPrescriptionUploaded(long prescriptionId);
    }

    private interface IGetUploadPrescriptionRequestModel {
        void onUploadPrescriptionRequest(String encodedImage);
    }

    public interface IPrescriptionCompleteListener {
        void onPrescriptionUploadCompleted();
    }

    /**
     * PRESCRIPTION LIST RESULT CALLBACK
     */
    public interface IPrescriptionListResultNotifier {
        void onPrescriptionListFetched(List<BaseRecyclerAdapter.IViewType> prescriptionList,
                                       List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> doctorNames,
                                       List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> patientName);
    }

    public interface IPrescriptionDescriptionResultNotifier {
        void onPrescriptionDetailFetched(List<BaseRecyclerAdapter.IViewType> prescriptionDetails, String doctorName, String patientName);
    }

    /**
     * CallBack interface for notifying the order history list.
     */
    public interface IGetOderListResultNotifier {
        void onOrderListFetched(List<BaseRecyclerAdapter.IViewType> orderList, ApiOrdersList.PageInfo pageInfo);
    }

    /**
     * CallBack interface for notifying the order Details.
     */
    public interface IOderDetailsResultNotifier {
        void onOrderDetailsFetched(List<BaseRecyclerAdapter.IViewType> orderList, List<OrderDetails.OrderProductItem> productList,
                                   String doctorName, String patientName);
    }

    /**
     * CallBack interface for notifying the order Details.
     */
    public interface IRevisedOderDetailsResultNotifier {
        void onRevisedOrderDetailsFetched(ApiOrderDetail.Response response);
    }

    /**
     * CallBack interface for notifying the Cancel OrderDetails.
     */
    public interface ICancelOrderResultNotifier {
        void onOrderCancelled(String message);
    }

    /**
     * Call Back interface for notifying the recent orders
     */
    public interface IRecentPharmaOrdersResultNotifier {
        void onRecentOrdersFetched(List<BaseRecyclerAdapter.IViewType> recentOrderList);
    }

    /**
     * Call back interface for notifying the order confirmation
     */
    public interface IPlaceOrderResultNotifier {
        void onOrderConfirmed();
    }

    /**
     * Call back interface for notifying the revise order
     */
    public interface IReviseOrderResultNotifier {
        void onOrderRevised();
    }

    /**
     * Call Back interface for notifying the store locator
     */
    public interface IStoreLocatorResultNotifier {
        void onStoreLocatorFetched(List<BaseRecyclerAdapter.IViewType> storesList);
    }

    /**
     * Call Back interface for notifying the reorder reminder
     */
    public interface IReOrderReminderResultNotifier {
        void onReminderSet();
    }

    public interface IBannerResultNotifier {
        void onBannersFetched(List<ApiHomeBanner.Banner> homeBannerList, List<ApiHomeBanner.Banner> storeBannerList);

        void onBannersFetchingFailed();
    }

    /**
     * Call Back interface for notifying the reorder reminder delete
     */
    public interface IReOrderReminderDeleteResultNotifier {
        void onReminderDelete();
    }

    /**
     * Call Back interface for notifying the order cancellation reasons
     */
    public interface IOrderCancellationReasonResultNotifier {
        void onCancellationReasons(List<String> uiDataList);
    }

    /**
     * Call Back interface for notifying the offers
     */
    public interface IOffersResultNotifier {
        void onOffersFetched(List<BaseRecyclerAdapter.IViewType> offersList);
    }

    /**
     * Call Back interface for notifying the faq
     */
    public interface IFAQResultNotifier {
        void onFAQFetched(List<FAQ.Faqs> offersList);
    }

    /**
     * Call Back interface for notifying the faq
     */
    public interface IFAQHomeResultNotifier {
        void onFAQHomeFetched(List<BaseRecyclerAdapter.IViewType> faqHomeList);
    }

    /**
     * Call Back interface for notifying the reward points
     */
    public interface IRewardPointsResultNotifier {
        void onRewardPointsFetched(List<BaseRecyclerAdapter.IViewType> rewardPointsList);

        void onRewardPointsFailed(String failureMessage);
    }

    /**
     * Call Back interface for updating the wallet
     */
    public interface IUpdateWalletResultNotifier {
        void onWalletUpdated(List<BaseRecyclerAdapter.IViewType> orderDetailList);
    }

    /**
     * Call Back interface for notifying initialize payment
     */
    public interface IInitializePaymentResultNotifier {
        void onPaymentInitializeSuccess(ApiInitializePayment.Response response);

        void onPaymentInitializeFailed(boolean isInventoryError, String errorMessage, int errorId);
    }

    /**
     * Call Back interface for refer a friend
     */
    public interface IReferFriendResultNotifier {
        void onReferFriendFetched(ApiReferFriend.Response apiReferFriend);
    }

    /*
     * Call Back interface for settings
     */
    public interface ISettingsResultNotifier {
        void onSettingsFetched(ApiSettings.Response apiReferFriend);
    }

    /*
     * Call Back interface for tagging menu as NEW
     */
    public interface INewFeaturesResultNotifier {
        void onNewFeatureListFetched(ApiNewTag.Response apiNewTagResponse);
    }

    /*
   * Call Back interface for notifying the result of Payment failure Request
   */
    public interface IPaymentFailureResultNotifier {
        void onPaymentFailureResultFetched(ApiCart.Response apiPaymentFailureResponse);
    }

    /**
     * Social Login
     */
    public interface ISocialLoginResultNotifier {
        void onSocialLoginSuccess(String accessToken);

        void onSocialNewUserLoginError(String message);

        void onSocialNewUserOtpError(String phoneNumber);

        void onSocialLoginError(String message);
    }

    /*
    * Call Back interface for notify me for signed in users Request
    */
    public interface INotifyMeSignedInUserResultNotifier {

        void onNotifyMeSignedInUserRequestResultFetched(ApiNotifyMe.Response apiNotifyMeSignedInUser);

        void onNotifyMeSignedInUserError(String errorMessage);
    }

    /*
    * Call Back interface for notify me for non signed in users Request
    */
    public interface INotifyMeNonSignedInUserResultNotifier {

        void onNotifyMeNonSignedInUserRequestResultFetched(ApiNotifyMe.Response apiNotifyMeNonSignedInUser);

        void onNotifyMeNonSignedInUserError(String errorMessage);
    }

    /*
   * Call Back interface for notification center
   */
    public interface INotificationCenterResultNotifier {

        void onNotificationCenterRequestResultFetched(List<BaseRecyclerAdapter.IViewType> notificationsList);
    }

    /*
  * Call Back interface for notification center
  */
    public interface INotificationCountRequestResultNotifier {

        void onNotificationCountRequestFetched(int notificationCount);
    }

    /**
     * Omni channel integration API
     */
    public interface IGetFulfillmentCenterResultNotifier {
        void onFulfillmentCenterFetched(int fulfillmentCenterId);
    }

    private static class ManagerInstanceHolder {

        private static ApiRequestManager INSTANCE = new ApiRequestManager();
    }
}
