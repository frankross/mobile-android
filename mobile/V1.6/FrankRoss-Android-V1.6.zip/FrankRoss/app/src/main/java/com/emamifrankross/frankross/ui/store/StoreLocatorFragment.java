/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.store;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.StoreLocatorAdapter;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.common.AlertDialogFragment;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.AppRuntimePermissionsManager;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;
import com.emamifrankross.frankross.ui.search.SearchActivity;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.IntentUtils;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by gauthami on 23/7/15.
 */

/**
 * This class represents the UI for store locator screen
 */
public class StoreLocatorFragment extends ApiRequestBaseFragment implements
        BaseRecyclerAdapter.RecyclerItemClickListener, IToolbar,
        LocationListener {

    private static final int REQUEST_CODE_STORE_LOCATOR = 111;

    private static final long MIN_DISTANCE_CHANGE_FOR_UPDATES = 10;
    private static final long MIN_TIME_BW_UPDATES = 1000 * 60;

    private ArrayList<BaseRecyclerAdapter.IViewType> mStoreLocatorScreenData = new ArrayList<>();
    private StoreLocatorAdapter mStoreLocatorRecyclerAdapter;
    private RobotoTextView mEmptyView;

    boolean isGPSEnabled = false;
    boolean isNetworkEnabled = false;
    boolean canGetLocation = false;

    private double mLatitude = 0.0d;
    private double mLongitude = 0.0d;
    private int mSelectedPosition = 0;//The selected phone number index from the store phone numbers listed in Chooser
    private String mPhoneNumber = "";

    public static StoreLocatorFragment create() {
        return new StoreLocatorFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mStoreLocatorRecyclerAdapter = new StoreLocatorAdapter(mStoreLocatorScreenData);

        getCurrentLocation();
        performStoreLocatorRequest();

        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.STORE_LOCATOR_LAUNCH_EVENT);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_store_locator, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initStoreLocatorRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method requests for stores list at particular longitude and latitude
     */
    private void performStoreLocatorRequest() {
        if (canGetLocation) {
            mFragmentInteractionListener.showBlockingProgressBar();
            mApiRequestManager.performGetStoreLocatorListRequest(mLongitude, mLatitude, new ApiRequestManager.IStoreLocatorResultNotifier() {
                @Override
                public void onStoreLocatorFetched(List<BaseRecyclerAdapter.IViewType> storesList) {
                    mFragmentInteractionListener.hideBlockingProgressBar();

                    if (storesList != null && !storesList.isEmpty()) {
                        mStoreLocatorScreenData.clear();
                        mStoreLocatorScreenData.addAll(storesList);
                        mStoreLocatorRecyclerAdapter.notifyDataSetChanged();
                    } else {
                        mEmptyView.setText(getString(R.string.store_locator_empty_view_txt));
                        mEmptyView.setVisibility(View.VISIBLE);
                    }
                }
            }, this, this);
        } else {
            showSettingsAlert();
        }
    }

    /**
     * Method that gets user location (longitude and latitude)
     */
    public void getCurrentLocation() {
        Location location = null;
        try {
            LocationManager locationManager = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
            isGPSEnabled = locationManager
                    .isProviderEnabled(LocationManager.GPS_PROVIDER);
            isNetworkEnabled = locationManager
                    .isProviderEnabled(LocationManager.NETWORK_PROVIDER);

            if (isGPSEnabled && isNetworkEnabled) {

                this.canGetLocation = true;
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                        AppRuntimePermissionsManager.checkPermissionForLocation(getActivity())) {
                    try {
                        locationManager.requestLocationUpdates(
                                LocationManager.GPS_PROVIDER,
                                MIN_TIME_BW_UPDATES,
                                MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
                        //GPS Enabled
                        location = locationManager
                                .getLastKnownLocation(LocationManager.PASSIVE_PROVIDER);
                        if (location == null) {
                            location = locationManager
                                    .getLastKnownLocation(LocationManager.GPS_PROVIDER);
                        }
                        if (location != null) {
                            mLatitude = location.getLatitude();
                            mLongitude = location.getLongitude();
                        }
                        //Used only for testing: location = Kolkata
                           /* mLatitude = 22.5667;
                            mLongitude = 88.3667;*/
                    } catch (SecurityException securityException) {

                    }
                } else {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                                    Manifest.permission.ACCESS_COARSE_LOCATION},
                            AppRuntimePermissionsManager.REQUEST_CODE_LOCATION_PERMISSIONS);
                }
            }

             /* if (isNetworkEnabled) {
                    locationManager.requestLocationUpdates(
                            LocationManager.NETWORK_PROVIDER,
                            MIN_TIME_BW_UPDATES,
                            MIN_DISTANCE_CHANGE_FOR_UPDATES, this);
                    //Network
                    if (locationManager != null) {
                        location = locationManager
                                .getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
                        if (location != null) {
                            mLatitude = location.getLatitude();
                            mLongitude = location.getLongitude();
                        }
                    }
                }*/

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Method that displays the Alert to enable the gps
     * If action is positive,takes user to the Settings screen, else displays error message
     */
    public void showSettingsAlert() {
        mFragmentInteractionListener.showAlert(getString(R.string.store_locator_gps_dialog_title),
                getString(R.string.store_locator_enable_gps),
                getString(R.string.action_settings), getString(R.string.cancel),
                new AlertDialogFragment.AlertPositiveActionListener() {
                    @Override
                    public void onPositiveAction() {
                        Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                        startActivityForResult(intent, REQUEST_CODE_STORE_LOCATOR);
                    }
                }, new AlertDialogFragment.AlertNegativeActionListener() {
                    @Override
                    public void onNegativeAction() {
                        mEmptyView.setText(getString(R.string.store_locator_loaction_service_disabled));
                        mEmptyView.setVisibility(View.VISIBLE);
                    }
                }, true);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_CANCELED || resultCode == Activity.RESULT_OK) {
            if (requestCode == REQUEST_CODE_STORE_LOCATOR) {
                getCurrentLocation();
                performStoreLocatorRequest();
            }
        }
    }

    /**
     * Method that initializes the Fragment's view
     *
     * @param view the view associated to the Store Locator fragment
     */
    private void initStoreLocatorRecyclerView(View view) {
        RecyclerView storeLocatorRecyclerView = (RecyclerView) view.findViewById(R.id.store_locator_container);
        storeLocatorRecyclerView.setHasFixedSize(false);
        storeLocatorRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mStoreLocatorRecyclerAdapter.setRecyclerItemClickListener(this);
        storeLocatorRecyclerView.setAdapter(mStoreLocatorRecyclerAdapter);

        mEmptyView = (RobotoTextView) view.findViewById(R.id.store_locator_empty_view_tv);
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (view.getId()) {
            case R.id.store_get_directions_tv:
                loadNavigationDirectionScreen(object);
                break;

            case R.id.store_call_us_tv:
                showCallAlert(object);
                break;
        }
    }

    /**
     * Method that pos up the alert dialogue to select the phone numbers
     *
     * @param object the clicked object details from recycler view
     */
    private void showCallAlert(Object object) {
        if (object instanceof StoreLocatorAdapter.StoreAddressDataItem) {
            final StoreLocatorAdapter.StoreAddressDataItem storeAddressDataItem =
                    (StoreLocatorAdapter.StoreAddressDataItem) object;

            if (storeAddressDataItem.phoneNumbers.size() > 0) {
                if (storeAddressDataItem.phoneNumbers.size() == 1) {
                    mFragmentInteractionListener.showAlert(null, storeAddressDataItem.phoneNumbers.get(0),
                            getString(R.string.call), getString(R.string.cancel), new AlertDialogFragment.AlertPositiveActionListener() {
                                @Override
                                public void onPositiveAction() {
                                    mPhoneNumber = storeAddressDataItem.phoneNumbers.get(0);
                                    call(storeAddressDataItem.phoneNumbers.get(0));
                                }
                            }, new AlertDialogFragment.AlertNegativeActionListener() {
                                @Override
                                public void onNegativeAction() {
                                }
                            }, true);
                } else {
                    showChoosePhoneNumberDialog(storeAddressDataItem.phoneNumbers);
                }
            }
        }
    }

    /**
     * Method that displays the list of phone numbers specific to a Store
     * Provides a user friendly dialog to choose among the phone numbers
     * if the list has more than one phone number
     *
     * @param phoneNumbers the list of store phone numbers
     */
    private void showChoosePhoneNumberDialog(final List<String> phoneNumbers) {
        mSelectedPosition = 0;
        AlertDialog.Builder builderSingle = new AlertDialog.Builder(getActivity());
        builderSingle.setTitle(getString(R.string.store_locator_choose_from_numbers_alert_title));

        final String[] locations = phoneNumbers.toArray(new String[phoneNumbers.size()]);

        builderSingle.setSingleChoiceItems(locations, mSelectedPosition, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mSelectedPosition = which;
            }
        });

        builderSingle.setPositiveButton(getString(R.string.call), new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                mPhoneNumber = phoneNumbers.get(mSelectedPosition);
                call(phoneNumbers.get(mSelectedPosition));
            }
        });

        builderSingle.setNegativeButton(
                getString(R.string.cancel),
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });

        builderSingle.show();
    }

    /**
     * Method that performs the Telephonic call action
     * using standard Call intent
     *
     * @param phoneNUmber the phone number chosen by user from the Phone number chooser
     */
    private void call(String phoneNUmber) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M ||
                AppRuntimePermissionsManager.checkPermissionForCall(getActivity())) {
            try {
                if (TextUtils.isEmpty(phoneNUmber)) return;
                phoneNUmber = phoneNUmber.trim();
                startActivity(IntentUtils.getCallIntent(phoneNUmber));
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SUPPORT_CALL_EVENT);
            } catch (SecurityException securityException) {

            }
        } else {
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE},
                    AppRuntimePermissionsManager.REQUEST_CODE_CALL_PERMISSIONS);
        }
    }

    /**
     * Method loads the google maps on clicking the get directions button
     *
     * @param object the clicked object details from recycler view
     */
    private void loadNavigationDirectionScreen(Object object) {
        if (object instanceof StoreLocatorAdapter.StoreAddressDataItem) {
            StoreLocatorAdapter.StoreAddressDataItem item = (StoreLocatorAdapter.StoreAddressDataItem) object;
            getActivity().startActivity(IntentUtils.getNavigationIntent(mLatitude, mLongitude, item.latitude, item.longitude));
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());

        mApiRequestManager.registerCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());

        mApiRequestManager.unregisterCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_store_locator);
    }

    @Override
    public int getToolbarMenuId() {
        return R.menu.menu_pharmacy;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_search:
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_FROM_TOOLBAR_EVENT);
                        startActivity(new Intent(getActivity(), SearchActivity.class));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;

                    case R.id.action_cart:
                        Map<String, String> cartClickData = Utils.cartToolbarClickDataForAnalytics(Constants.STORE_LOCATOR_SCREEN_NAME,
                                FrankRossEvents.VIEW_CART_FROM_TOOLBAR_SCREEN_NAME);
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_CART_FROM_TOOLBAR_EVENT, cartClickData);
                        startActivity(CartActivity.getActivityIntent(getActivity().getApplicationContext(), CartActivity.CART_FRAGMENT_ID));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;
                }
                return false;
            }
        };
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location != null) {
            FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.STORE_LOCATOR_LOCATION_CHANGE);
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case AppRuntimePermissionsManager.REQUEST_CODE_LOCATION_PERMISSIONS:
                if (grantResults != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    getCurrentLocation();
                    performStoreLocatorRequest();
                }
                break;
            case AppRuntimePermissionsManager.REQUEST_CODE_CALL_PERMISSIONS:
                if (grantResults != null && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    call(mPhoneNumber);
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
