/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;

import com.emamifrankross.frankross.core.apimodels.ApiNewTag;
import com.emamifrankross.frankross.core.apimodels.ApiSettings;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.core.network.IApiRequestCancel;
import com.emamifrankross.frankross.core.network.UrlConstants;
import com.emamifrankross.frankross.sdkmanager.ApptentiveManager;
import com.emamifrankross.frankross.sdkmanager.BranchManager;
import com.emamifrankross.frankross.sdkmanager.FacebookManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.AlertError;
import com.emamifrankross.frankross.ui.common.IErrorHandler;
import com.emamifrankross.frankross.ui.home.HomeActivity;
import com.emamifrankross.frankross.ui.viewmodels.UserInformation;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Utils;
import com.facebook.FacebookSdk;
import com.facebook.appevents.AppEventsLogger;
import com.newrelic.agent.android.NewRelic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Created by gowtham on 22/7/15.
 */

/**
 * This class represents the UI for Splash screen and manages the API calls in the splash delay
 */
public class SplashScreenActivity extends Activity {

    private static final long SPLASH_TIME_OUT = 6000;//6 sec
    private static final String NEW_RELIC_TOKEN =
            UrlConstants.DEV_MODE ? "AAb7b696f1273098e5294148abb1eaacfe9fda75e6" :
                    "AA03399a7e76487b524b8e362576729bf735436b12";
    private ApiRequestManager mApiRequestManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.APP_LAUNCH_EVENT);
        ApptentiveManager.registerAppAppLaunchEvent(SplashScreenActivity.this);

        initializeFacebook();

        initNewRelicToken();

        mApiRequestManager = ApiRequestManager.getInstance(getApplicationContext());
        mApiRequestManager.mBannerResponse = null;
        mApiRequestManager.setLoopingDelay(Constants.AUTO_SCROLL_INITIAL_DELAY);
        initBranchSessionWithUserID();

        setContentView(R.layout.activity_splash_screen);

        performNewTagFeaturesListRequest();
        getCategoryList();
        getCartItems();
        performSettingsRequest();
    }

    /**
     * Method that initializes New Relic sdk token
     */
    private void initNewRelicToken() {
        NewRelic.withApplicationToken(NEW_RELIC_TOKEN).start(getApplicationContext());
    }

    /**
     * Method that initializes the Facebook SDK on launch of the app
     */
    private void initializeFacebook() {
        FacebookSdk.sdkInitialize(getApplicationContext(), new FacebookSdk.InitializeCallback() {
            @Override
            public void onInitialized() {
                FacebookManager.logFacebookActivateAppEvent(SplashScreenActivity.this);
            }
        });
    }

    /**
     * Method that initialize the Branch SDK with the already saved used ID,when he/she is logged-in
     */
    private void initBranchSessionWithUserID() {

        if (Utils.isLoggedIn(SplashScreenActivity.this)) {
            if ((TextUtils.isEmpty(Utils.getUserID(SplashScreenActivity.this)))) {
                BranchManager.getBranchInstance(SplashScreenActivity.this).logout();
                Utils.clearUserID(SplashScreenActivity.this);
                performUserInfoRequest();
            } else {
                BranchManager.getBranchInstance(getApplicationContext()).setIdentity(Utils.getUserID(SplashScreenActivity.this));
            }
        }
    }

    /**
     * Method that adds the User details to set the User ID to Branch SDK
     */
    private void performUserInfoRequest() {
        final IApiRequestCancel apiRequestCancel = new IApiRequestCancel() {
            @Override
            public String getRequestTag() {
                return "UserDetails";
            }
        };
        mApiRequestManager.registerRequest(apiRequestCancel);

        mApiRequestManager.performUserInfoRequest(new ApiRequestManager.IGetUserInfoResultNotifier() {
            @Override
            public void onUserInfoFetched(UserInformation userInfo) {
                if (userInfo != null) {
                    Utils.saveUserName(getApplicationContext(), userInfo.userName);
                    Utils.saveUserMobileNUmber(getApplicationContext(), userInfo.userMobileNumber);
                    Utils.saveUserID(getApplicationContext(), userInfo.userId);
                    BranchManager.getBranchInstance(getApplicationContext()).setIdentity(userInfo.userId);
                }
            }
        }, new IErrorHandler() {
            @Override
            public <T> void handleError(AlertError<T> alertError, int statusCode) {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }

            @Override
            public void handleCommonError(int errorResourceId) {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, apiRequestCancel);
    }

    /**
     * Method to request for New tag features
     */
    private void performNewTagFeaturesListRequest() {
        final IApiRequestCancel apiRequestCancel = new IApiRequestCancel() {
            @Override
            public String getRequestTag() {
                return "Features";
            }
        };
        mApiRequestManager.registerRequest(apiRequestCancel);

        List<String> menuList = new ArrayList<>(1);
        Collections.addAll(menuList, getResources().getStringArray(R.array.drawer_mappings_category));
        Collections.addAll(menuList, getResources().getStringArray(R.array.drawer_mappings_sub_categories));

        ApiNewTag.Request apiNewTagRequest = new ApiNewTag.Request();
        apiNewTagRequest.setFeatures(menuList);

        mApiRequestManager.performNewFeaturesListRequest(apiNewTagRequest, new ApiRequestManager.INewFeaturesResultNotifier() {
            @Override
            public void onNewFeatureListFetched(ApiNewTag.Response apiNewTag) {
                mApiRequestManager.setNewFeaturesResponse(apiNewTag);
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, new IErrorHandler() {
            @Override
            public <T> void handleError(AlertError<T> alertError, int statusCode) {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }

            @Override
            public void handleCommonError(int errorResourceId) {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, apiRequestCancel);
    }

    /**
     * Method to request for the Categories
     */
    private void getCategoryList() {
        final IApiRequestCancel apiRequestCancel = new IApiRequestCancel() {
            @Override
            public String getRequestTag() {
                return "Categories";
            }
        };
        mApiRequestManager.registerRequest(apiRequestCancel);
        mApiRequestManager.performGetCategoriesRequest(new ApiRequestManager.IGetCategoriesResultNotifier() {
            @Override
            public void onCategoriesFetched(List<BaseRecyclerAdapter.IViewType> categoriesList) {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, new IErrorHandler() {
            @Override
            public <T> void handleError(AlertError<T> alertError, int statusCode) {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }

            @Override
            public void handleCommonError(int errorResourceId) {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, apiRequestCancel);

    }

    /**
     * Method requests for cart items to update the cart count
     */
    private void getCartItems() {
        final IApiRequestCancel apiRequestCancel = new IApiRequestCancel() {
            @Override
            public String getRequestTag() {
                return "Cart";
            }
        };
        mApiRequestManager.registerRequest(apiRequestCancel);
        mApiRequestManager.performGetCartItemsRequest(new ApiRequestManager.ICartItemDeleteResultNotifier() {
            @Override
            public void onCartItemDeleted() {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }

            @Override
            public void onCartResult(List<BaseRecyclerAdapter.IViewType> cartDataList) {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, new IErrorHandler() {
            @Override
            public <T> void handleError(AlertError<T> alertError, int statusCode) {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }

            @Override
            public void handleCommonError(int errorResourceId) {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, apiRequestCancel);
    }

    /**
     * Method that requests for App Settings
     */
    private void performSettingsRequest() {
        final IApiRequestCancel apiRequestCancel = new IApiRequestCancel() {
            @Override
            public String getRequestTag() {
                return "Settings";
            }
        };
        mApiRequestManager.registerRequest(apiRequestCancel);
        mApiRequestManager.performSettingsRequest(new ApiRequestManager.ISettingsResultNotifier() {
            @Override
            public void onSettingsFetched(ApiSettings.Response apiSettings) {
                mApiRequestManager.setSettingsResponse(apiSettings);
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, new IErrorHandler() {
            @Override
            public <T> void handleError(AlertError<T> alertError, int statusCode) {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }

            @Override
            public void handleCommonError(int errorResourceId) {
                mApiRequestManager.unregisterRequest(apiRequestCancel);
            }
        }, apiRequestCancel);
    }

    // delay is set for 4 second to launch FrankRossHomeActivity
    private void setDelay() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                launchHomeActivity();
            }
        }, SPLASH_TIME_OUT);
    }

    /**
     * Method that launches the Home screen after the splash
     */
    private void launchHomeActivity() {
        startActivity(HomeActivity.getActivityIntent(this, HomeActivity.HOME_FRAGMENT_TAG));
        overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        finish();
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        AppEventsLogger.activateApp(this);
        setDelay();
    }
}
