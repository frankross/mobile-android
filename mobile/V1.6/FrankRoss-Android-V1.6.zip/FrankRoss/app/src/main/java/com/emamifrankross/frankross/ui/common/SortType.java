/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

/**
 * Created by gowtham on 3/9/15.
 */
public enum SortType {
    NONE,
    LOW_TO_HIGH,
    HIGH_TO_LOW
}
