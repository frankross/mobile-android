/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.pharmacy;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiCategories;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;

/**
 * Created by gauthami on 8/7/15.
 */

/**
 * This class manages the fragment transactions for Shop by category based on the intents and its data
 */
public class PharmacyActivity extends BaseActivity {

    public static final String PHARMACY_SUB_CATEGORY_FRAGMENT_ID = "001";
    public static final String PHARMACY_TOP_SELLING_FRAGMENT_ID = "002";
    public static final String PHARMACY_FRAGMENT_ID = "003";

    private static final String EXTRA_FRAGMENT_ID = "fragment_id";
    private static final String EXTRA_CATEGORY = "category";
    private static final String EXTRA_CATEGORY_ID = "categoryId";
    private String mFragmentId = PHARMACY_FRAGMENT_ID;

    public static Intent getActivityIntent(Context appContext, String fragmentId,
                                           ApiCategories.Category category, long categoryId) {
        Intent intent = new Intent(appContext, PharmacyActivity.class);
        intent.putExtra(EXTRA_FRAGMENT_ID, fragmentId);
        intent.putExtra(EXTRA_CATEGORY, category);
        intent.putExtra(EXTRA_CATEGORY_ID, categoryId);

        return intent;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        String fragmentId = getIntent().getStringExtra(EXTRA_FRAGMENT_ID);
        ApiCategories.Category category = null;

        if (getIntent().getSerializableExtra(EXTRA_CATEGORY) != null)
            category = (ApiCategories.Category) getIntent().getSerializableExtra(EXTRA_CATEGORY);
        long categoryId = getIntent().getLongExtra(EXTRA_CATEGORY_ID, 0);
        mFragmentId = fragmentId;
        initFragment(category, categoryId);
    }

    private void initFragment(ApiCategories.Category category, long categoryId) {
        if (!TextUtils.isEmpty(mFragmentId)) {
            switch (mFragmentId) {
                case PHARMACY_SUB_CATEGORY_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(), PharmaCategoryFragment.create(category, categoryId), null,
                            R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.ADD);
                    break;
                case PHARMACY_TOP_SELLING_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(), CategoryFeaturedProductsFragment.create(categoryId), null,
                            R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.ADD);
                    break;
                case PHARMACY_FRAGMENT_ID:
                    loadFragment(getFragmentContainerId(), PharmacyFragment.create(), null,
                            R.anim.push_left_in, R.anim.push_left_out,
                            BaseFragment.FragmentTransactionType.ADD);
                    break;
                default:
                    break;

            }
        }
    }
}
