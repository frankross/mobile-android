package com.emamifrankross.frankross.ui.viewmodels;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;

/**
 * Created by gauthami on 30/12/15.
 */

/**
 * Horizontal scroll view more item view holder
 */
public class HorizontalScrollerViewMoreViewHolder extends RecyclerView.ViewHolder {

    public ImageView mCategoryIcon;
    public LinearLayout mCategoryLayout;

    public HorizontalScrollerViewMoreViewHolder(View itemView) {
        super(itemView);
        mCategoryIcon = (ImageView) itemView.findViewById(R.id.home_horizontal_scroll_view_more_iv);
        mCategoryLayout = (LinearLayout) itemView.findViewById(R.id.home_horizontal_scroll_view_more_linLyt);
    }
}
