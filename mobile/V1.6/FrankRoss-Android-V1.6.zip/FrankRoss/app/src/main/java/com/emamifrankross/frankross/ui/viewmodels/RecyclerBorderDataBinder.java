/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;

/**
 * Created by gowtham on 26/7/15.
 */

/**
 * COMMON RECYCLER BORDER ITEM BINDER
 */
public class RecyclerBorderDataBinder implements BaseRecyclerAdapter.RecyclerViewDataBinder<RecyclerBorderViewHolder,
        RecyclerBorderItem> {

    @Override
    public RecyclerBorderViewHolder getViewHolder(ViewGroup parent) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.border_item, parent, false);

        return new RecyclerBorderViewHolder(view);
    }

    @Override
    public void bindDataToViewHolder(RecyclerBorderViewHolder viewHolder, RecyclerBorderItem data,
                                     int position, BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {
        RecyclerView.LayoutParams params = new RecyclerView.LayoutParams(
                RecyclerView.LayoutParams.MATCH_PARENT, data.heightInPx
        );
        params.setMargins(data.leftMarginInPx, 0, data.rightMarginInPx, 0);
        viewHolder.mBorderView.setLayoutParams(params);
        viewHolder.mBorderView.setBackgroundColor(ContextCompat.getColor(viewHolder.mBorderView.getContext(), data.borderBackground));
    }

    @Override
    public int getViewType() {
        return ViewTypes.CommonViewType.BORDER_ITEM;
    }
}
