/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.prescription.prescriptionmedicines;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.HomeRecyclerAdapter;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.prescription.uploadprescription.UploadPrescriptionActivity;
import com.emamifrankross.frankross.ui.products.ProductDetailActivity;
import com.emamifrankross.frankross.ui.search.SearchActivity;
import com.emamifrankross.frankross.ui.viewmodels.CommonRecyclerHeaderItem;
import com.emamifrankross.frankross.ui.viewmodels.ProductDataModel;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderItem;
import com.emamifrankross.frankross.utils.Constants;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by gauthami on 8/7/15.
 */

/**
 * This class represents the UI for Prescription medicines screen
 */
public class PrescriptionMedicineFragment extends ApiRequestBaseFragment implements
        BaseRecyclerAdapter.RecyclerItemClickListener, IToolbar {

    private static final int REQUEST_CODE_UPLOAD_PRESCRIPTION = 111;
    private static final int REQUEST_CODE_CART = 222;
    private static final int REQUEST_CODE_PDP = 333;

    private List<BaseRecyclerAdapter.IViewType> mPrescriptionMedicineData = new ArrayList<>();
    private HomeRecyclerAdapter mPrescriptionMedicineAdapter;

    public static PrescriptionMedicineFragment create() {
        return new PrescriptionMedicineFragment();
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPrescriptionMedicineAdapter = new HomeRecyclerAdapter(mPrescriptionMedicineData);
        getRecentOrderedProducts();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initHomeRecyclerView(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    private void initHomeRecyclerView(View view) {
        RecyclerView prescriptionMedicineRecyclerView = (RecyclerView) view.findViewById(R.id.home_container);
        prescriptionMedicineRecyclerView.setHasFixedSize(false);
        prescriptionMedicineRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mPrescriptionMedicineAdapter = new HomeRecyclerAdapter(mPrescriptionMedicineData);
        mPrescriptionMedicineAdapter.setRecyclerItemClickListener(this);
        prescriptionMedicineRecyclerView.setAdapter(mPrescriptionMedicineAdapter);
    }

    private void getRecentOrderedProducts() {
        HomeRecyclerAdapter.UploadPrescriptionDataItem uploadPrescriptionDataItem = new HomeRecyclerAdapter.UploadPrescriptionDataItem();
        uploadPrescriptionDataItem.searchLinLytTitle = getString(R.string.prescription_medicine_search_linLyt_text);
        mPrescriptionMedicineData.add(uploadPrescriptionDataItem);

        if (Utils.isLoggedIn(getActivity())) {
            mFragmentInteractionListener.showBlockingProgressBar();
            mApiRequestManager.performGetRecentOrdersListRequest(10, new ApiRequestManager.IRecentPharmaOrdersResultNotifier() {
                @Override
                public void onRecentOrdersFetched(List<BaseRecyclerAdapter.IViewType> recentOrderList) {
                    mFragmentInteractionListener.hideBlockingProgressBar();
                    addDataToAdapter(recentOrderList);
                    mPrescriptionMedicineAdapter.notifyDataSetChanged();
                }
            }, this, this);
        }
    }

    private void addDataToAdapter(List<BaseRecyclerAdapter.IViewType> productList) {
        if (productList.size() > 0) {
            mPrescriptionMedicineData.add(new RecyclerBorderItem(1));
            mPrescriptionMedicineData.add(new CommonRecyclerHeaderItem(getString(R.string.recently_ordered)));
            mPrescriptionMedicineData.add(new RecyclerBorderItem(1));
            mPrescriptionMedicineData.addAll(productList);
        }
    }


    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {
            case ViewTypes.HomeViewType.UPLOAD_PRESCRIPTION:
                handleUploadPrescriptionClick(view);
                break;

            case ViewTypes.CommonViewType.PRODUCT_ITEM:
                handleProductItemClick((ProductDataModel) object);
                break;

            case ViewTypes.HomeViewType.VIEW_MORE_PRODUCTS:
                handleLoadMoreClick();
                break;
        }
    }

    private void handleProductItemClick(ProductDataModel object) {
        startActivityForResult(ProductDetailActivity.getActivityIntent(getActivity().getApplicationContext(),
                ProductDetailActivity.PHARMA_PRODUCT_DETAIL_FRAGMENT_ID, object.productId), REQUEST_CODE_PDP);
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    private void handleLoadMoreClick() {
        mPrescriptionMedicineAdapter.notifyDataSetChanged();
        getRecentOrderedProducts();
    }

    private void handleUploadPrescriptionClick(View view) {
        switch (view.getId()) {
            case R.id.home_search_linLay:
                Map<String, String> searchBarClickData = Utils.categoriesClickDataForAnalytics(Constants.PRESCRIPTION_MEDICINE_SCREEN_NAME,
                        FrankRossEvents.SEARCH_BAR_SCREEN_NAME_EVENT);
                FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_BAR_TAP_EVENT, searchBarClickData);
                startActivity(new Intent(getActivity(), SearchActivity.class));
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                break;

            case R.id.home_upload_button:
                startActivityForResult(UploadPrescriptionActivity.getActivityIntent(getActivity(), false, false), REQUEST_CODE_UPLOAD_PRESCRIPTION);
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                break;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_prescription_medicine);
    }

    @Override
    public int getToolbarMenuId() {
        return R.menu.menu_pharmacy;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_search:
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_FROM_TOOLBAR_EVENT);
                        startActivity(SearchActivity.getActivityIntent(getActivity()));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;

                    case R.id.action_cart:
                        Map<String, String> cartClickData = Utils.cartToolbarClickDataForAnalytics(Constants.PRESCRIPTION_MEDICINE_SCREEN_NAME,
                                FrankRossEvents.VIEW_CART_FROM_TOOLBAR_SCREEN_NAME);
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.VIEW_CART_FROM_TOOLBAR_EVENT, cartClickData);
                        startActivityForResult(CartActivity.getActivityIntent(getActivity().getApplicationContext(),
                                CartActivity.CART_FRAGMENT_ID), REQUEST_CODE_CART);
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;
                }
                return false;
            }
        };
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_UPLOAD_PRESCRIPTION || requestCode == REQUEST_CODE_CART || requestCode == REQUEST_CODE_PDP) {
            mPrescriptionMedicineData.clear();
            getRecentOrderedProducts();
        }
    }
}
