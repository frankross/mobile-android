/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.products.filter;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.ProductSortAdapter;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 4/8/15.
 */

/**
 * This class represents the UI for More info screen for a Pharma product
 */
public class FilterDetailFragment extends ApiRequestBaseFragment implements IToolbar,
        BaseRecyclerAdapter.RecyclerItemClickListener, View.OnClickListener {

    private List<BaseRecyclerAdapter.IViewType> mFilterDetailData = new ArrayList<>();
    private ProductSortAdapter mFilterDetailAdapter;
    private IFilterDetailFragmentActionListener mFilterDetailFragmentActionListener;

    private String mFilterDetailHeader = "";

    public static FilterDetailFragment create(String filterDetailHeader,
                                              List<BaseRecyclerAdapter.IViewType> brandsList) {
        FilterDetailFragment fragment = new FilterDetailFragment();
        fragment.setFilterDetailInfo(filterDetailHeader, brandsList);
        return fragment;
    }

    public void setFilterDetailInfo(String filterDetailHeader, List<BaseRecyclerAdapter.IViewType> filterList) {
        mFilterDetailHeader = filterDetailHeader;
        mFilterDetailData = filterList;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mFilterDetailAdapter = new ProductSortAdapter(mFilterDetailData);
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            mFilterDetailFragmentActionListener = (IFilterDetailFragmentActionListener) getActivity();
        } catch (ClassCastException classcastException) {
            throw new ClassCastException(context.toString()
                    + " must implement IFilterDetailFragmentActionListener");
        }
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    private void initViews(View view) {
        Button doneBtn = (Button) view.findViewById(R.id.filter_details_done_btn);
        doneBtn.setOnClickListener(this);
        RecyclerView productFilterRecyclerView = (RecyclerView) view.findViewById(R.id.filter_details_container);
        productFilterRecyclerView.setHasFixedSize(false);
        productFilterRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mFilterDetailAdapter.setRecyclerItemClickListener(this);
        productFilterRecyclerView.setAdapter(mFilterDetailAdapter);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_filter_details, container, false);
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (((BaseRecyclerAdapter.IViewType) object).getViewType()) {
            case ViewTypes.SortViewType.SORT_LIST_ITEM:
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.filter_details_done_btn:
                onSelectionCompleted();
                break;
        }
    }

    /**
     * Notify its parent on selection of the filter
     */
    private void onSelectionCompleted() {
        boolean isBrandSelected = (mFilterDetailHeader.equals(getString(R.string.filter_header_brand)));
        mFilterDetailFragmentActionListener.onFilterDetailsSelected(isBrandSelected);
        closeFragment();
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return mFilterDetailHeader;
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    /**
     * Interface definition for a callback to be invoked a brand is selected
     */
    public interface IFilterDetailFragmentActionListener {
        void onFilterDetailsSelected(boolean isBrandSelected);
    }
}
