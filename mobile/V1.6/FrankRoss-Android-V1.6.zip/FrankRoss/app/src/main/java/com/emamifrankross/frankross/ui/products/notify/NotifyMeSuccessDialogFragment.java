/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.products.notify;

import android.app.Dialog;
import android.view.View;
import android.widget.Button;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.BaseDialogFragment;

/**
 * Created by gauthami on 8/8/16.
 */

/**
 * This class represents the UI for success dialog for Notify me
 */
public class NotifyMeSuccessDialogFragment extends BaseDialogFragment implements View.OnClickListener {

    public static final String TAG = NotifyMeSuccessDialogFragment.class.getSimpleName();

    @Override
    public int getLayoutId() {
        return R.layout.fragment_product_notify_me_success_dialog;
    }

    @Override
    public void initViews(Dialog view) {
        Button okBtn = (Button) view.findViewById(R.id.notify_me_success_ok_btn);
        okBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.notify_me_success_ok_btn:
                getDialog().dismiss();
                break;
        }
    }
}

