/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 20/8/15.
 */
public class ApiStoreLocator {

    public class Response {

        @SerializedName("stores")
        private List<Store> storesList;

        private List<BaseRecyclerAdapter.IViewType> uiData = new ArrayList<>();

        public List<Store> getStoresList() {
            return storesList;
        }

        public List<BaseRecyclerAdapter.IViewType> getUiData() {
            return uiData;
        }

        public void setUiData(List<BaseRecyclerAdapter.IViewType> uiData) {
            this.uiData = uiData;
        }
    }
}
