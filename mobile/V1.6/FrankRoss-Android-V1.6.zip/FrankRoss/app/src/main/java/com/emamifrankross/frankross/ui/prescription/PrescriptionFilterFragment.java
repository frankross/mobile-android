/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.prescription;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.PrescriptionFilterAdapter;
import com.emamifrankross.frankross.ui.common.BaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 15/7/15.
 */

/**
 * This class represents the UI for Prescriptions filter screen
 */
public class PrescriptionFilterFragment extends BaseFragment implements IToolbar,
        BaseRecyclerAdapter.RecyclerItemClickListener, View.OnClickListener {

    public static final String TAG = PrescriptionFilterFragment.class.getName();

    private List<BaseRecyclerAdapter.IViewType> mPrescriptionFilterData = new ArrayList<>();
    private PrescriptionFilterAdapter mPrescriptionFilterAdapter;
    private IPrescriptionFilterSelectNotifier mPrescriptionFilterNotifier;
    private LinearLayout mPrescriptionsFilterLinLyt;

    private List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> mDoctorNames =
            new ArrayList<>();
    private List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> mPatientNames =
            new ArrayList<>();

    private List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> mSelectedDoctorNames =
            new ArrayList<>();
    private List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> mSelectedPatientNames =
            new ArrayList<>();

    public static PrescriptionFilterFragment create(List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem>
                                                            doctorNames,
                                                    List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem>
                                                            patientNames) {
        PrescriptionFilterFragment fragment = new PrescriptionFilterFragment();
        fragment.setFilterInfo(doctorNames, patientNames);
        return fragment;
    }

    private void setFilterInfo(List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> doctorNames,
                               List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem> patientNames) {
        mDoctorNames = doctorNames;
        mPatientNames = patientNames;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            mPrescriptionFilterNotifier = (IPrescriptionFilterSelectNotifier) getActivity();
        } catch (ClassCastException exception) {
            throw new ClassCastException(context.toString()
                    + " must implement IPrescriptionFilterSelectNotifier");
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPrescriptionFilterAdapter = new PrescriptionFilterAdapter(mPrescriptionFilterData);
        setProductSortByData();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_prescriptions_filter, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    /**
     * Method that populates the prescription filter data
     */
    private void setProductSortByData() {
        new AsyncTask<Void, Void, ArrayList<BaseRecyclerAdapter.IViewType>>() {
            @Override
            protected ArrayList<BaseRecyclerAdapter.IViewType> doInBackground(Void... params) {
                ArrayList<BaseRecyclerAdapter.IViewType> prescriptionFilterData = new ArrayList<BaseRecyclerAdapter.IViewType>();

                if (mPatientNames.size() > 0) {
                    PrescriptionFilterAdapter.PrescriptionHeaderFilterDataItem patientHeaderDataItem =
                            new PrescriptionFilterAdapter.PrescriptionHeaderFilterDataItem();
                    patientHeaderDataItem.prescriptionFilterHeader = "Patient";
                    patientHeaderDataItem.imageId = R.mipmap.patient;
                    prescriptionFilterData.add(patientHeaderDataItem);

                    for (BaseRecyclerAdapter.IViewType view : mPatientNames) {
                        PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem item =
                                (PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem) view;
                        prescriptionFilterData.add(new PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem(item));
                    }

                }

                if (mDoctorNames.size() > 0) {
                    PrescriptionFilterAdapter.PrescriptionHeaderFilterDataItem doctorHeaderDataItem =
                            new PrescriptionFilterAdapter.PrescriptionHeaderFilterDataItem();
                    doctorHeaderDataItem.prescriptionFilterHeader = "Doctor";
                    doctorHeaderDataItem.imageId = R.mipmap.doctor;
                    prescriptionFilterData.add(doctorHeaderDataItem);

                    for (BaseRecyclerAdapter.IViewType view : mDoctorNames) {
                        PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem item =
                                (PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem) view;
                        prescriptionFilterData.add(new PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem(item));
                    }
                }

                return prescriptionFilterData;
            }

            @Override
            protected void onPostExecute(ArrayList<BaseRecyclerAdapter.IViewType> sortData) {
                super.onPostExecute(sortData);
                mPrescriptionFilterData.clear();
                mPrescriptionFilterData.addAll(sortData);
                mPrescriptionFilterAdapter.notifyDataSetChanged();
                mPrescriptionsFilterLinLyt.setVisibility(mPatientNames.size() > 0 ||
                        mDoctorNames.size() > 0 ? View.VISIBLE : View.GONE);
            }
        }.execute();
    }

    private void initViews(View view) {
        RecyclerView prescriptionFilterRecyclerView = (RecyclerView) view.
                findViewById(R.id.prescriptions_recycler_view);
        prescriptionFilterRecyclerView.setHasFixedSize(false);
        prescriptionFilterRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mPrescriptionFilterAdapter = new PrescriptionFilterAdapter(mPrescriptionFilterData);
        mPrescriptionFilterAdapter.setRecyclerItemClickListener(this);
        prescriptionFilterRecyclerView.setAdapter(mPrescriptionFilterAdapter);

        Button applyBtn = (Button) view.findViewById(R.id.prescriptions_apply_btn);
        Button clearBtn = (Button) view.findViewById(R.id.prescriptions_reset_btn);
        mPrescriptionsFilterLinLyt = (LinearLayout) view.findViewById(R.id.prescriptions_bottom_bar_linLyt);

        applyBtn.setOnClickListener(this);
        clearBtn.setOnClickListener(this);
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;

        switch (((PrescriptionFilterAdapter.IViewType) object).getViewType()) {
            case ViewTypes.PrescriptionFilterViewType.SUB_HEADER_ITEM_VIEW_TYPE:
                break;
        }
    }

    /**
     * Method that resets the applied filters
     */
    private void reset() {
        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... params) {

                for (BaseRecyclerAdapter.IViewType view : mPrescriptionFilterData) {
                    if (view instanceof PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem) {
                        ((PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem) view).isChecked = false;
                    }
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                mPrescriptionFilterAdapter.notifyDataSetChanged();
            }
        }.execute();
    }

    /**
     * Method that populates the filter doctor and
     * patient name to help in filtering the Prescriptions
     */
    private void applyFilter() {
        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... params) {
                mDoctorNames.clear();
                mPatientNames.clear();
                for (BaseRecyclerAdapter.IViewType view : mPrescriptionFilterData) {
                    if (view instanceof PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem) {
                        PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem dataItem =
                                (PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem) view;
                        if (dataItem.prescriptionFilterHeader.equals("Doctor")) {
                            mDoctorNames.add(dataItem);
                            if (dataItem.isChecked) {
                                mSelectedDoctorNames.add(dataItem);
                            }
                        } else {
                            mPatientNames.add(dataItem);
                            if (dataItem.isChecked) {
                                mSelectedPatientNames.add(dataItem);
                            }
                        }
                    }
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);
                if (mSelectedPatientNames.isEmpty() && mSelectedDoctorNames.isEmpty()) {
                    mPrescriptionFilterNotifier.onFilterCleared();
                } else {
                    mPrescriptionFilterNotifier.onFilterApplied(mSelectedDoctorNames, mSelectedPatientNames);
                }
                closeFragment();
            }
        }.execute();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.prescriptions_apply_btn:
                applyFilter();
                break;
            case R.id.prescriptions_reset_btn:
                reset();
                break;
        }
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_prescription_filters);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    /**
     * Interface definition for a callback to be invoked when a filter selected
     */
    public interface IPrescriptionFilterSelectNotifier {
        /**
         * Called when Apply clicked
         *
         * @param selectedDoctorNames  the doctor names selected by user to filter the prescriptions
         * @param selectedPatientNames the patient names selected by user to filter the prescriptions
         */
        void onFilterApplied(List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem>
                                     selectedDoctorNames,
                             List<PrescriptionFilterAdapter.PrescriptionSubHeaderFilterDataItem>
                                     selectedPatientNames);

        /**
         * Called when Clear clicked
         */
        void onFilterCleared();
    }
}
