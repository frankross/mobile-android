/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 23/7/15.
 * <p> Adapter class for Prescription Filter Section</p>
 * <p>Supports the Two View Types </p>
 * <p> 1 : PRESCRIPTION FILTER HEADER VIEW TYPE </p>
 * <p> 2 : PRESCRIPTION FILTER SUB HEADER VIEW TYPE </p>
 * <p> 3 : PRESCRIPTION FILTER ACTION BUTTON VIEW TYPE </p>
 */
public class PrescriptionFilterAdapter extends BaseRecyclerAdapter {

    public PrescriptionFilterAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        List<RecyclerViewDataBinder> viewHolderTypeList = new ArrayList<>(1);
        viewHolderTypeList.add(new PrescriptionHeaderFilterViewHolderType());
        viewHolderTypeList.add(new PrescriptionSubHeaderFilterViewHolderType());
        viewHolderTypeList.add(new FilterActionBtnViewDataBinder());

        return viewHolderTypeList;
    }

    /**
     * PRESCRIPTION FILTER HEADER VIEW TYPE
     */

    public static class PrescriptionHeaderFilterDataItem implements IViewType {

        public String prescriptionFilterHeader;
        public int imageId;

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionFilterViewType.HEADER_ITEM_VIEW_TYPE;
        }
    }

    private static class PrescriptionHeaderFilterViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mPrescriptionFilterHeader;
        public ImageView mPrescriptionFilterIcon;

        public PrescriptionHeaderFilterViewHolder(View itemView) {
            super(itemView);
            mPrescriptionFilterHeader = (RobotoTextView) itemView.findViewById(R.id.prescription_filter_title_tv);
            mPrescriptionFilterIcon = (ImageView) itemView.findViewById(R.id.prescription_filter_header_iv);
        }
    }

    private static class PrescriptionHeaderFilterViewHolderType implements
            RecyclerViewDataBinder<PrescriptionHeaderFilterViewHolder, PrescriptionHeaderFilterDataItem> {

        @Override
        public PrescriptionHeaderFilterViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.prescription_filter_item, parent, false);

            return new PrescriptionHeaderFilterViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(PrescriptionHeaderFilterViewHolder viewHolder,
                                         final PrescriptionHeaderFilterDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mPrescriptionFilterHeader.setText(data.prescriptionFilterHeader);
            viewHolder.mPrescriptionFilterIcon.setImageResource(data.imageId);
        }

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionFilterViewType.HEADER_ITEM_VIEW_TYPE;
        }
    }

    /**
     * PRESCRIPTION FILTER SUB HEADER VIEW TYPE
     */

    public static class PrescriptionSubHeaderFilterDataItem implements IViewType {

        public boolean isChecked = false;
        public String prescriptionFilterSubHeader = "";
        public String prescriptionFilterHeader = "";

        public PrescriptionSubHeaderFilterDataItem() {
        }

        public PrescriptionSubHeaderFilterDataItem(PrescriptionSubHeaderFilterDataItem copyFilterItem) {
            isChecked = copyFilterItem.isChecked;
            prescriptionFilterSubHeader = copyFilterItem.prescriptionFilterSubHeader;
            prescriptionFilterHeader = copyFilterItem.prescriptionFilterHeader;
        }

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionFilterViewType.SUB_HEADER_ITEM_VIEW_TYPE;
        }

        @Override
        public boolean equals(Object o) {
            String subHeader = ((PrescriptionSubHeaderFilterDataItem) o).prescriptionFilterSubHeader;
            return prescriptionFilterSubHeader.equalsIgnoreCase(subHeader);
        }
    }

    private static class PrescriptionSubHeaderFilterViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mPrescriptionFilterHeader;
        private ImageView mPrescriptionFilterIndicator;
        private LinearLayout mPrescriptionFilterLinLyt;

        public PrescriptionSubHeaderFilterViewHolder(View itemView, Context context) {
            super(itemView);
            mPrescriptionFilterIndicator = (ImageView) itemView.findViewById(R.id.sort_indicator_iv);
            mPrescriptionFilterHeader = (RobotoTextView) itemView.findViewById(R.id.sort_by_text_tv);
            mPrescriptionFilterLinLyt = (LinearLayout) itemView.findViewById(R.id.sort_products_linLyt);

            mPrescriptionFilterHeader.setPadding(context.getResources().getDimensionPixelOffset(R.dimen.check_out_delivery_slot_time_left_padding), 0, 0, 0);
            mPrescriptionFilterHeader.setTextColor(ContextCompat.getColor(context, R.color.delivery_slot_text_color));
            mPrescriptionFilterHeader.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        }
    }

    private static class PrescriptionSubHeaderFilterViewHolderType implements
            RecyclerViewDataBinder<PrescriptionSubHeaderFilterViewHolder, PrescriptionSubHeaderFilterDataItem> {

        @Override
        public PrescriptionSubHeaderFilterViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.sort_products_list_item, parent, false);

            return new PrescriptionSubHeaderFilterViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(final PrescriptionSubHeaderFilterViewHolder viewHolder,
                                         final PrescriptionSubHeaderFilterDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mPrescriptionFilterHeader.setText(data.prescriptionFilterSubHeader);
            final Context context = viewHolder.mPrescriptionFilterHeader.getContext();
            viewHolder.mPrescriptionFilterIndicator.setImageResource(data.isChecked ?
                    R.mipmap.select : R.drawable.abc_list_divider_mtrl_alpha);
            viewHolder.mPrescriptionFilterHeader.setTextColor(ContextCompat.getColor(context,
                    data.isChecked ? R.color.delivery_slot_selected_text_color
                            : R.color.delivery_slot_text_color));

            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        data.isChecked = !data.isChecked;
                        viewHolder.mPrescriptionFilterIndicator.setImageResource((data.isChecked) ?
                                R.mipmap.select : R.drawable.abc_list_divider_mtrl_alpha);
                        viewHolder.mPrescriptionFilterHeader.setTextColor(ContextCompat.getColor(context,
                                data.isChecked ? R.color.delivery_slot_selected_text_color
                                        : R.color.delivery_slot_text_color));
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.PrescriptionFilterViewType.SUB_HEADER_ITEM_VIEW_TYPE;
        }
    }

    /**
     * PRESCRIPTION FILTER ACTION BUTTON VIEW TYPE
     */
    public static class FilterActionBtnDataItem implements IViewType {

        @Override
        public int getViewType() {
            return ViewTypes.FilterViewType.FILTER_ACTION_BUTTON;
        }
    }

    private static class FilterActionBtnViewHolder extends RecyclerView.ViewHolder {

        private Button mFilterApplyBtn;
        private Button mFilterResetBtn;

        public FilterActionBtnViewHolder(View itemView) {
            super(itemView);

            mFilterApplyBtn = (Button) itemView.findViewById(R.id.filter_products_apply_btn);
            mFilterResetBtn = (Button) itemView.findViewById(R.id.filter_products_reset_btn);

            mFilterApplyBtn.setText(itemView.getContext().getString(R.string.apply));
            mFilterResetBtn.setText(itemView.getContext().getString(R.string.clear));
        }
    }

    private static class FilterActionBtnViewDataBinder implements
            RecyclerViewDataBinder<FilterActionBtnViewHolder, FilterActionBtnDataItem> {

        @Override
        public FilterActionBtnViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.filter_action_btn, parent, false);

            return new FilterActionBtnViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final FilterActionBtnViewHolder viewHolder,
                                         final FilterActionBtnDataItem data, final int position,
                                         final RecyclerItemClickListener recyclerViewClickListener) {
            if (recyclerViewClickListener != null) {
                viewHolder.mFilterApplyBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
                viewHolder.mFilterResetBtn.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.FilterViewType.FILTER_ACTION_BUTTON;
        }
    }
}
