/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 10/7/15.
 */
public class ApiCommonError {

    @SerializedName("message")
    private String errorMessage = "Unknown Error";

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
