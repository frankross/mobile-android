/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.utils;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.util.Log;
import android.util.TypedValue;

import java.io.ByteArrayOutputStream;
import java.io.File;

/**
 * Created by gowtham on 6/7/15.
 */

public class BitmapUtils {

    private static final String TAG = BitmapUtils.class.getName();

    private static final int UNCONSTRAINED = -1;

    public static byte[] getBytes(Bitmap bmp, boolean isBigThumbnail) {
        Log.d("TAG", "Get Bytes : " + bmp);
        ByteArrayOutputStream stream = new ByteArrayOutputStream();

        int compressionQuality = 50;
        if (isBigThumbnail) {
            compressionQuality = 70;
        }
        bmp.compress(Bitmap.CompressFormat.PNG, compressionQuality, stream);

        return stream.toByteArray();
    }

    public static Bitmap getBitmap(File bitmapFile) {
        Bitmap bitmap = null;

        if (bitmapFile.exists()) {
            bitmap = BitmapFactory.decodeFile(bitmapFile.getAbsolutePath());
        }

        return bitmap;
    }

    public static Bitmap getScaledBitmap(String imagePath, int reqWidth, int reqHeight) {
        Bitmap bitmap;

        File imgFile = new File(imagePath);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(imagePath, options);

        options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight);

        options.inJustDecodeBounds = false;
        options.inPurgeable = true;
        bitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath(), options);

        return bitmap;
    }

    public static Bitmap getScaledPrescriptionBitmap(String imagePath) {
        Bitmap bitmap;

        File imgFile = new File(imagePath);
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(imagePath, options);

        final int height = options.outHeight;
        final int width = options.outWidth;

        if (width > height) {
            options.inSampleSize = calculateInSampleSize(options, 1000, 750);
        } else {
            options.inSampleSize = calculateInSampleSize(options, 750, 1000);
        }

        options.inJustDecodeBounds = false;
        options.inPurgeable = true;
        bitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath(), options);

        return bitmap;
    }

    public static int calculateInSampleSize(
            BitmapFactory.Options options, int reqWidth, int reqHeight) {
        // Raw height and width of image
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;
        Log.d(TAG, "width = " + width + " height = " + height);
        Log.d(TAG, " request width = " + reqWidth + " request height = " + reqHeight);

        inSampleSize = Math.max(Math.round((float) width / (float) reqWidth),
                Math.round((float) height / (float) reqHeight));
        Log.d(TAG, "sample Size = " + inSampleSize);

        return (inSampleSize >= 1) ? inSampleSize : 1;
    }


    // Rotates the bitmap by the specified degree.
    // If a new bitmap is created, the original bitmap is recycled.
    public static Bitmap rotate(Bitmap b, int degrees) {
        if (degrees != 0 && b != null) {
            Matrix m = new Matrix();
            m.setRotate(degrees,
                    (float) b.getWidth() / 2, (float) b.getHeight() / 2);
            try {
                Bitmap b2 = Bitmap.createBitmap(
                        b, 0, 0, b.getWidth(), b.getHeight(), m, true);
                if (b != b2) {
                    b.recycle();
                    b = b2;
                }
            } catch (OutOfMemoryError ex) {
                // We have no memory to rotate. Return the original bitmap.
            }
        }
        return b;
    }

    /*
     * Compute the sample size as a function of minSideLength
     * and maxNumOfPixels.
     * minSideLength is used to specify that minimal width or height of a
     * bitmap.
     * maxNumOfPixels is used to specify the maximal size in pixels that is
     * tolerable in terms of memory usage.
     *
     * The function returns a sample size based on the constraints.
     * Both size and minSideLength can be passed in as IImage.UNCONSTRAINED,
     * which indicates no care of the corresponding constraint.
     * The functions prefers returning a sample size that
     * generates a smaller bitmap, unless minSideLength = IImage.UNCONSTRAINED.
     *
     * Also, the function rounds up the sample size to a power of 2 or multiple
     * of 8 because BitmapFactory only honors sample size this way.
     * For example, BitmapFactory downsamples an image by 2 even though the
     * request is 3. So we round up the sample size to avoid OOM.
     */
    public static int computeSampleSize(BitmapFactory.Options options,
                                        int minSideLength, int maxNumOfPixels) {
        int initialSize = computeInitialSampleSize(options, minSideLength,
                maxNumOfPixels);

        int roundedSize;
        if (initialSize <= 8) {
            roundedSize = 1;
            while (roundedSize < initialSize) {
                roundedSize <<= 1;
            }
        } else {
            roundedSize = (initialSize + 7) / 8 * 8;
        }

        return roundedSize;
    }

    private static int computeInitialSampleSize(BitmapFactory.Options options,
                                                int minSideLength, int maxNumOfPixels) {
        double w = options.outWidth;
        double h = options.outHeight;

        int lowerBound = (maxNumOfPixels == UNCONSTRAINED) ? 1 :
                (int) Math.ceil(Math.sqrt(w * h / maxNumOfPixels));
        int upperBound = (minSideLength == UNCONSTRAINED) ? 128 :
                (int) Math.min(Math.floor(w / minSideLength),
                        Math.floor(h / minSideLength));

        if (upperBound < lowerBound) {
            // return the larger one when there is no overlapping zone.
            return lowerBound;
        }

        if ((maxNumOfPixels == UNCONSTRAINED) &&
                (minSideLength == UNCONSTRAINED)) {
            return 1;
        } else if (minSideLength == UNCONSTRAINED) {
            return lowerBound;
        } else {
            return upperBound;
        }
    }

    public static int convertDptoPixel(Context context, int valueInDp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                valueInDp, context.getResources().getDisplayMetrics());
    }
}
