/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.viewmodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;

/**
 * Created by gowtham on 17/12/15.
 */
public class HorizontalRecyclerViewItem implements BaseRecyclerAdapter.IViewType {

    public int viewHeight = 143;
    public BaseRecyclerAdapter mHorizontalRecyclerViewAdapter;

    @Override
    public int getViewType() {
        return ViewTypes.CommonViewType.VIEW_HORIZONTAL_RECYCLER_ITEM;
    }
}
