/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.utils;

/**
 * Created by gowtham on 24/6/15.
 */
public class Constants {

    public static final boolean ENABLE_DEBUG_LOG = false;
    public static final String LOG_TAG = "FrankRoss";

    /**
     * INTENT EXTRAS
     */
    public static final String INTENT_EXTRA_PRESCRIPTION_ID = "prescriptionId";

    public static final String APP_PLAY_STORE_URL_WEB = "https://play.google.com/store/apps/details?id=";
    public static final String APP_PLAY_STORE_URL = "market://details?id=";
    public static final String APP_PLAY_STORE_URL_REFERRER = "https://play.google.com/store/apps/details?referrer=";

    /**
     * GCM
     */
    public static final String SENT_TOKEN_TO_SERVER = "sentTokenToServer";
    public static final String REGISTRATION_COMPLETE = "registrationComplete";
    public static final String GCM_TOKEN = "gcm_token";
    public static final String GCM_API_SERVER_KEY = "AIzaSyCUsGkUIPjm2d53__-Ol33YIgMrSejNR_8";

    /**
     * APP LINKING CONSTANTS
     */
    public static final String DEEP_LINKING_ORDER_DETAILS_SCREEN = "order";
    public static final String DEEP_LINKING_PRESCRIPTION_DETAILS_SCREEN = "prescription";
    public static final String DEEP_LINKING_CART = "cart";
    public static final String DEEP_LINKING_PPDP = "ppdp";//pharma PDP
    public static final String DEEP_LINKING_NPDP = "npdp";//non pharma PDP
    public static final String DEEP_LINKING_HEALTH_ARTICLES = "health_article";//health articles

    /**
     * REQUEST CODE
     */
    public static final int REQUEST_CODE_FOR_LOGIN = 121;
    public static final int REQUEST_CODE_ORDER_HISTORY = 1234;
    public static final int REQUEST_CODE_PRESCRIPTION_DETAIL = 1235;
    public static final int REQUEST_CODE_CART = 1236;
    public static final int REQUEST_CODE_SUB_CATEGORY = 1237;
    public static final int REQUEST_CODE_PRODUCT_LISTING = 1238;
    public static final int REQUEST_CODE_WEB_VIEW = 1239;
    public static final int REQUEST_CODE_CATEGORY = 1240;
    public static final int REQUEST_CODE_INVITE_FRIENDS = 1241;
    public static final int REQUEST_CODE_BRANCH_DEEPLINKING = 1242;

    /**
     * BORDER height
     */
    public static final int OFFERS_ITEM_BORDER_HEIGHT = 30;
    public static final int NOTIFICATIONS_ITEM_BORDER_HEIGHT = 5;

    /**
     * Auto scroll delay in milliseconds
     */
    public static int AUTO_SCROLL_PRIMARY_DELAY = 10000;
    public static int AUTO_SCROLL_SECONDARY_DELAY = 4000;
    public static int AUTO_SCROLL_INITIAL_DELAY = 9000;

    /**
     * Category id to match for Prescription Medicine navigation
     */
    public static final long CATEGORY_PHARMACY_ID = 810;

    /**
     * Screen names for the Flurry event
     */
    public static final String PRODUCT_LISTING_SCREEN_NAME = "Product Listing";
    public static final String HOME_SCREEN_NAME = "Home";
    public static final String FAQ_SCREEN_NAME = "FAQ";
    public static final String PHARMA_SUB_CATEGORY_SCREEN_NAME = "Pharmacy Sub category";
    public static final String CATEGORIES_SCREEN_NAME = "Categories";
    public static final String PRESCRIPTION_MEDICINE_SCREEN_NAME = "Prescription Medicine";
    public static final String NON_PHARMA_PDP_SCREEN_NAME = "Non Pharma Product Details";
    public static final String PHARMA_PDP_SCREEN_NAME = "Pharma Product Details";
    public static final String SEARCH_RESULT_SCREEN_NAME = "Search Result";
    public static final String STORE_LOCATOR_SCREEN_NAME = "Store Locator";
    public static final String OFFERS_SCREEN_NAME = "Offers";
}
