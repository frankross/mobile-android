/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.home;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.UrlConstants;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.utils.PreferenceUtils;
import com.emamifrankross.frankross.utils.Utils;

/**
 * Created by gauthami on 25/9/15.
 */

/**
 * This class represents the UI for Switching between the host urls - purely for development and testing
 */
public class StagingUrlFragment extends ApiRequestBaseFragment implements IToolbar, View.OnClickListener {

    private EditText mBaseUrl;
    private EditText mAlgoliaSuffix;
    private EditText mPrivacyUrl;

    private IOnUrlSelectListener mIOnUrlSelectListener;

    public static StagingUrlFragment create() {

        return new StagingUrlFragment();
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        try {
            mIOnUrlSelectListener = (IOnUrlSelectListener) getActivity();
        } catch (ClassCastException exception) {
            throw new ClassCastException(context.toString()
                    + " must implement IOnUrlSelectListener");
        }
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_staging_url, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }

    private void initViews(View view) {
        mBaseUrl = (EditText) view.findViewById(R.id.staging_url_base_et);
        mAlgoliaSuffix = (EditText) view.findViewById(R.id.staging_algolia_suffix_et);
        mPrivacyUrl = (EditText) view.findViewById(R.id.staging_privacy_url_et);
        Button doneBtn = (Button) view.findViewById(R.id.staging_urls_done_btn);

        initDefaultValue();

        doneBtn.setOnClickListener(this);
    }

    private void initDefaultValue() {
        mBaseUrl.setText(PreferenceUtils.getStringFromSharedPreference(getActivity(), PreferenceUtils.PREFERENCE_KEY_API_STAGING_URL));
        mAlgoliaSuffix.setText(PreferenceUtils.getStringFromSharedPreference(getActivity(), PreferenceUtils.PREFERENCE_KEY_ALGOLIA_SUFFIX));
        mPrivacyUrl.setText(PreferenceUtils.getStringFromSharedPreference(getActivity(), PreferenceUtils.PREFERENCE_KEY_PRIVACY_URL));
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return "";
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.staging_urls_done_btn:
                if (!TextUtils.isEmpty(mBaseUrl.getText().toString())) {
                    if (!mBaseUrl.getText().toString().equals(PreferenceUtils.getStringFromSharedPreference(
                            getActivity(), PreferenceUtils.PREFERENCE_KEY_API_STAGING_URL))) {
                        performLogout();
                    }
                    PreferenceUtils.saveStringIntoSharedPreference(getActivity(),
                            PreferenceUtils.PREFERENCE_KEY_API_STAGING_URL, mBaseUrl.getText().toString());
                } else {
                    PreferenceUtils.saveStringIntoSharedPreference(getActivity(),
                            PreferenceUtils.PREFERENCE_KEY_API_STAGING_URL, UrlConstants.BASE_URL_STAGING);
                }
                if (!TextUtils.isEmpty(mAlgoliaSuffix.getText().toString())) {
                    PreferenceUtils.saveStringIntoSharedPreference(getActivity(),
                            PreferenceUtils.PREFERENCE_KEY_ALGOLIA_SUFFIX, mAlgoliaSuffix.getText().toString());
                } else {
                    PreferenceUtils.saveStringIntoSharedPreference(getActivity(),
                            PreferenceUtils.PREFERENCE_KEY_ALGOLIA_SUFFIX, UrlConstants.ALGOLIA_STAGING_SUFFIX);
                }
                if (!TextUtils.isEmpty(mPrivacyUrl.getText().toString())) {
                    PreferenceUtils.saveStringIntoSharedPreference(getActivity(),
                            PreferenceUtils.PREFERENCE_KEY_PRIVACY_URL, mPrivacyUrl.getText().toString());
                } else {
                    PreferenceUtils.saveStringIntoSharedPreference(getActivity(),
                            PreferenceUtils.PREFERENCE_KEY_PRIVACY_URL, UrlConstants.PRIVACY_URL);
                }
                mIOnUrlSelectListener.onStagingUrlSelect();
                break;
        }
    }

    private void performLogout() {
        Utils.clearAccessToken(getActivity().getApplicationContext());
    }

    interface IOnUrlSelectListener {
        void onStagingUrlSelect();
    }
}
