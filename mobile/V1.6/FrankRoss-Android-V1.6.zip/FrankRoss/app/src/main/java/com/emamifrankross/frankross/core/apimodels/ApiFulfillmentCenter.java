/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gauthami on 14/10/16.
 */
public class ApiFulfillmentCenter {

    public static class Request {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("billing_address_id")
        private long billing_address_id;

        @SerializedName("area_id")
        private long area_id;

        @SerializedName("shipping_address_id")
        private long shipping_address_id;

        public void setBillingAddressId(long billing_address_id) {
            this.billing_address_id = billing_address_id;
        }

        public void setAreaId(long area_id) {
            this.area_id = area_id;
        }

        public void setShippingAddressI(long shipping_address_id) {
            this.shipping_address_id = shipping_address_id;
        }
    }

    public static class Response {

        @SerializedName("fulfillment_center_id")
        private int fulfillment_center_id;

        public int getFulfillmentCenterId() {
            return fulfillment_center_id;
        }

        public void setFulfillmentCenterId(int fulfillment_center_id) {
            this.fulfillment_center_id = fulfillment_center_id;
        }
    }
}
