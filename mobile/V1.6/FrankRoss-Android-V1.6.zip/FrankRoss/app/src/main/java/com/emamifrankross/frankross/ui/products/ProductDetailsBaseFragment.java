/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.products;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.search.SearchActivity;
import com.facebook.FacebookSdk;

/**
 * Created by gauthami on 3/8/15.
 */

/**
 * This class represents the UI for Product detail
 */
public class ProductDetailsBaseFragment extends ApiRequestBaseFragment implements View.OnClickListener,
        IToolbar {

    public Button mAddToCart;
    protected RelativeLayout mAddToCartLayout;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        FacebookSdk.sdkInitialize(getActivity().getApplicationContext());
        return inflater.inflate(R.layout.fragment_product_detail_base, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
    }

    private void initViews(View view) {
        mAddToCartLayout = (RelativeLayout) view.findViewById(R.id.product_detail_add_to_cart_linlay);
        mAddToCartLayout.setVisibility(View.GONE);
        mAddToCart = (Button) view.findViewById(R.id.product_detail_add_to_cart_btn);
        ImageView supportBtn = (ImageView) view.findViewById(R.id.product_detail_support_btn);
        ImageView shareBtn = (ImageView) view.findViewById(R.id.product_detail_share_btn);

        supportBtn.setOnClickListener(this);
        shareBtn.setOnClickListener(this);
        mAddToCart.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.product_detail_add_to_cart_btn:
                if (mAddToCart.getText().toString().equals(getString(R.string.product_detail_add_to_cart_button_title))) {
                    onAddToCartClicked();
                } else {
                    onNotifyMeClicked();
                }
                break;
            case R.id.product_detail_support_btn:
                onSupportClicked();
                break;
            case R.id.product_detail_share_btn:
                onProductDetailShareClicked();
                break;
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());

        mApiRequestManager.registerCartCountChangeNotifier((BaseActivity) getActivity());
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());

        mApiRequestManager.unregisterCartCountChangeNotifier((BaseActivity) getActivity());
    }

    protected void onSupportClicked() {

    }

    protected void onAddToCartClicked() {

    }

    protected void onNotifyMeClicked() {

    }

    protected void onProductDetailShareClicked() {

    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().finish();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.product_detail);
    }

    @Override
    public int getToolbarMenuId() {
        return R.menu.menu_pharmacy;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.action_search:
                        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SEARCH_FROM_TOOLBAR_EVENT);
                        startActivity(new Intent(getActivity(), SearchActivity.class));
                        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
                        break;

                    case R.id.action_cart:
                        onCartClicked();
                        break;
                }
                return false;
            }
        };
    }

    protected void onCartClicked() {
        startActivity(CartActivity.getActivityIntent(getActivity().getApplicationContext(),
                CartActivity.CART_FRAGMENT_ID));
        getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }
}
