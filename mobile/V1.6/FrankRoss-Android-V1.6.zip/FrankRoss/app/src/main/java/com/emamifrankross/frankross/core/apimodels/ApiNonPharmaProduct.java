/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 2/8/15.
 */
public class ApiNonPharmaProduct extends ApiProduct {

    private String variantValue = "";

    private List<String> keyFeatures = new ArrayList<>(1);

    private String productDescription = "";

    private List<String> specifications = new ArrayList<>(1);

    private List<VariationTheme> variationTheme = new ArrayList<>(1);

    private List<Combination> variationCombination = new ArrayList<>(1);

    public String getVariantValue() {
        return variantValue;
    }

    public void setVariantValue(String variantValue) {
        this.variantValue = variantValue;
    }

    public List<String> getKeyFeatures() {
        return keyFeatures;
    }

    public void setKeyFeatures(List<String> keyFeatures) {
        this.keyFeatures = keyFeatures;
    }

    public String getProductDescription() {
        return productDescription;
    }

    public void setProductDescription(String productDescription) {
        this.productDescription = productDescription;
    }

    public List<String> getSpecifications() {
        return specifications;
    }

    public void setSpecifications(List<String> specifications) {
        this.specifications = specifications;
    }

    public List<VariationTheme> getVariationThemes() {
        return variationTheme;
    }

    public void setVariationThemes(List<VariationTheme> variationTheme) {
        this.variationTheme = variationTheme;
    }

    public List<Combination> getVariationCombination() {
        return variationCombination;
    }

    public void setVariationCombination(List<Combination> variationCombination) {
        this.variationCombination = variationCombination;
    }

    public static class VariationTheme {

        private String variationPropertyName = "";

        private String variantDisplayName = "";

        private List<String> supportedValues = new ArrayList<>(1);

        public String getVariationPropertyName() {
            return variationPropertyName;
        }

        public void setVariationPropertyName(String variationPropertyName) {
            this.variationPropertyName = variationPropertyName;
        }

        public List<String> getSupportedValues() {
            return supportedValues;
        }

        public void setSupportedValues(List<String> supportedValues) {
            this.supportedValues = supportedValues;
        }

        public String getVariantDisplayName() {
            return variantDisplayName;
        }

        public void setVariantDisplayName(String variantDisplayName) {
            this.variantDisplayName = variantDisplayName;
        }
    }

    public static class Combination {

        private long productId;

        private String primaryVariantValue = "";

        private String secondaryVariantValue = "";

        public long getProductId() {
            return productId;
        }

        public void setProductId(long productId) {
            this.productId = productId;
        }

        public String getPrimaryVariantValue() {
            return primaryVariantValue;
        }

        public void setPrimaryVariantValue(String primaryVariantValue) {
            this.primaryVariantValue = primaryVariantValue;
        }

        public String getSecondaryVariantValue() {
            return secondaryVariantValue;
        }

        public void setSecondaryVariantValue(String secondaryVariantValue) {
            this.secondaryVariantValue = secondaryVariantValue;
        }
    }
}
