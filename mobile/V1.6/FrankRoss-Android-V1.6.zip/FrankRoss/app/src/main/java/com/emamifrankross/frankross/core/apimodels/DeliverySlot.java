/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 4/8/15.
 */
public class DeliverySlot {

    @SerializedName("id")
    private long id = -1;

    @SerializedName("slot_id")
    private String slot_id = "";

    @SerializedName("slot_date")
    private String slot_date = "";

    @SerializedName("slot_description")
    private String slot_description = "";

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getSlot_id() {
        return slot_id;
    }

    public void setSlot_id(String slot_id) {
        this.slot_id = slot_id;
    }

    public String getSlot_date() {
        return slot_date;
    }

    public void setSlot_date(String slot_date) {
        this.slot_date = slot_date;
    }

    public String getSlot_description() {
        return slot_description;
    }

    public void setSlot_description(String slot_description) {
        this.slot_description = slot_description;
    }
}
