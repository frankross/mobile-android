/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.prescription;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.RequestCartItem;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.OrderHistoryAdapter;
import com.emamifrankross.frankross.ui.adapters.PrescriptionDetailsAdapter;
import com.emamifrankross.frankross.ui.cart.CartActivity;
import com.emamifrankross.frankross.ui.common.ApiRequestBaseFragment;
import com.emamifrankross.frankross.ui.common.IToolbar;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.products.pharmaproductdetail.QuestionAndAnswerFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 16/7/15.
 */

/**
 * This class represents the UI for Prescription detail screen
 */
public class PrescriptionDetailFragment extends ApiRequestBaseFragment implements IToolbar,
        BaseRecyclerAdapter.RecyclerItemClickListener,
        View.OnClickListener {

    private static final String BUNDLE_KEY_PRESCRIPTION_ID = "prescriptionId";

    private List<BaseRecyclerAdapter.IViewType> mPrescriptionData = new ArrayList<>();
    private PrescriptionDetailsAdapter mPrescriptionDetailsAdapter;

    private Button mOrderBtn;
    private String mDoctorName;
    private String mPatientName;

    public static PrescriptionDetailFragment create(long prescriptionId) {
        PrescriptionDetailFragment fragment = new PrescriptionDetailFragment();

        Bundle bundle = new Bundle();
        bundle.putLong(BUNDLE_KEY_PRESCRIPTION_ID, prescriptionId);
        fragment.setArguments(bundle);

        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mPrescriptionDetailsAdapter = new PrescriptionDetailsAdapter(mPrescriptionData);

        if (getArguments() != null) {
            long prescriptionId = getArguments().getLong(BUNDLE_KEY_PRESCRIPTION_ID);
            mFragmentInteractionListener.showBlockingProgressBar();
            getPrescriptionDetail(prescriptionId);
        }
    }

    /**
     * Method that requests for prescription details
     *
     * @param prescriptionId the prescription whose details is requested
     */
    private void getPrescriptionDetail(long prescriptionId) {
        mApiRequestManager.performGetPrescriptionDetailRequest(prescriptionId, new ApiRequestManager.IPrescriptionDescriptionResultNotifier() {

            @Override
            public void onPrescriptionDetailFetched(List<BaseRecyclerAdapter.IViewType> prescriptionDetails, String doctorName, String patientName) {
                if (getActivity() != null && prescriptionDetails != null && prescriptionDetails.size() > 0) {
                    mOrderBtn.setVisibility(View.VISIBLE);
                    mPrescriptionData.clear();
                    mPrescriptionData.addAll(prescriptionDetails);
                    mPrescriptionDetailsAdapter.notifyDataSetChanged();
                    mFragmentInteractionListener.hideBlockingProgressBar();

                    mDoctorName = doctorName;
                    mPatientName = patientName;
                }
            }
        }, this, this);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_prescription_details, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initViews(view);
        mToolbarInteractionListener.updateToolbar(this);
    }


    private void initViews(View view) {
        RecyclerView prescriptionDetailRecyclerView = (RecyclerView) view.findViewById(R.id.prescription_recycler_view);
        prescriptionDetailRecyclerView.setHasFixedSize(false);
        //prescriptionDetailRecyclerView.getItemAnimator().setSupportsChangeAnimations(false);
        prescriptionDetailRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mPrescriptionDetailsAdapter.setRecyclerItemClickListener(this);
        prescriptionDetailRecyclerView.setAdapter(mPrescriptionDetailsAdapter);

        mOrderBtn = (Button) view.findViewById(R.id.prescription_order_btn);
        mOrderBtn.setOnClickListener(this);

        if (mPrescriptionData != null && mPrescriptionData.size() > 0) {
            mOrderBtn.setVisibility(View.VISIBLE);
        } else {
            mOrderBtn.setVisibility(View.GONE);
        }

        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PRESCRIPTION_DETAILS_VISIT_EVENT);
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (object == null) return;
        switch (((OrderHistoryAdapter.IViewType) object).getViewType()) {
            case ViewTypes.PrescriptionViewType.PRESCRIPTION_INFO:
                break;
            case ViewTypes.PrescriptionViewType.PRESCRIPTION_DOSAGE_INFO_HEADER:
                break;
            case ViewTypes.SortViewType.SORT_LIST_ITEM:
                PrescriptionDetailsAdapter.PrescriptionNotesDataItem prescriptionNotesDataItem =
                        (PrescriptionDetailsAdapter.PrescriptionNotesDataItem) object;
                mFragmentInteractionListener.loadFragment(getId(),
                        QuestionAndAnswerFragment.create(prescriptionNotesDataItem.notesHeader,
                                prescriptionNotesDataItem.noteDescription),
                        null, R.anim.push_left_in, R.anim.fade_out,
                        FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
                break;
        }
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.prescription_order_btn:
                performOrderRequest();
                break;
        }
    }

    private void performOrderRequest() {
        mFragmentInteractionListener.showBlockingProgressBar();
        addReorderedItemsToCart();
    }

    private void addReorderedItemsToCart() {
        new AsyncTask<Void, Void, List<RequestCartItem>>() {

            @Override
            protected List<RequestCartItem> doInBackground(Void... params) {
                List<RequestCartItem> requestCartItems = new ArrayList<>(1);
                for (BaseRecyclerAdapter.IViewType view : mPrescriptionData) {
                    if (view.getViewType() == ViewTypes.PrescriptionViewType.PRESCRIPTION_DOSAGE_INFO) {
                        PrescriptionDetailsAdapter.PrescriptionDosageDataItem dosageDataItem =
                                (PrescriptionDetailsAdapter.PrescriptionDosageDataItem) view;
                        if (dosageDataItem != null && dosageDataItem.presMedicineVariantId > 0) {
                            FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.ORDER_FROM_PRESCRIPTION_EVENT);

                            RequestCartItem cartItem = new RequestCartItem();
                            cartItem.setVariantId(dosageDataItem.presMedicineVariantId);

                            int quantity = mApiRequestManager.getCartItemQuantityForReOrder(dosageDataItem.presMedicineVariantId, 1);
                            //  quantity = (quantity == 0) ? 1 : quantity+1;

                            cartItem.setQuantity(quantity);

                            requestCartItems.add(cartItem);
                        }
                    }
                }

                return requestCartItems;
            }

            @Override
            protected void onPostExecute(List<RequestCartItem> requestCartItems) {
                super.onPostExecute(requestCartItems);
                performAddToCart(requestCartItems);
            }
        }.execute();
    }

    private void performAddToCart(List<RequestCartItem> requestCartItems) {
        mApiRequestManager.performAddCartRequest(requestCartItems, new ApiRequestManager.IAddCartResultNotifier() {

            @Override
            public void onProductAdded() {
                mFragmentInteractionListener.hideBlockingProgressBar();
                startActivity(CartActivity.getActivityIntentForPatientDetails(mDoctorName, mPatientName, getActivity()));
                getActivity().overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
            }

            @Override
            public void onProductAddFailed() {
                mFragmentInteractionListener.hideBlockingProgressBar();
                Toast.makeText(getActivity().getApplicationContext(),
                        getString(R.string.add_to_cart_failure_msg), Toast.LENGTH_SHORT).show();
            }
        }, this, this);
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(getActivity());
        //FrankRossAnalytics.getFrankRossTracker().logTimedEvent(FrankRossEvents.TIME_SPENT_PRESCRIPTION_DETAILS_EVENT, null);
    }

    @Override
    public void onStop() {
        super.onStop();
        //FrankRossAnalytics.getFrankRossTracker().endTimedEvent(FrankRossEvents.TIME_SPENT_PRESCRIPTION_DETAILS_EVENT, null);
        FrankRossAnalytics.getFrankRossTracker().endSession(getActivity());
    }

    @Override
    public int getToolbarNavigationIconId() {
        return R.mipmap.back;
    }

    @Override
    public View.OnClickListener getNavigationClickListener() {
        return new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeFragment();
            }
        };
    }

    @Override
    public String getToolbarTitleId() {
        return getString(R.string.drawer_menu_prescription);
    }

    @Override
    public int getToolbarMenuId() {
        return 0;
    }

    @Override
    public Toolbar.OnMenuItemClickListener getToolbarMenuItemClickListener() {
        return null;
    }
}
