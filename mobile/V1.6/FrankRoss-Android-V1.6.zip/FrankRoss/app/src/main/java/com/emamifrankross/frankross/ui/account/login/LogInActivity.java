/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.account.login;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.BaseActivity;
import com.emamifrankross.frankross.ui.common.BaseFragment;

/**
 * Created by gauthami on 2/7/15.
 */

/**
 * This class manages the login based intents and its data
 */
public class LogInActivity extends BaseActivity {

    public static final int LOG_IN_FRAGMENT = 001;
    public static final int REGISTER_IN_FRAGMENT = 002;
    public static final int REGISTER_SOCIAL_FRAGMENT = 003;

    private static final String FRAGMENT_ID = "fragmentID";
    private static final String EXTRA_IS_FROM_CART = "CartLogin";

    private static final String EXTRA_USER_MAIL_ID = "social_user_mail";
    private static final String EXTRA_USER_NAME = "social_user_name";
    private static final String EXTRA_USER_ID = "social_user_id";
    private static final String EXTRA_USER_ACCESS_TOKEN = "social_user_access_token";
    private static final String EXTRA_PROVIDER = "social_provider";

    public static Intent getActivityIntent(Context context, boolean isFromCart, int fragmentId) {
        Intent intent = new Intent(context, LogInActivity.class);
        intent.putExtra(FRAGMENT_ID, fragmentId);
        intent.putExtra(EXTRA_IS_FROM_CART, isFromCart);

        return intent;
    }

    public static Intent getActivityIntentForSocialLogIn(Context context, int fragmentId, String userName,
                                                         String mailId, String provider, String accessToken,
                                                         String userId) {
        Intent intent = new Intent(context, LogInActivity.class);
        intent.putExtra(FRAGMENT_ID, fragmentId);
        intent.putExtra(EXTRA_USER_NAME, userName);
        intent.putExtra(EXTRA_USER_MAIL_ID, mailId);
        intent.putExtra(EXTRA_PROVIDER, provider);
        intent.putExtra(EXTRA_USER_ACCESS_TOKEN, accessToken);
        intent.putExtra(EXTRA_USER_ID, userId);

        return intent;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        if (intent != null) {
            int fragmentId = intent.getIntExtra(FRAGMENT_ID, 001);
            boolean isFromCart = intent.getBooleanExtra(EXTRA_IS_FROM_CART, false);
            String userName = intent.getStringExtra(EXTRA_USER_NAME);
            String userMailId = intent.getStringExtra(EXTRA_USER_MAIL_ID);
            String userAccessToken = intent.getStringExtra(EXTRA_USER_ACCESS_TOKEN);
            String userId = intent.getStringExtra(EXTRA_USER_ID);
            String provider = intent.getStringExtra(EXTRA_PROVIDER);
            initFragment(fragmentId, isFromCart, userName, userMailId, userAccessToken, userId, provider);
        }
    }

    private void initFragment(int fragmentId, boolean isFromCart, String userName, String userMailId,
                              String userAccessToken, String userId, String provider) {
        BaseFragment fragment = null;
        switch (fragmentId) {
            case LOG_IN_FRAGMENT:
                fragment = LogInFragment.create(isFromCart);
                break;
            case REGISTER_IN_FRAGMENT:
                fragment = RegistrationFragment.create();
                break;
            case REGISTER_SOCIAL_FRAGMENT:
                fragment = SocialUserRegistrationFragment.create(provider, userAccessToken, userId, userName, userMailId);
                break;
        }
        loadFragment(R.id.fragment_container, fragment, LogInActivity.class.getName(),
                0, 0, BaseFragment.FragmentTransactionType.REPLACE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Fragment fragment = getSupportFragmentManager().findFragmentById(getFragmentContainerId());

        if (fragment != null && fragment instanceof EnterOTPFragment) {
            EnterOTPFragment enterOTPFragment = (EnterOTPFragment) fragment;
            enterOTPFragment.unregisterOtpAutoReadListener();
        }
    }
}
