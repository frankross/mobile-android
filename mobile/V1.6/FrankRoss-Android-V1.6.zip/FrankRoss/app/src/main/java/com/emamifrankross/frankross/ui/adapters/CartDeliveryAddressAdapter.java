/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 23/7/15.
 * <p> Adapter class for CheckOut Delivery Address Section</p>
 * <p>Supports the Four View Types </p>
 * <p> 1 : CHECKOUT HEADER VIEW TYPE </p>
 * <p> 2 : CHECKOUT DELIVER TO VIEW TYPE </p>
 * <p> 3 : CHECKOUT DELIVERY SLOT VIEW TYPE </p>
 * <p> 4 : CHECKOUT DOCTOR PATIENT INFO VIEW TYPE </p>
 */
public class CartDeliveryAddressAdapter extends BaseRecyclerAdapter {

    public CartDeliveryAddressAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<BaseRecyclerAdapter.RecyclerViewDataBinder> getViewDataBinders() {
        List<BaseRecyclerAdapter.RecyclerViewDataBinder> viewHolderTypeList = new ArrayList<>(1);
        viewHolderTypeList.add(new CheckOutHeaderViewHolderType());
        viewHolderTypeList.add(new CheckOutDeliverToViewHolderType());
        viewHolderTypeList.add(new CheckOutDeliverySlotViewHolderType());
        viewHolderTypeList.add(new CheckOutDoctorPatientInfoViewDataBinder());

        return viewHolderTypeList;
    }

    /**
     * CHECKOUT HEADER VIEW TYPE
     */

    public static class CheckOutHeaderDataItem implements BaseRecyclerAdapter.IViewType {

        public String checkOutSubHeader;
        public String checkOutHeader;

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutDeliveryAddressViewType.CHECKOUT_HEADER_VIEW_TYPE;
        }
    }

    private static class CheckOutHeaderViewHolder extends RecyclerView.ViewHolder {

        public RobotoTextView mCheckOutHeader;
        public RobotoTextView mCheckOutSubHeader;

        public CheckOutHeaderViewHolder(View itemView) {
            super(itemView);
            mCheckOutHeader = (RobotoTextView) itemView.findViewById(R.id.check_out_header_sub_title_tv);
            mCheckOutSubHeader = (RobotoTextView) itemView.findViewById(R.id.check_out_header_title_tv);
        }
    }

    private static class CheckOutHeaderViewHolderType implements
            BaseRecyclerAdapter.RecyclerViewDataBinder<CheckOutHeaderViewHolder, CheckOutHeaderDataItem> {

        @Override
        public CheckOutHeaderViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.check_out_header, parent, false);

            return new CheckOutHeaderViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(CheckOutHeaderViewHolder viewHolder,
                                         final CheckOutHeaderDataItem data, final int position,
                                         final BaseRecyclerAdapter.RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mCheckOutHeader.setText(data.checkOutHeader);
            viewHolder.mCheckOutSubHeader.setText(data.checkOutSubHeader);
        }

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutDeliveryAddressViewType.CHECKOUT_HEADER_VIEW_TYPE;
        }
    }

    /**
     * CHECKOUT DELIVER TO VIEW TYPE
     */

    public static class CheckOutDeliverToItem implements IViewType {
        public String userName = "";
        public String fullAddress = "";
        public String mobileNumber = "";
        public String changeBtnTxt = "";

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutDeliveryAddressViewType.CHECKOUT_DELIVER_TO_VIEW_TYPE;
        }
    }

    public static class CheckOutDeliverToViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mCheckOutAddressHeader;
        private RobotoTextView mCheckOutChangeAddress;
        private RobotoTextView mCheckOutUserName;
        private RobotoTextView mCheckOutAddress;
        private RobotoTextView mCheckOutMobileNumber;
        private ImageView mCheckOutNextIcon;

        public CheckOutDeliverToViewHolder(View view) {
            super(view);
            mCheckOutAddressHeader = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_header_tv);
            mCheckOutChangeAddress = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_change_tv);
            mCheckOutUserName = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_user_name_tv);
            mCheckOutAddress = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_full_address_tv);
            mCheckOutMobileNumber = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_mobile_number_tv);
            mCheckOutNextIcon = (ImageView) view.findViewById(R.id.check_out_deliver_to_next_icon_iv);
            mCheckOutAddressHeader.setText(mCheckOutAddressHeader.getContext().getString(R.string.check_out_deliver_to));
        }
    }

    private class CheckOutDeliverToViewHolderType implements RecyclerViewDataBinder<CheckOutDeliverToViewHolder,
            CheckOutDeliverToItem> {
        @Override
        public CheckOutDeliverToViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.check_out_deliver_to, parent, false);

            return new CheckOutDeliverToViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(CheckOutDeliverToViewHolder viewHolder, final CheckOutDeliverToItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mCheckOutChangeAddress.setText(data.changeBtnTxt);
            viewHolder.mCheckOutMobileNumber.setText(data.mobileNumber);

            if (!TextUtils.isEmpty(data.userName)) {
                viewHolder.mCheckOutUserName.setText(data.userName);
                viewHolder.mCheckOutUserName.setVisibility(View.VISIBLE);
            } else {
                viewHolder.mCheckOutUserName.setVisibility(View.GONE);
            }

            if (!TextUtils.isEmpty(data.fullAddress)) {
                viewHolder.mCheckOutAddress.setText(data.fullAddress);
                viewHolder.mCheckOutAddress.setVisibility(View.VISIBLE);
            } else {
                viewHolder.mCheckOutAddress.setVisibility(View.GONE);
            }

            if (recyclerViewClickListener != null) {
                viewHolder.mCheckOutChangeAddress.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
            viewHolder.mCheckOutMobileNumber.setVisibility(View.GONE);
        }

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutDeliveryAddressViewType.CHECKOUT_DELIVER_TO_VIEW_TYPE;
        }
    }

    /**
     * CHECKOUT DELIVERY SLOT VIEW TYPE
     */

    public static class CheckOutDeliverySlotDataItem implements IViewType {

        public String deliverySlotHeader = "";
        public String deliverySlotTime = "";

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutDeliveryAddressViewType.CHECKOUT_DELIVERY_SLOT_VIEW_TYPE;
        }
    }

    public static class CheckOutDeliverySlotViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mCheckOutAddressHeader;
        private RobotoTextView mCheckOutChangeAddress;
        private RobotoTextView mCheckOutUserName;
        private RobotoTextView mCheckOutAddress;
        private RobotoTextView mCheckOutMobileNumber;
        private ImageView mCheckOutNextIcon;

        public CheckOutDeliverySlotViewHolder(View view, Context context) {
            super(view);
            mCheckOutAddressHeader = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_header_tv);
            mCheckOutChangeAddress = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_change_tv);
            mCheckOutUserName = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_user_name_tv);
            mCheckOutAddress = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_full_address_tv);
            mCheckOutMobileNumber = (RobotoTextView) view.findViewById(R.id.check_out_deliver_to_mobile_number_tv);
            mCheckOutNextIcon = (ImageView) view.findViewById(R.id.check_out_deliver_to_next_icon_iv);

            mCheckOutMobileNumber.setVisibility(View.GONE);
            mCheckOutChangeAddress.setVisibility(View.GONE);
            mCheckOutNextIcon.setVisibility(View.VISIBLE);
            mCheckOutNextIcon.setEnabled(false);
            view.findViewById(R.id.card_view_linLyt).setBackgroundColor(ContextCompat.getColor(view.getContext(), R.color.white_background));
        }
    }

    private class CheckOutDeliverySlotViewHolderType implements RecyclerViewDataBinder<CheckOutDeliverySlotViewHolder,
            CheckOutDeliverySlotDataItem> {
        @Override
        public CheckOutDeliverySlotViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.check_out_deliver_to, parent, false);

            return new CheckOutDeliverySlotViewHolder(view, parent.getContext());
        }

        @Override
        public void bindDataToViewHolder(CheckOutDeliverySlotViewHolder viewHolder, final CheckOutDeliverySlotDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            if (!TextUtils.isEmpty(data.deliverySlotHeader)) {
                viewHolder.mCheckOutAddressHeader.setText(viewHolder.mCheckOutAddressHeader.getResources().getString(R.string.check_out_choose_delivery_slot));
                viewHolder.mCheckOutUserName.setVisibility(View.VISIBLE);
                viewHolder.mCheckOutUserName.setText(data.deliverySlotHeader);
            } else {
                viewHolder.mCheckOutAddressHeader.setText(viewHolder.mCheckOutAddressHeader.getResources().getString(R.string.check_out_deliver_to_header));
                viewHolder.mCheckOutUserName.setVisibility(View.GONE);
            }

            if (!TextUtils.isEmpty(data.deliverySlotTime)) {
               /* viewHolder.mCheckOutAddressHeader.setText(viewHolder.mCheckOutAddressHeader.getContext().getResources().
                        getString(R.string.check_out_delivery_slot));*/
                viewHolder.mCheckOutAddress.setVisibility(View.VISIBLE);
                viewHolder.mCheckOutAddress.setText(data.deliverySlotTime);
            } else {
                viewHolder.mCheckOutAddress.setVisibility(View.GONE);
            }
            if (recyclerViewClickListener != null) {
                viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutDeliveryAddressViewType.CHECKOUT_DELIVERY_SLOT_VIEW_TYPE;
        }
    }

    /**
     * DOCTOR PATIENT INFO VIEW TYPE
     */

    public static class CheckOutDoctorPatientInfoDataItem implements IViewType {

        public String doctorName = "";
        public String patientName = "";
        public boolean isExpand = false;
        public boolean isOptional = true;//if false then both fields are mandatory
        public boolean isDeliverySlotSelected = false;
        public boolean isRevisedOrder = false;

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutDeliveryAddressViewType.CHECKOUT_DOCTOR_PATIENT_INFO_VIEW_TYPE;
        }
    }

    public static class CheckOutDoctorPatientInfoViewHolder extends RecyclerView.ViewHolder {
        private EditText mDoctorName;
        private EditText mPatientName;
        private ImageView mHeaderImage;
        private ImageView mDoctorNameEditIcon;
        private ImageView mPatientNameEditIcon;
        private RobotoTextView mDoctorNamePrefix;
        private RobotoTextView mPrescriptionDetailsHeader;
        private LinearLayout mPrescriptionHeaderLinLay;
        private LinearLayout mPrescriptionInfoLinLyt;

        public CheckOutDoctorPatientInfoViewHolder(View view) {
            super(view);
            mPrescriptionDetailsHeader = (RobotoTextView) view.findViewById(R.id.checkout_prescription_details_header_tv);
            mDoctorNamePrefix = (RobotoTextView) view.findViewById(R.id.checkout_doctor_name_prefix_tv);
            mPrescriptionInfoLinLyt = (LinearLayout) view.findViewById(R.id.checkout_prescription_info_linLyt);
            mDoctorName = (EditText) view.findViewById(R.id.checkout_doctor_name_et);
            mPatientName = (EditText) view.findViewById(R.id.checkout_patient_name_et);
            mHeaderImage = (ImageView) view.findViewById(R.id.checkout_prescription_details_header_iv);
            mPrescriptionHeaderLinLay = (LinearLayout) view.findViewById(R.id.checkout_prescription_details_header_linLay);
            mDoctorNameEditIcon = (ImageView) view.findViewById(R.id.checkout_doctor_name_edit_iv);
            mPatientNameEditIcon = (ImageView) view.findViewById(R.id.checkout_patient_name_edit_iv);
        }
    }

    private static class CheckOutDoctorPatientInfoViewDataBinder implements
            RecyclerViewDataBinder<CheckOutDoctorPatientInfoViewHolder, CheckOutDoctorPatientInfoDataItem> {

        @Override
        public CheckOutDoctorPatientInfoViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.checkout_doctor_patient_info, parent, false);
            return new CheckOutDoctorPatientInfoViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(final CheckOutDoctorPatientInfoViewHolder viewHolder, final CheckOutDoctorPatientInfoDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            if (data.doctorName.startsWith(viewHolder.mDoctorName.getContext().getString(R.string.checkout_doctor_prefix) + " ")) {
                viewHolder.mDoctorNamePrefix.setVisibility(View.GONE);
            } else {
                viewHolder.mDoctorNamePrefix.setVisibility(View.VISIBLE);
            }

            viewHolder.mPatientNameEditIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    viewHolder.mPatientName.requestFocus();
                    InputMethodManager imm = (InputMethodManager) viewHolder.mPatientName.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(viewHolder.mPatientName, InputMethodManager.SHOW_IMPLICIT);

                }
            });

            viewHolder.mDoctorNameEditIcon.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    viewHolder.mDoctorName.requestFocus();
                    InputMethodManager imm = (InputMethodManager) viewHolder.mDoctorName.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                    imm.showSoftInput(viewHolder.mDoctorName, InputMethodManager.SHOW_IMPLICIT);
                }
            });

            if (data.isOptional) {
                viewHolder.mDoctorName.setHint(viewHolder.mDoctorName.getContext().getString(R.string.cart_checkout_doctor_name_hint_optional));
                viewHolder.mPatientName.setHint(viewHolder.mDoctorName.getContext().getString(R.string.cart_checkout_patient_name_hint_optional));
                viewHolder.mDoctorName.setText(data.doctorName);
                viewHolder.mPatientName.setText(data.patientName);

                if (data.isExpand) {
                    viewHolder.mHeaderImage.setRotation(180);
                    viewHolder.mPrescriptionInfoLinLyt.setVisibility(View.VISIBLE);
                } else {
                    viewHolder.mHeaderImage.setRotation(0);
                    viewHolder.mPrescriptionInfoLinLyt.setVisibility(View.GONE);
                }

                viewHolder.mHeaderImage.setVisibility(View.VISIBLE);
                if (recyclerViewClickListener != null) {
                    viewHolder.mPrescriptionHeaderLinLay.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            int visibilityState = viewHolder.mPrescriptionInfoLinLyt.getVisibility();
                            if (visibilityState != View.VISIBLE) {
                                data.isExpand = true;
                                viewHolder.mPrescriptionInfoLinLyt.setVisibility(View.VISIBLE);
                                viewHolder.mPatientName.requestFocus();
                                final int widthSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
                                final int heightSpec = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
                                viewHolder.mPrescriptionInfoLinLyt.measure(widthSpec, heightSpec);
                                ValueAnimator mAnimator = slideAnimator(0, viewHolder.mPrescriptionInfoLinLyt.getMeasuredHeight(),
                                        viewHolder.mPrescriptionInfoLinLyt);
                                mAnimator.start();
                                viewHolder.mHeaderImage.setRotation(180);
                            } else {
                                data.isExpand = false;
                                viewHolder.mHeaderImage.setRotation(0);
                                int finalHeight = viewHolder.mPrescriptionInfoLinLyt.getHeight();
                                ValueAnimator mAnimator = slideAnimator(finalHeight, 0, viewHolder.mPrescriptionInfoLinLyt);
                                mAnimator.addListener(new Animator.AnimatorListener() {
                                    @Override
                                    public void onAnimationStart(Animator animation) {

                                    }

                                    @Override
                                    public void onAnimationEnd(Animator animator) {
                                        viewHolder.mPrescriptionInfoLinLyt.post(new Runnable() {
                                            @Override
                                            public void run() {
                                                InputMethodManager imm = (InputMethodManager)
                                                        viewHolder.mPrescriptionInfoLinLyt.getContext().
                                                                getSystemService(Context.INPUT_METHOD_SERVICE);
                                                imm.hideSoftInputFromWindow(viewHolder.mPrescriptionInfoLinLyt.getWindowToken(), 0);
                                            }
                                        });
                                        viewHolder.mPrescriptionInfoLinLyt.setVisibility(View.GONE);
                                    }

                                    @Override
                                    public void onAnimationCancel(Animator animation) {

                                    }

                                    @Override
                                    public void onAnimationRepeat(Animator animation) {

                                    }
                                });
                                mAnimator.start();
                            }
                        }
                    });
                }
            } else {
                viewHolder.mDoctorName.setHint(viewHolder.mDoctorName.getContext().getString(R.string.cart_checkout_doctor_name_hint_mandatory));
                viewHolder.mPatientName.setHint(viewHolder.mDoctorName.getContext().getString(R.string.cart_checkout_patient_name_hint_mandatory));
                viewHolder.mHeaderImage.setVisibility(View.GONE);
                viewHolder.mDoctorName.setText(data.doctorName);
                viewHolder.mPatientName.setText(data.patientName);

                viewHolder.mPrescriptionInfoLinLyt.setVisibility(View.VISIBLE);
            }

            if (!TextUtils.isEmpty(viewHolder.mDoctorName.getText().toString())) {
                viewHolder.mDoctorName.setSelection(viewHolder.mDoctorName.getText().length());
            }

            if (!TextUtils.isEmpty(viewHolder.mPatientName.getText().toString())) {
                viewHolder.mPatientName.setSelection(viewHolder.mPatientName.getText().length());
            }

            if (!data.isOptional && data.isDeliverySlotSelected) {
                /*viewHolder.mPatientName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                    @Override
                    public void onFocusChange(View v, boolean hasFocus) {
                        viewHolder.mPatientName.post(new Runnable() {
                            @Override
                            public void run() {
                                InputMethodManager imm = (InputMethodManager) viewHolder.mPatientName.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                                imm.showSoftInput(viewHolder.mPatientName, InputMethodManager.SHOW_IMPLICIT);
                            }
                        });
                    }
                });*/
                viewHolder.mPatientName.requestFocus();
            }

            viewHolder.mDoctorName.setEnabled(!data.isRevisedOrder);
            viewHolder.mPatientName.setEnabled(!data.isRevisedOrder);

            viewHolder.mDoctorName.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                }

                @Override
                public void afterTextChanged(Editable s) {
                    if (s != null && !TextUtils.isEmpty(s.toString())) {
                        //if (s.toString().startsWith(viewHolder.mDoctorName.getContext().getString(R.string.checkout_doctor_prefix) + " ")) {
                        data.doctorName = s.toString();
                        /*} else {
                            data.doctorName = Utils.getDoctorPrefixedName(s.toString());
                        }*/
                    } else {
                        data.doctorName = s.toString();
                    }
                }
            });

            viewHolder.mPatientName.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                }

                @Override
                public void afterTextChanged(Editable s) {
                    data.patientName = s.toString();
                }
            });
        }

        @Override
        public int getViewType() {
            return ViewTypes.CheckOutDeliveryAddressViewType.CHECKOUT_DOCTOR_PATIENT_INFO_VIEW_TYPE;
        }
    }

    private static ValueAnimator slideAnimator(int start, int end, final LinearLayout view) {

        ValueAnimator animator = ValueAnimator.ofInt(start, end);

        animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                int value = (Integer) valueAnimator.getAnimatedValue();
                ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
                layoutParams.height = value;
                view.setLayoutParams(layoutParams);
            }
        });
        return animator;
    }
}