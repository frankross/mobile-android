/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.utils.Utils;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 30/3/16.
 */
public class ApiRewardPoints {
    public class Response {

        @SerializedName("message")
        private String failureMessage = "";

        @SerializedName("earned")
        private String earnedRewardPoints = "";

        @SerializedName("spend")
        private String spendRewardPoints = "";

        @SerializedName("available")
        private String availableRewardPoints = "";

        @SerializedName("invite_code")
        private String inviteCode;

        @SerializedName("invite_description")
        private String inviteDescription;

        @SerializedName("transactions")
        private List<RewardTransaction> rewardTransactionList;

        private List<BaseRecyclerAdapter.IViewType> uiData = new ArrayList<>();

        public List<RewardTransaction> getRewardPointsList() {
            return rewardTransactionList;
        }

        public List<BaseRecyclerAdapter.IViewType> getUiData() {
            return uiData;
        }

        public void setUiData(List<BaseRecyclerAdapter.IViewType> uiData) {
            this.uiData = uiData;
        }

        public double getEarnedRewardPoints() {
            return Utils.getDoubleValue(earnedRewardPoints);
        }

        public void setEarnedRewardPoints(String earnedRewardPoints) {
            this.earnedRewardPoints = earnedRewardPoints;
        }

        public double getSpendRewardPoints() {
            return Utils.getDoubleValue(spendRewardPoints);
        }

        public void setSpendRewardPoints(String spendRewardPoints) {
            this.spendRewardPoints = spendRewardPoints;
        }

        public double getAvailableRewardPoints() {
            return Utils.getDoubleValue(availableRewardPoints);
        }

        public void setAvailableRewardPoints(String availableRewardPoints) {
            this.availableRewardPoints = availableRewardPoints;
        }

        public String getInviteCode() {
            return inviteCode;
        }

        public void setInviteCode(String inviteCode) {
            this.inviteCode = inviteCode;
        }

        public String getInviteDescription() {
            return inviteDescription;
        }

        public void setInviteDescription(String inviteDescription) {
            this.inviteDescription = inviteDescription;
        }

        public String getFailureMessage() {
            return failureMessage;
        }

        public void setFailureMessage(String failureMessage) {
            this.failureMessage = failureMessage;
        }
    }
}
