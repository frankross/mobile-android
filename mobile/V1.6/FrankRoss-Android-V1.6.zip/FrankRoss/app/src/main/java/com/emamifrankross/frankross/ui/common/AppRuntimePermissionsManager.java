/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.v4.app.ActivityCompat;

/**
 * Created by gauthami on 31/8/16.
 */
public class AppRuntimePermissionsManager {

    public static final int REQUEST_CODE_LOCATION_PERMISSIONS = 1;
    public static final int REQUEST_CODE_CALL_PERMISSIONS = 2;
    public static final int REQUEST_CODE_CAMERA_PERMISSIONS = 3;
    public static final int REQUEST_CODE_GALLERY_PERMISSIONS = 4;
    public static final int REQUEST_CODE_OTP_AUTO_READ_PERMISSIONS = 5;
    public static final int REQUEST_CODE_READ_CONTACTS_READ_PHONE_STATE_PERMISSIONS = 6;
    public static final int REQUEST_CODE_OTP_AUTO_READ_GOOGLE_PERMISSIONS = 7;

    public AppRuntimePermissionsManager() {
    }

    /**
     * Method that checks for Location service permission allowed to app
     *
     * @param context the application context
     * @return the boolean that decides if the Android system has granted access for the feature
     */
    public static boolean checkPermissionForLocation(Context context) {

        return (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && ActivityCompat.checkSelfPermission(context,
                Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(context,
                        Manifest.permission.ACCESS_COARSE_LOCATION) ==
                        PackageManager.PERMISSION_GRANTED);
    }

    /**
     * Method that checks for call permission allowed to app
     *
     * @param context the application context
     * @return the boolean that decides if the Android system has granted access for the feature
     */
    public static boolean checkPermissionForCall(Context context) {

        return (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && ActivityCompat.checkSelfPermission(context,
                Manifest.permission.CALL_PHONE) ==
                PackageManager.PERMISSION_GRANTED);
    }

    /**
     * Method that checks for read message permission allowed to app
     *
     * @param context the application context
     * @return the boolean that decides if the Android system has granted access for the feature
     */
    public static boolean checkPermissionForOtpReadFromMessage(Context context) {

        return (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && ActivityCompat.checkSelfPermission(context,
                Manifest.permission.READ_SMS) ==
                PackageManager.PERMISSION_GRANTED);
    }

    /**
     * Method that checks for Capturing image permission allowed to app
     *
     * @param context the application context
     * @return the boolean that decides if the Android system has granted access for the feature
     */
    public static boolean checkPermissionForCamera(Context context) {

        return (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && ActivityCompat.checkSelfPermission(context,
                Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED);
    }

    /**
     * Method that checks for External storage permission allowed to app
     *
     * @param context the application context
     * @return the boolean that decides if the Android system has granted access for the feature
     */
    public static boolean checkPermissionForExternalStorage(Context context) {

        return (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && ActivityCompat.checkSelfPermission(context,
                Manifest.permission.READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED);
    }

    /**
     * Method that checks for Read contacts allowed to app
     *
     * @param context the application context
     * @return the boolean that decides if the Android system has granted access for the feature
     */
    public static boolean checkPermissionForReadContactsReadPhoneState(Context context) {

        return (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M &&
                ActivityCompat.checkSelfPermission(context,
                        Manifest.permission.READ_CONTACTS) ==
                        PackageManager.PERMISSION_GRANTED
                &&
                ActivityCompat.checkSelfPermission(context,
                        Manifest.permission.READ_PHONE_STATE) ==
                        PackageManager.PERMISSION_GRANTED
                &&
                ActivityCompat.checkSelfPermission(context,
                        Manifest.permission.READ_SMS) ==
                        PackageManager.PERMISSION_GRANTED);
    }

    /**
     * Method that checks for social login permissions allowed to app
     *
     * @param context the application context
     * @return the boolean that decides if the Android system has granted access for the feature
     */
    public static boolean checkPermissionForSocialLogin(Context context) {

        return (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && ActivityCompat.checkSelfPermission(context,
                Manifest.permission.GET_ACCOUNTS) ==
                PackageManager.PERMISSION_GRANTED);
    }
}
