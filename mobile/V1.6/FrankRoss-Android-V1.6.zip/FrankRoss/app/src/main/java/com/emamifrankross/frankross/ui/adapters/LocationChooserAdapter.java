/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gowtham on 21/7/15.
 * <p> Adapter class for Location Chooser. Handles the Header categories and sub categories.</p>
 * <p>Supports the Three View Types </p>
 * <p> 1 : LOCATION_VIEW_TYPE_HEADER </p>
 * <p> 2 : LOCATION_VIEW_TYPE_LIST_ITEM  </p>
 * <p> 3 : LOCATION_VIEW_TYPE_FOOTER </p>
 */
public class LocationChooserAdapter extends BaseRecyclerAdapter implements ViewTypes.LocationChooserViewType {

    public LocationChooserAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        ArrayList<RecyclerViewDataBinder> viewDataBinderTypes = new ArrayList<>(1);
        viewDataBinderTypes.add(new LocationChooserHeaderDataBinder());
        viewDataBinderTypes.add(new LocationItemDataBinder());
        viewDataBinderTypes.add(new LocationChooserFooterDataBinder());

        return viewDataBinderTypes;
    }

    /**
     * LOCATION HEADER ITEM
     */
    public static class LocationChooserHeaderItem implements IViewType {
        @Override
        public int getViewType() {
            return LOCATION_HEADER;
        }
    }

    private static class LocationChooserHeaderDataBinder implements RecyclerViewDataBinder<RecyclerView.ViewHolder,
            LocationChooserHeaderItem> {

        @Override
        public RecyclerView.ViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.location_chooser_header, parent, false);

            return new RecyclerView.ViewHolder(view) {
            };
        }

        @Override
        public void bindDataToViewHolder(RecyclerView.ViewHolder viewHolder, LocationChooserHeaderItem data,
                                         int position, RecyclerItemClickListener recyclerViewClickListener) {

        }

        @Override
        public int getViewType() {
            return LOCATION_HEADER;
        }
    }


    /**
     * LOCATION LIST ITEM
     */
    public static class LocationChooserListItem implements IViewType {
        public String LocationName;
        public int locationId;
        public boolean isSelected;

        @Override
        public int getViewType() {
            return LOCATION_LIST_ITEM;
        }
    }

    private static class LocationItemViewHolder extends RecyclerView.ViewHolder {
        private TextView mLocationTextView;
        private ImageView mSelectImageView;
        private LinearLayout mLocationListItemLayout;

        public LocationItemViewHolder(View itemView) {
            super(itemView);

            mLocationTextView = (TextView) itemView.findViewById(R.id.location_name_tv);
            mSelectImageView = (ImageView) itemView.findViewById(R.id.location_chooser_iv);
            mLocationListItemLayout = (LinearLayout) itemView.findViewById(R.id.location_list_item_linlay);
        }
    }

    private static class LocationItemDataBinder implements RecyclerViewDataBinder<LocationItemViewHolder, LocationChooserListItem> {

        @Override
        public LocationItemViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.location_chooser_list_item, parent, false);

            return new LocationItemViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(LocationItemViewHolder viewHolder, final LocationChooserListItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mLocationTextView.setText(data.LocationName);
            viewHolder.mSelectImageView.setImageResource((data.isSelected) ? R.mipmap.radiobutton : R.mipmap.radiobutton_unselect);
            viewHolder.mLocationListItemLayout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (recyclerViewClickListener != null) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                }
            });

        }

        @Override
        public int getViewType() {
            return LOCATION_LIST_ITEM;
        }
    }

    /**
     * LOCATION FOOTER ITEM
     */
    public static class LocationChooserFooterItem implements IViewType {

        @Override
        public int getViewType() {
            return LOCATION_FOOTER;
        }
    }

    private static class LocationChooserFooterDataBinder implements
            RecyclerViewDataBinder<RecyclerView.ViewHolder, LocationChooserFooterItem> {

        @Override
        public RecyclerView.ViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.location_chooser_footer, parent, false);
            return new RecyclerView.ViewHolder(view) {
            };
        }

        @Override
        public void bindDataToViewHolder(RecyclerView.ViewHolder viewHolder, LocationChooserFooterItem data,
                                         int position, RecyclerItemClickListener recyclerViewClickListener) {

        }

        @Override
        public int getViewType() {
            return LOCATION_FOOTER;
        }
    }

}
