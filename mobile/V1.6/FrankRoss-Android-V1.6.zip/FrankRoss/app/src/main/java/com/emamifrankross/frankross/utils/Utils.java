/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.utils;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.UnderlineSpan;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Patterns;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.emamifrankross.frankross.FrankRossApplication;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.common.RupeeTypefaceSpan;

import org.json.JSONException;
import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class Utils {

    private static final String TAG = Utils.class.getClass().getSimpleName();

    /**
     * Method that checks if the mail id entered by user is in valid format
     *
     * @param email the user's input email address
     * @return true if the mail id is in valid format
     */
    public static boolean isValidEmail(String email) {
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    /**
     * Method that checks if the phone number entered by user is in valid format
     * and matches the character count
     *
     * @param phoneNumber the user's input phone number
     * @return true if the phone number is in valid format and matches the character count
     */
    public static boolean isValidPhoneNumber(String phoneNumber) {
        return Patterns.PHONE.matcher(phoneNumber).matches() && phoneNumber.length() == 10;
    }

    /**
     * Method that gets the device width in pixel
     *
     * @param context the application context
     * @return the device screen width in pixel
     */
    public static int getDisplayWidth(Activity context) {
        DisplayMetrics metrics = new DisplayMetrics();
        context.getWindowManager().getDefaultDisplay().getMetrics(metrics);

        return metrics.widthPixels;
    }

    /**
     * Method that gets the device height in pixel
     *
     * @param context the application context
     * @return the device screen height in pixel
     */
    public static int getDisplayHeight(Activity context) {
        DisplayMetrics metrics = new DisplayMetrics();
        context.getWindowManager().getDefaultDisplay().getMetrics(metrics);

        return metrics.heightPixels;
    }

    /**
     * Method that coverts the dp value to pixel
     *
     * @param context   the application context
     * @param valueInDp the dp value
     * @return the density independent pixel value
     */
    public static int convertDpToPixel(Context context, int valueInDp) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                valueInDp, context.getResources().getDisplayMetrics());
    }

    public static String getDeviceID(Context context) {
        String androidId = Secure.getString(context.getContentResolver(),
                Secure.ANDROID_ID);
        if (TextUtils.isEmpty(androidId)) {

            String deviceID = Secure.getString(context.getContentResolver(),
                    Secure.ANDROID_ID);
            String deviceManufacturer = Build.MANUFACTURER;
            deviceManufacturer = deviceManufacturer.replaceAll("\\s", "");
            String deviceModel = Build.MODEL;

            androidId = deviceManufacturer + "-" + deviceModel + "-" + deviceID;
        }

        if (TextUtils.isEmpty(androidId))
            androidId = "PWPAndroid";

        return androidId;
    }

    public static String getOSVersion() {
        return Build.VERSION.RELEASE;
    }

    /**
     * 4.0
     * <p/>
     * Uses static final constants to detect if the device's platform version is
     * ICS or later.
     */
    public static boolean hasICS() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.ICE_CREAM_SANDWICH;
    }

    /**
     * 4.0
     * <p/>
     * Uses static final constants to detect if the device's platform version is
     * ICS or later.
     */
    public static boolean hasKitKat() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT;
    }

    /**
     * 4.1
     * <p/>
     * Uses static final constants to detect if the device's platform version is
     * JELLYBEAN or later.
     */
    public static boolean hasJELLYBEAN() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN;
    }

    /**
     * 4.2
     * <p/>
     * Uses static final constants to detect if the device's platform version is
     * JELLYBEAN or later.
     */
    public static boolean hasJELLYBEAN_MR1() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1;
    }

    /**
     * 4.2
     * <p/>
     * Uses static final constants to detect if the device's platform version is
     * JELLYBEAN or later.
     */
    public static boolean hasLOLLYPOP() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP;
    }

    public static boolean isAppRunning(Context context) {
        // check with the first task(task in the foreground)
        // in the returned list of tasks
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> runningProcesses = activityManager.getRunningAppProcesses();
        for (ActivityManager.RunningAppProcessInfo processInfo : runningProcesses) {
            if (processInfo.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                for (String activeProcess : processInfo.pkgList) {
                    if (activeProcess.equals(context.getPackageName())) {
                        //If your app is the process in foreground, then it's not in running in background
                        return false;
                    }
                }
            }
        }
        return true;
    }


    public static String getDeviceDetails(Context applicationContext) {
        JSONObject deviceDetailJson = new JSONObject();
        try {
            deviceDetailJson.put("make", Build.MANUFACTURER);
            deviceDetailJson.put("model", Build.MODEL);
            deviceDetailJson.put("device_id", getDeviceID(applicationContext));
            deviceDetailJson.put("imei", getDeviceImei(applicationContext));
            deviceDetailJson.put("android_version",
                    Build.VERSION.RELEASE);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return deviceDetailJson.toString();
    }

    public static String getDeviceImei(Context applicationContext) {
        TelephonyManager telephonyManager = (TelephonyManager) applicationContext
                .getSystemService(Context.TELEPHONY_SERVICE);
        return telephonyManager.getDeviceId();
    }

    public static boolean isAPILevel21AndAbove() {
        return true; //(android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP);
    }

    public static boolean isLoggedIn(Context applicationContext) {
        return !TextUtils.isEmpty(PreferenceUtils
                .getStringFromSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_KEY_ACCESS_TOKEN));
    }

    public static String getAccessToken(Context applicationContext) {
        return PreferenceUtils.getStringFromSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_KEY_ACCESS_TOKEN);
    }

    public static void clearAccessToken(Context applicationContext) {
        PreferenceUtils.saveStringIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_KEY_ACCESS_TOKEN, "");
    }

    public static void saveLocationInfo(Context applicationContext, String locationName, int locationId) {
        PreferenceUtils.saveStringIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_KEY_LOCATION_NAME, locationName);
        PreferenceUtils.saveIntegerIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_KEY_LOCATION_ID, locationId);
    }

    public static String getLocationName(Context applicationContext) {
        return PreferenceUtils.getStringFromSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_KEY_LOCATION_NAME);
    }

    public static int getLocationId(Context applicationContext) {
        return PreferenceUtils.getIntegerFromSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_KEY_LOCATION_ID);
    }

    public static boolean isLocationSaved(Context appContext) {
        return !TextUtils.isEmpty(getLocationName(appContext));
    }

    public static String getAlgoliaCityFilterKey(Context appContext) {
        return "city_" + getLocationId(appContext.getApplicationContext());
    }

    public static void saveUserName(Context applicationContext, String userName) {
        PreferenceUtils.saveStringIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_USER_NAME, userName);
    }

    public static String getUserName(Context applicationContext) {
        return PreferenceUtils.getStringFromSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_USER_NAME);
    }

    public static void saveUserMobileNUmber(Context applicationContext, String userMobileNumber) {
        PreferenceUtils.saveStringIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_USER_MOBILE_NUMBER, userMobileNumber);
    }

    public static String getUseMobileNumber(Context applicationContext) {
        return PreferenceUtils.getStringFromSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_USER_MOBILE_NUMBER);
    }

    public static void saveUserID(Context applicationContext, String userID) {
        PreferenceUtils.saveStringIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_USER_ID, userID);
    }

    public static String getUserID(Context applicationContext) {
        return PreferenceUtils.getStringFromSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_USER_ID);
    }

    public static void clearUserID(Context applicationContext) {
        PreferenceUtils.saveStringIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_USER_ID, "");
    }

    public static void clearIsRegistered(Context applicationContext) {
        PreferenceUtils.saveBooleanIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_IS_REGISTERED, false);
    }

    public static void saveBooleanIsRegistered(Context applicationContext) {
        PreferenceUtils.saveBooleanIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_IS_REGISTERED, true);
    }

    public static boolean getBooleanIsRegistered(Context applicationContext) {
        return PreferenceUtils.getBooleanFromSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_IS_REGISTERED);
    }

    public static void clearIsFailureDialogShown(Context applicationContext) {
        PreferenceUtils.saveBooleanIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_IS_FAILURE_DIALOG_SHOWN, false);
    }

    public static void saveBooleansFailureDialogShown(Context applicationContext) {
        PreferenceUtils.saveBooleanIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_IS_FAILURE_DIALOG_SHOWN, true);
    }

    public static boolean getBooleansFailureDialogShown(Context applicationContext) {
        return PreferenceUtils.getBooleanFromSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_IS_FAILURE_DIALOG_SHOWN);
    }

    public static void clearIsWelcomeDialogShown(Context applicationContext) {
        PreferenceUtils.saveBooleanIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_IS_WELCOME_DIALOG_SHOWN, false);
    }

    public static void saveBooleanIsWelcomeDialogShown(Context applicationContext) {
        PreferenceUtils.saveBooleanIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_IS_WELCOME_DIALOG_SHOWN, true);
    }

    public static boolean getBooleanIsWelcomeDialogShown(Context applicationContext) {
        return PreferenceUtils.getBooleanFromSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_IS_WELCOME_DIALOG_SHOWN);
    }

    public static void saveSpinnerSelectedItemPosition(Context applicationContext, int spinnerSelectedItemPosition) {
        PreferenceUtils.saveIntegerIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_SPINNER_ITEM_POSITION, spinnerSelectedItemPosition);
    }

    public static int getSpinnerSelectedItemPosition(Context applicationContext) {
        return PreferenceUtils.getIntegerFromSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_SPINNER_ITEM_POSITION);
    }

    public static void clearSpinnerSelectedItemPosition(Context applicationContext) {
        PreferenceUtils.saveIntegerIntoSharedPreference(applicationContext, PreferenceUtils.PREFERENCE_SPINNER_ITEM_POSITION, -1);
    }

    /**
     * This method converts dp unit to equivalent pixels, depending on device density.
     *
     * @param dp      A value in dp (density independent pixels) unit. Which we need to convert into pixels
     * @param context Context to get resources and device specific display metrics
     * @return A float value to represent px equivalent to dp depending on device density
     */
    public static float convertDpToPixel(float dp, Context context) {
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        return dp * (metrics.densityDpi / 160f);
    }

    /**
     * This method converts device specific pixels to density independent pixels.
     *
     * @param px      A value in px (pixels) unit. Which we need to convert into db
     * @param context Context to get resources and device specific display metrics
     * @return A float value to represent dp equivalent to px value
     */
    public static float convertPixelsToDp(float px, Context context) {
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        return px / (metrics.densityDpi / 160f);
    }

    /**
     * Method that sets padding to the view dynamically
     *
     * @param view    the view to which the padding has to be applied
     * @param context the application context
     * @param left    the left padding
     * @param top     the top padding
     * @param right   the right padding
     * @param bottom  the bottom padding
     */
    public static void setPaddingInDp(View view, Context context, float left, float top, float right, float bottom) {
        int leftInPx = (int) convertDpToPixel(left, context);
        int topInPx = (int) convertDpToPixel(top, context);
        int rightInPx = (int) convertDpToPixel(right, context);
        int bottomInPx = (int) convertDpToPixel(bottom, context);

        view.setPadding(leftInPx, topInPx, rightInPx, bottomInPx);
    }

    /**
     * Method that calculates the total discount for a product based on the selling price and mrp price
     *
     * @param salesPrice the product selling price
     * @param mrpPrice   the mrp price for the product
     * @return the discount
     */
    public static int getDiscount(double salesPrice, double mrpPrice) {
        return (int) (((salesPrice - mrpPrice) / (salesPrice)) * 100);
    }

    /**
     * Method that capitalizes the words in input sentence or sentences
     *
     * @param sentence the sentence/s
     * @return the capitalized words in the input sentence
     */
    public static String getCapitalizedWords(String sentence) {
        StringBuilder res = new StringBuilder();
        if (TextUtils.isEmpty(sentence)) return "";
        String[] strArr = sentence.split(" ");
        for (String str : strArr) {
            char[] stringArray = str.trim().toCharArray();

            if (stringArray.length > 0) {
                stringArray[0] = Character.toUpperCase(stringArray[0]);
                str = new String(stringArray);
                res.append(str).append(" ");
            }
        }
        return res.toString().trim();
    }

    /**
     * Method that capitalizes the input sentence or sentences
     *
     * @param sentence the sentence/s
     * @return the Capitalized sentences
     */
    public static String getCapitalizedSentence(String sentence) {
        boolean flag = true;
        StringBuilder res = new StringBuilder();
        String[] strArr = sentence.split(" ");
        for (String str : strArr) {
            if (flag) {
                char[] stringArray = str.trim().toCharArray();

                if (stringArray.length > 0) {
                    stringArray[0] = Character.toUpperCase(stringArray[0]);
                    str = new String(stringArray);
                    flag = false;
                }
            }
            res.append(str).append(" ");
        }
        return res.toString().trim();
    }

    /**
     * <pre>
     *
     * To get rupee symbol in between two strings use this function
     *
     * For Ex:
     * String: Your Balance is (rupee symbol) 300
     * Then call this function as
     *
     * SpannableStringBuilder rupeeStringBuilder = getRupeeFormat(mContext, "Your Balance is", "300");
     *
     * </pre>
     *
     * @param context the application context
     * @param first   the string to be appended before the rupee symbol
     * @param rest    the string to be appended after the rupee symbol
     * @return SpannableStringBuilder
     */
    public static SpannableStringBuilder addRupeeSymbol(
            Context context, String first, String rest) {
        if (context == null) {
            return new SpannableStringBuilder(first + "\u20B9" + rest);
        }
        int firstLength = first.length();

        Typeface rupeeFont = Typeface.createFromAsset(context.getAssets(), "font/Rupee.ttf");

        String builderString = first + "` " + rest;
        SpannableStringBuilder rupeeFormat = new SpannableStringBuilder(builderString);

        rupeeFormat.setSpan(new RupeeTypefaceSpan("", rupeeFont, null), firstLength, firstLength + 1,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        return rupeeFormat;
    }

    /**
     * <pre>
     *
     * To get rupee symbol in between two strings use this function
     *
     * For Ex:
     * String: Your Balance is (rupee symbol) 300
     * Then call this function as
     *
     * SpannableStringBuilder rupeeStringBuilder = getRupeeFormat(mContext, "Your Balance is", "300");
     *
     * </pre>
     *
     * @param context the application context
     * @param first   the string to be appended before the rupee symbol
     * @param rest    the string to be appended after the rupee symbol
     * @return SpannableStringBuilder
     */
    public static SpannableStringBuilder addRupeeSymbolWithoutSpace(
            Context context, String first, String rest) {
        if (context == null) {
            return new SpannableStringBuilder(first + "\u20B9" + rest);
        }
        int firstLength = first.length();

        Typeface rupeeFont = Typeface.createFromAsset(context.getAssets(), "font/Rupee.ttf");

        String builderString = first + "`" + rest;
        SpannableStringBuilder rupeeFormat = new SpannableStringBuilder(builderString);

        rupeeFormat.setSpan(new RupeeTypefaceSpan("", rupeeFont, null), firstLength, firstLength + 1,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

        return rupeeFormat;
    }

    /**
     * Method that prefixes the mobile number with +91
     *
     * @param mobileNumber the mobile number that has to be prefixed with +91
     * @return +91 prefixed mobile number
     */
    public static String getFormattedMobileNumber(String mobileNumber) {
        return "+91 " + mobileNumber;
    }

    /**
     * Method that calculates the String value from two point double format
     *
     * @param d the double value that has to be converted to String
     * @return the String value
     */
    public static String getFormattedDouble(double d) {
        DecimalFormat twoDecimals = new DecimalFormat("#0.00");
        return twoDecimals.format(d);
    }

    /**
     * Method that calculates the String value from two point double format
     *
     * @param d the double value that has to be converted to String
     * @return the String value
     */
    public static String getDiscountFormattedDouble(double d) {
        if ((d == Math.floor(d)) && !Double.isInfinite(d)) {
            return (int) d + "";
        } else {
            DecimalFormat twoDecimals = new DecimalFormat("#0.00");
            return twoDecimals.format(d);
        }
    }

    /**
     * Method that calculates the double value from String format
     *
     * @param doubleValueInString the String that has to be converted to double
     * @return the double value
     */
    public static double getDoubleValue(String doubleValueInString) {
        double value = 0.0d;
        if (TextUtils.isEmpty(doubleValueInString)) return value;
        try {
            value = Double.valueOf(doubleValueInString);
        } catch (NumberFormatException exception) {
            exception.printStackTrace();
        }
        return value;
    }

    /**
     * Method that generates the Strip info string to be displayed in the Quantity picker based on the input data
     *
     * @param innerPackageQuantity the inner packaging quantity for the product
     * @param outerPackageQuantity the outer packaging quantity for the product
     * @param unitOfSale           the unit of sale for the product
     * @return the strip info for the productS
     */
    public static String getStripInfo(String innerPackageQuantity, String outerPackageQuantity, String unitOfSale) {
        StringBuilder outerPackagingQtyBuilder = new StringBuilder();

        if (!TextUtils.isEmpty(outerPackageQuantity) /*&& outerPackageQuantity.substring(0, 1).contains("1")*/) {
            if (outerPackageQuantity.substring(0, 1).contains("1")) {
                outerPackagingQtyBuilder.append("Each ").append(outerPackageQuantity.substring(1));
            } else {
                outerPackagingQtyBuilder.append("Each ").append(outerPackageQuantity);
            }
            //outerPackageQuantity = "Each " + outerPackageQuantity;/*outerPackageQuantity.substring(1)*/
            if (!TextUtils.isEmpty(innerPackageQuantity)) {
                return outerPackagingQtyBuilder.toString() +
                        " consists of " + innerPackageQuantity;
            }
        }
        if (!TextUtils.isEmpty(outerPackageQuantity) && TextUtils.isEmpty(innerPackageQuantity)) {
            return unitOfSale;
        }
        return "";
    }

    /**
     * Method that prefixes the input string with Dr. when the input string is not empty
     *
     * @param doctorName the doctor's name that has to be prefixed with Dr.
     * @return empty or doctor name with the prefix Dr.
     */
    public static String getDoctorPrefixedName(String doctorName) {
        if (!TextUtils.isEmpty(doctorName)) {
            return "Dr. " + doctorName;
        }
        return "";
    }

    /**
     * To map the category name of the categories that was clicked
     *
     * @param categoryName the name of the category
     * @return the categories flurry mapped data
     */
    public static Map<String, String> categoriesClickDataForAnalytics(String categoryName, String categoryNameKey) {
        Map<String, String> productClickData = new HashMap<>();
        productClickData.put(categoryNameKey, categoryName);
        return productClickData;
    }

    /**
     * To map the cart icon click in Toolbar from various screens
     *
     * @param screenName    the name of the screen where the cart icon was clicked from toolbar
     * @param screenNameKey the screen name key
     * @return the cart tap from tool bar flurry mapped data
     */
    public static Map<String, String> cartToolbarClickDataForAnalytics(String screenName, String screenNameKey) {
        Map<String, String> productClickData = new HashMap<>();
        productClickData.put(screenNameKey, screenName);
        return productClickData;
    }

    /**
     * To map the faq topic id on visiting FAQ screen
     *
     * @param faqTopicId the name of the screen where the cart icon was clicked from toolbar
     * @return the faq flurry mapped data
     */
    public static Map<String, String> faqVisitDataForAnalytics(String faqTopicId) {
        Map<String, String> faqVisitData = new HashMap<>();
        faqVisitData.put(FrankRossEvents.FAQ_TOPIC_ID, faqTopicId);
        return faqVisitData;
    }

    /**
     * To map the checkout data on clicking Confirm Order button
     *
     * @param walletState   true/false
     * @param paymentMethod the selected payment method
     * @return the confirm order flurry mapped data
     */
    public static Map<String, String> confirmOrderClickDataForAnalytics(boolean walletState, String paymentMethod) {
        Map<String, String> confirmOrderClickData = new HashMap<>();
        confirmOrderClickData.put(FrankRossEvents.WALLET_STATE, walletState ? "true" : "false");
        confirmOrderClickData.put(FrankRossEvents.PAYMENT_METHOD_SELECTED, paymentMethod);
        return confirmOrderClickData;
    }

    /**
     * To map the notify me data for analytics
     *
     * @param loggedInUser the boolean that decides if the user is registered or unregistered
     * @return the notify me mapped data for analytics
     */
    public static Map<String, String> notifyMeClickDataForAnalytics(boolean loggedInUser) {
        Map<String, String> confirmOrderClickData = new HashMap<>();
        confirmOrderClickData.put(FrankRossEvents.NOTIFY_ME_USER_CONFIRMATION, loggedInUser ? "Registered" : "Unregistered");
        return confirmOrderClickData;
    }

    /**
     * To map the share channel selected by user for analytics
     *
     * @param shareChannel the user selected share channel
     * @return the social share mapped data for analytics
     */
    public static Map<String, String> shareDataForAnalytics(String shareChannel) {
        Map<String, String> confirmOrderClickData = new HashMap<>();
        confirmOrderClickData.put(FrankRossEvents.SHARING_MEDIUM, shareChannel);
        return confirmOrderClickData;
    }

    /**
     * Method to copy the text to clipboard
     *
     * @param copyToClipboardText the text to be copied to clipboard
     * @param context             the application context
     */
    public static void copyToClipboard(String copyToClipboardText, Context context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.HONEYCOMB) {
            android.text.ClipboardManager clipboard = (android.text.ClipboardManager)
                    context.getSystemService(Context.CLIPBOARD_SERVICE);
            clipboard.setText(copyToClipboardText);
        } else {
            android.content.ClipboardManager clipboard = (android.content.ClipboardManager)
                    context.getSystemService(Context.CLIPBOARD_SERVICE);
            android.content.ClipData clip = android.content.ClipData.newPlainText("Copied Text", copyToClipboardText);
            clipboard.setPrimaryClip(clip);
        }
    }

    /**
     * Method that converts the input display pixels to the scaled pixels based on the device density
     *
     * @param context       the application context
     * @param displayPixels the input display pixels
     * @return scaled pixels based on the device density
     */
    public static int getDisplayPixels(Context context, int displayPixels) {
        final float scale = context.getResources().getDisplayMetrics().density;
        return (int) (displayPixels * scale + 0.5f);
    }

    /**
     * Method that generates underlined text
     *
     * @param textToBeUnderlined the text that has to be underlined
     * @return underlined text
     */
    public static SpannableString getUnderlinedText(String textToBeUnderlined) {
        SpannableString content = new SpannableString(textToBeUnderlined);
        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);
        return content;
    }

    /**
     * Method that generates random number for stacking the push notification
     *
     * @return the random number
     */
    public static int getRandomNumForPushNotificationStacking() {
        Random random = new Random();
        return random.nextInt(9999 - 1000) + 1000;
    }

    /**
     * Method that displays the Standard toast for long duration
     *
     * @param context the application context
     * @param message the message that has to be displayed in the Toast
     */
    public static void show_toast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }

    /**
     * Method that extracts the OTP from message which is prefixed with the prefix text
     *
     * @param message the OTP message
     * @param prefix  the prefix of the message to which look for
     * @return the otp code
     */
    public static String getOtpFromMessage(String message, String prefix) {
        Log.d(TAG, "Message = " + message + " prefix = " + prefix);
        int startIndex = message.lastIndexOf(prefix);
        String link = message.substring(startIndex, message.length());
        String otp = link.replaceAll("\\D+", "");
        Log.d(TAG, "OTP =" + otp);
        return otp;
    }

    /**
     * Extracts only the numerical value from the message string.
     * N.B. Uses regex to do the operation. Better performance can be possible.
     *
     * @param message the OTP message
     * @return get only numeric digits from OTP message
     */
    private String getOtpFromMessage(String message) {
        return message.replaceAll("\\D+", "");
    }

    /**
     * Method that enables all the views in a view group
     *
     * @param view the view or view group
     */
    public static void enableViews(View view) {
        if (view != null) {
            view.setEnabled(true);
            if (view instanceof ViewGroup) {
                ViewGroup group = (ViewGroup) view;

                for (int idx = 0; idx < group.getChildCount(); idx++) {
                    enableViews(group.getChildAt(idx));
                }
            }
        }
    }

    /**
     * Method that disables all the views in a view group
     *
     * @param view the view or view group
     */
    public static void disableViews(View view) {
        if (view != null) {
            view.setEnabled(false);
            if (view instanceof ViewGroup) {
                ViewGroup group = (ViewGroup) view;

                for (int idx = 0; idx < group.getChildCount(); idx++) {
                    disableViews(group.getChildAt(idx));
                }
            }
        }
    }

    /**
     * Method that logs/prints the Key hash for the app's current mode-release/debug
     *
     * @param context the application context
     */
    public static String printKeyHash(FrankRossApplication context) {
        PackageInfo packageInfo;
        String key = null;
        try {
            String packageName = context.getApplicationContext().getPackageName();
            packageInfo = context.getPackageManager().getPackageInfo(packageName,
                    PackageManager.GET_SIGNATURES);
            Log.d("Package Name=", context.getApplicationContext().getPackageName());

            for (Signature signature : packageInfo.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                key = new String(Base64.encode(md.digest(), 0));
                // String key = new String(Base64.encodeBytes(md.digest()));
                Log.d("Key Hash= ", key);
            }
        } catch (PackageManager.NameNotFoundException e1) {
            Log.d("Name not found", e1.toString());
        } catch (NoSuchAlgorithmException e) {
            Log.d("No such an algorithm", e.toString());
        } catch (Exception e) {
            Log.d("Exception", e.toString());
        }

        return key;
    }

    /**
     * Method that returns the installed app version
     *
     * @param context the application context
     * @return installed app version
     */
    public static String getInstalledAppVersion(Activity context) {
        PackageManager manager = context.getPackageManager();
        PackageInfo info = null;
        try {
            info = manager.getPackageInfo(
                    context.getPackageName(), 0);
        } catch (PackageManager.NameNotFoundException e) {
            Log.d("Name not found", e.toString());
        }
        String appVersion = (info == null) ? "" : info.versionName;
        Log.d(TAG, "App version = " + appVersion);
        return appVersion;
    }
}
