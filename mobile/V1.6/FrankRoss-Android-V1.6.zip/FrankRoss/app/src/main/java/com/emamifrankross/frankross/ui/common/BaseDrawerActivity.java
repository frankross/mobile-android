/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.common;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.View;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.network.ApiRequestManager;
import com.emamifrankross.frankross.core.network.IApiRequestCancel;
import com.emamifrankross.frankross.core.network.UrlConstants;
import com.emamifrankross.frankross.sdkmanager.FrankRossAnalytics;
import com.emamifrankross.frankross.sdkmanager.FrankRossEvents;
import com.emamifrankross.frankross.ui.wallet.FrankRossWalletFragment;
import com.emamifrankross.frankross.ui.referral.ReferFriendActivity;
import com.emamifrankross.frankross.ui.account.AccountFragment;
import com.emamifrankross.frankross.ui.account.login.LogInActivity;
import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.NavigationDrawerAdapter;
import com.emamifrankross.frankross.ui.faq.FAQActivity;
import com.emamifrankross.frankross.ui.home.HomeFragment;
import com.emamifrankross.frankross.ui.home.LocationChooserFragment;
import com.emamifrankross.frankross.ui.offers.OffersFragment;
import com.emamifrankross.frankross.ui.order.OrderHistoryActivity;
import com.emamifrankross.frankross.ui.pharmacy.PharmacyFragment;
import com.emamifrankross.frankross.ui.store.StoreLocatorFragment;
import com.emamifrankross.frankross.ui.support.SupportActivity;
import com.emamifrankross.frankross.ui.viewmodels.RecyclerBorderItem;
import com.emamifrankross.frankross.ui.viewmodels.UserInformation;
import com.emamifrankross.frankross.utils.Log;
import com.emamifrankross.frankross.utils.Utils;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by gowtham on 30/6/15.
 */
public abstract class BaseDrawerActivity extends BaseActivity
        implements NavigationDrawerAdapter.RecyclerItemClickListener,
        LocationChooserFragment.ILocationUpdateListener, IDrawerSlideController,
        AccountFragment.IUserUpdateNotifier, IApiRequestCancel, IErrorHandler {

    private static final int HEADER_INDEX = 0;
    private static final int ACCOUNT_INDEX = 20;
    private static final int LOCATION_INDEX = 21;
    private static final int HOME_INDEX = 1;
    private static final int PHARMACY_INDEX = 2;
    private static final int MY_ORDER_INDEX = 3;
    private static final int MY_PRESCRIPTION_INDEX = 4;
    private static final int REFER_EARN_INDEX = 5;
    private static final int OFFERS_INDEX = 6;
    private static final int HEALTH_ARTICLES_INDEX = 7;
    private static final int REFER_A_FRIEND_INDEX = 8;
    private static final int EMERGENCY_INDEX = 9;// /border added
    private static final int SUPPORT_INDEX = 11;
    private static final int STORE_LOCATOR_INDEX = 12;
    private static final int PRIVACY_POLICY_INDEX = 13;
    private static final int FAQ_INDEX = 14;

    private static final int REQUEST_CODE_HOME_ACCOUNT = 1121;
    private static final int REQUEST_CODE_STORE_LOCATOR = 1122;
    private static final int REQUEST_CODE_REFER_EARN_ACCOUNT = 1123;
    private static final int REQUEST_CODE_INVITE_FRIENDS = 1124;

    private RecyclerView mDrawerView;
    private ArrayList<BaseRecyclerAdapter.IViewType> mDrawerItemList;
    private NavigationDrawerAdapter mNavigationDrawerAdapter;
    private String TAG = BaseDrawerActivity.class.getName();
    private int mTappedPosition = -1;
    private ApiRequestManager mApiRequestManager;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mApiRequestManager = ApiRequestManager.getInstance(getApplicationContext());
        initViews();
        mDrawerItemList = new ArrayList<>();
        loadDrawerData();
    }

    @Override
    protected void setToolbarListeners(View.OnClickListener navigationClickListener, Toolbar.OnMenuItemClickListener toolbarMenuItemClickListener) {
        //Set the listeners before the super method call.
        //Ignore the navigation item click listener and set new onclick listener to  open the drawer
        mToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mDrawerLayout.openDrawer(mDrawerView);
            }
        });

        super.setToolbarListeners(navigationClickListener, toolbarMenuItemClickListener);
    }

    @Override
    public void updateLocation(boolean isRefresh) {
        if (mDrawerItemList != null && mDrawerItemList.size() > 0) {
            if (isRefresh)
                mApiRequestManager.clearResponseCacheOnLocationUpdate();
            NavigationDrawerAdapter.DrawerHeaderItem headerItem = (NavigationDrawerAdapter.DrawerHeaderItem) mDrawerItemList.get(HEADER_INDEX);
            headerItem.headerName = Utils.getLocationName(getApplicationContext());
            Log.d("Gauthami", "get from shared pref" + Utils.getLocationName(getApplicationContext()));

            if (Utils.isLoggedIn(this.getApplicationContext())) {
                if (TextUtils.isEmpty(Utils.getUserName(this))) {
                    getUserInfoDetails(headerItem);
                } else {
                    headerItem.userName = Utils.getUserName(this);
                }
            } else {
                headerItem.userName = getString(R.string.log_in_btn_text);
            }

            mNavigationDrawerAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void lockDrawer() {
        if (mDrawerLayout != null)
            mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_LOCKED_CLOSED);
    }

    @Override
    public void unlockDrawer() {
        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
    }

    private void initViews() {
        mDrawerLayout = (DrawerLayout) findViewById(R.id.base_drawer_layout);
        mDrawerLayout.setDrawerLockMode(DrawerLayout.LOCK_MODE_UNLOCKED);
        mDrawerLayout.setDrawerShadow(R.mipmap.drawer_shadow, GravityCompat.START);
        mDrawerLayout.addDrawerListener(mDrawerListener);

        mDrawerView = (RecyclerView) findViewById(R.id.drawer_recycler);
    }

    private void loadDrawerData() {
        new AsyncTask<Void, Void, ArrayList<BaseRecyclerAdapter.IViewType>>() {

            @Override
            protected ArrayList<BaseRecyclerAdapter.IViewType> doInBackground(Void... params) {
                ArrayList<BaseRecyclerAdapter.IViewType> drawerItems = new ArrayList<BaseRecyclerAdapter.IViewType>();
                addHeaderItem(drawerItems);
                addCategories(drawerItems);
                //  addSubCategories(drawerItems);
                addSecondaryCategories(drawerItems);

                return drawerItems;
            }

            @Override
            protected void onPostExecute(ArrayList<BaseRecyclerAdapter.IViewType> iViewTypes) {
                super.onPostExecute(iViewTypes);
                mDrawerItemList.addAll(iViewTypes);
                mNavigationDrawerAdapter = new NavigationDrawerAdapter(mDrawerItemList);
                mNavigationDrawerAdapter.setRecyclerItemClickListener(BaseDrawerActivity.this);
                mDrawerView.setAdapter(mNavigationDrawerAdapter);
            }
        }.execute();
    }

    private void addSecondaryCategories(ArrayList<BaseRecyclerAdapter.IViewType> drawerItemList) {
        String[] secondaryCategories = getResources().getStringArray(R.array.drawer_sub_categories);
        String[] mappingsCategory = getResources().getStringArray(R.array.drawer_mappings_sub_categories);
        HashMap<String, String> stringStringHashMap = new HashMap<>();
        if (mApiRequestManager.getNewFeaturesResponse() != null) {
            stringStringHashMap = mApiRequestManager.getNewFeaturesResponse().getFeatures().singleKeyValueToJson();
        }

        int index = 0;
        for (String secondaryCategoryName : secondaryCategories) {
            NavigationDrawerAdapter.DrawerSecondaryCategoryItem subCategoryItem = new NavigationDrawerAdapter.DrawerSecondaryCategoryItem();
            subCategoryItem.secondaryCategoryName = secondaryCategoryName;

            if (!stringStringHashMap.isEmpty() &&
                    stringStringHashMap.containsKey(mappingsCategory[index]) &&
                    !TextUtils.isEmpty(stringStringHashMap.get(mappingsCategory[index]))) {
                subCategoryItem.categoryIsNew = true;
                subCategoryItem.categoryTagName = stringStringHashMap.get(mappingsCategory[index]);
            } else {
                subCategoryItem.categoryIsNew = false;
            }
            drawerItemList.add(subCategoryItem);
            index++;
        }
    }
/*
    private void addSubCategories(ArrayList<BaseRecyclerAdapter.IViewType> drawerItemList) {
        String[] subCategories = getResources().getStringArray(R.array.drawer_sub_categories);
        int[] drawableIds = {R.mipmap.drawer_pres_medicines, R.mipmap.drawer_otc,
                R.mipmap.drawer_medicalaids, R.mipmap.drawer_more};

        int[] selectedDrawableIds = {R.mipmap.drawer_pres_medicines_selected, R.mipmap.drawer_otc_selected,
                R.mipmap.drawer_medicalaids_selected,
                R.mipmap.drawer_more_selected};


        int index = PRESCRIPTION_MEDICINES_INDEX; //starting index for Subcategories
        int drawableIndex = 0;
        for (String subCategoryName : subCategories) {
            NavigationDrawerAdapter.DrawerSubCategoryItem subCategoryItem = new NavigationDrawerAdapter.DrawerSubCategoryItem();
            subCategoryItem.categoryDrawableId = drawableIds[drawableIndex];
            subCategoryItem.categorySelectedDrawableId = selectedDrawableIds[drawableIndex];
            subCategoryItem.categoryName = subCategoryName;
            drawerItemList.add(index, subCategoryItem);
            index++;
            drawableIndex++;
        }
        drawerItemList.add(index, new RecyclerBorderItem((int) Utils.convertDpToPixel(1, getApplicationContext())));
    }*/

    private void addCategories(ArrayList<BaseRecyclerAdapter.IViewType> drawerItemList) {
        String[] categories = getResources().getStringArray(R.array.drawer_categories);
        int[] drawableIds = {R.mipmap.drawer_home, R.mipmap.pharmacy,
                R.mipmap.drawer_myorder, R.mipmap.drawer_prescriptions, R.mipmap.wallet_selected,
                R.mipmap.offers, R.mipmap.health_articles, R.mipmap.refer_friend, R.mipmap.drawer_emergency};

        int[] selectedDrawableIds = {R.mipmap.drawer_home_selected, R.mipmap.pharmacy_selected,
                R.mipmap.drawer_myorder_selected, R.mipmap.drawer_prescriptions_selected, R.mipmap.wallet,
                R.mipmap.offers_selected,
                R.mipmap.health_articles_selected, R.mipmap.refer_friend_select, R.mipmap.drawer_emergency_selected};

        HashMap<String, String> stringStringHashMap = new HashMap<>();
        if (mApiRequestManager.getNewFeaturesResponse() != null) {
            stringStringHashMap = mApiRequestManager.getNewFeaturesResponse().getFeatures().singleKeyValueToJson();
        }

        int index = 0;
        for (String categoryName : categories) {
            String[] mappingsCategory = getResources().getStringArray(R.array.drawer_mappings_category);
            NavigationDrawerAdapter.DrawerCategoryItem categoryItem = new NavigationDrawerAdapter.DrawerCategoryItem();
            categoryItem.categoryName = categoryName;
            categoryItem.categoryDrawableId = drawableIds[index];
            categoryItem.categorySelectedDrawableId = selectedDrawableIds[index];

            if (!stringStringHashMap.isEmpty() &&
                    stringStringHashMap.containsKey(mappingsCategory[index]) &&
                    !TextUtils.isEmpty(stringStringHashMap.get(mappingsCategory[index]))) {
                categoryItem.categoryIsNew = true;
                categoryItem.categoryTagName = stringStringHashMap.get(mappingsCategory[index]);
            } else {
                categoryItem.categoryIsNew = false;
            }
            drawerItemList.add(categoryItem);
            index++;
            // drawerItemList.add(new RecyclerBorderItem((int) Utils.convertDpToPixel(1, getApplicationContext())));
           /* if (index == 0) {
                drawerItemList.add(new RecyclerBorderItem((int) Utils.convertDpToPixel(1, getApplicationContext())));
            } else if (index == 1) {
                RecyclerBorderItem borderItem = new RecyclerBorderItem((int) Utils.convertDpToPixel(1, getApplicationContext()));
                borderItem.leftMarginInPx = (int) Utils.convertDpToPixel(16, getApplicationContext());
                drawerItemList.add(borderItem);
            }*/
        }

        drawerItemList.add(new RecyclerBorderItem((int) Utils.convertDpToPixel(1, getApplicationContext())));
    }

    private void addHeaderItem(ArrayList<BaseRecyclerAdapter.IViewType> drawerItemList) {
        NavigationDrawerAdapter.DrawerHeaderItem drawerHeaderItem = new NavigationDrawerAdapter.DrawerHeaderItem();
        drawerHeaderItem.headerName = Utils.getLocationName(getApplicationContext());

        if (Utils.isLoggedIn(this.getApplicationContext())) {
            if (TextUtils.isEmpty(Utils.getUserName(this))) {
                getUserInfoDetails(drawerHeaderItem);
            } else {
                drawerHeaderItem.userName = Utils.getUserName(this);
            }
        } else {
            drawerHeaderItem.userName = getString(R.string.log_in_btn_text);
        }

        drawerItemList.add(drawerHeaderItem);
    }

    private void getUserInfoDetails(final NavigationDrawerAdapter.DrawerHeaderItem drawerHeaderItem) {
        mApiRequestManager.performUserInfoRequest(new ApiRequestManager.IGetUserInfoResultNotifier() {
            @Override
            public void onUserInfoFetched(UserInformation userInfo) {
                if (userInfo != null) {
                    drawerHeaderItem.userName = userInfo.userName;
                    Utils.saveUserName(BaseDrawerActivity.this, userInfo.userName);
                    Utils.saveUserMobileNUmber(BaseDrawerActivity.this, userInfo.userMobileNumber);
                    mNavigationDrawerAdapter.notifyItemChanged(0);
                }
            }
        }, this, this);
    }

    private DrawerLayout.DrawerListener mDrawerListener = new DrawerLayout.DrawerListener() {

        @Override
        public void onDrawerStateChanged(int arg0) {
        }

        @Override
        public void onDrawerSlide(View arg0, float arg1) {
        }

        @Override
        public void onDrawerOpened(View arg0) {
            if (mDrawerItemList != null && mDrawerItemList.size() > 0) {
                NavigationDrawerAdapter.DrawerHeaderItem headerItem = (NavigationDrawerAdapter.DrawerHeaderItem) mDrawerItemList.get(0);

                if (Utils.isLoggedIn(BaseDrawerActivity.this.getApplicationContext())) {
                    if (TextUtils.isEmpty(Utils.getUserName(BaseDrawerActivity.this.getApplicationContext()))) {
                        getUserInfoDetails(headerItem);
                    } else {
                        headerItem.userName = Utils.getUserName(BaseDrawerActivity.this.getApplicationContext());
                    }
                } else {
                    headerItem.userName = getString(R.string.log_in_btn_text);
                }

                hide_keyboard();
            }
        }

        @Override
        public void onDrawerClosed(View arg0) {
            handleClick();
        }
    };

    protected void handleClick() {
        hideBlockingProgressBar();

        switch (mTappedPosition) {
            case HEADER_INDEX:
                launchLocationChooserFragment();
                break;

            case HOME_INDEX:
                loadHomeFragment();
                break;

            case PHARMACY_INDEX:
                loadPharmacyFragment();
                break;

            case MY_ORDER_INDEX:
                loadMyOrdersScreen();
                break;

            case MY_PRESCRIPTION_INDEX:
                loadMyPrescriptionScreen();
                break;

            case REFER_EARN_INDEX:
                loadFrankRossWalletScreen();
                break;

            case EMERGENCY_INDEX:
                loadEmergencyInWebViewFragment();
                break;

            case SUPPORT_INDEX:
                loadSupportFragment();
                break;

            case STORE_LOCATOR_INDEX:
                loadStoreLocatorFragment();
                break;

            case PRIVACY_POLICY_INDEX:
                loadPrivacyPolicyIndex();
                break;

            case ACCOUNT_INDEX:
                loadAccountFragment();
                break;

            case LOCATION_INDEX:
                launchLocationChooserFragment();
                break;

            case OFFERS_INDEX:
                loadOffersFragment();
                break;

            case HEALTH_ARTICLES_INDEX:
                loadHealthArticlesInWebViewFragment();
                break;

            case REFER_A_FRIEND_INDEX:
                loadReferFriendActivity();
                break;

            case FAQ_INDEX:
                loadFaqFragment();
        }
        mTappedPosition = -1;
    }

    @Override
    public void onStart() {
        super.onStart();
        FrankRossAnalytics.getFrankRossTracker().startSession(this);
    }

    @Override
    public void onStop() {
        super.onStop();
        FrankRossAnalytics.getFrankRossTracker().endSession(this);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mNavigationDrawerAdapter != null) {
            mNavigationDrawerAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onRecyclerItemClick(int position, View view, Object object) {
        if (view.getId() == R.id.drawer_header_user_name_linLyt) {
            mTappedPosition = ACCOUNT_INDEX;
        } else if (view.getId() == R.id.drawer_location_linLay) {
            mTappedPosition = LOCATION_INDEX;
        } else {
            mTappedPosition = position;
        }

        mDrawerLayout.closeDrawer(mDrawerView);
    }

    private void loadPrivacyPolicyIndex() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.PRIVACY_POLICY_DRAWER_TAP_EVENT);
        loadFragment(getFragmentContainerId(), WebViewFragment.create(UrlConstants.getPrivacyUrl(), getString(R.string.drawer_menu_privacy_policy)),
                null, R.anim.push_left_in, R.anim.fade_out,
                BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    private void loadStoreLocatorFragment() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.STORE_LOCATOR_DRAWER_TAP_EVENT);
        loadFragment(getFragmentContainerId(), StoreLocatorFragment.create(), null, R.anim.push_left_in, R.anim.fade_out,
                BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    private void loadFaqFragment() {
        startActivity(FAQActivity.getActivityIntent(getApplicationContext(), FAQActivity.FAQ_TOP_QUERY_FRAGMENT));
        overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    private void loadAccountFragment() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.MY_ACCOUNT_EVENT);
        if (Utils.isLoggedIn(getApplicationContext())) {
            loadFragment(getFragmentContainerId(), AccountFragment.create(), null, R.anim.push_left_in, R.anim.fade_out,
                    BaseFragment.FragmentTransactionType.CLEAR_BACK_STACK_AND_REPLACE);
        } else {
            startActivityForResult(LogInActivity.getActivityIntent(getApplicationContext(), false,
                    LogInActivity.LOG_IN_FRAGMENT), REQUEST_CODE_HOME_ACCOUNT);
            overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    private void loadMyOrdersScreen() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.MY_ORDER_DRAWER_TAP_EVENT);
        startActivity(OrderHistoryActivity.getActivityIntent(getApplicationContext(), OrderHistoryActivity.ORDER_HISTORY_FRAGMENT_ID));
        overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    private void loadMyPrescriptionScreen() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.MY_PRESCRIPTIONS_TAP_EVENT);
        startActivity(OrderHistoryActivity.getActivityIntent(getApplicationContext(), OrderHistoryActivity.PRESCRIPTION_FRAGMENT_ID));
        overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
    }

    private void loadFrankRossWalletScreen() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.FRANK_ROSS_WALLET_DRAWER_TAP_EVENT);
        if (Utils.isLoggedIn(getApplicationContext())) {
            loadFragment(getFragmentContainerId(), FrankRossWalletFragment.create(), null, R.anim.push_left_in, R.anim.fade_out,
                    BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
        } else {
            startActivityForResult(LogInActivity.getActivityIntent(getApplicationContext(), false,
                    LogInActivity.LOG_IN_FRAGMENT), REQUEST_CODE_REFER_EARN_ACCOUNT);
            overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    private void loadReferFriendActivity() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.REFER_FRIEND_DRAWER_TAP_EVENT);
        if (Utils.isLoggedIn(getApplicationContext())) {
            startActivity(ReferFriendActivity.getActivityIntent(getApplicationContext(), ReferFriendActivity.INVITE_FRIENDS_FRAGMENT));
            overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        } else {
            startActivityForResult(LogInActivity.getActivityIntent(getApplicationContext(), false,
                    LogInActivity.LOG_IN_FRAGMENT), REQUEST_CODE_INVITE_FRIENDS);
            overridePendingTransition(R.anim.push_left_in, R.anim.fade_out);
        }
    }

    private void loadSupportFragment() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.SUPPORT_DRAWER_TAP_EVENT);
        startActivity(SupportActivity.getActivityIntent(getApplicationContext()));
    }

    private void loadOffersFragment() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.OFFERS_DRAWER_TAP_EVENT);
        loadFragment(getFragmentContainerId(), OffersFragment.create(),
                null, R.anim.push_left_in, R.anim.fade_out,
                BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    private void loadEmergencyInWebViewFragment() {
        //FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.HEALTH_ARTICLES_DRAWER_TAP_EVENT);
        loadFragment(getFragmentContainerId(),
                WebViewFragment.create(UrlConstants.getEmergencyUrl(),
                        getString(R.string.drawer_menu_emergency)),
                null, R.anim.push_left_in, R.anim.fade_out,
                BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    private void loadHealthArticlesInWebViewFragment() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.HEALTH_ARTICLES_DRAWER_TAP_EVENT);
        loadFragment(getFragmentContainerId(),
                WebViewFragment.create(UrlConstants.getHealthArticlesUrl(),
                        getString(R.string.drawer_menu_health_articles)),
                null, R.anim.push_left_in, R.anim.fade_out,
                BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    private void loadPharmacyFragment() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.CATEGORIES_DRAWER_TAP_EVENT);
        loadFragment(getFragmentContainerId(), PharmacyFragment.create(), null, R.anim.push_left_in, R.anim.fade_out,
                BaseFragment.FragmentTransactionType.CLEAR_BACK_STACK_AND_REPLACE);
    }

    protected void loadHomeFragment() {
        FrankRossAnalytics.getFrankRossTracker().logEvent(FrankRossEvents.HOME_DRAWER_TAP_EVENT);
        loadFragment(getFragmentContainerId(), HomeFragment.create(), null, R.anim.push_left_in, R.anim.fade_out,
                BaseFragment.FragmentTransactionType.CLEAR_BACK_STACK_AND_REPLACE);
    }

    private void launchLocationChooserFragment() {
        loadFragment(getFragmentContainerId(), LocationChooserFragment.create(getApplicationContext(), null), null, R.anim.push_left_in, R.anim.fade_out,
                BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
    }

    @Override
    public void onUserInfoUpdated(String userName) {
        NavigationDrawerAdapter.DrawerHeaderItem headerItem = (NavigationDrawerAdapter.DrawerHeaderItem) mDrawerItemList.get(HEADER_INDEX);
        headerItem.headerName = Utils.getLocationName(getApplicationContext());
        headerItem.userName = TextUtils.isEmpty(userName) ? getString(R.string.log_in_btn_text) : userName;
        mNavigationDrawerAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_CODE_HOME_ACCOUNT) {
                loadFragment(getFragmentContainerId(), AccountFragment.create(), TAG, R.anim.push_left_in,
                        R.anim.push_left_out, BaseFragment.FragmentTransactionType.CLEAR_BACK_STACK_AND_REPLACE);
            } else if (requestCode == REQUEST_CODE_STORE_LOCATOR) {
                loadFragment(getFragmentContainerId(), StoreLocatorFragment.create(), null, R.anim.push_left_in, R.anim.fade_out,
                        BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
            } else if (requestCode == REQUEST_CODE_REFER_EARN_ACCOUNT) {
                loadFragment(getFragmentContainerId(), FrankRossWalletFragment.create(), null, R.anim.push_left_in, R.anim.fade_out,
                        BaseFragment.FragmentTransactionType.ADD_TO_BACK_STACK_AND_REPLACE);
            } else if (requestCode == REQUEST_CODE_INVITE_FRIENDS) {
                loadReferFriendActivity();
            }
        }
    }

    @Override
    public String getRequestTag() {
        return null;
    }

    @Override
    public <T> void handleError(AlertError<T> alertError, int statusCode) {

    }

    @Override
    public void handleCommonError(int errorResourceId) {

    }
}
