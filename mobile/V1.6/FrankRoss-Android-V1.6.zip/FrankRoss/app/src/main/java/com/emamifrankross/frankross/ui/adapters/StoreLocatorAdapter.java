/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 23/7/15.
 * <p> Adapter class for Store locator Section</p>
 * <p>Supports the One View Types </p>
 * <p> 1 : STORE ADDRESS VIEW TYPE </p>
 */
public class StoreLocatorAdapter extends BaseRecyclerAdapter {

    public StoreLocatorAdapter(@NonNull List<IViewType> dataList) {
        super(dataList);
    }

    @NonNull
    @Override
    protected List<RecyclerViewDataBinder> getViewDataBinders() {
        ArrayList<RecyclerViewDataBinder> viewHolderTypes = new ArrayList<>(1);
        viewHolderTypes.add(new StoreAddressViewHolderType());

        return viewHolderTypes;
    }

    /**
     * STORE ADDRESS VIEW TYPE
     */
    public static class StoreAddressDataItem implements IViewType {

        public String storeAddressTitle = "";
        public String storeFullAddress = "";
        public String storeTimings = "";
        public String storeDistance = "";
        public double latitude = 0.0d;
        public double longitude = 0.0d;
        public List<String> phoneNumbers = new ArrayList<>(1);

        @Override
        public int getViewType() {
            return ViewTypes.StoreLocatorViewType.STORE_LOCATOR_ITEM_VIEW_TYPE;
        }
    }

    public static class StoreAddressViewHolder extends RecyclerView.ViewHolder {

        private RobotoTextView mStoreAddressTitle;
        private RobotoTextView mStoreFullAddress;
        private RobotoTextView mStoreTimings;
        private RobotoTextView mStoreGetDirections;
        private RobotoTextView mStoreCallUs;

        public StoreAddressViewHolder(View view) {
            super(view);
            mStoreAddressTitle = (RobotoTextView) view.findViewById(R.id.store_address_title_tv);
            mStoreFullAddress = (RobotoTextView) view.findViewById(R.id.store_full_address_tv);
            mStoreTimings = (RobotoTextView) view.findViewById(R.id.store_timing_constraint_tv);
            mStoreGetDirections = (RobotoTextView) view.findViewById(R.id.store_get_directions_tv);
            mStoreCallUs = (RobotoTextView) view.findViewById(R.id.store_call_us_tv);
        }
    }

    private class StoreAddressViewHolderType implements RecyclerViewDataBinder<StoreAddressViewHolder,
            StoreAddressDataItem> {
        @Override
        public StoreAddressViewHolder getViewHolder(ViewGroup parent) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.store_address_list_item, parent, false);
            return new StoreAddressViewHolder(view);
        }

        @Override
        public void bindDataToViewHolder(StoreAddressViewHolder viewHolder, final StoreAddressDataItem data,
                                         final int position, final RecyclerItemClickListener recyclerViewClickListener) {
            viewHolder.mStoreAddressTitle.setText(data.storeAddressTitle);
            viewHolder.mStoreTimings.setText(data.storeTimings);
            viewHolder.mStoreFullAddress.setText(data.storeFullAddress);

            if (recyclerViewClickListener != null) {
                viewHolder.mStoreGetDirections.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
                viewHolder.mStoreCallUs.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        recyclerViewClickListener.onRecyclerItemClick(position, v, data);
                    }
                });
            }
        }

        @Override
        public int getViewType() {
            return ViewTypes.StoreLocatorViewType.STORE_LOCATOR_ITEM_VIEW_TYPE;
        }
    }
}