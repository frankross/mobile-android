/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.emamifrankross.frankross.ui.adapters.BaseRecyclerAdapter;
import com.emamifrankross.frankross.ui.adapters.LocationChooserAdapter;
import com.emamifrankross.frankross.ui.common.ViewTypes;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by gowtham on 16/7/15.
 */
public class ApiLocation {

    public static class Response {

        @SerializedName("cities")
        private List<Cities> cities;

        private List<LocationChooserAdapter.LocationChooserListItem> uiData;

        public List<Cities> getCities() {
            return cities;
        }

        public List<LocationChooserAdapter.LocationChooserListItem> getUiData() {
            return uiData;
        }

        public void setUiData(List<LocationChooserAdapter.LocationChooserListItem> uiData) {
            this.uiData = uiData;
        }
    }

    public static class Cities implements BaseRecyclerAdapter.IViewType, ViewTypes.CommonViewType {

        @SerializedName("id")
        private int id;

        @SerializedName("name")
        private String name;

        @SerializedName("state")
        private String state;

        @SerializedName("areas")
        private List<Area> areas;

        @SerializedName("warehouse_code")
        private String warehouse_code;

        @SerializedName("country")
        private String country;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getState() {
            return state;
        }

        public void setState(String state) {
            this.state = state;
        }

        public List<Area> getAreas() {
            return areas;
        }

        public void setAreas(List<Area> areas) {
            this.areas = areas;
        }

        public String getWarehouse_code() {
            return warehouse_code;
        }

        public void setWarehouse_code(String warehouse_code) {
            this.warehouse_code = warehouse_code;
        }

        public String getCountry() {
            return country;
        }

        public void setCountry(String country) {
            this.country = country;
        }

        @Override
        public int getViewType() {
            return PRODUCT_ITEM;
        }
    }

    public static class Area {

        @SerializedName("pincode")
        private int pincode;

        @SerializedName("id")
        private int id;

        @SerializedName("name")
        private String name;

        public int getPincode() {
            return pincode;
        }

        public void setPincode(int pincode) {
            this.pincode = pincode;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }
    }
}
