/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 21/8/15.
 */
public class ReorderReminderDetails {

    @SerializedName("reorder_reminder_unit")
    private String reorderReminderUnit;

    @SerializedName("reorder_reminder_duration")
    private int reorderReminderDuration;

    @SerializedName("reoder_reminder_date")
    private String reorderReminderDate;

    @SerializedName("reorderReminder")
    private boolean reorderReminder;

    public String getReorderReminderUnit() {
        return reorderReminderUnit;
    }

    public void setReorderReminderUnit(String reorderReminderUnit) {
        this.reorderReminderUnit = reorderReminderUnit;
    }

    public int getReorderReminderDuration() {
        return reorderReminderDuration;
    }

    public void setReorderReminderDuration(int reorderReminderDuration) {
        this.reorderReminderDuration = reorderReminderDuration;
    }

    public String getReorderReminderDate() {
        return reorderReminderDate;
    }

    public void setReorderReminderDate(String reorderReminderDate) {
        this.reorderReminderDate = reorderReminderDate;
    }

    public boolean getReorderReminder() {
        return reorderReminder;
    }

    public void setReorderReminder(boolean reorderReminder) {
        this.reorderReminder = reorderReminder;
    }
}
