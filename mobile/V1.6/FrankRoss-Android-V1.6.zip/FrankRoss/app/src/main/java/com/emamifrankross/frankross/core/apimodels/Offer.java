/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.annotations.SerializedName;

/**
 * Created by gauthami on 23/2/16.
 */
public class Offer {

    @SerializedName("id")
    private int id;

    @SerializedName("listable")
    private boolean listable;

    @SerializedName("promotion_id")
    private int promotion_id;

    @SerializedName("image_url")
    private String image_url;

    @SerializedName("html_link")
    private String html_link;

    @SerializedName("coupon_code")
    private String coupon_code;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isListable() {
        return listable;
    }

    public void setListable(boolean listable) {
        this.listable = listable;
    }

    public int getPromotion_id() {
        return promotion_id;
    }

    public void setPromotion_id(int promotion_id) {
        this.promotion_id = promotion_id;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getHtml_link() {
        return html_link;
    }

    public void setHtml_link(String html_link) {
        this.html_link = html_link;
    }

    public String getCoupon_code() {
        return coupon_code;
    }

    public void setCoupon_code(String coupon_code) {
        this.coupon_code = coupon_code;
    }
}
