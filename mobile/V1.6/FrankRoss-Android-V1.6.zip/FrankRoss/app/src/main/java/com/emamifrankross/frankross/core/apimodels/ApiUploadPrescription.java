/**
 * Copyright (c) 2015, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.core.apimodels;

import com.google.gson.Gson;
import com.google.gson.annotations.SerializedName;

/**
 * Created by gowtham on 6/8/15.
 */
public class ApiUploadPrescription {

    public static class PutRequest {
        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("prescription_upload")
        private PutRequestPrescription prescription = new PutRequestPrescription();

        public PutRequestPrescription getPrescription() {
            return prescription;
        }

        public void setPrescription(PutRequestPrescription prescription) {
            this.prescription = prescription;
        }
    }

    public static class PostRequest {

        public String toJsonString() {
            return new Gson().toJson(this);
        }

        @SerializedName("prescription_upload")
        private PostRequestPrescription prescription = new PostRequestPrescription();

        public PostRequestPrescription getPrescription() {
            return prescription;
        }

        public void setPrescription(PostRequestPrescription prescription) {
            this.prescription = prescription;
        }
    }

    public static class PostRequestPrescription {

        @SerializedName("image_upload")
        private String imageUploadBase64String = "";

        @SerializedName("prepare_cart")
        private boolean prepareCart;

        public String getImageUploadBase64String() {
            return imageUploadBase64String;
        }

        public void setImageUploadBase64String(String imageUploadBase64String) {
            this.imageUploadBase64String = imageUploadBase64String;
        }

        public boolean isPrepareCart() {
            return prepareCart;
        }

        public void setPrepareCart(boolean prepareCart) {
            this.prepareCart = prepareCart;
        }
    }

    public static class PutRequestPrescription {

        @SerializedName("image_upload")
        private String imageUploadBase64String = "";

        public String getImageUploadBase64String() {
            return imageUploadBase64String;
        }

        public void setImageUploadBase64String(String imageUploadBase64String) {
            this.imageUploadBase64String = imageUploadBase64String;
        }
    }

    public static class PostResponse {
        @SerializedName("prescription_upload")
        private ResponsePrescription prescription;

        public ResponsePrescription getPrescription() {
            return prescription;
        }

        public void setPrescription(ResponsePrescription prescription) {
            this.prescription = prescription;
        }
    }

    public static class PutResponse {

    }

    public static class ResponsePrescription {

        @SerializedName("id")
        private long imageUploadId;

        public long getImageUploadId() {
            return imageUploadId;
        }

        public void setImageUploadId(long imageUploadId) {
            this.imageUploadId = imageUploadId;
        }
    }
}
