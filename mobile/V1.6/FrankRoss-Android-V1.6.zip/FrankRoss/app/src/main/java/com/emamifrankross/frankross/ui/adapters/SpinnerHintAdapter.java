/**
 * Copyright (c) 2016, Emami FrankRoss Ltd
 * Written under contract by Robosoft Technologies Pvt. Ltd.
 */

package com.emamifrankross.frankross.ui.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.emamifrankross.frankross.R;
import com.emamifrankross.frankross.core.apimodels.ApiReturnReasons;
import com.emamifrankross.frankross.ui.customviews.RobotoTextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by gauthami on 9/8/16.
 * Adapter class for Spinner Hint in Return Products Section
 */
public class SpinnerHintAdapter extends ArrayAdapter<ApiReturnReasons> {

    private List<ApiReturnReasons> mSpinnerReturnReasonsData = new ArrayList<>(1);
    private LayoutInflater mLayoutInflater;

    public SpinnerHintAdapter(Context context, List<ApiReturnReasons> objects, int theLayoutResId) {
        super(context, theLayoutResId, objects);
        mSpinnerReturnReasonsData = objects;
        mLayoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return getCustomView(position, convertView, parent);
    }

    @Override
    public int getCount() {
        int count = super.getCount();
        return count > 0 ? count - 1 : count;
    }

    public View getCustomView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder = null;

        if (convertView == null) {
            convertView = mLayoutInflater.inflate(R.layout.return_products_custom_spinner_item, parent, false);
            holder = new ViewHolder();
            holder.mReturnReason = (RobotoTextView) convertView.findViewById(R.id.return_products_spinner_reason_tv);
            holder.mReturnReasonSelect = (ImageView) convertView.findViewById(R.id.return_products_spinner_reason_select_iv);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        holder.mReturnReason.setText(mSpinnerReturnReasonsData.get(position).getReturnReason());
        holder.mReturnReasonSelect.setVisibility((mSpinnerReturnReasonsData.get(position).isSelected() &&
                !holder.mReturnReason.getText().toString().equals(
                        getContext().getString(R.string.return_product_select_reason_hint))) ? View.VISIBLE : View.GONE);

        return convertView;
    }

    private static class ViewHolder {
        RobotoTextView mReturnReason;
        ImageView mReturnReasonSelect;
    }
}