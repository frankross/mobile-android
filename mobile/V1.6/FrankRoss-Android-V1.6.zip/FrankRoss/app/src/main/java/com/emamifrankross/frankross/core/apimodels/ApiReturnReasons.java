package com.emamifrankross.frankross.core.apimodels;

/**
 * Created by gauthami on 9/8/16.
 */
public class ApiReturnReasons {

    private String returnReason = "";

    private boolean isSelected = false;

    public String getReturnReason() {
        return returnReason;
    }

    public void setReturnReason(String returnReason) {
        this.returnReason = returnReason;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}
